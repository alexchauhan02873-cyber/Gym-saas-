import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { handleGymApi } from "./src/lib/gym-api.server";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "10mb" }));

  // API routes bridge to handleGymApi
  app.all("/api/*", async (req, res) => {
    try {
      const url = `${req.protocol}://${req.get("host") || "localhost:3000"}${req.originalUrl}`;
      const headers = new Headers();
      for (const [key, value] of Object.entries(req.headers)) {
        if (value) {
          if (Array.isArray(value)) {
            value.forEach((v) => headers.append(key, v));
          } else {
            headers.set(key, value);
          }
        }
      }

      const body = ["GET", "HEAD"].includes(req.method)
        ? undefined
        : JSON.stringify(req.body);

      const request = new Request(url, {
        method: req.method,
        headers,
        body,
      });

      const response = await handleGymApi(request);
      res.status(response.status);

      response.headers.forEach((value, key) => {
        res.setHeader(key, value);
      });

      const responseData = await response.text();
      res.send(responseData);
    } catch (err: any) {
      console.error("Express API bridge error:", err);
      res.status(500).json({ success: false, message: err?.message || "Internal server error" });
    }
  });

  // Vite middleware for SPA development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`GYM SaaS server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
