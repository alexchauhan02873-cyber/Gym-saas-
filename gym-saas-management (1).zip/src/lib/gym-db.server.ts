import fs from 'fs';
import path from 'path';

export const COLLECTIONS = [
  "gyms",
  "owners",
  "members",
  "membershipPlans",
  "attendance",
  "payments",
  "sessions",
  "memberSessions",
  "workouts",
  "diets",
  "tasks",
  "notifications",
  "pushSubscriptions",
  "vapidKeys",
  "xpTransactions",
  "memberBadges",
  "memberMonthlyMetrics",
  "memberLoginLinks",
  "gymPaymentSettings",
  "invoices",
  "ownerDailyTasks",
  "adminSessions",
  "saasSubscriptions",
  "auditLogs",
  "broadcasts",
  "broadcastRecipients",
  "aiRecommendations",
  "platformAdmins",
  "memberStatusHistory",
  "gymStatusHistory",
  "workoutTemplates",
  "dietTemplates",
  "broadcastProviders",
  "onboardingDrafts",
  "exerciseLibrary",
  "memberPreferences",
  "memberPrivacy",
  "memberAchievements",
  "gymScheduleDays",
  "gymScheduleSessions",
  "memberMonthlyPerformance",
  "gymClosures",
  "notices",
  "idempotencyRecords",
  "queueJobs",
  "dlqJobs",
  "users",
  "authSessions",
  "passwordResets",
  "memberActivityLogs",
] as const;

export type CollectionName = (typeof COLLECTIONS)[number];
export type GymDb = Record<CollectionName, any[]>;

const DB_FILE_PATH = path.join(process.cwd(), '.gym_db.json');

let memoryDb: GymDb | null = null;

function getInitialSeedData(): GymDb {
  const db = {} as GymDb;
  for (const name of COLLECTIONS) {
    db[name] = [];
  }

  // Seed Gym 1
  const demoGym = {
    id: "demo_gym_1",
    gymName: "Apex Fitness Club",
    ownerName: "Alex Chauhan",
    phone: "9263604732",
    gymCode: "A6N4K8",
    accessCode: "A6N4K8",
    status: "ACTIVE",
    saasPlan: "Pro",
    subscriptionStatus: "ACTIVE",
    location: "Kankarbagh, Patna",
    createdAt: new Date().toISOString(),
  };

  const demoOwner = {
    id: "demo_owner_1",
    gymId: "demo_gym_1",
    fullName: "Alex Chauhan",
    phone: "9263604732",
  };

  const demoPlan = {
    id: "plan_1",
    gymId: "demo_gym_1",
    planName: "Monthly Pro Gym Pass",
    price: 1500,
    durationDays: 30,
    duration: 30,
    durationUnit: "Days",
    status: "ACTIVE",
    createdAt: new Date().toISOString(),
  };

  const demoMember1 = {
    id: "mem_1",
    gymId: "demo_gym_1",
    memberDisplayId: "MEM-0001",
    memberAccessCode: "483921",
    fullName: "Rahul Kumar",
    phone: "9876543210",
    age: 24,
    gender: "Male",
    location: "Patna",
    planId: "plan_1",
    startDate: new Date().toISOString().split("T")[0],
    endDate: new Date(Date.now() + 25 * 86400000).toISOString().split("T")[0],
    status: "ACTIVE",
    lifetimeXp: 350,
    createdAt: new Date().toISOString(),
  };

  const demoMember2 = {
    id: "mem_2",
    gymId: "demo_gym_1",
    memberDisplayId: "MEM-0002",
    memberAccessCode: "P4K8W2",
    fullName: "Priya Sharma",
    phone: "9876543211",
    age: 22,
    gender: "Female",
    location: "Patna",
    planId: "plan_1",
    startDate: new Date().toISOString().split("T")[0],
    endDate: new Date(Date.now() + 20 * 86400000).toISOString().split("T")[0],
    status: "ACTIVE",
    lifetimeXp: 180,
    createdAt: new Date().toISOString(),
  };

  db.gyms.push(demoGym);
  db.owners.push(demoOwner);
  db.membershipPlans.push(demoPlan);
  db.members.push(demoMember1, demoMember2);

  db.gymPaymentSettings.push({
    id: "gps_1",
    gymId: "demo_gym_1",
    upiId: "apexfitness@upi",
    upiDisplayName: "Apex Fitness Club",
    paymentInstructions: "Please send transaction screenshot on WhatsApp after paying.",
    isEnabled: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  });

  return db;
}

export async function loadDb(): Promise<GymDb> {
  if (memoryDb) return memoryDb;

  try {
    if (fs.existsSync(DB_FILE_PATH)) {
      const raw = fs.readFileSync(DB_FILE_PATH, 'utf-8');
      const parsed = JSON.parse(raw);
      memoryDb = {} as GymDb;
      for (const name of COLLECTIONS) {
        memoryDb[name] = Array.isArray(parsed[name]) ? parsed[name] : [];
      }
      return memoryDb;
    }
  } catch (e) {
    console.error("Error reading database file, using seed data:", e);
  }

  memoryDb = getInitialSeedData();
  await saveDb(memoryDb);
  return memoryDb;
}

export async function saveCollections(db: GymDb, _names?: CollectionName[]): Promise<void> {
  memoryDb = db;
  try {
    fs.writeFileSync(DB_FILE_PATH, JSON.stringify(db, null, 2), 'utf-8');
  } catch (e) {
    console.error("Error writing database file:", e);
  }
}

export async function saveDb(db: GymDb): Promise<void> {
  await saveCollections(db, [...COLLECTIONS]);
}

export function nextId(prefix: string): string {
  return `${prefix}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
}
