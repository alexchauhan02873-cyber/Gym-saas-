export type Language = 
  | 'en' // English
  | 'hi' // Hindi
  | 'bn' // Bengali
  | 'te' // Telugu
  | 'mr' // Marathi
  | 'ta' // Tamil
  | 'gu' // Gujarati
  | 'kn' // Kannada
  | 'ml' // Malayalam
  | 'or'; // Odia

export interface LanguageOption {
  code: Language;
  name: string; // Native name
  englishName: string;
}

export const LANGUAGES: LanguageOption[] = [
  { code: 'hi', name: 'हिन्दी', englishName: 'Hindi' },
  { code: 'en', name: 'English', englishName: 'English' },
  { code: 'bn', name: 'বাংলা', englishName: 'Bengali' },
  { code: 'te', name: 'తెలుగు', englishName: 'Telugu' },
  { code: 'mr', name: 'मराठी', englishName: 'Marathi' },
  { code: 'ta', name: 'தமிழ்', englishName: 'Tamil' },
  { code: 'gu', name: 'ગુજરાતી', englishName: 'Gujarati' },
  { code: 'kn', name: 'ಕನ್ನಡ', englishName: 'Kannada' },
  { code: 'ml', name: 'മലയാളം', englishName: 'Malayalam' },
  { code: 'or', name: 'ଓଡ଼ିଆ', englishName: 'Odia' }
];

export function getStoredLanguage(): Language {
  if (typeof window === 'undefined') return 'en';
  const saved = localStorage.getItem('app_language') as Language;
  if (saved && LANGUAGES.some(l => l.code === saved)) {
    return saved;
  }
  return 'en';
}

export function setStoredLanguage(lang: Language) {
  if (typeof window !== 'undefined') {
    localStorage.setItem('app_language', lang);
  }
}

// Translations Dictionary
const translations: Record<Language, Record<string, string>> = {
  en: {
    // General
    'common.continue': 'Continue',
    'common.back': 'Back',
    'common.skip': 'Skip for now',
    'common.save': 'Save & Continue',
    'common.finish': 'Finish Setup',
    'common.done': 'Done',
    'common.copy': 'Copy Code',
    'common.copied': 'Copied!',
    'common.whatsapp': 'Share on WhatsApp',
    'common.share': 'Share',
    'common.required': 'Field is required',
    'common.language': 'Select Language',
    
    // Code Entry
    'code.title': 'Enter your Access Code',
    'code.subtitle': 'Enter the 6-character code provided by your gym or owner',
    'code.verify': 'VERIFY CODE',
    'code.verifying': 'VERIFYING...',
    'code.invalid': 'Invalid code. Please check and try again.',
    'code.member_code_label': 'Member Access Code',

    // Owner Onboarding
    'owner.onboarding.title': 'Gym Owner Onboarding',
    'owner.step1.title': 'Owner Details',
    'owner.step1.subtitle': 'Tell us about yourself',
    'owner.step1.name': 'Full Name',
    'owner.step1.phone': 'Phone Number',
    'owner.step1.photo': 'Profile Photo (Optional)',
    
    'owner.step2.title': 'Gym Details',
    'owner.step2.subtitle': 'Setup your gym profile',
    'owner.step2.gym_name': 'Gym Name',
    'owner.step2.gym_phone': 'Gym Helpline Phone',
    'owner.step2.address': 'Gym Address',
    'owner.step2.city': 'City',
    'owner.step2.gym_type': 'Gym Type',
    'owner.step2.open_time': 'Opening Time',
    'owner.step2.close_time': 'Closing Time',
    'owner.step2.weekly_off': 'Weekly Off',
    
    'owner.step3.title': 'Payment Setup',
    'owner.step3.subtitle': 'How should members pay you?',
    'owner.step3.upi_id': 'UPI ID (e.g. name@upi)',
    'owner.step3.upi_name': 'UPI Display Name',
    
    'owner.step4.title': 'Membership Plans',
    'owner.step4.subtitle': 'Create your gym plans',
    'owner.step4.plan_name': 'Plan Name (e.g. Monthly Pro)',
    'owner.step4.price': 'Price (₹)',
    'owner.step4.duration': 'Duration',
    'owner.step4.add_plan': 'Add Another Plan',

    'owner.step5.title': 'Add First Member',
    'owner.step5.subtitle': 'Optionally add a founding gym member',
    'owner.step5.member_name': 'Member Name',
    'owner.step5.member_phone': 'Member Phone',
    'owner.step5.member_created': 'MEMBER CREATED ✓',
    'owner.step5.access_code_info': 'Permanent 6-Digit Member Access Code:',

    'owner.step6.title': 'Review & Finish',
    'owner.step6.subtitle': 'Double check your workspace setup',

    // Member Onboarding
    'member.onboarding.title': 'Member Onboarding',
    'member.step1.welcome': 'Welcome to {{gym_name}}! 👋',
    'member.step1.subtitle': 'Let us finish your profile to personalize your workout & diet experience.',
    'member.step1.get_started': 'Get Started',

    'member.step2.title': 'Personal Information',
    'member.step2.subtitle': 'Basic personal details',
    'member.step2.gender': 'Gender',
    'member.step2.location': 'City / Location',

    'member.step3.title': 'Fitness Preferences',
    'member.step3.subtitle': 'Help AI personalize your workout & diet plans',
    'member.step3.goal': 'Primary Fitness Goal',
    'member.step3.exp': 'Experience Level',
    'member.step3.freq': 'Workout Frequency per Week',
    'member.step3.equip': 'Equipment Access',
    'member.step3.food': 'Food Preference',
    'member.step3.diet_restrict': 'Dietary Restrictions / Allergies (Optional)',

    'member.step4.title': 'App & Notification Setup',
    'member.step4.subtitle': 'Stay updated with workouts and attendance',
    'member.step4.enable_notif': 'Enable Notifications',
    'member.step4.install_pwa': 'Install App on Phone',

    'member.step5.title': "You're All Set! 🎉",
    'member.step5.subtitle': 'Your personalized fitness dashboard is ready.',
    'member.step5.open_dashboard': 'Open My Dashboard',
  },

  hi: {
    'common.continue': 'आगे बढ़ें',
    'common.back': 'पीछे',
    'common.skip': 'अभी छोड़ें',
    'common.save': 'सहेजें और आगे बढ़ें',
    'common.finish': 'सेटअप पूरा करें',
    'common.done': 'संपन्न',
    'common.copy': 'कोड कॉपी करें',
    'common.copied': 'कॉपी हो गया!',
    'common.whatsapp': 'व्हाट्सएप पर शेयर करें',
    'common.share': 'शेयर करें',
    'common.required': 'यह विवरण आवश्यक है',
    'common.language': 'भाषा चुनें',

    'code.title': 'अपना एक्सेस कोड दर्ज करें',
    'code.subtitle': 'जिम या ऑनर द्वारा प्रदान किया गया 6-अंकों का कोड दर्ज करें',
    'code.verify': 'कोड सत्यापित करें',
    'code.verifying': 'सत्यापित हो रहा है...',
    'code.invalid': 'अमान्य कोड। कृपया जाँचें और पुनः प्रयास करें।',
    'code.member_code_label': 'सदस्य एक्सेस कोड',

    'owner.onboarding.title': 'जिम ऑनर ऑनबोर्डिंग',
    'owner.step1.title': 'मालिक का विवरण',
    'owner.step1.subtitle': 'अपने बारे में बताएं',
    'owner.step1.name': 'पूरा नाम',
    'owner.step1.phone': 'फ़ोन नंबर',
    'owner.step1.photo': 'प्रोफ़ाइल फ़ोटो (वैकल्पिक)',

    'owner.step2.title': 'जिम का विवरण',
    'owner.step2.subtitle': 'अपने जिम की जानकारी दर्ज करें',
    'owner.step2.gym_name': 'जिम का नाम',
    'owner.step2.gym_phone': 'जिम हेल्पलाइन फ़ोन',
    'owner.step2.address': 'जिम का पता',
    'owner.step2.city': 'शहर',
    'owner.step2.gym_type': 'जिम का प्रकार',
    'owner.step2.open_time': 'खुलने का समय',
    'owner.step2.close_time': 'बंद होने का समय',
    'owner.step2.weekly_off': 'साप्ताहिक छुट्टी',

    'owner.step3.title': 'भुगतान सेटअप',
    'owner.step3.subtitle': 'सदस्य आपको भुगतान कैसे करें?',
    'owner.step3.upi_id': 'UPI ID (जैसे name@upi)',
    'owner.step3.upi_name': 'UPI नाम',

    'owner.step4.title': 'सदस्यता प्लान',
    'owner.step4.subtitle': 'अपने जिम प्लान बनाएं',
    'owner.step4.plan_name': 'प्लान का नाम',
    'owner.step4.price': 'मूल्य (₹)',
    'owner.step4.duration': 'अवधि',
    'owner.step4.add_plan': 'एक और प्लान जोड़ें',

    'owner.step5.title': 'पहला सदस्य जोड़ें',
    'owner.step5.subtitle': 'पहला सदस्य जोड़ें (वैकल्पिक)',
    'owner.step5.member_name': 'सदस्य का नाम',
    'owner.step5.member_phone': 'सदस्य का फ़ोन',
    'owner.step5.member_created': 'सदस्य जोड़ा गया ✓',
    'owner.step5.access_code_info': 'स्थायी 6-अंकीय सदस्य एक्सेस कोड:',

    'owner.step6.title': 'समीक्षा और समाप्त करें',
    'owner.step6.subtitle': 'अपने जिम सेटअप की समीक्षा करें',

    'member.onboarding.title': 'सदस्य ऑनबोर्डिंग',
    'member.step1.welcome': '{{gym_name}} में आपका स्वागत है! 👋',
    'member.step1.subtitle': 'अपने कसरत और आहार अनुभव को अनुकूलित करने के लिए प्रोफ़ाइल पूरी करें।',
    'member.step1.get_started': 'शुरू करें',

    'member.step2.title': 'व्यक्तिगत जानकारी',
    'member.step2.subtitle': 'बुनियादी जानकारी',
    'member.step2.gender': 'लिंग',
    'member.step2.location': 'शहर / स्थान',

    'member.step3.title': 'फिटनेस प्राथमिकताएं',
    'member.step3.subtitle': 'आहार और कसरत योजना अनुकूलित करने के लिए',
    'member.step3.goal': 'मुख्य फिटनेस लक्ष्य',
    'member.step3.exp': 'अनुभव स्तर',
    'member.step3.freq': 'साप्ताहिक कसरत आवृत्ति',
    'member.step3.equip': 'उपकरण उपलब्धता',
    'member.step3.food': 'आहार पसंद',
    'member.step3.diet_restrict': 'एलर्जी/प्रतिबंध (वैकल्पिक)',

    'member.step4.title': 'ऐप और सूचनाएं',
    'member.step4.subtitle': 'कसरत और उपस्थिति अपडेट प्राप्त करें',
    'member.step4.enable_notif': 'सूचनाएं चालू करें',
    'member.step4.install_pwa': 'फोन में ऐप इंस्टॉल करें',

    'member.step5.title': 'सब तैयार है! 🎉',
    'member.step5.subtitle': 'आपका फिटनेस डैशबोर्ड तैयार है।',
    'member.step5.open_dashboard': 'डैशबोर्ड खोलें',
  },

  bn: {
    'common.continue': 'এগিয়ে যান',
    'common.back': 'ফিরে যান',
    'common.skip': 'এখন এড়িয়ে যান',
    'common.save': 'সংরক্ষণ ও এগিয়ে যান',
    'common.finish': 'সেটআপ সম্পন্ন করুন',
    'common.done': 'সম্পন্ন',
    'common.copy': 'কোড কপি করুন',
    'common.copied': 'কপি হয়েছে!',
    'common.whatsapp': 'হোয়াটসঅ্যাপে শেয়ার করুন',
    'common.share': 'শেয়ার করুন',
    'common.required': 'ক্ষেত্রটি প্রয়োজনীয়',
    'common.language': 'ভাষা নির্বাচন করুন',

    'code.title': 'আপনার অ্যাক্সেস কোড লিখুন',
    'code.subtitle': 'জিম বা মালিক দ্বারা প্রদত্ত ৬-সংখ্যার কোডটি লিখুন',
    'code.verify': 'কোড যাচাই করুন',
    'code.verifying': 'যাচাই করা হচ্ছে...',
    'code.invalid': 'অকার্যকর কোড। অনুগ্রহ করে যাচাই করে আবার চেষ্টা করুন।',
    'code.member_code_label': 'মেম্বার অ্যাক্সেস কোড',

    'owner.onboarding.title': 'জিম ওনার অনবোর্ডিং',
    'owner.step1.title': 'মালিকের বিবরণ',
    'owner.step1.subtitle': 'আপনার সম্পর্কে বলুন',
    'owner.step1.name': 'সম্পূর্ণ নাম',
    'owner.step1.phone': 'ফোন নম্বর',
    'owner.step1.photo': 'প্রোফাইল ছবি (ঐচ্ছিক)',

    'owner.step2.title': 'জিমের বিবরণ',
    'owner.step2.subtitle': 'জিম প্রোফাইল সেটআপ করুন',
    'owner.step2.gym_name': 'জিমের নাম',
    'owner.step2.gym_phone': 'জিম ফোন',
    'owner.step2.address': 'ঠিকানা',
    'owner.step2.city': 'শহর',
    'owner.step2.gym_type': 'জিমের ধরন',
    'owner.step2.open_time': 'খোলার সময়',
    'owner.step2.close_time': 'বন্ধের সময়',
    'owner.step2.weekly_off': 'সাপ্তাহিক ছুটি',

    'owner.step3.title': 'পেমেন্ট সেটআপ',
    'owner.step3.subtitle': 'সদস্যরা কীভাবে পেমেন্ট করবেন?',
    'owner.step3.upi_id': 'UPI আইডি',
    'owner.step3.upi_name': 'UPI নাম',

    'owner.step4.title': 'মেম্বারশিপ প্ল্যান',
    'owner.step4.subtitle': 'প্ল্যান তৈরি করুন',
    'owner.step4.plan_name': 'প্ল্যানের নাম',
    'owner.step4.price': 'মূল্য (₹)',
    'owner.step4.duration': 'মেয়াদ',
    'owner.step4.add_plan': 'আরেকটি প্ল্যান যোগ করুন',

    'owner.step5.title': 'প্রথম সদস্য যোগ করুন',
    'owner.step5.subtitle': 'প্রথম সদস্য যোগ করুন (ঐচ্ছিক)',
    'owner.step5.member_name': 'সদস্যের নাম',
    'owner.step5.member_phone': 'সদস্যের ফোন',
    'owner.step5.member_created': 'সদস্য তৈরি হয়েছে ✓',
    'owner.step5.access_code_info': 'স্থায়ী ৬-সংখ্যার সদস্য অ্যাক্সেস কোড:',

    'owner.step6.title': 'পুনরীক্ষণ ও সম্পন্ন',
    'owner.step6.subtitle': 'আপনার ওয়ার্কস্পেস সেটআপ পরীক্ষা করুন',

    'member.onboarding.title': 'সদস্য অনবোর্ডিং',
    'member.step1.welcome': '{{gym_name}}-এ স্বাগতম! 👋',
    'member.step1.subtitle': 'আপনার প্রোফাইল সম্পন্ন করুন।',
    'member.step1.get_started': 'শুরু করুন',

    'member.step2.title': 'ব্যক্তিগত তথ্য',
    'member.step2.subtitle': 'মৌলিক বিবরণ',
    'member.step2.gender': 'লিঙ্গ',
    'member.step2.location': 'শহর',

    'member.step3.title': 'ফিটনেস পছন্দ',
    'member.step3.subtitle': 'ওয়ার্কআউট ও ডায়েট প্ল্যান কাস্টমাইজ করতে',
    'member.step3.goal': 'প্রধান লক্ষ্য',
    'member.step3.exp': 'অভিজ্ঞতার স্তর',
    'member.step3.freq': 'সাপ্তাহিক ওয়ার্কআউট',
    'member.step3.equip': 'সরঞ্জাম উপলব্ধতা',
    'member.step3.food': 'খাবারের পছন্দ',
    'member.step3.diet_restrict': 'অ্যালার্জি/সীমাবদ্ধতা',

    'member.step4.title': 'অ্যাপ ও নোটিফিকেশন',
    'member.step4.subtitle': 'আপডেট পান',
    'member.step4.enable_notif': 'নোটিফিকেশন চালু করুন',
    'member.step4.install_pwa': 'অ্যাপ ইনস্টল করুন',

    'member.step5.title': 'সব প্রস্তুত! 🎉',
    'member.step5.subtitle': 'আপনার ফিটনেস ড্যাশবোর্ড তৈরি।',
    'member.step5.open_dashboard': 'ড্যাশবোর্ড খুলুন',
  },

  te: {
    'common.continue': 'కొనసాగించండి',
    'common.back': 'వెనుకకు',
    'common.skip': 'ఇప్పుడు దాటవేయి',
    'common.save': 'సేవ్ చేసి ముందుకు సాగండి',
    'common.finish': 'సెటప్ పూర్తి చేయండి',
    'common.done': 'పూర్తయింది',
    'common.copy': 'కోడ్ కాపీ చేయండి',
    'common.copied': 'కాపీ చేయబడింది!',
    'common.whatsapp': 'వాట్సాప్‌లో షేర్ చేయండి',
    'common.share': 'షేర్ చేయండి',
    'common.required': 'ఈ వివరాలు అవసరం',
    'common.language': 'భాషను ఎంచుకోండి',

    'code.title': 'మీ ఆక్సెస్ కోడ్‌ను నమోదు చేయండి',
    'code.subtitle': 'మీ జిమ్ లేదా యజమాని అందించిన 6-అంకెల కోడ్‌ను ఎంటర్ చేయండి',
    'code.verify': 'కోడ్‌ను సరిచూడండి',
    'code.verifying': 'పరిశీలిస్తోంది...',
    'code.invalid': 'చెల్లని కోడ్. దయచేసి మళ్లీ ప్రయత్నించండి.',
    'code.member_code_label': 'సభ్యత్వ ఆక్సెస్ కోడ్',

    'owner.onboarding.title': 'జిమ్ ఓనర్ ఆన్‌బోర్డింగ్',
    'owner.step1.title': 'యజమాని వివరాలు',
    'owner.step1.subtitle': 'మీ గురించి చెప్పండి',
    'owner.step1.name': 'పూర్తి పేరు',
    'owner.step1.phone': 'ఫోన్ నంబర్',
    'owner.step1.photo': 'ప్రొఫైల్ ఫోటో (ఐచ్ఛికం)',

    'owner.step2.title': 'జిమ్ వివరాలు',
    'owner.step2.subtitle': 'జిమ్ సమాచారం నమోదు చేయండి',
    'owner.step2.gym_name': 'జిమ్ పేరు',
    'owner.step2.gym_phone': 'జిమ్ హెల్ప్‌లైన్ ఫోన్',
    'owner.step2.address': 'చిరునామా',
    'owner.step2.city': 'నగరం',
    'owner.step2.gym_type': 'జిమ్ రకం',
    'owner.step2.open_time': 'ప్రారంభ సమయం',
    'owner.step2.close_time': 'ముగింపు సమయం',
    'owner.step2.weekly_off': 'వారాంతపు సెలవు',

    'owner.step3.title': 'చెల్లింపుల సెటప్',
    'owner.step3.subtitle': 'సభ్యులు మీకు ఎలా చెల్లించాలి?',
    'owner.step3.upi_id': 'UPI ఐడి',
    'owner.step3.upi_name': 'UPI పేరు',

    'owner.step4.title': 'సభ్యత్వ ప్లాన్లు',
    'owner.step4.subtitle': 'మీ జిమ్ ప్లాన్‌లను సృష్టించండి',
    'owner.step4.plan_name': 'ప్లాన్ పేరు',
    'owner.step4.price': 'ధర (₹)',
    'owner.step4.duration': 'వ్యవధి',
    'owner.step4.add_plan': 'మరొక ప్లాన్ జోడించండి',

    'owner.step5.title': 'మొదటి సభ్యుడిని జోడించండి',
    'owner.step5.subtitle': 'మొదటి సభ్యుడిని జోడించండి (ఐచ్ఛికం)',
    'owner.step5.member_name': 'సభ్యుని పేరు',
    'owner.step5.member_phone': 'సభ్యుని ఫోన్',
    'owner.step5.member_created': 'సభ్యుడు చేర్చబడ్డాడు ✓',
    'owner.step5.access_code_info': 'శాశ్వత 6-అంకెల సభ్యత్వ ఆక్సెస్ కోడ్:',

    'owner.step6.title': 'సమీక్షించండి & పూర్తి చేయండి',
    'owner.step6.subtitle': 'సెటప్‌ను సరిచూసుకోండి',

    'member.onboarding.title': 'సభ్యత్వ ఆన్‌బోర్డింగ్',
    'member.step1.welcome': '{{gym_name}} కు స్వాగతం! 👋',
    'member.step1.subtitle': 'మీ ప్రొఫైల్‌ను పూర్తి చేయండి.',
    'member.step1.get_started': 'ప్రారంభించండి',

    'member.step2.title': 'వ్యక్తిగత సమాచారం',
    'member.step2.subtitle': 'ప్రాథమిక వివరాలు',
    'member.step2.gender': 'లింగం',
    'member.step2.location': 'నగరం',

    'member.step3.title': 'ఫిట్‌నెస్ ప్రాధాన్యతలు',
    'member.step3.subtitle': 'మీ ప్లాన్‌ను రూపొందించడానికి',
    'member.step3.goal': 'ప్రధాన లక్ష్యం',
    'member.step3.exp': 'అనుభవ స్థాయి',
    'member.step3.freq': 'వారానికి వర్కౌట్ రోజులు',
    'member.step3.equip': 'పరికరాల లభ్యత',
    'member.step3.food': 'ఆహార ప్రాధాన్యత',
    'member.step3.diet_restrict': 'అలెర్జీలు / పరిమితులు',

    'member.step4.title': 'యాప్ సెట్టింగ్‌లు',
    'member.step4.subtitle': 'నోటిఫికేషన్‌లను పొందేందుకు',
    'member.step4.enable_notif': 'నోటిఫికేషన్లు ప్రారంభించండి',
    'member.step4.install_pwa': 'యాప్‌ను ఇన్‌స్టాల్ చేయండి',

    'member.step5.title': 'అంతా సిద్ధమైంది! 🎉',
    'member.step5.subtitle': 'మీ డ్యాష్‌బోర్డ్ సిద్ధంగా ఉంది.',
    'member.step5.open_dashboard': 'డ్యాష్‌బోర్డ్ తెరవండి',
  },

  mr: {
    'common.continue': 'पुढे चला',
    'common.back': 'मागे',
    'common.skip': 'सध्या वगळा',
    'common.save': 'जतन करा आणि पुढे जा',
    'common.finish': 'सेटअप पूर्ण करा',
    'common.done': 'पूर्ण झाले',
    'common.copy': 'कोड कॉपी करा',
    'common.copied': 'कॉपी केले!',
    'common.whatsapp': 'व्हॉट्सॲपवर शेअर करा',
    'common.share': 'शेअर करा',
    'common.required': 'माहिती आवश्यक आहे',
    'common.language': 'भाषा निवडा',

    'code.title': 'तुमचा ॲक्सेस कोड टाका',
    'code.subtitle': 'जिम किंवा मालकाने दिलेला ६-अंकी कोड टाका',
    'code.verify': 'कोड सत्यापित करा',
    'code.verifying': 'तपासत आहे...',
    'code.invalid': 'अवैध कोड. कृपया तपासून पुन्हा प्रयत्न करा.',
    'code.member_code_label': 'सदस्य ॲक्सेस कोड',

    'owner.onboarding.title': 'जिम मालक ऑनबोर्डिंग',
    'owner.step1.title': 'मालकाचा तपशील',
    'owner.step1.subtitle': 'तुमच्याबद्दल सांगा',
    'owner.step1.name': 'पूर्ण नाव',
    'owner.step1.phone': 'फोन नंबर',
    'owner.step1.photo': 'प्रोफाइल फोटो (ऐच्छिक)',

    'owner.step2.title': 'जिमचा तपशील',
    'owner.step2.subtitle': 'जिमची माहिती भरा',
    'owner.step2.gym_name': 'जिमचे नाव',
    'owner.step2.gym_phone': 'जिम हेल्पलाइन नंबर',
    'owner.step2.address': 'पत्ता',
    'owner.step2.city': 'शहर',
    'owner.step2.gym_type': 'जिमचा प्रकार',
    'owner.step2.open_time': 'उघडण्याची वेळ',
    'owner.step2.close_time': 'बंद होण्याची वेळ',
    'owner.step2.weekly_off': 'साप्ताहिक सुट्टी',

    'owner.step3.title': 'पेमेंट सेटअप',
    'owner.step3.subtitle': 'सदस्यांनी तुम्हाला पैसे कसे द्यावेत?',
    'owner.step3.upi_id': 'UPI आयडी',
    'owner.step3.upi_name': 'UPI नाव',

    'owner.step4.title': 'सदस्यत्व प्लॅन',
    'owner.step4.subtitle': 'तुमचे प्लॅन तयार करा',
    'owner.step4.plan_name': 'प्लॅनचे नाव',
    'owner.step4.price': 'किंमत (₹)',
    'owner.step4.duration': 'कालावधी',
    'owner.step4.add_plan': 'आणखी प्लॅन जोडा',

    'owner.step5.title': 'पहिला सदस्य जोडा',
    'owner.step5.subtitle': 'पहिला सदस्य जोडा (ऐच्छिक)',
    'owner.step5.member_name': 'सदस्याचे नाव',
    'owner.step5.member_phone': 'सदस्याचा फोन',
    'owner.step5.member_created': 'सदस्य जोडला गेला ✓',
    'owner.step5.access_code_info': 'कायमस्वरूपी ६-अंकी सदस्य ॲक्सेस कोड:',

    'owner.step6.title': 'पुनरावलोकन आणि पूर्ण करा',
    'owner.step6.subtitle': 'सेटअपची खात्री करा',

    'member.onboarding.title': 'सदस्य ऑनबोर्डिंग',
    'member.step1.welcome': '{{gym_name}} मध्ये आपले स्वागत आहे! 👋',
    'member.step1.subtitle': 'तुमची प्रोफाइल पूर्ण करा.',
    'member.step1.get_started': 'सुरू करा',

    'member.step2.title': 'वैयक्तिक माहिती',
    'member.step2.subtitle': 'मूलभूत माहिती',
    'member.step2.gender': 'लिंग',
    'member.step2.location': 'शहर',

    'member.step3.title': 'फिटनेस प्राधान्ये',
    'member.step3.subtitle': 'वर्कआउट प्लॅन तयार करण्यासाठी',
    'member.step3.goal': 'मुख्य ध्येय',
    'member.step3.exp': 'अनुभव पातळी',
    'member.step3.freq': 'आठवड्यातून वर्कआउट दिवस',
    'member.step3.equip': 'साहित्य उपलब्धता',
    'member.step3.food': 'आहार आवड',
    'member.step3.diet_restrict': 'ॲलर्जी / निर्बंध',

    'member.step4.title': 'ॲप आणि सूचना',
    'member.step4.subtitle': 'अपडेट मिळवण्यासाठी',
    'member.step4.enable_notif': 'सूचना सुरू करा',
    'member.step4.install_pwa': 'ॲप इंस्टॉल करा',

    'member.step5.title': 'सर्व तयार आहे! 🎉',
    'member.step5.subtitle': 'तुमचा डॅशबोर्ड तयार आहे.',
    'member.step5.open_dashboard': 'डॅशबोर्ड उघडा',
  },

  ta: {
    'common.continue': 'தொடரவும்',
    'common.back': 'பின்செல்லவும்',
    'common.skip': 'தவிர்க்கவும்',
    'common.save': 'சேமித்துத் தொடரவும்',
    'common.finish': 'அமைப்பை முடிக்கவும்',
    'common.done': 'முடிந்தது',
    'common.copy': 'கோப்பை நகலெடு',
    'common.copied': 'நகலெடுக்கப்பட்டது!',
    'common.whatsapp': 'வாட்ஸ்அப்பில் பகிரவும்',
    'common.share': 'பகிரவும்',
    'common.required': 'இப்புலம் தேவையானது',
    'common.language': 'மொழியைத் தேர்ந்தெடுக்கவும்',

    'code.title': 'உங்கள் அணுகல் குறியீட்டை உள்ளிடவும்',
    'code.subtitle': 'உங்கள் ஜிம் அல்லது உரிமையாளர் வழங்கிய 6 இலக்க குறியீட்டை உள்ளிடவும்',
    'code.verify': 'சரிபார்க்கவும்',
    'code.verifying': 'சரிபார்க்கிறது...',
    'code.invalid': 'தவறான குறியீடு. மீண்டும் முயற்சிக்கவும்.',
    'code.member_code_label': 'உறுப்பினர் அணுகல் குறியீடு',

    'owner.onboarding.title': 'ஜிம் உரிமையாளர் சேர்க்கை',
    'owner.step1.title': 'உரிமையாளர் விவரங்கள்',
    'owner.step1.subtitle': 'உங்களைப் பற்றி சொல்லுங்கள்',
    'owner.step1.name': 'முழு பெயர்',
    'owner.step1.phone': 'தொலைபேசி எண்',
    'owner.step1.photo': 'சுயவிவரப் படம் (விருப்பத்தேர்வு)',

    'owner.step2.title': 'ஜிம் விவரங்கள்',
    'owner.step2.subtitle': 'ஜிம் தகவலை உள்ளிடவும்',
    'owner.step2.gym_name': 'ஜிம் பெயர்',
    'owner.step2.gym_phone': 'ஜிம் உதவி எண்',
    'owner.step2.address': 'முகவரி',
    'owner.step2.city': 'நகரம்',
    'owner.step2.gym_type': 'ஜிம் வகை',
    'owner.step2.open_time': 'திறக்கும் நேரம்',
    'owner.step2.close_time': 'மூடும் நேரம்',
    'owner.step2.weekly_off': 'வார விடுமுறை',

    'owner.step3.title': 'கட்டண அமைப்பு',
    'owner.step3.subtitle': 'உறுப்பினர்கள் எவ்வாறு செலுத்த வேண்டும்?',
    'owner.step3.upi_id': 'UPI ஐடி',
    'owner.step3.upi_name': 'UPI பெயர்',

    'owner.step4.title': 'உறுப்பினர் திட்டங்கள்',
    'owner.step4.subtitle': 'திட்டங்களை உருவாக்கவும்',
    'owner.step4.plan_name': 'திட்டத்தின் பெயர்',
    'owner.step4.price': 'விலை (₹)',
    'owner.step4.duration': 'கால அளவு',
    'owner.step4.add_plan': 'மற்றொரு திட்டத்தைச் சேர்க்கவும்',

    'owner.step5.title': 'முதல் உறுப்பினரைச் சேர்க்கவும்',
    'owner.step5.subtitle': 'முதல் உறுப்பினரைச் சேர்க்கவும் (விருப்பத்தேர்வு)',
    'owner.step5.member_name': 'உறுப்பினர் பெயர்',
    'owner.step5.member_phone': 'உறுப்பினர் போன்',
    'owner.step5.member_created': 'உறுப்பினர் சேர்க்கப்பட்டார் ✓',
    'owner.step5.access_code_info': 'நிரந்தர 6 இலக்க உறுப்பினர் அணுகல் குறியீடு:',

    'owner.step6.title': 'சரிபார்த்து முடிக்கவும்',
    'owner.step6.subtitle': 'அமைப்பை சரிபார்க்கவும்',

    'member.onboarding.title': 'உறுப்பினர் சேர்க்கை',
    'member.step1.welcome': '{{gym_name}}-க்கு வரவேற்கிறோம்! 👋',
    'member.step1.subtitle': 'உங்கள் விவரங்களை பூர்த்தி செய்யவும்.',
    'member.step1.get_started': 'தொடங்கவும்',

    'member.step2.title': 'தனிப்பட்ட தகவல்',
    'member.step2.subtitle': 'அடிப்படை விவரங்கள்',
    'member.step2.gender': 'பாலினம்',
    'member.step2.location': 'நகரம்',

    'member.step3.title': 'உடற்பயிற்சி விருப்பங்கள்',
    'member.step3.subtitle': 'திட்டத்தை வடிவமைக்க',
    'member.step3.goal': 'முக்கிய இலக்கு',
    'member.step3.exp': 'அனுபவ நிலை',
    'member.step3.freq': 'வாராந்திர உடற்பயிற்சி',
    'member.step3.equip': 'கருவிகள் இருப்பு',
    'member.step3.food': 'உணவு விருப்பம்',
    'member.step3.diet_restrict': 'ஒவ்வாமை / கட்டுப்பாடுகள்',

    'member.step4.title': 'செயலி அமைப்புகள்',
    'member.step4.subtitle': 'அறிவிப்புகளைப் பெற',
    'member.step4.enable_notif': 'அறிவிப்புகளை இயக்கு',
    'member.step4.install_pwa': 'செயலியை நிறுவுங்கள்',

    'member.step5.title': 'எல்லாம் தயார்! 🎉',
    'member.step5.subtitle': 'உங்கள் டேஷ்போர்டு தயார்.',
    'member.step5.open_dashboard': 'டேஷ்போர்டைத் திறக்கவும்',
  },

  gu: {
    'common.continue': 'આગળ વધો',
    'common.back': 'પાછા જાવ',
    'common.skip': 'હમણાં છોડો',
    'common.save': 'સાચવો અને આગળ વધો',
    'common.finish': 'સેટઅપ પૂર્ણ કરો',
    'common.done': 'પૂર્ણ',
    'common.copy': 'કોડ કોપી કરો',
    'common.copied': 'કોપી થયું!',
    'common.whatsapp': 'વોટ્સએપ પર શેર કરો',
    'common.share': 'શેર કરો',
    'common.required': 'આ માહિતી જરૂરી છે',
    'common.language': 'ભાષા પસંદ કરો',

    'code.title': 'તમારો એક્સેસ કોડ દાખલ કરો',
    'code.subtitle': 'જીમ અથવા ઓનર દ્વારા આપેલો 6-અંકનો કોડ દાખલ કરો',
    'code.verify': 'કોડ ચકાસો',
    'code.verifying': 'ચકાસી રહ્યું છે...',
    'code.invalid': 'અમાન્ય કોડ. કૃપા કરીને ફરી પ્રયાસ કરો.',
    'code.member_code_label': 'સભ્ય એક્સેસ કોડ',

    'owner.onboarding.title': 'જીમ ઓનર ઓનબોર્ડિંગ',
    'owner.step1.title': 'માલિકની વિગતો',
    'owner.step1.subtitle': 'તમારા વિશે જણાવો',
    'owner.step1.name': 'પૂરું નામ',
    'owner.step1.phone': 'ફોન નંબર',
    'owner.step1.photo': 'પ્રોફાઇલ ફોટો (મરજીયાત)',

    'owner.step2.title': 'જીમની વિગતો',
    'owner.step2.subtitle': 'જીમ માહિતી દાખલ કરો',
    'owner.step2.gym_name': 'જીમનું નામ',
    'owner.step2.gym_phone': 'જીમ હેલ્પલાઇન ફોન',
    'owner.step2.address': 'સરનામું',
    'owner.step2.city': 'શહેર',
    'owner.step2.gym_type': 'જીમનો પ્રકાર',
    'owner.step2.open_time': 'ખુલવાનો સમય',
    'owner.step2.close_time': 'બંધ થવાનો સમય',
    'owner.step2.weekly_off': 'સાપ્તાહિક રજા',

    'owner.step3.title': 'પેમેન્ટ સેટઅપ',
    'owner.step3.subtitle': 'સભ્યો તમને કેવી રીતે ચૂકવણી કરશે?',
    'owner.step3.upi_id': 'UPI ID',
    'owner.step3.upi_name': 'UPI નામ',

    'owner.step4.title': 'મેમ્બરશિપ પ્લાન',
    'owner.step4.subtitle': 'પ્લાન બનાવો',
    'owner.step4.plan_name': 'પ્લાનનું નામ',
    'owner.step4.price': 'કિંમત (₹)',
    'owner.step4.duration': 'સમયગાળો',
    'owner.step4.add_plan': 'બીજો પ્લાન ઉમેરો',

    'owner.step5.title': 'પ્રથમ સભ્ય ઉમેરો',
    'owner.step5.subtitle': 'પ્રથમ સભ્ય ઉમેરો (મરજીયાત)',
    'owner.step5.member_name': 'સભ્યનું નામ',
    'owner.step5.member_phone': 'સભ્યનો ફોન',
    'owner.step5.member_created': 'સભ્ય ઉમેરાયો ✓',
    'owner.step5.access_code_info': 'કાયમી 6-અંકનો સભ્ય એક્સેસ કોડ:',

    'owner.step6.title': 'ચકાસો અને પૂર્ણ કરો',
    'owner.step6.subtitle': 'સેટઅપની સમીક્ષા કરો',

    'member.onboarding.title': 'સભ્ય ઓનબોર્ડિંગ',
    'member.step1.welcome': '{{gym_name}} માં સ્વાગત છે! 👋',
    'member.step1.subtitle': 'તમારી પ્રોફાઇલ પૂર્ણ કરો.',
    'member.step1.get_started': 'શરૂ કરો',

    'member.step2.title': 'અંગત માહિતી',
    'member.step2.subtitle': 'મૂળભૂત વિગતો',
    'member.step2.gender': 'જાતિ',
    'member.step2.location': 'શહેર',

    'member.step3.title': 'ફિટનેસ પસંદગીઓ',
    'member.step3.subtitle': 'પ્લાન તૈયાર કરવા માટે',
    'member.step3.goal': 'મુખ્ય લક્ષ્ય',
    'member.step3.exp': 'અનુભવનું સ્તર',
    'member.step3.freq': 'અઠવાડિયાના વર્કઆઉટ દિવસો',
    'member.step3.equip': 'સાધનોની ઉપલબ્ધતા',
    'member.step3.food': 'ખોરાકની પસંદગી',
    'member.step3.diet_restrict': 'એલર્જી / મર્યાદાઓ',

    'member.step4.title': 'એપ અને નોટિફિકેશન',
    'member.step4.subtitle': 'અપડેટ મેળવવા માટે',
    'member.step4.enable_notif': 'નોટિફિકેશન ચાલુ કરો',
    'member.step4.install_pwa': 'એપ ઇન્સ્ટોલ કરો',

    'member.step5.title': 'બધું તૈયાર છે! 🎉',
    'member.step5.subtitle': 'તમારું ડેશબોર્ડ તૈયાર છે.',
    'member.step5.open_dashboard': 'ડેશબોર્ડ ખોલો',
  },

  kn: {
    'common.continue': 'ಮುಂದುವರಿಸಿ',
    'common.back': 'ಹಿಂತಿರುಗಿ',
    'common.skip': 'ಈಗ ಬೇಡ',
    'common.save': 'ಉಳಿಸಿ ಮತ್ತು ಮುಂದುವರಿಸಿ',
    'common.finish': 'ಸೆಟಪ್ ಪೂರ್ಣಗೊಳಿಸಿ',
    'common.done': 'ಪೂರ್ಣಗೊಂಡಿದೆ',
    'common.copy': 'ಕೋಡ್ ಕಾಪಿ ಮಾಡಿ',
    'common.copied': 'ಕಾಪಿ ಮಾಡಲಾಗಿದೆ!',
    'common.whatsapp': 'ವಾಟ್ಸಾಪ್‌ನಲ್ಲಿ ಹಂಚಿಕೊಳ್ಳಿ',
    'common.share': 'ಹಂಚಿಕೊಳ್ಳಿ',
    'common.required': 'ಈ ವಿವರ ಅಗತ್ಯವಿದೆ',
    'common.language': 'ಭಾಷೆ ಆಯ್ಕೆಮಾಡಿ',

    'code.title': 'ನಿಮ್ಮ ಆಕ್ಸೆಸ್ ಕೋಡ್ ನಮೂದಿಸಿ',
    'code.subtitle': 'ನಿಮ್ಮ ಜಿಮ್ ಅಥವಾ ಮಾಲೀಕರು ನೀಡಿದ 6-ಅಂಕೆಗಳ ಕೋಡ್ ನಮೂದಿಸಿ',
    'code.verify': 'ಕೋಡ್ ಪರಿಶೀಲಿಸಿ',
    'code.verifying': 'ಪರಿಶೀಲಿಸಲಾಗುತ್ತಿದೆ...',
    'code.invalid': 'ಅಸಿಂಧು ಕೋಡ್. ದಯವಿಟ್ಟು ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ.',
    'code.member_code_label': 'ಸದಸ್ಯರ ಆಕ್ಸೆಸ್ ಕೋಡ್',

    'owner.onboarding.title': 'ಜಿಮ್ ಮಾಲೀಕರ ಆನ್‌ಬೋರ್ಡಿಂಗ್',
    'owner.step1.title': 'ಮಾಲೀಕರ ವಿವರಗಳು',
    'owner.step1.subtitle': 'ನಿಮ್ಮ ಬಗ್ಗೆ ತಿಳಿಸಿ',
    'owner.step1.name': 'ಪೂರ್ಣ ಹೆಸರು',
    'owner.step1.phone': 'ಫೋನ್ ಸಂಖ್ಯೆ',
    'owner.step1.photo': 'ಪ್ರೊಫೈಲ್ ಫೋಟೋ (ಐಚ್ಛಿಕ)',

    'owner.step2.title': 'ಜಿಮ್ ವಿವರಗಳು',
    'owner.step2.subtitle': 'ಜಿಮ್ ಮಾಹಿತಿ ನಮೂದಿಸಿ',
    'owner.step2.gym_name': 'ಜಿಮ್ ಹೆಸರು',
    'owner.step2.gym_phone': 'ಜಿಮ್ ಫೋನ್',
    'owner.step2.address': 'ವಿಳಾಸ',
    'owner.step2.city': 'ನಗರ',
    'owner.step2.gym_type': 'ಜಿಮ್ ಮಾದರಿ',
    'owner.step2.open_time': 'ಆರಂಭದ ಸಮಯ',
    'owner.step2.close_time': 'ಮುಕ್ತಾಯದ ಸಮಯ',
    'owner.step2.weekly_off': 'ವಾರದ ರಜೆ',

    'owner.step3.title': 'ಪಾವತಿ ಸೆಟಪ್',
    'owner.step3.subtitle': 'ಸದಸ್ಯರು ನಿಮಗೆ ಹೇಗೆ ಪಾವತಿಸಬೇಕು?',
    'owner.step3.upi_id': 'UPI ಐಡಿ',
    'owner.step3.upi_name': 'UPI ಹೆಸರು',

    'owner.step4.title': 'ಸದಸ್ಯತ್ವ ಯೋಜನೆಗಳು',
    'owner.step4.subtitle': 'ಯೋಜನೆಗಳನ್ನು ರಚಿಸಿ',
    'owner.step4.plan_name': 'ಯೋಜನೆಯ ಹೆಸರು',
    'owner.step4.price': 'ಬೆಲೆ (₹)',
    'owner.step4.duration': 'ಅವಧಿ',
    'owner.step4.add_plan': 'ಇನ್ನೊಂದು ಯೋಜನೆ ಸೇರಿಸಿ',

    'owner.step5.title': 'ಮೊದಲ ಸದಸ್ಯರನ್ನು ಸೇರಿಸಿ',
    'owner.step5.subtitle': 'ಮೊದಲ ಸದಸ್ಯರನ್ನು ಸೇರಿಸಿ (ಐಚ್ಛಿಕ)',
    'owner.step5.member_name': 'ಸದಸ್ಯರ ಹೆಸರು',
    'owner.step5.member_phone': 'ಸದಸ್ಯರ ಫೋನ್',
    'owner.step5.member_created': 'ಸದಸ್ಯರನ್ನು ಸೇರಿಸಲಾಗಿದೆ ✓',
    'owner.step5.access_code_info': 'ಶಾಶ್ವತ 6-ಅಂಕೆಗಳ ಸದಸ್ಯತ್ವ ಆಕ್ಸೆಸ್ ಕೋಡ್:',

    'owner.step6.title': 'ಪರಿಶೀಲಿಸಿ ಮತ್ತು ಮುಗಿಸಿ',
    'owner.step6.subtitle': 'ಸೆಟಪ್ ಪರಿಶೀಲಿಸಿ',

    'member.onboarding.title': 'ಸದಸ್ಯರ ಆನ್‌ಬೋರ್ಡಿಂಗ್',
    'member.step1.welcome': '{{gym_name}} ಗೆ സ്വാಗತ! 👋',
    'member.step1.subtitle': 'ನಿಮ್ಮ ಪ್ರೊಫೈಲ್ ಪೂರ್ಣಗೊಳಿಸಿ.',
    'member.step1.get_started': 'ಪ್ರಾರಂಭಿಸಿ',

    'member.step2.title': 'ವೈಯಕ್ತಿಕ ಮಾಹಿತಿ',
    'member.step2.subtitle': 'ಮೂಲಭೂತ ವಿವರಗಳು',
    'member.step2.gender': 'ಲಿಂಗ',
    'member.step2.location': 'ನಗರ',

    'member.step3.title': 'ಫಿಟ್ನೆಸ್ ಆದ್ಯತೆಗಳು',
    'member.step3.subtitle': 'ಯೋಜನೆ ರೂಪಿಸಲು',
    'member.step3.goal': 'ಮುಖ್ಯ ಗುರಿ',
    'member.step3.exp': 'ಅನುಭವದ ಮಟ್ಟ',
    'member.step3.freq': 'ವಾರದ ವರ್ಕೌಟ್ ದಿನಗಳು',
    'member.step3.equip': 'ಉಪಕರಣ ಲಭ್ಯತೆ',
    'member.step3.food': 'ಆಹಾರ ಆದ್ಯತೆ',
    'member.step3.diet_restrict': 'ಅಲರ್ಜಿ / ನಿರ್ಬಂಧಗಳು',

    'member.step4.title': 'ಆ್ಯಪ್ ಸೆಟ್ಟಿಂಗ್‌ಗಳು',
    'member.step4.subtitle': 'ಅಪ್‌ಡೇಟ್ ಪಡೆಯಲು',
    'member.step4.enable_notif': 'ನೋಟಿಫಿಕೇಶನ್ ಆನ್ ಮಾಡಿ',
    'member.step4.install_pwa': 'ಆ್ಯಪ್ ಇನ್‌ಸ್ಟಾಲ್ ಮಾಡಿ',

    'member.step5.title': 'ಎಲ್ಲವೂ ಸಿದ್ಧವಾಗಿದೆ! 🎉',
    'member.step5.subtitle': 'ನಿಮ್ಮ ಡ್ಯಾಶ್‌ಬೋರ್ಡ್ ಸಿದ್ಧವಾಗಿದೆ.',
    'member.step5.open_dashboard': 'ಡ್ಯಾಶ್‌ಬೋರ್ಡ್ ತೆರೆಯಿರಿ',
  },

  ml: {
    'common.continue': 'തുടരുക',
    'common.back': 'പിന്നോട്ട്',
    'common.skip': 'ഇപ്പോൾ ഒഴിവാക്കുക',
    'common.save': 'സേവ് ചെയ്തു തുടരുക',
    'common.finish': 'സെറ്റപ്പ് പൂർത്തിയാക്കുക',
    'common.done': 'പൂർത്തിയായി',
    'common.copy': 'കോഡ് കോപ്പി ചെയ്യുക',
    'common.copied': 'കോപ്പി ചെയ്തു!',
    'common.whatsapp': 'വാട്ട്‌സാപ്പിൽ പങ്കിടുക',
    'common.share': 'പങ്കിടുക',
    'common.required': 'ഈ വിവരങ്ങൾ ആവശ്യമാണ്',
    'common.language': 'ഭാഷ തിരഞ്ഞെടുക്കുക',

    'code.title': 'ആക്സസ് കോഡ് നൽകുക',
    'code.subtitle': 'ജിം അല്ലെങ്കിൽ ഉടമ നൽകിയ 6 അക്ക കോഡ് നൽകുക',
    'code.verify': 'കോഡ് പരിശോധിക്കുക',
    'code.verifying': 'പരിശോധിക്കുന്നു...',
    'code.invalid': 'തെറ്റായ കോഡ്. വീണ്ടും ശ്രമിക്കുക.',
    'code.member_code_label': 'അംഗത്വ ആക്സസ് കോഡ്',

    'owner.onboarding.title': 'ജിം ഉടമ ഓൺബോർഡിംഗ്',
    'owner.step1.title': 'ഉടമയുടെ വിവരങ്ങൾ',
    'owner.step1.subtitle': 'നിങ്ങളെക്കുറിച്ച് പറയുക',
    'owner.step1.name': 'പൂർണ്ണ നാമം',
    'owner.step1.phone': 'ഫോൺ നമ്പർ',
    'owner.step1.photo': 'പ്രൊഫൈൽ ഫോട്ടോ (ഐച്ഛികം)',

    'owner.step2.title': 'ജിം വിവരങ്ങൾ',
    'owner.step2.subtitle': 'ജിം പ്രൊഫൈൽ നൽകുക',
    'owner.step2.gym_name': 'ജിമ്മിന്റെ പേര്',
    'owner.step2.gym_phone': 'ജിം ഫോൺ',
    'owner.step2.address': 'വിലാസം',
    'owner.step2.city': 'നഗരം',
    'owner.step2.gym_type': 'ജിം തരം',
    'owner.step2.open_time': 'തുറക്കുന്ന സമയം',
    'owner.step2.close_time': 'അടയ്ക്കുന്ന സമയം',
    'owner.step2.weekly_off': 'ആഴ്ചയിലെ അവധി',

    'owner.step3.title': 'പേയ്മെന്റ് സെറ്റപ്പ്',
    'owner.step3.subtitle': 'അംഗങ്ങൾ എങ്ങനെ പണമടയ്ക്കണം?',
    'owner.step3.upi_id': 'UPI ഐഡി',
    'owner.step3.upi_name': 'UPI പേര്',

    'owner.step4.title': 'അംഗത്വ പ്ലാനുകൾ',
    'owner.step4.subtitle': 'പ്ലാനുകൾ ഉണ്ടാക്കുക',
    'owner.step4.plan_name': 'പ്ലാനിന്റെ പേര്',
    'owner.step4.price': 'വില (₹)',
    'owner.step4.duration': 'കാലയളവ്',
    'owner.step4.add_plan': 'മറ്റൊരു പ്ലാൻ ചേർക്കുക',

    'owner.step5.title': 'ആദ്യ അംഗത്തെ ചേർക്കുക',
    'owner.step5.subtitle': 'ആദ്യ അംഗത്തെ ചേർക്കുക (ഐച്ഛികം)',
    'owner.step5.member_name': 'അംഗത്തിന്റെ പേര്',
    'owner.step5.member_phone': 'അംഗത്തിന്റെ ഫോൺ',
    'owner.step5.member_created': 'അംഗത്തെ ചേർത്തു ✓',
    'owner.step5.access_code_info': 'സ്ഥിരമായ 6 അക്ക അംഗത്വ ആക്സസ് കോഡ്:',

    'owner.step6.title': 'പരിശോധിച്ച് പൂർത്തിയാക്കുക',
    'owner.step6.subtitle': 'സെറ്റപ്പ് പരിശോധിക്കുക',

    'member.onboarding.title': 'അംഗത്വ ഓൺബോർഡിംഗ്',
    'member.step1.welcome': '{{gym_name}}-ലേക്ക് സ്വാഗതം! 👋',
    'member.step1.subtitle': 'പ്രൊഫൈൽ പൂർത്തിയാക്കുക.',
    'member.step1.get_started': 'ആരംഭിക്കുക',

    'member.step2.title': 'വ്യക്തിഗത വിവരങ്ങൾ',
    'member.step2.subtitle': 'അടിസ്ഥാന വിവരങ്ങൾ',
    'member.step2.gender': 'ലിംഗം',
    'member.step2.location': 'നഗരം',

    'member.step3.title': 'ഫിറ്റ്നസ് മുൻഗണനകൾ',
    'member.step3.subtitle': 'പ്ലാൻ തയാറാക്കാൻ',
    'member.step3.goal': 'പ്രധാന ലക്ഷ്യം',
    'member.step3.exp': 'പരിചയസമ്പത്ത്',
    'member.step3.freq': 'ആഴ്ചയിലെ വർക്കൗട്ട് ദിവസങ്ങൾ',
    'member.step3.equip': 'ഉപകരണ ലഭ്യത',
    'member.step3.food': 'ഭക്ഷണ മുൻഗണന',
    'member.step3.diet_restrict': 'അലർജികൾ / നിയന്ത്രണങ്ങൾ',

    'member.step4.title': 'ആപ്പ് ക്രമീകരണങ്ങൾ',
    'member.step4.subtitle': 'അറിയിപ്പുകൾ ലഭിക്കാൻ',
    'member.step4.enable_notif': 'നോട്ടിഫിക്കേഷൻ ഓൺ ചെയ്യുക',
    'member.step4.install_pwa': 'ആപ്പ് ഇൻസ്റ്റാൾ ചെയ്യുക',

    'member.step5.title': 'എല്ലാം സജ്ജമാണ്! 🎉',
    'member.step5.subtitle': 'നിങ്ങളുടെ ഡാഷ്‌ബോർഡ് സജ്ജമാണ്.',
    'member.step5.open_dashboard': 'ഡാഷ്‌ബോർഡ് തുറക്കുക',
  },

  or: {
    'common.continue': 'ଆଗକୁ ବଢ଼ନ୍ତୁ',
    'common.back': 'ପଛକୁ',
    'common.skip': 'ବର୍ତ୍ତମାନ ଛାଡନ୍ତୁ',
    'common.save': 'ସଂରକ୍ଷଣ କରନ୍ତୁ ଏବଂ ଆଗକୁ ବଢ଼ନ୍ତୁ',
    'common.finish': 'ସେଟଅପ୍ ଶେଷ କରନ୍ତୁ',
    'common.done': 'ସମ୍ପନ୍ନ',
    'common.copy': 'କୋଡ୍ କପି କରନ୍ତୁ',
    'common.copied': 'କପି ହେଲା!',
    'common.whatsapp': 'ହ୍ୱାଟସ୍‌ଆପ୍‌ରେ ସେୟାର୍ କରନ୍ତୁ',
    'common.share': 'ସେୟାର୍ କରନ୍ତୁ',
    'common.required': 'ଏହି ସୂଚନା ଆବଶ୍ୟକ',
    'common.language': 'ଭାଷା ବାଛନ୍ତୁ',

    'code.title': 'ଆପଣଙ୍କ ଆକ୍ସେସ୍ କୋଡ୍ ଦିଅନ୍ତୁ',
    'code.subtitle': 'ଜିମ୍ କିମ୍ବା ମାଲିକଙ୍କ ଦ୍ୱାରା ପ୍ରଦତ୍ତ ୬-ଅଙ୍କ ବିଶିଷ୍ଟ କୋଡ୍ ଦିଅନ୍ତୁ',
    'code.verify': 'କୋଡ୍ ଯାଞ୍ଚ କରନ୍ତୁ',
    'code.verifying': 'ଯାଞ୍ଚ ହେଉଛି...',
    'code.invalid': 'ଅବୈଧ କୋଡ୍। ଦୟାକରି ଯାଞ୍ଚ କରି ପୁଣି ଚେଷ୍ଟା କରନ୍ତୁ।',
    'code.member_code_label': 'ସଦସ୍ୟ ଆକ୍ସେସ୍ କୋଡ୍',

    'owner.onboarding.title': 'ଜିମ୍ ମାଲିକ ଅନ୍‌ବୋର୍ଡିଂ',
    'owner.step1.title': 'ମାଲିକଙ୍କ ବିବରଣୀ',
    'owner.step1.subtitle': 'ଆପଣଙ୍କ ବିଷୟରେ କୁହନ୍ତୁ',
    'owner.step1.name': 'ପୂରା ନାମ',
    'owner.step1.phone': 'ଫୋନ୍ ନମ୍ବର',
    'owner.step1.photo': 'ପ୍ରୋଫାଇଲ୍ ଫୋଟୋ (ଇଚ୍ଛାଧୀନ)',

    'owner.step2.title': 'ଜିମ୍‌ ବିବରଣୀ',
    'owner.step2.subtitle': 'ଜିମ୍‌ ସୂଚନା ଦିଅନ୍ତୁ',
    'owner.step2.gym_name': 'ଜିମ୍‌ ନାମ',
    'owner.step2.gym_phone': 'ଜିମ୍‌ ଫୋନ୍',
    'owner.step2.address': 'ଠିକଣା',
    'owner.step2.city': 'ସହର',
    'owner.step2.gym_type': 'ଜିମ୍‌ ପ୍ରକାର',
    'owner.step2.open_time': 'ଖୋଲିବା ସମୟ',
    'owner.step2.close_time': 'ବନ୍ଦ ହେବା ସମୟ',
    'owner.step2.weekly_off': 'ସାପ୍ତାହିକ ଛୁଟି',

    'owner.step3.title': 'ପେମେଣ୍ଟ ସେଟଅପ୍',
    'owner.step3.subtitle': 'ସଦସ୍ୟମାନେ କିପରି ଦେୟ ଦେବେ?',
    'owner.step3.upi_id': 'UPI ଆଇଡି',
    'owner.step3.upi_name': 'UPI ନାମ',

    'owner.step4.title': 'ସଦସ୍ୟତା ପ୍ଲାନ୍',
    'owner.step4.subtitle': 'ପ୍ଲାନ୍ ତିଆରି କରନ୍ତୁ',
    'owner.step4.plan_name': 'ପ୍ଲାନ୍ ନାମ',
    'owner.step4.price': 'ମୂଲ୍ୟ (₹)',
    'owner.step4.duration': 'ଅବଧି',
    'owner.step4.add_plan': 'ଅନ୍ୟ ଏକ ପ୍ଲାନ୍ ଯୋଡନ୍ତୁ',

    'owner.step5.title': 'ପ୍ରଥମ ସଦସ୍ୟ ଯୋଡନ୍ତୁ',
    'owner.step5.subtitle': 'ପ୍ରଥମ ସଦସ୍ୟ ଯୋଡନ୍ତୁ (ଇଚ୍ଛାଧୀନ)',
    'owner.step5.member_name': 'ସଦସ୍ୟଙ୍କ ନାମ',
    'owner.step5.member_phone': 'ସଦସ୍ୟଙ୍କ ଫୋନ୍',
    'owner.step5.member_created': 'ସଦସ୍ୟ ଯୋଡାଗଲା ✓',
    'owner.step5.access_code_info': 'ସ୍ଥାୟୀ ୬-ଅଙ୍କ ବିଶିଷ୍ଟ ସଦସ୍ୟ ଆକ୍ସେସ୍ କୋଡ୍:',

    'owner.step6.title': 'ଯାଞ୍ଚ କରନ୍ତୁ ଏବଂ ସମାପ୍ତ କରନ୍ତୁ',
    'owner.step6.subtitle': 'ସେଟଅପ୍ ଯାଞ୍ଚ କରନ୍ତୁ',

    'member.onboarding.title': 'ସଦସ୍ୟ ଅନ୍‌ବୋର୍ଡିଂ',
    'member.step1.welcome': '{{gym_name}} କୁ ସ୍ୱାଗତ! 👋',
    'member.step1.subtitle': 'ପ୍ରୋଫାଇଲ୍ ସମ୍ପୂର୍ଣ୍ଣ କରନ୍ତୁ।',
    'member.step1.get_started': 'ଆରମ୍ଭ କରନ୍ତୁ',

    'member.step2.title': 'ବ୍ୟକ୍ତିଗତ ସୂଚନା',
    'member.step2.subtitle': 'ମୌଳିକ ବିବରଣୀ',
    'member.step2.gender': 'ଲିଙ୍ଗ',
    'member.step2.location': 'ସହର',

    'member.step3.title': 'ଫିଟନେସ୍ ପସନ୍ଦ',
    'member.step3.subtitle': 'ପ୍ଲାନ୍ ପ୍ରସ୍ତୁତ କରିବା ପାଇଁ',
    'member.step3.goal': 'ମୁଖ୍ୟ ଲକ୍ଷ୍ୟ',
    'member.step3.exp': 'ଅନୁଭବ ସ୍ତର',
    'member.step3.freq': 'ସାପ୍ତାହିକ ୱାର୍କଆଉଟ୍ ଦିନ',
    'member.step3.equip': 'ଉପକରଣ ଉପଲବ୍ଧତା',
    'member.step3.food': 'ଖାଦ୍ୟ ପସନ୍ଦ',
    'member.step3.diet_restrict': 'ଆଲର୍ଜି / କଟକଣା',

    'member.step4.title': 'ଆପ୍ ସେଟିଂସ',
    'member.step4.subtitle': 'ଅପଡେଟ୍ ପାଇବା ପାଇଁ',
    'member.step4.enable_notif': 'ନୋଟିଫିକେସନ୍ ଅନ୍ କରନ୍ତୁ',
    'member.step4.install_pwa': 'ଆପ୍ ଇନଷ୍ଟଲ୍ କରନ୍ତୁ',

    'member.step5.title': 'ସବୁ ପ୍ରସ୍ତୁତ! 🎉',
    'member.step5.subtitle': 'ଆପଣଙ୍କ ଡ୍ୟାସବୋର୍ଡ ପ୍ରସ୍ତୁତ।',
    'member.step5.open_dashboard': 'ଡ୍ୟାସବୋର୍ଡ ଖୋଲନ୍ତୁ',
  }
};

export function t(key: string, lang?: Language, replacements?: Record<string, string>): string {
  const currentLang = lang || getStoredLanguage();
  let text = translations[currentLang]?.[key] || translations['en']?.[key] || key;
  
  if (replacements) {
    Object.keys(replacements).forEach((rKey) => {
      text = text.replace(new RegExp(`{{${rKey}}}`, 'g'), replacements[rKey]);
    });
  }
  
  return text;
}
