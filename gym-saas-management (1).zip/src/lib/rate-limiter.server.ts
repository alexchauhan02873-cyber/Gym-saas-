/**
 * Distributed Redis-backed & Memory-backed Sliding Window Rate Limiter & Brute-Force Protection
 * Hardened for production scale (2,000+ gyms, 300,000 members).
 */

import Redis from "ioredis";

let redisClient: Redis | null = null;
if (process.env.REDIS_URL) {
  try {
    redisClient = new Redis(process.env.REDIS_URL, {
      maxRetriesPerRequest: 3,
      enableOfflineQueue: false,
    });
    redisClient.on("error", (err) => console.error("Redis Rate Limiter Error:", err?.message || err));
  } catch (e) {
    console.warn("Failed to initialize Redis client, falling back to memory store.");
  }
}

interface RateLimitRecord {
  timestamps: number[];
}

interface BruteForceRecord {
  failedAttempts: number;
  firstFailedAt: number;
  lockoutUntil: number;
}

const rateLimitStore = new Map<string, RateLimitRecord>();
const bruteForceStore = new Map<string, BruteForceRecord>();

// Clean up stale memory store records every 10 minutes
setInterval(() => {
  const now = Date.now();
  for (const [key, record] of rateLimitStore.entries()) {
    record.timestamps = record.timestamps.filter((ts) => now - ts < 3600000);
    if (record.timestamps.length === 0) {
      rateLimitStore.delete(key);
    }
  }

  for (const [key, record] of bruteForceStore.entries()) {
    if (now > record.lockoutUntil && now - record.firstFailedAt > 86400000) {
      bruteForceStore.delete(key);
    }
  }
}, 600000);

export async function checkRateLimitAsync(
  key: string,
  maxRequests = 120,
  windowMs = 60000
): Promise<{ allowed: boolean; remaining: number; resetMs: number }> {
  if (redisClient && redisClient.status === "ready") {
    try {
      const redisKey = `rl:${key}`;
      const now = Date.now();
      const clearBefore = now - windowMs;

      const pipeline = redisClient.pipeline();
      pipeline.zremrangebyscore(redisKey, 0, clearBefore);
      pipeline.zadd(redisKey, now, `${now}_${Math.random()}`);
      pipeline.zcard(redisKey);
      pipeline.expire(redisKey, Math.ceil(windowMs / 1000));

      const results = await pipeline.exec();
      const requestCount = (results && results[2] && (results[2][1] as number)) || 1;

      if (requestCount > maxRequests) {
        return {
          allowed: false,
          remaining: 0,
          resetMs: windowMs,
        };
      }

      return {
        allowed: true,
        remaining: Math.max(0, maxRequests - requestCount),
        resetMs: windowMs,
      };
    } catch (err) {
      // Fallback to synchronous in-memory rate limiter on Redis transient failure
    }
  }

  return checkRateLimit(key, maxRequests, windowMs);
}

export function checkRateLimit(
  key: string,
  maxRequests = 120,
  windowMs = 60000
): { allowed: boolean; remaining: number; resetMs: number } {
  const now = Date.now();
  let record = rateLimitStore.get(key);

  if (!record) {
    record = { timestamps: [] };
    rateLimitStore.set(key, record);
  }

  // Filter out timestamps older than the window
  record.timestamps = record.timestamps.filter((ts) => now - ts < windowMs);

  if (record.timestamps.length >= maxRequests) {
    const oldest = record.timestamps[0] || now;
    const resetMs = Math.max(0, windowMs - (now - oldest));
    return {
      allowed: false,
      remaining: 0,
      resetMs,
    };
  }

  record.timestamps.push(now);
  return {
    allowed: true,
    remaining: maxRequests - record.timestamps.length,
    resetMs: windowMs,
  };
}

/**
 * Member Code Brute Force Protection (6-digit Member Access Code)
 * Protects against credential scanning across 1,000,000 possible 6-digit combinations.
 */
export function checkMemberCodeBruteForce(
  ip: string,
  gymCode = "",
  memberCode = ""
): { locked: boolean; remainingAttempts: number; retryAfterSeconds: number } {
  const now = Date.now();
  const key = `bf_mem_${ip}_${gymCode}_${memberCode}`;
  const record = bruteForceStore.get(key);

  if (!record) {
    return { locked: false, remainingAttempts: 5, retryAfterSeconds: 0 };
  }

  if (now < record.lockoutUntil) {
    const retryAfterSeconds = Math.ceil((record.lockoutUntil - now) / 1000);
    return {
      locked: true,
      remainingAttempts: 0,
      retryAfterSeconds,
    };
  }

  // If lockout window expired (> 15 minutes since first fail), reset count
  if (now - record.firstFailedAt > 900000) {
    bruteForceStore.delete(key);
    return { locked: false, remainingAttempts: 5, retryAfterSeconds: 0 };
  }

  const remainingAttempts = Math.max(0, 5 - record.failedAttempts);
  return { locked: false, remainingAttempts, retryAfterSeconds: 0 };
}

export function recordFailedMemberCodeAttempt(
  ip: string,
  gymCode = "",
  memberCode = ""
): { locked: boolean; retryAfterSeconds: number } {
  const now = Date.now();
  const key = `bf_mem_${ip}_${gymCode}_${memberCode}`;
  let record = bruteForceStore.get(key);

  if (!record) {
    record = {
      failedAttempts: 1,
      firstFailedAt: now,
      lockoutUntil: 0,
    };
  } else {
    record.failedAttempts += 1;
  }

  if (record.failedAttempts >= 10) {
    // 15-minute lockout for 10+ failed attempts
    record.lockoutUntil = now + 900000;
  } else if (record.failedAttempts >= 5) {
    // 60-second progressive cooldown for 5 failed attempts
    record.lockoutUntil = now + 60000;
  }

  bruteForceStore.set(key, record);

  const locked = now < record.lockoutUntil;
  const retryAfterSeconds = locked ? Math.ceil((record.lockoutUntil - now) / 1000) : 0;
  return { locked, retryAfterSeconds };
}

export function resetFailedMemberCodeAttempts(
  ip: string,
  gymCode = "",
  memberCode = ""
): void {
  const key = `bf_mem_${ip}_${gymCode}_${memberCode}`;
  bruteForceStore.delete(key);
}

/**
 * Mobile Auth Login Brute Force Protection (5 failed login attempts / 15 minutes)
 */
export function checkLoginRateLimit(
  ip: string,
  mobile: string
): { locked: boolean; remainingAttempts: number; retryAfterSeconds: number } {
  const now = Date.now();
  const key = `bf_login_${ip}_${mobile}`;
  const record = bruteForceStore.get(key);

  if (!record) {
    return { locked: false, remainingAttempts: 5, retryAfterSeconds: 0 };
  }

  if (now < record.lockoutUntil) {
    const retryAfterSeconds = Math.ceil((record.lockoutUntil - now) / 1000);
    return {
      locked: true,
      remainingAttempts: 0,
      retryAfterSeconds,
    };
  }

  if (now - record.firstFailedAt > 900000) {
    bruteForceStore.delete(key);
    return { locked: false, remainingAttempts: 5, retryAfterSeconds: 0 };
  }

  const remainingAttempts = Math.max(0, 5 - record.failedAttempts);
  return { locked: false, remainingAttempts, retryAfterSeconds: 0 };
}

export function recordFailedLoginAttempt(
  ip: string,
  mobile: string
): { locked: boolean; retryAfterSeconds: number } {
  const now = Date.now();
  const key = `bf_login_${ip}_${mobile}`;
  let record = bruteForceStore.get(key);

  if (!record) {
    record = {
      failedAttempts: 1,
      firstFailedAt: now,
      lockoutUntil: 0,
    };
  } else {
    record.failedAttempts += 1;
  }

  if (record.failedAttempts >= 5) {
    record.lockoutUntil = now + 900000; // 15 minutes lockout for 5 failed attempts
  }

  bruteForceStore.set(key, record);

  const locked = now < record.lockoutUntil;
  const retryAfterSeconds = locked ? Math.ceil((record.lockoutUntil - now) / 1000) : 0;
  return { locked, retryAfterSeconds };
}

export function resetFailedLoginAttempts(ip: string, mobile: string): void {
  const key = `bf_login_${ip}_${mobile}`;
  bruteForceStore.delete(key);
}

/**
 * Signup Rate Limiter (3 account creations / hour / IP)
 */
export function checkSignupRateLimit(
  ip: string
): { allowed: boolean; remaining: number; resetMs: number } {
  return checkRateLimit(`signup_${ip}`, 3, 3600000);
}

export function applyRateLimitHeaders(
  headers: Headers,
  limit: number,
  remaining: number,
  resetMs: number
): void {
  headers.set("X-RateLimit-Limit", String(limit));
  headers.set("X-RateLimit-Remaining", String(Math.max(0, remaining)));
  headers.set("X-RateLimit-Reset", String(Math.ceil(resetMs / 1000)));
}
