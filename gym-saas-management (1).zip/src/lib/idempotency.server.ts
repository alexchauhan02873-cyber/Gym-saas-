/**
 * Distributed Redis & Persistent DB Idempotency Engine for Financial & Mutation Safety.
 * Prevents duplicate payments, duplicate renewals, duplicate invoices, and duplicate attendance records.
 */

import Redis from "ioredis";

let redisClient: Redis | null = null;
if (process.env.REDIS_URL) {
  try {
    redisClient = new Redis(process.env.REDIS_URL, {
      maxRetriesPerRequest: 3,
      enableOfflineQueue: false,
    });
    redisClient.on("error", (err) => console.error("Redis Idempotency Error:", err?.message || err));
  } catch (e) {
    console.warn("Failed to initialize Redis idempotency client.");
  }
}

interface CachedIdempotencyResult {
  status: number;
  data: any;
  createdAt: number;
}

const idempotencyStore = new Map<string, CachedIdempotencyResult>();

// Clean up stale idempotency records older than 24 hours in memory
setInterval(() => {
  const now = Date.now();
  for (const [key, record] of idempotencyStore.entries()) {
    if (now - record.createdAt > 86400000) {
      idempotencyStore.delete(key);
    }
  }
}, 3600000);

export async function checkIdempotencyAsync(
  key: string,
  db?: any
): Promise<{ hit: boolean; status?: number; data?: any }> {
  if (!key || typeof key !== "string" || !key.trim()) {
    return { hit: false };
  }

  const cleanKey = key.trim();

  // 1. Try Redis lookup
  if (redisClient && redisClient.status === "ready") {
    try {
      const raw = await redisClient.get(`idemp:${cleanKey}`);
      if (raw) {
        const parsed = JSON.parse(raw);
        return {
          hit: true,
          status: parsed.status,
          data: parsed.data,
        };
      }
    } catch (e) {
      // Fallback
    }
  }

  // 2. Fallback to memory/DB check
  return checkIdempotency(cleanKey, db);
}

export function checkIdempotency(key: string, db?: any): { hit: boolean; status?: number; data?: any } {
  if (!key || typeof key !== "string" || !key.trim()) {
    return { hit: false };
  }

  const cleanKey = key.trim();
  const memoryRecord = idempotencyStore.get(cleanKey);
  if (memoryRecord) {
    return {
      hit: true,
      status: memoryRecord.status,
      data: memoryRecord.data,
    };
  }

  if (db && Array.isArray(db.idempotencyRecords)) {
    const dbRecord = db.idempotencyRecords.find((r: any) => r.key === cleanKey);
    if (dbRecord) {
      idempotencyStore.set(cleanKey, {
        status: dbRecord.status,
        data: dbRecord.data,
        createdAt: dbRecord.createdAt || Date.now(),
      });
      return {
        hit: true,
        status: dbRecord.status,
        data: dbRecord.data,
      };
    }
  }

  return { hit: false };
}

export async function saveIdempotencyResultAsync(
  key: string,
  status: number,
  data: any,
  db?: any
): Promise<void> {
  if (!key || typeof key !== "string" || !key.trim()) return;

  const cleanKey = key.trim();
  const payload = { status, data, createdAt: Date.now() };

  // 1. Save to Redis with 24-hour TTL (86400s)
  if (redisClient && redisClient.status === "ready") {
    try {
      await redisClient.set(`idemp:${cleanKey}`, JSON.stringify(payload), "EX", 86400);
    } catch (e) {
      // Fallback
    }
  }

  // 2. Save to Memory & DB
  saveIdempotencyResult(cleanKey, status, data, db);
}

export function saveIdempotencyResult(key: string, status: number, data: any, db?: any): void {
  if (!key || typeof key !== "string" || !key.trim()) return;

  const cleanKey = key.trim();
  const createdAt = Date.now();

  idempotencyStore.set(cleanKey, {
    status,
    data,
    createdAt,
  });

  if (db) {
    if (!Array.isArray(db.idempotencyRecords)) {
      db.idempotencyRecords = [];
    }
    const existingIdx = db.idempotencyRecords.findIndex((r: any) => r.key === cleanKey);
    if (existingIdx !== -1) {
      db.idempotencyRecords[existingIdx] = { key: cleanKey, status, data, createdAt };
    } else {
      db.idempotencyRecords.push({ key: cleanKey, status, data, createdAt });
    }
  }
}

