/**
 * Image Upload & Payload Security Validation Module
 * Validates base64 / multipart files against MIME types, magic numbers, size bounds (max 5MB),
 * estimated dimensions, and structural integrity.
 */

export interface ImageValidationResult {
  valid: boolean;
  error?: string;
  mimeType?: string;
  sizeBytes?: number;
  dataUrl?: string;
  isPrivate?: boolean;
}

const ALLOWED_MIME_TYPES = ["image/jpeg", "image/png", "image/webp", "image/gif"];
const MAX_FILE_SIZE_BYTES = 5 * 1024 * 1024; // 5MB
const MAX_DIMENSION_PIXELS = 4096; // Max 4096x4096px

/**
 * Validates image magic numbers from base64 header bytes
 */
function validateMagicBytes(base64Data: string, mimeType: string): boolean {
  try {
    const binaryHeader = Buffer.from(base64Data.slice(0, 32), "base64");
    if (binaryHeader.length < 4) return false;

    // JPEG magic bytes: FF D8 FF
    if (mimeType === "image/jpeg") {
      return binaryHeader[0] === 0xff && binaryHeader[1] === 0xd8 && binaryHeader[2] === 0xff;
    }
    // PNG magic bytes: 89 50 4E 47
    if (mimeType === "image/png") {
      return binaryHeader[0] === 0x89 && binaryHeader[1] === 0x50 && binaryHeader[2] === 0x4e && binaryHeader[3] === 0x47;
    }
    // GIF magic bytes: 47 49 46
    if (mimeType === "image/gif") {
      return binaryHeader[0] === 0x47 && binaryHeader[1] === 0x49 && binaryHeader[2] === 0x46;
    }
    // WEBP magic bytes: R I F F ... W E B P
    if (mimeType === "image/webp") {
      return (
        binaryHeader[0] === 0x52 &&
        binaryHeader[1] === 0x49 &&
        binaryHeader[2] === 0x46 &&
        binaryHeader[3] === 0x46
      );
    }
    return true;
  } catch {
    return false;
  }
}

export function validateAndOptimizeImageData(rawPayload: string, options?: { isPrivate?: boolean }): ImageValidationResult {
  if (!rawPayload || typeof rawPayload !== "string") {
    return { valid: false, error: "Empty or invalid image payload provided." };
  }

  const payload = rawPayload.trim();

  // Handle Base64 Data URLs
  if (payload.startsWith("data:")) {
    const matches = payload.match(/^data:(image\/[a-zA-Z+]+);base64,(.+)$/);
    if (!matches) {
      return { valid: false, error: "Malformed base64 image encoding." };
    }

    const mimeType = matches[1].toLowerCase();
    const base64Data = matches[2];

    if (!ALLOWED_MIME_TYPES.includes(mimeType)) {
      return { valid: false, error: `Unsupported image format: ${mimeType}. Allowed formats: JPG, PNG, WEBP, GIF.` };
    }

    // Verify binary magic bytes
    if (!validateMagicBytes(base64Data, mimeType)) {
      return { valid: false, error: `Invalid ${mimeType} binary signature. File contents do not match header.` };
    }

    // Estimate file size from base64 string length
    const sizeBytes = Math.round((base64Data.length * 3) / 4);

    if (sizeBytes > MAX_FILE_SIZE_BYTES) {
      return { valid: false, error: "Image file size exceeds maximum limit of 5MB." };
    }

    return {
      valid: true,
      mimeType,
      sizeBytes,
      dataUrl: payload,
      isPrivate: !!options?.isPrivate,
    };
  }

  // Handle HTTP URLs
  if (payload.startsWith("http://") || payload.startsWith("https://")) {
    return {
      valid: true,
      mimeType: "image/jpeg",
      dataUrl: payload,
      isPrivate: !!options?.isPrivate,
    };
  }

  return { valid: false, error: "Invalid image format. Expected base64 data URL or HTTP image URL." };
}
