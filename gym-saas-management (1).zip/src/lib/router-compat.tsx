import React, { useState, useEffect, useMemo, createContext, useContext } from 'react';

// Reactive location state
const LocationContext = createContext<{ pathname: string; search: string }>({
  pathname: typeof window !== 'undefined' ? window.location.pathname : '/',
  search: typeof window !== 'undefined' ? window.location.search : '',
});

export function RouterProvider({ children }: { children: React.ReactNode }) {
  const [loc, setLoc] = useState(() => ({
    pathname: typeof window !== 'undefined' ? window.location.pathname : '/',
    search: typeof window !== 'undefined' ? window.location.search : '',
  }));

  useEffect(() => {
    const handlePopState = () => {
      setLoc({
        pathname: window.location.pathname,
        search: window.location.search,
      });
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  return (
    <LocationContext.Provider value={loc}>
      {children}
    </LocationContext.Provider>
  );
}

export const Router = RouterProvider;

export function useLocation() {
  const ctx = useContext(LocationContext);
  return {
    pathname: ctx.pathname,
    search: ctx.search,
    hash: typeof window !== 'undefined' ? window.location.hash : '',
    state: null,
  };
}

export function useNavigate() {
  return useMemo(() => {
    return (to: string | number, options?: { replace?: boolean }) => {
      if (typeof to === 'number') {
        window.history.go(to);
        return;
      }
      if (options?.replace) {
        window.history.replaceState(null, '', to);
      } else {
        window.history.pushState(null, '', to);
      }
      window.dispatchEvent(new PopStateEvent('popstate'));
    };
  }, []);
}

export function useParams<T extends Record<string, string> = Record<string, string>>(): T {
  const pathname = typeof window !== 'undefined' ? window.location.pathname : '';
  const segments = pathname.split('/').filter(Boolean);
  const params: Record<string, string> = {};

  if (segments[0] === 'owner' && segments[1] === 'members' && segments[2]) {
    params.memberId = segments[2];
    params.id = segments[2];
  }
  if (segments[0] === 'm' && segments[1]) {
    params.token = segments[1];
  }

  return params as T;
}

export function useSearchParams(): [
  URLSearchParams,
  (next: URLSearchParams | Record<string, string>, options?: { replace?: boolean }) => void
] {
  const loc = useLocation();
  const searchParams = useMemo(() => new URLSearchParams(loc.search), [loc.search]);
  const navigate = useNavigate();

  const setSearchParams = (
    next: URLSearchParams | Record<string, string>,
    options?: { replace?: boolean }
  ) => {
    const searchStr = next instanceof URLSearchParams ? next.toString() : new URLSearchParams(next).toString();
    const url = loc.pathname + (searchStr ? `?${searchStr}` : '');
    navigate(url, options);
  };

  return [searchParams, setSearchParams];
}

export interface LinkProps extends React.AnchorHTMLAttributes<HTMLAnchorElement> {
  to: string;
  replace?: boolean;
  children?: React.ReactNode;
  className?: string;
  onClick?: (e: any) => void;
  key?: string | number;
}

export function Link({ to, replace, children, className, onClick, ...rest }: LinkProps) {
  const navigate = useNavigate();

  const handleClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    if (onClick) onClick(e);
    if (!e.defaultPrevented && e.button === 0 && !e.metaKey && !e.altKey && !e.ctrlKey && !e.shiftKey) {
      e.preventDefault();
      navigate(to, { replace });
    }
  };

  return (
    <a href={to} onClick={handleClick} className={className} {...rest}>
      {children}
    </a>
  );
}

export function Navigate({ to, replace }: { to: string; replace?: boolean }) {
  const navigate = useNavigate();
  useEffect(() => {
    navigate(to, { replace });
  }, [navigate, to, replace]);
  return null;
}

export interface RouteProps {
  path: string;
  element: React.ReactNode;
}

export function Route(props: RouteProps) {
  return <>{props.element}</>;
}

export function Routes({ children }: { children: React.ReactNode }) {
  const loc = useLocation();
  const currentPath = loc.pathname;

  let exactMatch: React.ReactNode = null;
  let paramMatch: React.ReactNode = null;
  let fallbackElement: React.ReactNode = null;

  React.Children.forEach(children, (child) => {
    if (!React.isValidElement<RouteProps>(child)) return;
    const { path, element } = child.props;

    if (path === '*') {
      fallbackElement = element;
      return;
    }

    if (path === currentPath) {
      exactMatch = element;
      return;
    }

    // Dynamic param route matching, e.g. /owner/members/:id
    if (!exactMatch && path.includes(':')) {
      const pathParts = path.split('/').filter(Boolean);
      const currentParts = currentPath.split('/').filter(Boolean);

      if (pathParts.length === currentParts.length) {
        let match = true;
        for (let i = 0; i < pathParts.length; i++) {
          if (!pathParts[i].startsWith(':') && pathParts[i] !== currentParts[i]) {
            match = false;
            break;
          }
        }
        if (match) {
          paramMatch = element;
        }
      }
    }
  });

  return <>{exactMatch || paramMatch || fallbackElement}</>;
}
