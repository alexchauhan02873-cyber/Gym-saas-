/**
 * Single source of truth for member + gym access states.
 * Browser-safe: imported by UI and by the server API layer.
 */

export type AccessState = "ACTIVE" | "FROZEN" | "BLOCKED" | "ARCHIVED";

/** Legacy values that existed before the status system was centralised. */
const MEMBER_ALIASES: Record<string, AccessState> = {
  ACTIVE: "ACTIVE",
  FROZEN: "FROZEN",
  BLOCKED: "BLOCKED",
  DISABLED: "BLOCKED",
  SUSPENDED: "BLOCKED",
  ARCHIVED: "ARCHIVED",
  REMOVED: "ARCHIVED",
  DELETED: "ARCHIVED",
};

const GYM_ALIASES: Record<string, AccessState> = {
  ACTIVE: "ACTIVE",
  TRIAL: "ACTIVE",
  PAST_DUE: "ACTIVE", // billing state, never an access state
  BLOCKED: "BLOCKED",
  SUSPENDED: "BLOCKED",
  ARCHIVED: "ARCHIVED",
  CANCELLED: "ARCHIVED",
  DELETED: "ARCHIVED",
};

export function normalizeMemberStatus(status?: string | null): AccessState {
  if (!status) return "ACTIVE";
  return MEMBER_ALIASES[String(status).toUpperCase()] ?? "ACTIVE";
}

export function normalizeGymStatus(status?: string | null): AccessState {
  if (!status) return "ACTIVE";
  return GYM_ALIASES[String(status).toUpperCase()] ?? "ACTIVE";
}

/** Highest restriction wins: ARCHIVED > BLOCKED > FROZEN > ACTIVE. */
export const STATE_RANK: Record<AccessState, number> = {
  ARCHIVED: 3,
  BLOCKED: 2,
  FROZEN: 1,
  ACTIVE: 0,
};

export const STATE_BADGES: Record<AccessState, { dot: string; label: string; className: string }> = {
  ACTIVE: { dot: "●", label: "ACTIVE", className: "bg-[#34A853]/10 text-[#34A853] border-[#34A853]/25" },
  FROZEN: { dot: "●", label: "FROZEN", className: "bg-[#E8A33D]/10 text-[#E8A33D] border-[#E8A33D]/25" },
  BLOCKED: { dot: "●", label: "BLOCKED", className: "bg-[#D64545]/10 text-[#D64545] border-[#D64545]/25" },
  ARCHIVED: { dot: "●", label: "ARCHIVED", className: "bg-[var(--surface-sec)] text-[var(--text-sec)] border-[var(--border)]" },
};

export const BLOCK_REASONS = [
  "Payment overdue",
  "Policy violation",
  "Misconduct",
  "Requested by member",
  "Under review",
  "Other",
];

export const GYM_BLOCK_REASONS = [
  "Subscription overdue",
  "Policy violation",
  "Owner requested suspension",
  "Technical investigation",
  "Other",
];

/** Friendly copy for every denial code the API can return. */
export const ACCESS_MESSAGES: Record<string, { title: string; body: string }> = {
  MEMBER_BLOCKED: {
    title: "Your gym access is currently restricted",
    body: "Please contact your gym for assistance.",
  },
  MEMBER_ARCHIVED: {
    title: "Your membership is no longer active",
    body: "Please contact your gym if you would like to rejoin.",
  },
  GYM_BLOCKED: {
    title: "This gym is currently unavailable",
    body: "Please contact your gym or platform support for more information.",
  },
  GYM_ARCHIVED: {
    title: "This gym is no longer active",
    body: "Please contact platform support for more information.",
  },
  OWNER_GYM_BLOCKED: {
    title: "Gym access suspended",
    body: "Your gym is currently unavailable. Please contact support or your platform administrator.",
  },
  OWNER_GYM_ARCHIVED: {
    title: "Gym archived",
    body: "This gym is no longer active on the platform. Please contact support.",
  },
  SESSION_EXPIRED: {
    title: "Please sign in again",
    body: "Your session has expired.",
  },
};

export function accessMessage(code?: string | null) {
  return (code && ACCESS_MESSAGES[code]) || ACCESS_MESSAGES["SESSION_EXPIRED"];
}
