/**
 * Real Web Push (RFC 8291 aes128gcm + RFC 8292 VAPID) implemented with Web Crypto
 * so it runs inside Node or edge runtime without native binaries.
 */

function b64urlEncode(bytes: ArrayBuffer | Uint8Array): string {
  const arr = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  let str = "";
  for (const b of arr) str += String.fromCharCode(b);
  return btoa(str).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function b64urlDecode(input: string): Uint8Array {
  const pad = input.replace(/-/g, "+").replace(/_/g, "/");
  const padded = pad + "=".repeat((4 - (pad.length % 4)) % 4);
  const raw = atob(padded);
  const out = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) out[i] = raw.charCodeAt(i);
  return out;
}

function concat(...parts: Uint8Array[]): Uint8Array {
  const total = parts.reduce((n, p) => n + p.length, 0);
  const out = new Uint8Array(total);
  let offset = 0;
  for (const p of parts) {
    out.set(p, offset);
    offset += p.length;
  }
  return out;
}

export interface VapidKeyPair {
  publicKey: string;
  privateKeyJwk: JsonWebKey;
  subject: string;
  createdAt: string;
}

/** Generates a genuine P-256 VAPID key pair. */
export async function generateVapidKeys(subject = "mailto:support@gym.app"): Promise<VapidKeyPair> {
  const pair = await crypto.subtle.generateKey({ name: "ECDSA", namedCurve: "P-256" }, true, ["sign", "verify"]);
  const rawPublic = await crypto.subtle.exportKey("raw", pair.publicKey);
  const jwk = await crypto.subtle.exportKey("jwk", pair.privateKey);
  return { publicKey: b64urlEncode(rawPublic), privateKeyJwk: jwk, subject, createdAt: new Date().toISOString() };
}

async function signVapidJwt(audience: string, keys: VapidKeyPair): Promise<string> {
  const header = b64urlEncode(new TextEncoder().encode(JSON.stringify({ typ: "JWT", alg: "ES256" })));
  const payload = b64urlEncode(
    new TextEncoder().encode(
      JSON.stringify({ aud: audience, exp: Math.floor(Date.now() / 1000) + 12 * 60 * 60, sub: keys.subject || "mailto:support@gym.app" }),
    ),
  );
  const signingInput = `${header}.${payload}`;
  const privateKey = await crypto.subtle.importKey(
    "jwk",
    { ...keys.privateKeyJwk, key_ops: ["sign"], ext: true },
    { name: "ECDSA", namedCurve: "P-256" },
    false,
    ["sign"],
  );
  const signature = await crypto.subtle.sign({ name: "ECDSA", hash: "SHA-256" }, privateKey, new TextEncoder().encode(signingInput));
  return `${signingInput}.${b64urlEncode(signature)}`;
}

async function hkdf(salt: Uint8Array, ikm: Uint8Array, info: Uint8Array, length: number): Promise<Uint8Array> {
  const key = await crypto.subtle.importKey("raw", ikm as unknown as ArrayBuffer, "HKDF", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({ name: "HKDF", hash: "SHA-256", salt: salt as unknown as ArrayBuffer, info: info as unknown as ArrayBuffer }, key, length * 8);
  return new Uint8Array(bits);
}

async function encryptPayload(payload: string, p256dh: string, authSecret: string) {
  const clientPublic = b64urlDecode(p256dh);
  const auth = b64urlDecode(authSecret);
  const local = await crypto.subtle.generateKey({ name: "ECDH", namedCurve: "P-256" }, true, ["deriveBits"]);
  const localPublicRaw = new Uint8Array(await crypto.subtle.exportKey("raw", local.publicKey));
  const clientKey = await crypto.subtle.importKey("raw", clientPublic as unknown as ArrayBuffer, { name: "ECDH", namedCurve: "P-256" }, false, []);
  const sharedBits = await crypto.subtle.deriveBits({ name: "ECDH", public: clientKey }, local.privateKey, 256);
  const shared = new Uint8Array(sharedBits);
  const enc = new TextEncoder();
  const keyInfo = concat(enc.encode("WebPush: info\0"), clientPublic, localPublicRaw);
  const ikm = await hkdf(auth, shared, keyInfo, 32);
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const cek = await hkdf(salt, ikm, enc.encode("Content-Encoding: aes128gcm\0"), 16);
  const nonce = await hkdf(salt, ikm, enc.encode("Content-Encoding: nonce\0"), 12);
  const aesKey = await crypto.subtle.importKey("raw", cek as unknown as ArrayBuffer, "AES-GCM", false, ["encrypt"]);
  const plaintext = concat(enc.encode(payload), new Uint8Array([2]));
  const ciphertext = new Uint8Array(
    await crypto.subtle.encrypt({ name: "AES-GCM", iv: nonce as unknown as ArrayBuffer }, aesKey, plaintext as unknown as ArrayBuffer),
  );
  const recordSize = new Uint8Array([0, 0, 16, 0]); // 4096
  return concat(salt, recordSize, new Uint8Array([localPublicRaw.length]), localPublicRaw, ciphertext);
}

export interface PushSubscriptionShape {
  endpoint: string;
  keys?: { p256dh?: string; auth?: string };
}

export interface PushSendResult {
  ok: boolean;
  status: number;
  expired: boolean;
  error?: string;
}

/** Sends one real Web Push message. Never throws. */
export async function sendWebPush(
  subscription: PushSubscriptionShape,
  payload: Record<string, unknown>,
  keys: VapidKeyPair,
  ttlSeconds = 60 * 60 * 24,
): Promise<PushSendResult> {
  try {
    const p256dh = subscription.keys?.p256dh;
    const auth = subscription.keys?.auth;
    if (!subscription.endpoint || !p256dh || !auth) {
      return { ok: false, status: 0, expired: true, error: "Incomplete subscription" };
    }
    const audience = new URL(subscription.endpoint).origin;
    const jwt = await signVapidJwt(audience, keys);
    const body = await encryptPayload(JSON.stringify(payload), p256dh, auth);
    const response = await fetch(subscription.endpoint, {
      method: "POST",
      headers: {
        Authorization: `vapid t=${jwt}, k=${keys.publicKey}`,
        "Content-Encoding": "aes128gcm",
        "Content-Type": "application/octet-stream",
        TTL: String(ttlSeconds),
      },
      body: body as unknown as BodyInit,
    });
    return {
      ok: response.ok,
      status: response.status,
      expired: response.status === 404 || response.status === 410,
      ...(response.ok ? {} : { error: `Push service responded ${response.status}` }),
    };
  } catch (error) {
    return { ok: false, status: 0, expired: false, error: error instanceof Error ? error.message : "Push failed" };
  }
}
