/**
 * Single source of truth for time-based greetings.
 * Always evaluated in the gym timezone (India / Asia/Kolkata).
 */

export const GYM_TIMEZONE = "Asia/Kolkata";

export function getGymHour(date: Date = new Date(), timeZone: string = GYM_TIMEZONE): number {
  try {
    const hourStr = new Intl.DateTimeFormat("en-US", { timeZone, hour: "2-digit", hour12: false }).format(date);
    const hour = Number(hourStr);
    return Number.isFinite(hour) ? hour % 24 : date.getHours();
  } catch (e) {
    return date.getHours();
  }
}

/** 
 * Time ranges according to spec:
 * 05:00 - 11:59 -> Good morning
 * 12:00 - 16:59 -> Good afternoon
 * 17:00 - 04:59 -> Good evening
 */
export function getGreeting(date: Date = new Date(), timeZone: string = GYM_TIMEZONE): string {
  const hour = getGymHour(date, timeZone);
  if (hour >= 5 && hour < 12) return "Good morning";
  if (hour >= 12 && hour < 17) return "Good afternoon";
  return "Good evening";
}

const BANNED_NAME_FALLBACKS = new Set(["ayush", "owner", "user", "admin", "gym owner", "super admin"]);

export function cleanOwnerFirstName(fullName?: string | null): string {
  if (!fullName) return "";
  const trimmed = fullName.trim();
  if (!trimmed) return "";
  const firstWord = trimmed.split(/\s+/)[0];
  if (BANNED_NAME_FALLBACKS.has(firstWord.toLowerCase())) {
    return "";
  }
  return firstWord.charAt(0).toUpperCase() + firstWord.slice(1).toLowerCase();
}

/**
 * Greeting line builder.
 * Examples: "Good morning, Alex", "Good afternoon, Priya", "Good evening"
 */
export function getGreetingLine(name?: string | null, date: Date = new Date(), timeZone: string = GYM_TIMEZONE): string {
  const greeting = getGreeting(date, timeZone);
  const cleanName = cleanOwnerFirstName(name);
  return cleanName ? `${greeting}, ${cleanName}` : greeting;
}

export function firstName(fullName?: string | null): string {
  return cleanOwnerFirstName(fullName);
}
