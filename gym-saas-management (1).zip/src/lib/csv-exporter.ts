// Utility for exporting gym data to CSV format with proper string escaping

export function downloadCSV(filename: string, csvContent: string) {
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

function escapeCSVField(field: any): string {
  if (field === null || field === undefined) return '""';
  const str = String(field).replace(/"/g, '""');
  return `"${str}"`;
}

export function exportMembersToCSV(members: any[], gymName = 'Gym') {
  const headers = [
    'Member ID',
    'Full Name',
    'Phone Number',
    'Email',
    'Locality / City',
    'Gender',
    'Age',
    'Membership Plan',
    'Status',
    'Payment Status',
    'Joining Date',
    'Plan Expiry Date',
    'Attendance Streak (Days)'
  ];

  const rows = members.map(m => [
    m.memberDisplayId || m.memberCode || m.id || '',
    m.fullName || '',
    m.phone || '',
    m.email || '',
    m.location || m.locality || '',
    m.gender || '',
    m.age || '',
    m.planName || 'Monthly Plan',
    m.status || 'Active',
    m.due || m.paymentStatus === 'DUE' ? 'Pending Dues' : (m.paymentStatus || 'PAID'),
    m.joinedDate || m.createdAt?.split('T')[0] || '',
    m.membershipExpiry || m.endDate || 'N/A',
    m.attendanceStreak || 0
  ]);

  const csvContent = [
    headers.map(escapeCSVField).join(','),
    ...rows.map(row => row.map(escapeCSVField).join(','))
  ].join('\n');

  const todayStr = new Date().toISOString().split('T')[0];
  const sanitizedGymName = gymName.toLowerCase().replace(/[^a-z0-9]/g, '_');
  downloadCSV(`${sanitizedGymName}_members_${todayStr}.csv`, csvContent);
}

export function exportAttendanceToCSV(attendanceList: any[], gymName = 'Gym') {
  const headers = [
    'Date',
    'Time',
    'Member ID',
    'Member Name',
    'Phone Number',
    'Check-in Status',
    'Check-in Method'
  ];

  const rows = attendanceList.map(item => [
    item.date || item.checkInTime?.split('T')[0] || new Date().toISOString().split('T')[0],
    item.time || item.checkInTime?.split('T')[1]?.slice(0, 5) || '10:00 AM',
    item.memberCode || item.memberDisplayId || item.memberId || '',
    item.memberName || item.fullName || 'Member',
    item.phone || '',
    item.status || 'PRESENT',
    item.method || item.type || 'QR_SCAN'
  ]);

  const csvContent = [
    headers.map(escapeCSVField).join(','),
    ...rows.map(row => row.map(escapeCSVField).join(','))
  ].join('\n');

  const todayStr = new Date().toISOString().split('T')[0];
  const sanitizedGymName = gymName.toLowerCase().replace(/[^a-z0-9]/g, '_');
  downloadCSV(`${sanitizedGymName}_attendance_${todayStr}.csv`, csvContent);
}
