/**
 * Mobile Number + Password Authentication Session Helpers
 */

export const APP_SESSION_KEYS = ["admin_session", "gym_session", "member_session"] as const;

export async function getAccessToken(): Promise<string | null> {
  try {
    return localStorage.getItem("auth_token");
  } catch {
    return null;
  }
}

/** POST helper that attaches the session bearer token. */
export async function authPost(path: string, body?: unknown) {
  const token = await getAccessToken();
  const response = await fetch(path, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: JSON.stringify(body ?? {}),
  });
  const data = await response.json().catch(() => ({}));
  return { status: response.status, data } as { status: number; data: any };
}

/** GET helper that attaches the session bearer token. */
export async function authGet(path: string) {
  const token = await getAccessToken();
  const response = await fetch(path, {
    headers: token ? { Authorization: `Bearer ${token}` } : {},
  });
  const data = await response.json().catch(() => ({}));
  return { status: response.status, data } as { status: number; data: any };
}

/**
 * Server-side revalidation of the live session.
 */
export async function checkAccessState(): Promise<{ allowed: boolean; code?: string; role?: string }> {
  try {
    const { status, data } = await authPost("/api/access/state");
    if (status === 401) return { allowed: false, code: "SESSION_EXPIRED" };
    return { allowed: !!data?.allowed, code: data?.code, role: data?.role };
  } catch {
    return { allowed: true };
  }
}

export function clearAppSessions() {
  for (const key of APP_SESSION_KEYS) localStorage.removeItem(key);
  localStorage.removeItem("auth_token");
  localStorage.removeItem("auth_user");
  localStorage.removeItem("owner_onboarding_progress");
}

/** Reads a stored application context. */
export function readAppSession(key: (typeof APP_SESSION_KEYS)[number], authUserId?: string) {
  const raw = localStorage.getItem(key);
  if (!raw) return null;
  try {
    const parsed = JSON.parse(raw);
    if (!parsed) {
      localStorage.removeItem(key);
      return null;
    }
    if (authUserId && parsed.authUserId && parsed.authUserId !== authUserId) {
      localStorage.removeItem(key);
      return null;
    }
    return parsed;
  } catch {
    localStorage.removeItem(key);
    return null;
  }
}

/** Revokes the application context and mobile auth session, then returns home. */
export async function signOutEverything() {
  clearAppSessions();
  window.location.replace("/");
}
