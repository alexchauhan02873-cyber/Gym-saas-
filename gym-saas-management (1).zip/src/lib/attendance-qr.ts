/**
 * Canonical attendance-QR payload format.
 * ONE source of truth shared by the owner QR generator (DailyQR page),
 * the member scanner (camera + gallery) and the server validator, so the
 * generated string and the expected string can never drift apart again.
 *
 * Wire format (version 1):
 *   {"type":"GYM_ATTENDANCE","version":1,"token":"<opaque session token>"}
 */

export const ATTENDANCE_QR_TYPE = "GYM_ATTENDANCE";
export const ATTENDANCE_QR_VERSION = 1;

export type AttendanceQrPayload = {
  type: typeof ATTENDANCE_QR_TYPE;
  version: number;
  token: string;
};

/** Builds the exact string that gets encoded into the QR image. */
export function buildAttendanceQrPayload(token: string): string {
  const payload: AttendanceQrPayload = {
    type: ATTENDANCE_QR_TYPE,
    version: ATTENDANCE_QR_VERSION,
    token,
  };
  return JSON.stringify(payload);
}

export type ParsedAttendanceQr =
  | { validFormat: true; token: string; version: number; legacy: boolean }
  | { validFormat: false; reason: string };

const TOKEN_PATTERN = /^[A-Za-z0-9_-]{16,128}$/;

/**
 * Parses a scanned string. Accepts:
 *  - version 1 canonical JSON payloads
 *  - legacy owner payloads: {"gymId":"...","token":"QR_...","date":"..."}
 *  - a bare legacy token string
 * Anything else is a genuine format error (never reported as "wrong gym").
 */
export function parseAttendanceQrPayload(raw: unknown): ParsedAttendanceQr {
  if (typeof raw !== "string") return { validFormat: false, reason: "Payload missing." };

  // Strip whitespace/newlines/zero-width characters some decoders add.
  const cleaned = raw.replace(/[\u200B-\u200D\uFEFF]/g, "").trim();
  if (!cleaned) return { validFormat: false, reason: "Payload empty." };

  if (cleaned.startsWith("{")) {
    let parsed: any;
    try {
      parsed = JSON.parse(cleaned);
    } catch {
      return { validFormat: false, reason: "Payload is not readable." };
    }

    const token = typeof parsed?.token === "string" ? parsed.token.trim() : "";
    if (!token) return { validFormat: false, reason: "Payload has no token." };

    if (parsed.type === ATTENDANCE_QR_TYPE) {
      const version = Number(parsed.version) || 1;
      if (!TOKEN_PATTERN.test(token)) return { validFormat: false, reason: "Token format invalid." };
      return { validFormat: true, token, version, legacy: false };
    }

    // Legacy owner payload ({gymId, token, date}) - structurally valid, older format.
    if (typeof parsed?.gymId === "string") {
      return { validFormat: true, token, version: 0, legacy: true };
    }

    return { validFormat: false, reason: "Not a gym attendance QR." };
  }

  // Bare token (legacy QR images encoded the token alone).
  if (cleaned.startsWith("QR_") || TOKEN_PATTERN.test(cleaned)) {
    return { validFormat: true, token: cleaned, version: 0, legacy: !cleaned.match(TOKEN_PATTERN) };
  }

  return { validFormat: false, reason: "Not a gym attendance QR." };
}

/** UI copy for every backend result code. Never a catch-all "Invalid QR". */
export const SCAN_MESSAGES: Record<string, { title: string; message: string }> = {
  INVALID_QR_FORMAT: { title: "Invalid QR", message: "That code isn't a gym attendance QR. Please scan the QR shown at your gym." },
  INVALID_QR_TOKEN: { title: "Invalid QR", message: "This QR isn't recognised. Ask the front desk to show today's attendance QR." },
  QR_EXPIRED: { title: "QR Expired", message: "Today's attendance QR is no longer active." },
  QR_REVOKED: { title: "QR Revoked", message: "This QR has been turned off by your gym." },
  WRONG_GYM: { title: "Wrong Gym", message: "This QR belongs to another gym." },
  ALREADY_CHECKED_IN: { title: "Already Present", message: "You're already marked present today." },
  MEMBERSHIP_INACTIVE: { title: "Membership Inactive", message: "Your membership isn't active. Please contact your gym." },
  NOT_ALLOWED: { title: "Access Restricted", message: "Your account can't check in right now. Please contact your gym." },
  SESSION_EXPIRED: { title: "Session Expired", message: "Please sign in again to mark your attendance." },
  RATE_LIMITED: { title: "Too Many Attempts", message: "Too many scan attempts. Please wait a moment and try again." },
  ATTENDANCE_VERIFICATION_ERROR: { title: "Verification Failed", message: "Attendance couldn't be verified right now." },
  NETWORK_ERROR: { title: "No Connection", message: "QR scanned, but we couldn't verify it. Check your internet connection and try again." },
  CAMERA_DENIED: { title: "Camera Blocked", message: "Camera permission is blocked. Allow camera access, or upload the QR from your gallery." },
  CAMERA_UNAVAILABLE: { title: "Camera Unavailable", message: "No usable camera was found. You can upload the QR image from your gallery." },
  CAMERA_INSECURE: { title: "Camera Unavailable", message: "Camera scanning needs a secure (https) connection. Upload the QR from your gallery instead." },
};

/** Maps an HTTP status to a canonical result code. */
export function codeFromStatus(status: number, fallback = "ATTENDANCE_VERIFICATION_ERROR"): string {
  switch (status) {
    case 400: return "INVALID_QR_FORMAT";
    case 401: return "SESSION_EXPIRED";
    case 403: return "NOT_ALLOWED";
    case 404: return "INVALID_QR_TOKEN";
    case 409: return "ALREADY_CHECKED_IN";
    case 410: return "QR_EXPIRED";
    case 422: return "MEMBERSHIP_INACTIVE";
    case 429: return "RATE_LIMITED";
    default: return status >= 500 ? "ATTENDANCE_VERIFICATION_ERROR" : fallback;
  }
}

/** Maps a getUserMedia DOMException name to a camera state code. */
export function codeFromCameraError(name?: string): string {
  switch (name) {
    case "NotAllowedError":
    case "SecurityError":
      return "CAMERA_DENIED";
    case "NotFoundError":
    case "OverconstrainedError":
      return "CAMERA_UNAVAILABLE";
    case "NotReadableError":
    case "AbortError":
      return "CAMERA_UNAVAILABLE";
    default:
      return "CAMERA_UNAVAILABLE";
  }
}
