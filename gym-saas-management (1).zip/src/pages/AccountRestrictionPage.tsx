import React, { useEffect, useState } from 'react';
import { ShieldAlert, Snowflake, Archive, Headset, LogOut, AlertCircle, Building2, User, Clock } from 'lucide-react';
import { useSearchParams, useNavigate } from '@/lib/router-compat';
import { signOutEverything } from '@/lib/app-auth';

export default function AccountRestrictionPage() {
  const [params] = useSearchParams();
  const navigate = useNavigate();

  const [status, setStatus] = useState<'FROZEN' | 'BLOCKED' | 'ARCHIVED'>('BLOCKED');
  const [reason, setReason] = useState<string>('');
  const [gymName, setGymName] = useState<string>('');
  const [userName, setUserName] = useState<string>('');
  const [role, setRole] = useState<'owner' | 'member'>('owner');
  const [updatedAt, setUpdatedAt] = useState<string>('');

  useEffect(() => {
    // 1. Try URL parameters first
    const urlStatus = (params.get('status') || params.get('type') || '').toUpperCase();
    const urlReason = params.get('reason');
    const urlGym = params.get('gymName');
    const urlUser = params.get('userName');
    const urlRole = params.get('role');
    const urlDate = params.get('date');

    // 2. Try auth session in localStorage
    const authUser = localStorage.getItem('auth_user');
    const gymSession = localStorage.getItem('gym_session');
    const memberSession = localStorage.getItem('member_session');

    let resolvedStatus: 'FROZEN' | 'BLOCKED' | 'ARCHIVED' = 'BLOCKED';
    let resolvedReason = 'Account access restricted by administration.';
    let resolvedGym = 'Gym Workspace';
    let resolvedUser = '';
    let resolvedRole: 'owner' | 'member' = 'owner';
    let resolvedDate = new Date().toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });

    if (urlStatus === 'FROZEN' || urlStatus === 'BLOCKED' || urlStatus === 'ARCHIVED') {
      resolvedStatus = urlStatus;
    }

    if (urlReason) resolvedReason = urlReason;
    if (urlGym) resolvedGym = urlGym;
    if (urlUser) resolvedUser = urlUser;
    if (urlRole === 'member' || urlRole === 'owner') resolvedRole = urlRole;
    if (urlDate) resolvedDate = urlDate;

    // Check stored session data
    if (gymSession) {
      try {
        const parsed = JSON.parse(gymSession);
        if (parsed.accountStatus && parsed.accountStatus.status) {
          resolvedStatus = parsed.accountStatus.status;
          if (parsed.accountStatus.reason) resolvedReason = parsed.accountStatus.reason;
          if (parsed.gymName) resolvedGym = parsed.gymName;
          resolvedRole = 'owner';
        }
      } catch {}
    } else if (memberSession) {
      try {
        const parsed = JSON.parse(memberSession);
        if (parsed.accountStatus && parsed.accountStatus.status) {
          resolvedStatus = parsed.accountStatus.status;
          if (parsed.accountStatus.reason) resolvedReason = parsed.accountStatus.reason;
          if (parsed.memberName) resolvedUser = parsed.memberName;
          resolvedRole = 'member';
        }
      } catch {}
    }

    setStatus(resolvedStatus);
    setReason(resolvedReason);
    setGymName(resolvedGym);
    setUserName(resolvedUser);
    setRole(resolvedRole);
    setUpdatedAt(resolvedDate);
  }, [params]);

  const handleSignOut = () => {
    void signOutEverything();
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-[var(--bg)] text-[var(--text)] flex items-center justify-center px-4 py-12 relative overflow-hidden">
      <div className="w-full max-w-md clay-raised rounded-[28px] p-7 md:p-8 space-y-6 text-center shadow-xl border border-[var(--border)] relative z-10 animate-fade-in">
        
        {/* Status Icon Badge */}
        <div className="flex justify-center">
          {status === 'FROZEN' && (
            <div className="w-20 h-20 rounded-3xl bg-amber-500/10 border border-amber-500/20 text-amber-500 flex items-center justify-center shadow-sm">
              <Snowflake size={40} className="animate-pulse" />
            </div>
          )}
          {status === 'BLOCKED' && (
            <div className="w-20 h-20 rounded-3xl bg-red-500/10 border border-red-500/20 text-[#D64545] flex items-center justify-center shadow-sm">
              <ShieldAlert size={40} />
            </div>
          )}
          {status === 'ARCHIVED' && (
            <div className="w-20 h-20 rounded-3xl bg-neutral-500/10 border border-neutral-500/20 text-neutral-400 flex items-center justify-center shadow-sm">
              <Archive size={40} />
            </div>
          )}
        </div>

        {/* Title and Badge */}
        <div className="space-y-2">
          <span
            className={`text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-full border inline-block ${
              status === 'FROZEN'
                ? 'bg-amber-500/10 text-amber-500 border-amber-500/25'
                : status === 'BLOCKED'
                ? 'bg-red-500/10 text-[#D64545] border-red-500/25'
                : 'bg-neutral-500/10 text-neutral-400 border-neutral-500/25'
            }`}
          >
            ACCOUNT STATUS: {status}
          </span>

          <h1 className="text-xl font-black uppercase tracking-wider text-[var(--text)] pt-1">
            {status === 'FROZEN' && (role === 'owner' ? 'Gym Owner Account Frozen' : 'Membership Account Frozen')}
            {status === 'BLOCKED' && (role === 'owner' ? 'Gym Owner Account Blocked' : 'Membership Account Blocked')}
            {status === 'ARCHIVED' && (role === 'owner' ? 'Gym Account Archived' : 'Membership Account Archived')}
          </h1>

          <p className="text-xs text-[var(--text-sec)] font-medium leading-relaxed max-w-sm mx-auto">
            {status === 'FROZEN' && 'Your account operations are temporarily restricted by administration.'}
            {status === 'BLOCKED' && 'Access to the protected dashboard and features has been blocked.'}
            {status === 'ARCHIVED' && 'This account is no longer active on the platform.'}
          </p>
        </div>

        {/* Details Card */}
        <div className="neo-pressed p-4 rounded-2xl text-left space-y-3.5 border border-[var(--border)]">
          {gymName && (
            <div className="flex items-center gap-2 text-xs font-bold text-[var(--text)]">
              <Building2 size={16} className="text-neutral-400 shrink-0" />
              <span className="truncate">{gymName}</span>
            </div>
          )}

          {userName && (
            <div className="flex items-center gap-2 text-xs font-bold text-[var(--text)]">
              <User size={16} className="text-neutral-400 shrink-0" />
              <span className="truncate">{userName}</span>
            </div>
          )}

          <div className="pt-2 border-t border-[var(--border)]">
            <span className="text-[10px] font-extrabold uppercase tracking-widest text-[var(--text-sec)] block mb-1">
              Restriction Reason
            </span>
            <p className="text-xs font-bold text-[var(--text)] leading-snug bg-white/50 dark:bg-black/30 p-2.5 rounded-xl border border-[var(--border)]">
              {reason || 'Administrative restriction placed on account.'}
            </p>
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-[var(--border)] text-[10px] font-bold">
            <span className="text-[var(--text-sec)] uppercase tracking-wider flex items-center gap-1">
              <Clock size={12} /> Status Updated:
            </span>
            <span className="text-[var(--text)]">{updatedAt}</span>
          </div>
        </div>

        {/* Scope Info Box */}
        <div className="p-3.5 rounded-2xl bg-neutral-500/5 border border-[var(--border)] text-left text-[11px] space-y-1">
          <span className="font-bold text-[var(--text)] block">What is restricted:</span>
          <ul className="list-disc list-inside text-[var(--text-sec)] space-y-0.5 text-[10px]">
            {role === 'owner' ? (
              <>
                <li>Protected Gym Owner Dashboard access</li>
                <li>Member check-ins and payment recording</li>
                <li>Financial reports and analytics</li>
              </>
            ) : (
              <>
                <li>Protected Member Dashboard access</li>
                <li>QR code attendance check-in</li>
                <li>Workout logging and member statistics</li>
              </>
            )}
          </ul>
          <p className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold pt-1">
            ✓ Historical payment & attendance data remains safely preserved in server records.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col gap-3 pt-2">
          <a
            href={`https://wa.me/919263604732?text=${encodeURIComponent(
              `Hello Support, my ${role} account (${gymName || userName || 'Account'}) is currently ${status}. Reason: ${reason}. Please assist.`
            )}`}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full h-12 rounded-2xl bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 hover:opacity-90 active:scale-95 transition-all shadow-md cursor-pointer"
          >
            <Headset size={16} /> Contact Support
          </a>

          <button
            type="button"
            onClick={handleSignOut}
            className="w-full h-12 rounded-2xl bg-white dark:bg-[#1c1c1c] border border-neutral-300 dark:border-neutral-700 text-xs font-bold uppercase tracking-widest text-[var(--text)] flex items-center justify-center gap-2 hover:bg-neutral-100 dark:hover:bg-neutral-800 active:scale-95 transition-all cursor-pointer shadow-sm"
          >
            <LogOut size={16} /> Sign Out / Change Account
          </button>
        </div>
      </div>
    </div>
  );
}
