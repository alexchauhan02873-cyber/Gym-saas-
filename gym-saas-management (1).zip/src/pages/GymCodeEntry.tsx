import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from '@/lib/router-compat';
import { motion, AnimatePresence } from 'motion/react';
import {
  Check,
  AlertCircle,
  Loader2,
  Dumbbell,
  Phone,
  Lock,
  Eye,
  EyeOff,
  ArrowRight,
  LogOut,
  ShieldCheck,
  KeyRound,
  UserPlus,
} from 'lucide-react';
import LanguageSelector from '@/components/LanguageSelector';
import { t, getStoredLanguage, type Language } from '@/lib/i18n';
import { clearAppSessions } from '@/lib/app-auth';

type Phase = 'loading' | 'auth' | 'code';
type AuthMode = 'login' | 'signup' | 'forgot';

export default function GymCodeEntry() {
  const navigate = useNavigate();
  const [phase, setPhase] = useState<Phase>('loading');
  const [authMode, setAuthMode] = useState<AuthMode>('login');
  const [lang, setLang] = useState<Language>(getStoredLanguage());

  // Form State
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  // Status State
  const [authLoading, setAuthLoading] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [authSuccessMsg, setAuthSuccessMsg] = useState<string | null>(null);

  // Logged-in Auth User
  const [authUser, setAuthUser] = useState<{ id: string; phone: string } | null>(null);

  // Forgot Password State
  const [forgotStep, setForgotStep] = useState<'request' | 'reset'>('request');
  const [recoveryOtp, setRecoveryOtp] = useState('');
  const [demoOtpHint, setDemoOtpHint] = useState<string | null>(null);

  // Code Entry State
  const [code, setCode] = useState<string[]>(Array(6).fill(''));
  const [codeStatus, setCodeStatus] = useState<'idle' | 'verifying' | 'success' | 'error'>('idle');
  const [codeErrorMessage, setCodeErrorMessage] = useState('');

  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);
  const verifyingRef = useRef(false);

  const applyRoleContext = useCallback(
    (user: { id: string; phone: string }, roleContext: any) => {
      if (!roleContext || !roleContext.role || !roleContext.redirect) {
        return false;
      }

      const { role, gymId, memberId, gymName, memberName, onboardingCompleted, token, redirect } = roleContext;

      if (role === 'super_admin') {
        localStorage.setItem(
          'admin_session',
          JSON.stringify({ role: 'super_admin', token: token || `asess_${Date.now()}`, authUserId: user.id })
        );
        navigate(redirect);
        return true;
      }

      if (role === 'owner') {
        localStorage.setItem(
          'gym_session',
          JSON.stringify({ gymId, gymName: gymName || 'Gym Workspace', role: 'owner', authUserId: user.id })
        );
        navigate(redirect);
        return true;
      }

      if (role === 'member') {
        const isCompleted = onboardingCompleted !== false;
        localStorage.setItem(
          'member_session',
          JSON.stringify({
            gymId,
            memberId,
            role: 'member',
            memberName,
            token,
            onboardingCompleted: isCompleted,
            authUserId: user.id,
          })
        );
        navigate(redirect);
        return true;
      }

      if (role === 'owner_onboarding') {
        navigate('/owner/onboarding');
        return true;
      }

      return false;
    },
    [navigate]
  );

  const applyContext = useCallback((data: any) => {
    if (data.role === 'super_admin') {
      localStorage.setItem('admin_session', JSON.stringify({ role: 'super_admin', token: data.token, authUserId: authUser?.id }));
      navigate('/admin/dashboard');
    } else if (data.role === 'owner_onboarding') {
      navigate('/owner/onboarding');
    } else if (data.role === 'owner') {
      localStorage.setItem('gym_session', JSON.stringify({ gymId: data.gymId, gymName: data.gymName, role: 'owner', authUserId: authUser?.id }));
      if (data.onboardingCompleted === false) {
        navigate('/owner/onboarding');
      } else {
        navigate('/owner/dashboard');
      }
    } else if (data.role === 'member') {
      const isCompleted = data.onboardingCompleted !== false && data.onboardingComplete !== false;
      localStorage.setItem('member_session', JSON.stringify({ gymId: data.gymId, memberId: data.memberId, role: 'member', token: data.token, onboardingCompleted: isCompleted, authUserId: authUser?.id }));
      if (!isCompleted) {
        navigate('/member/onboarding');
      } else {
        navigate('/member/dashboard');
      }
    }
  }, [navigate, authUser]);

  // Clean phone input to keep digits only
  const handlePhoneChange = (val: string) => {
    const digits = val.replace(/\D/g, '');
    if (digits.length <= 10) {
      setPhone(digits);
    }
  };

  // Validate session on boot
  useEffect(() => {
    const initAuth = async () => {
      const storedToken = localStorage.getItem('auth_token');
      if (storedToken) {
        try {
          const response = await fetch('/api/auth/session', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${storedToken}` },
          });
          const data = await response.json();
          if (data.success && data.user) {
            setAuthUser(data.user);
            if (data.roleContext && applyRoleContext(data.user, data.roleContext)) {
              return;
            }
            setPhase('code');
            return;
          }
        } catch {
          // Token invalid
        }
      }
      clearAppSessions();
      setPhase('auth');
    };

    void initAuth();
  }, [applyRoleContext]);

  useEffect(() => {
    if (phase === 'code' && inputRefs.current[0]) {
      setTimeout(() => inputRefs.current[0]?.focus(), 150);
    }
  }, [phase]);

  // Auth Submit Handlers
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setAuthSuccessMsg(null);

    const clean = phone.trim();
    if (!/^[6-9]\d{9}$/.test(clean)) {
      setAuthError('Please enter a valid 10-digit Indian mobile number.');
      return;
    }

    if (!password) {
      setAuthError('Please enter your password.');
      return;
    }

    setAuthLoading(true);
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone: clean, password }),
      });
      const data = await response.json();

      if (data.success) {
        localStorage.setItem('auth_token', data.token);
        localStorage.setItem('auth_user', JSON.stringify(data.user));
        setAuthUser(data.user);
        setAuthLoading(false);

        if (data.roleContext && applyRoleContext(data.user, data.roleContext)) {
          return;
        }
        setPhase('code');
      } else {
        setAuthError(data.message || 'Login failed. Please check your credentials.');
        setAuthLoading(false);
      }
    } catch {
      setAuthError('Network error during login. Please try again.');
      setAuthLoading(false);
    }
  };

  const handleSignupSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setAuthSuccessMsg(null);

    const clean = phone.trim();
    if (!/^[6-9]\d{9}$/.test(clean)) {
      setAuthError('Please enter a valid 10-digit Indian mobile number starting with 6, 7, 8, or 9.');
      return;
    }

    if (!password || password.length < 8) {
      setAuthError('Password must be at least 8 characters long.');
      return;
    }

    if (password !== confirmPassword) {
      setAuthError('Password and Confirm Password do not match.');
      return;
    }

    setAuthLoading(true);
    try {
      const response = await fetch('/api/auth/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone: clean, password, confirmPassword }),
      });
      const data = await response.json();

      if (data.success) {
        localStorage.setItem('auth_token', data.token);
        localStorage.setItem('auth_user', JSON.stringify(data.user));
        setAuthUser(data.user);
        setAuthLoading(false);

        if (data.roleContext && applyRoleContext(data.user, data.roleContext)) {
          return;
        }
        setPhase('code');
      } else {
        setAuthError(data.message || 'Failed to create account.');
        setAuthLoading(false);
      }
    } catch {
      setAuthError('Network error during account creation. Please try again.');
      setAuthLoading(false);
    }
  };

  const handleRequestOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setAuthSuccessMsg(null);

    const clean = phone.trim();
    if (!/^[6-9]\d{9}$/.test(clean)) {
      setAuthError('Please enter a valid 10-digit Indian mobile number.');
      return;
    }

    setAuthLoading(true);
    try {
      const response = await fetch('/api/auth/forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone: clean, action: 'request_otp' }),
      });
      const data = await response.json();
      setAuthLoading(false);

      if (data.success) {
        setForgotStep('reset');
        if (data.otp) setDemoOtpHint(data.otp);
        setAuthSuccessMsg(data.message || 'Recovery verification code sent.');
      } else {
        setAuthError(data.message || 'Could not send recovery code.');
      }
    } catch {
      setAuthError('Network error requesting recovery code.');
      setAuthLoading(false);
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setAuthSuccessMsg(null);

    const clean = phone.trim();
    if (!/^[6-9]\d{9}$/.test(clean)) {
      setAuthError('Please enter a valid 10-digit Indian mobile number.');
      return;
    }

    if (!recoveryOtp || recoveryOtp.trim().length !== 6) {
      setAuthError('Please enter the 6-digit recovery code.');
      return;
    }

    if (!password || password.length < 8) {
      setAuthError('New password must be at least 8 characters long.');
      return;
    }

    if (password !== confirmPassword) {
      setAuthError('New password and confirm password do not match.');
      return;
    }

    setAuthLoading(true);
    try {
      const response = await fetch('/api/auth/forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          phone: clean,
          action: 'reset_password',
          otp: recoveryOtp.trim(),
          newPassword: password,
          confirmPassword,
        }),
      });
      const data = await response.json();
      setAuthLoading(false);

      if (data.success) {
        setAuthSuccessMsg('Password reset successfully! Log in with your new password.');
        setPassword('');
        setConfirmPassword('');
        setRecoveryOtp('');
        setForgotStep('request');
        setDemoOtpHint(null);
        setTimeout(() => {
          setAuthMode('login');
        }, 1500);
      } else {
        setAuthError(data.message || 'Password reset failed.');
      }
    } catch {
      setAuthError('Network error during password reset.');
      setAuthLoading(false);
    }
  };

  const handleAuthSignOut = () => {
    clearAppSessions();
    setAuthUser(null);
    setPassword('');
    setConfirmPassword('');
    setPhase('auth');
    setAuthMode('login');
  };

  // Access Code Handlers
  const handleCodeChange = (index: number, value: string) => {
    if (!/^[a-zA-Z0-9]*$/.test(value)) return;
    const newCode = [...code];
    newCode[index] = value.toUpperCase();
    setCode(newCode);
    if (value && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }
    if (value && index === 5 && newCode.every((char) => char !== '')) {
      inputRefs.current[index]?.blur();
      handleVerifyCode(newCode.join(''));
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !code[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const handlePaste = (e: React.ClipboardEvent) => {
    e.preventDefault();
    const pastedData = e.clipboardData.getData('text/plain').toUpperCase().replace(/[^A-Z0-9]/g, '');
    if (pastedData) {
      const newCode = Array(6).fill('');
      for (let i = 0; i < Math.min(pastedData.length, 6); i++) {
        newCode[i] = pastedData[i];
      }
      setCode(newCode);
      const nextIndex = Math.min(pastedData.length, 5);
      inputRefs.current[nextIndex]?.focus();
      if (newCode.every((char) => char !== '')) {
        inputRefs.current[nextIndex]?.blur();
        handleVerifyCode(newCode.join(''));
      }
    }
  };

  const handleVerifyCode = async (rawCode: string) => {
    const fullCode = rawCode.trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
    if (fullCode.length !== 6) {
      setCodeStatus('error');
      setCodeErrorMessage(t('code.invalid', lang));
      return;
    }
    if (verifyingRef.current) return;
    verifyingRef.current = true;
    setCodeStatus('verifying');
    setCodeErrorMessage('');

    try {
      const authToken = localStorage.getItem('auth_token') || '';
      const response = await fetch('/api/verify-code', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(authToken ? { Authorization: `Bearer ${authToken}` } : {}),
        },
        body: JSON.stringify({ code: fullCode }),
      });
      const data = await response.json();

      if (data?.success) {
        setCodeStatus('success');
        setTimeout(() => applyContext(data), 600);
      } else {
        setCodeStatus('error');
        setCodeErrorMessage(data?.message || t('code.invalid', lang));
      }
    } catch {
      setCodeStatus('error');
      setCodeErrorMessage(t('code.invalid', lang));
    } finally {
      verifyingRef.current = false;
    }
  };

  if (phase === 'loading') {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-[var(--bg)] text-[var(--text)] px-4">
        <div className="flex flex-col items-center text-center animate-fade-in">
          <div className="w-16 h-16 rounded-full neo-pressed flex items-center justify-center text-[var(--text)] mb-4 border border-[var(--border)]">
            <Dumbbell size={32} />
          </div>
          <h1 className="text-2xl font-bold tracking-widest uppercase">Gym Workspace</h1>
          <p className="text-xs uppercase tracking-[0.2em] text-[var(--text-sec)] mt-2">Connecting session...</p>
          <span className="mt-6 flex animate-spin text-[var(--text-sec)]">
            <Loader2 size={22} />
          </span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-[var(--bg)] text-[var(--text)] px-4 relative py-12">
      {/* Language Selector */}
      <div className="absolute top-6 right-6">
        <LanguageSelector onLanguageChange={(newLang) => setLang(newLang)} variant="compact" />
      </div>

      <div className="w-full max-w-md animate-fade-in">
        <div className="clay-raised p-8 rounded-[28px] flex flex-col items-center text-center relative overflow-hidden shadow-xl border border-[var(--border)]">
          <div className="w-16 h-16 rounded-full neo-pressed flex items-center justify-center text-[var(--text)] mb-3 mx-auto border border-[var(--border)] shadow-sm">
            <Dumbbell size={32} />
          </div>

          <span className="text-[10px] font-extrabold uppercase tracking-widest text-[var(--text-sec)] block mb-1">
            GYM MANAGEMENT SYSTEM
          </span>

          <AnimatePresence mode="wait">
            {phase === 'auth' ? (
              <motion.div
                key="auth-phase"
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -12 }}
                className="w-full flex flex-col items-center mt-2"
              >
                {/* Auth Mode Toggle Tabs */}
                <div className="flex w-full bg-neutral-200/60 dark:bg-neutral-800/60 p-1 rounded-2xl mb-6">
                  <button
                    type="button"
                    onClick={() => {
                      setAuthMode('login');
                      setAuthError(null);
                      setAuthSuccessMsg(null);
                    }}
                    className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                      authMode === 'login'
                        ? 'bg-white dark:bg-neutral-900 text-neutral-900 dark:text-white shadow-sm'
                        : 'text-neutral-500 hover:text-neutral-900 dark:hover:text-white'
                    }`}
                  >
                    Log In
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setAuthMode('signup');
                      setAuthError(null);
                      setAuthSuccessMsg(null);
                    }}
                    className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                      authMode === 'signup'
                        ? 'bg-white dark:bg-neutral-900 text-neutral-900 dark:text-white shadow-sm'
                        : 'text-neutral-500 hover:text-neutral-900 dark:hover:text-white'
                    }`}
                  >
                    Create Account
                  </button>
                </div>

                <h2 className="text-xl font-black tracking-wider uppercase mb-1">
                  {authMode === 'login' && 'Welcome Back'}
                  {authMode === 'signup' && 'Register Account'}
                  {authMode === 'forgot' && (forgotStep === 'request' ? 'Password Recovery' : 'Reset Password')}
                </h2>
                <p className="text-xs text-[var(--text-sec)] mb-6 max-w-xs font-medium leading-relaxed">
                  {authMode === 'login' && 'Enter your Indian mobile number and password to log in.'}
                  {authMode === 'signup' && 'Sign up with your 10-digit Indian mobile number and password (min 8 chars).'}
                  {authMode === 'forgot' &&
                    (forgotStep === 'request'
                      ? 'Enter your mobile number to receive a 6-digit recovery code.'
                      : 'Enter the 6-digit code and choose a new password.')}
                </p>

                {authError && (
                  <div className="mb-5 p-3.5 bg-red-500/10 border border-red-500/20 rounded-2xl flex items-start gap-2.5 text-[#D64545] text-xs font-bold text-left w-full animate-shake">
                    <AlertCircle size={16} className="shrink-0 mt-0.5" />
                    <span className="leading-snug">{authError}</span>
                  </div>
                )}

                {authSuccessMsg && (
                  <div className="mb-5 p-3.5 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl flex items-start gap-2.5 text-emerald-600 dark:text-emerald-400 text-xs font-bold text-left w-full">
                    <Check size={16} className="shrink-0 mt-0.5" />
                    <span className="leading-snug">{authSuccessMsg}</span>
                  </div>
                )}

                {demoOtpHint && authMode === 'forgot' && forgotStep === 'reset' && (
                  <div className="mb-4 px-3.5 py-2 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-700 dark:text-amber-400 text-xs font-bold w-full text-center">
                    <span>Recovery Code: </span>
                    <span className="font-black tracking-widest text-sm">{demoOtpHint}</span>
                  </div>
                )}

                <form
                  onSubmit={
                    authMode === 'login'
                      ? handleLoginSubmit
                      : authMode === 'signup'
                      ? handleSignupSubmit
                      : forgotStep === 'request'
                      ? handleRequestOtp
                      : handleResetPassword
                  }
                  className="w-full flex flex-col gap-4 text-left"
                >
                  {/* Indian Mobile Number Input */}
                  <div>
                    <label className="block text-[11px] font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1.5">
                      Indian Mobile Number
                    </label>
                    <div className="relative flex items-center">
                      <div className="absolute left-3.5 flex items-center gap-1.5 text-neutral-500 text-xs font-bold pointer-events-none select-none border-r border-neutral-300 dark:border-neutral-700 pr-2">
                        <span>🇮🇳</span>
                        <span>+91</span>
                      </div>
                      <input
                        type="tel"
                        inputMode="numeric"
                        placeholder="9876543210"
                        maxLength={10}
                        value={phone}
                        onChange={(e) => handlePhoneChange(e.target.value)}
                        disabled={authMode === 'forgot' && forgotStep === 'reset'}
                        className="w-full h-12 pl-24 pr-4 rounded-2xl bg-white dark:bg-[#181818] border border-neutral-300 dark:border-neutral-700 text-sm font-bold text-neutral-900 dark:text-white outline-none focus:border-neutral-900 dark:focus:border-white transition-all shadow-sm disabled:opacity-60"
                        required
                      />
                    </div>
                  </div>

                  {/* OTP Input for Forgot Password Step 2 */}
                  {authMode === 'forgot' && forgotStep === 'reset' && (
                    <div>
                      <label className="block text-[11px] font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1.5">
                        6-Digit Recovery Code
                      </label>
                      <div className="relative flex items-center">
                        <KeyRound size={16} className="absolute left-3.5 text-neutral-400 pointer-events-none" />
                        <input
                          type="text"
                          inputMode="numeric"
                          placeholder="123456"
                          maxLength={6}
                          value={recoveryOtp}
                          onChange={(e) => setRecoveryOtp(e.target.value.replace(/\D/g, ''))}
                          className="w-full h-12 pl-10 pr-4 rounded-2xl bg-white dark:bg-[#181818] border border-neutral-300 dark:border-neutral-700 text-sm font-bold text-neutral-900 dark:text-white outline-none focus:border-neutral-900 dark:focus:border-white transition-all shadow-sm tracking-widest"
                          required
                        />
                      </div>
                    </div>
                  )}

                  {/* Password Input */}
                  {(authMode !== 'forgot' || forgotStep === 'reset') && (
                    <div>
                      <label className="block text-[11px] font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1.5">
                        {authMode === 'forgot' ? 'New Password (min 8 chars)' : 'Password'}
                      </label>
                      <div className="relative flex items-center">
                        <Lock size={16} className="absolute left-3.5 text-neutral-400 pointer-events-none" />
                        <input
                          type={showPassword ? 'text' : 'password'}
                          placeholder="••••••••"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          className="w-full h-12 pl-10 pr-11 rounded-2xl bg-white dark:bg-[#181818] border border-neutral-300 dark:border-neutral-700 text-sm font-bold text-neutral-900 dark:text-white outline-none focus:border-neutral-900 dark:focus:border-white transition-all shadow-sm"
                          required
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3.5 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 cursor-pointer"
                        >
                          {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Confirm Password Input (For Signup & Forgot Password Step 2) */}
                  {(authMode === 'signup' || (authMode === 'forgot' && forgotStep === 'reset')) && (
                    <div>
                      <label className="block text-[11px] font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1.5">
                        Confirm {authMode === 'forgot' ? 'New Password' : 'Password'}
                      </label>
                      <div className="relative flex items-center">
                        <Lock size={16} className="absolute left-3.5 text-neutral-400 pointer-events-none" />
                        <input
                          type={showConfirmPassword ? 'text' : 'password'}
                          placeholder="••••••••"
                          value={confirmPassword}
                          onChange={(e) => setConfirmPassword(e.target.value)}
                          className="w-full h-12 pl-10 pr-11 rounded-2xl bg-white dark:bg-[#181818] border border-neutral-300 dark:border-neutral-700 text-sm font-bold text-neutral-900 dark:text-white outline-none focus:border-neutral-900 dark:focus:border-white transition-all shadow-sm"
                          required
                        />
                        <button
                          type="button"
                          onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                          className="absolute right-3.5 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 cursor-pointer"
                        >
                          {showConfirmPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Submit Button */}
                  <button
                    type="submit"
                    disabled={authLoading}
                    className="w-full h-13 mt-2 rounded-2xl bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 hover:opacity-90 active:scale-95 transition-all shadow-md cursor-pointer disabled:opacity-50"
                  >
                    {authLoading ? (
                      <Loader2 size={18} className="animate-spin" />
                    ) : authMode === 'login' ? (
                      <>
                        <span>LOG IN</span>
                        <ArrowRight size={16} />
                      </>
                    ) : authMode === 'signup' ? (
                      <>
                        <span>CREATE ACCOUNT</span>
                        <UserPlus size={16} />
                      </>
                    ) : forgotStep === 'request' ? (
                      <>
                        <span>GET RECOVERY CODE</span>
                        <ArrowRight size={16} />
                      </>
                    ) : (
                      <>
                        <span>RESET PASSWORD</span>
                        <KeyRound size={16} />
                      </>
                    )}
                  </button>
                </form>

                {/* Auxiliary Mode Links */}
                <div className="mt-5 flex flex-col items-center gap-2 text-xs">
                  {authMode === 'login' && (
                    <>
                      <button
                        type="button"
                        onClick={() => {
                          setAuthMode('forgot');
                          setAuthError(null);
                        }}
                        className="text-[var(--text-sec)] hover:text-[var(--text)] font-semibold transition-colors cursor-pointer"
                      >
                        Forgot Password?
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setAuthMode('signup');
                          setAuthError(null);
                        }}
                        className="text-neutral-900 dark:text-white font-bold hover:underline cursor-pointer"
                      >
                        First time? Create an account
                      </button>
                    </>
                  )}

                  {authMode === 'signup' && (
                    <button
                      type="button"
                      onClick={() => {
                        setAuthMode('login');
                        setAuthError(null);
                      }}
                      className="text-neutral-900 dark:text-white font-bold hover:underline cursor-pointer"
                    >
                      Already have an account? Log In
                    </button>
                  )}

                  {authMode === 'forgot' && (
                    <div className="flex flex-col items-center gap-1.5">
                      {forgotStep === 'reset' && (
                        <button
                          type="button"
                          onClick={() => {
                            setForgotStep('request');
                            setAuthError(null);
                          }}
                          className="text-[var(--text-sec)] hover:text-[var(--text)] font-semibold transition-colors cursor-pointer"
                        >
                          Request New Verification Code
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => {
                          setAuthMode('login');
                          setForgotStep('request');
                          setAuthError(null);
                        }}
                        className="text-neutral-900 dark:text-white font-bold hover:underline cursor-pointer"
                      >
                        Back to Log In
                      </button>
                    </div>
                  )}
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="code-phase"
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -12 }}
                className="w-full flex flex-col items-center mt-2"
              >
                {/* Authenticated User Status Chip */}
                {authUser && (
                  <div className="mb-5 px-3.5 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/25 flex items-center gap-2 text-xs font-bold text-emerald-600 dark:text-emerald-400">
                    <ShieldCheck size={15} className="shrink-0" />
                    <span>🇮🇳 +91 {authUser.phone}</span>
                    <button
                      type="button"
                      onClick={handleAuthSignOut}
                      title="Switch Account / Log Out"
                      className="ml-1 text-neutral-400 hover:text-red-500 cursor-pointer transition-colors"
                    >
                      <LogOut size={13} />
                    </button>
                  </div>
                )}

                <h2 className="text-xl font-black tracking-wider uppercase mb-1">
                  {t('code.title', lang)}
                </h2>
                <p className="text-xs tracking-wide text-[var(--text-sec)] mb-6 max-w-xs font-medium leading-relaxed">
                  {t('code.subtitle', lang)}
                </p>

                <AnimatePresence mode="wait">
                  {codeStatus === 'error' && (
                    <motion.div
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                      className="mb-5 flex items-center justify-center gap-2 text-[#D64545] text-xs font-bold"
                      role="alert"
                    >
                      <AlertCircle size={16} />
                      <span>{codeErrorMessage}</span>
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* 6-Digit Code Inputs */}
                <motion.div
                  animate={codeStatus === 'error' ? { x: [-8, 8, -8, 8, 0] } : {}}
                  transition={{ duration: 0.4 }}
                  className="flex gap-2 sm:gap-3 mb-6 w-full justify-center"
                >
                  {code.map((char, index) => (
                    <input
                      key={index}
                      ref={(el) => {
                        inputRefs.current[index] = el;
                      }}
                      type="text"
                      inputMode="text"
                      autoCapitalize="characters"
                      autoCorrect="off"
                      spellCheck={false}
                      maxLength={1}
                      value={char}
                      onChange={(e) => handleCodeChange(index, e.target.value)}
                      onKeyDown={(e) => handleKeyDown(index, e)}
                      onPaste={handlePaste}
                      disabled={codeStatus === 'verifying' || codeStatus === 'success'}
                      aria-label={`Access Code Digit ${index + 1}`}
                      className={`w-10 h-12 sm:w-12 sm:h-14 text-center text-xl sm:text-2xl font-black rounded-2xl outline-none transition-all duration-200 
                        bg-white dark:bg-[#181818] text-neutral-900 dark:text-white border-2 
                        ${char ? 'border-neutral-900 dark:border-white' : 'border-neutral-300 dark:border-neutral-700'}
                        focus:border-neutral-900 dark:focus:border-white focus:ring-2 focus:ring-neutral-900 dark:focus:ring-white uppercase shadow-sm`}
                    />
                  ))}
                </motion.div>

                {/* Verify Code Button */}
                <button
                  type="button"
                  onClick={() => handleVerifyCode(code.join(''))}
                  disabled={code.some((c) => !c) || codeStatus === 'verifying' || codeStatus === 'success'}
                  className="w-full h-13 rounded-2xl bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs uppercase tracking-widest font-black flex items-center justify-center transition-all disabled:opacity-50 disabled:cursor-not-allowed hover:opacity-90 active:scale-95 cursor-pointer shadow-md mb-3"
                >
                  {codeStatus === 'verifying' ? (
                    <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1, ease: 'linear' }}>
                      <Loader2 size={20} />
                    </motion.div>
                  ) : codeStatus === 'success' ? (
                    <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} className="flex items-center gap-2">
                      <Check size={20} /> VERIFIED
                    </motion.div>
                  ) : (
                    t('code.verify', lang)
                  )}
                </button>

                <button
                  type="button"
                  onClick={handleAuthSignOut}
                  className="text-xs text-[var(--text-sec)] hover:text-[var(--text)] font-semibold transition-colors cursor-pointer"
                >
                  Switch Mobile Account / Log Out
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
