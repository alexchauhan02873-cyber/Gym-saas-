import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, Link } from '@/lib/router-compat';
import { motion, AnimatePresence } from 'motion/react';
import { Check, AlertCircle, Loader2, Dumbbell, ArrowLeft } from 'lucide-react';

export default function MemberLogin() {
  const navigate = useNavigate();
  const [code, setCode] = useState<string[]>(Array(6).fill(''));
  const [status, setStatus] = useState<'idle' | 'verifying' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState('');
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  useEffect(() => {
    const memberSessionStr = localStorage.getItem('member_session');
    if (memberSessionStr) {
      try {
        const mSession = JSON.parse(memberSessionStr);
        if (mSession && mSession.role === 'member' && mSession.memberId) {
          fetch(`/api/members/${mSession.gymId}/${mSession.memberId}`)
            .then(res => res.json())
            .then(m => {
              if (m && m.onboardingCompleted === false) {
                navigate('/member/onboarding', { replace: true });
              } else {
                navigate('/member/dashboard', { replace: true });
              }
            })
            .catch(() => {
              navigate('/member/dashboard', { replace: true });
            });
        }
      } catch (e) {}
    }
  }, [navigate]);

  useEffect(() => {
    if (inputRefs.current[0]) {
      inputRefs.current[0].focus();
    }
  }, []);

  const handleChange = (index: number, value: string) => {
    if (!/^[a-zA-Z0-9]*$/.test(value)) return;
    const newCode = [...code];
    newCode[index] = value.toUpperCase();
    setCode(newCode);
    if (value && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }
    if (value && index === 5 && newCode.every(char => char !== '')) {
      handleVerify(newCode.join(''));
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !code[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const handlePaste = (e: React.ClipboardEvent) => {
    e.preventDefault();
    const pastedData = e.clipboardData.getData('text/plain').toUpperCase().replace(/[^A-Z0-9]/g, '');
    if (pastedData) {
      const newCode = [...code];
      for (let i = 0; i < Math.min(pastedData.length, 6); i++) {
        newCode[i] = pastedData[i];
      }
      setCode(newCode);
      const nextIndex = Math.min(pastedData.length, 5);
      inputRefs.current[nextIndex]?.focus();
      
      if (newCode.every(char => char !== '')) {
        handleVerify(newCode.join(''));
      }
    }
  };

  const handleVerify = async (fullCode: string) => {
    setStatus('verifying');
    setErrorMessage('');
    try {
      const response = await fetch('/api/verify-code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: fullCode })
      });
      const data = await response.json();
      if (data.success && data.role === 'member') {
        setStatus('success');
        const isCompleted = data.onboardingCompleted !== false && data.onboardingComplete !== false;
        localStorage.setItem('member_session', JSON.stringify({
          gymId: data.gymId,
          memberId: data.memberId,
          role: 'member',
          token: data.token,
          onboardingCompleted: isCompleted
        }));
        setTimeout(() => {
          if (!isCompleted) {
            navigate('/member/onboarding', { replace: true });
          } else {
            navigate('/member/dashboard', { replace: true });
          }
        }, 600);
      } else {
        setStatus('error');
        setErrorMessage(data.message || 'Invalid Member Access Code. Check code with your gym owner.');
      }
    } catch (err) {
      setStatus('error');
      setErrorMessage('Something went wrong. Please try again.');
    }
  };

  return (
    <div className="min-h-screen bg-[var(--bg)] text-[var(--text)] flex flex-col items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-sm"
      >
        <div className="clay-raised p-8 rounded-[28px] flex flex-col items-center text-center relative overflow-hidden">
          <div className="w-16 h-16 rounded-full neo-pressed flex items-center justify-center mx-auto text-[var(--text)] mb-4 border border-[var(--border)]">
            <Dumbbell size={28} />
          </div>
          <span className="text-[9px] uppercase font-bold tracking-widest text-[var(--text-sec)] block mb-1">
            SECURE MEMBER ACCESS
          </span>
          <h1 className="text-xl font-black uppercase tracking-wider mb-2">
            ENTER MEMBER CODE
          </h1>
          <p className="text-xs text-[var(--text-sec)] font-medium mb-8 leading-relaxed">
            Enter your unique 6-character access code provided by your gym owner.
          </p>

          <AnimatePresence mode="wait">
            {status === 'error' && (
              <motion.div 
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="mb-6 flex flex-col items-center text-[#D64545]"
              >
                <div className="flex items-center gap-2 font-medium mb-1 text-xs">
                  <AlertCircle size={16} />
                  <span>{errorMessage}</span>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <motion.div 
            animate={status === 'error' ? { x: [-10, 10, -10, 10, 0] } : {}}
            transition={{ duration: 0.4 }}
            className="flex gap-2 mb-8 w-full justify-center"
          >
            {code.map((char, index) => (
              <input
                key={index}
                ref={el => { inputRefs.current[index] = el; }}
                type="text"
                maxLength={1}
                value={char}
                onChange={(e) => handleChange(index, e.target.value)}
                onKeyDown={(e) => handleKeyDown(index, e)}
                onPaste={handlePaste}
                disabled={status === 'verifying' || status === 'success'}
                aria-label={`Member Code digit ${index + 1} of 6`}
                className={`w-10 h-12 sm:w-11 sm:h-13 text-center text-xl font-bold rounded-xl outline-none transition-all duration-200 
                  bg-white dark:bg-[#181818] text-neutral-900 dark:text-white border-2 
                  ${char ? 'border-neutral-900 dark:border-white' : 'border-neutral-300 dark:border-neutral-700'}
                  focus:border-neutral-900 dark:focus:border-white focus:ring-2 focus:ring-neutral-900 dark:focus:ring-white uppercase shadow-sm`}
              />
            ))}
          </motion.div>

          <button
            onClick={() => handleVerify(code.join(''))}
            disabled={code.some(c => !c) || status === 'verifying' || status === 'success'}
            className="w-full h-12 rounded-[16px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs uppercase tracking-widest font-bold flex items-center justify-center transition-all disabled:opacity-50 disabled:cursor-not-allowed hover:opacity-80 active:scale-95 mb-6 cursor-pointer"
          >
            {status === 'verifying' ? (
              <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1, ease: "linear" }}>
                <Loader2 size={20} />
              </motion.div>
            ) : status === 'success' ? (
              <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} className="flex items-center gap-2">
                <Check size={20} /> VERIFIED
              </motion.div>
            ) : (
              'LOGIN TO DASHBOARD'
            )}
          </button>

          <div className="pt-4 border-t border-[var(--border)] w-full flex justify-between items-center text-[10px] font-bold uppercase text-[var(--text-sec)]">
            <Link to="/" className="flex items-center gap-1 text-[var(--text)] hover:opacity-80">
              <ArrowLeft size={14} /> Main Portal
            </Link>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
