import React from 'react';
import { Snowflake, Headset, LogOut, Calendar } from 'lucide-react';
import { useSearchParams } from '@/lib/router-compat';
import { signOutEverything } from '@/lib/app-auth';

export default function AccessFrozen() {
  const [params] = useSearchParams();
  const reasonParam = params.get('reason') || 'Account temporarily frozen by platform administration.';
  const dateParam = params.get('date') || new Date().toISOString().split('T')[0];
  const untilParam = params.get('until') || 'Indefinite';

  return (
    <div className="min-h-screen bg-[var(--bg)] text-[var(--text)] flex items-center justify-center px-5 py-12">
      <div className="w-full max-w-md clay-raised rounded-[28px] p-8 space-y-6 text-center animate-in fade-in duration-300">
        <div className="w-16 h-16 rounded-full neo-pressed mx-auto flex items-center justify-center text-[#E8A33D]">
          <Snowflake size={32} />
        </div>

        <div className="space-y-2">
          <span className="text-[9px] font-black uppercase tracking-widest text-[#E8A33D] bg-[#E8A33D]/10 px-3 py-1 rounded-full border border-[#E8A33D]/20 inline-block">
            STATUS: FROZEN
          </span>
          <h1 className="text-xl font-black uppercase tracking-wider text-[var(--text)] pt-2">
            Account Temporarily Frozen
          </h1>
          <p className="text-xs text-[var(--text-sec)]">
            Your account operations are temporarily placed on hold.
          </p>
        </div>

        <div className="neo-pressed p-4 rounded-[18px] text-left space-y-3">
          <div>
            <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Freeze Reason</span>
            <p className="text-xs font-semibold text-[var(--text)] mt-0.5">{reasonParam}</p>
          </div>
          <div className="grid grid-cols-2 gap-2 pt-2 border-t border-[var(--border)] text-[10px]">
            <div>
              <span className="text-[var(--text-sec)] font-bold uppercase tracking-wider block">Frozen On:</span>
              <span className="font-mono font-bold text-[var(--text)] mt-0.5 block">{dateParam}</span>
            </div>
            <div>
              <span className="text-[var(--text-sec)] font-bold uppercase tracking-wider block">Frozen Until:</span>
              <span className="font-mono font-bold text-[#E8A33D] mt-0.5 block">{untilParam}</span>
            </div>
          </div>
        </div>

        <div className="flex flex-col gap-3">
          <a
            href="https://wa.me/919263604732?text=Hello%20Support%2C%20my%20account%20is%20frozen.%20Please%20help."
            target="_blank"
            rel="noopener noreferrer"
            className="h-12 rounded-[16px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-bold uppercase tracking-widest flex items-center justify-center gap-2"
          >
            <Headset size={16} /> Contact Support
          </a>
          <button
            onClick={() => void signOutEverything()}
            className="h-12 rounded-[16px] neo-raised text-xs font-bold uppercase tracking-widest flex items-center justify-center gap-2 active:scale-95 transition-transform cursor-pointer"
          >
            <LogOut size={16} /> Sign Out
          </button>
        </div>
      </div>
    </div>
  );
}
