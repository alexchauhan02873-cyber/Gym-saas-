import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from '@/lib/router-compat';
import { 
  Dumbbell, Plus, Check, Users, Send, Trash2, Calendar, Clock, 
  RefreshCw, Search, ShieldAlert, Sparkles, Filter, X, ChevronRight, Ban,
  FileText, Activity, AlertTriangle, Layers, ArrowRight, User
} from 'lucide-react';
import OwnerLayout from '../../components/OwnerLayout';

type ViewTab = 'WITHOUT_WORKOUT' | 'ACTIVE_WORKOUT' | 'EXPIRED_WORKOUT';

interface ExerciseItem {
  id?: string;
  name: string;
  category?: string;
  muscleGroup?: string;
  sets: number;
  reps: string;
  weight: string;
  rest: string;
  notes?: string;
}

export default function OwnerWorkout() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const preselectedMemberId = searchParams.get('memberId') || searchParams.get('member');

  const [gymId, setGymId] = useState('');
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<ViewTab>('WITHOUT_WORKOUT');
  const [members, setMembers] = useState<any[]>([]);
  const [activeWorkouts, setActiveWorkouts] = useState<any[]>([]);
  const [templates, setTemplates] = useState<any[]>([]);
  const [exerciseLibrary, setExerciseLibrary] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState('');

  // Builder Drawer / Modal state
  const [builderOpen, setBuilderOpen] = useState(false);
  const [selectedMember, setSelectedMember] = useState<any | null>(null);
  const [workoutTitle, setWorkoutTitle] = useState('Daily Muscle & Strength Plan');
  const [workoutGoal, setWorkoutGoal] = useState('Hypertrophy & Strength');
  const [builderExercises, setBuilderExercises] = useState<ExerciseItem[]>([
    { name: 'Barbell Bench Press', category: 'Strength', muscleGroup: 'Chest', sets: 4, reps: '10-12', weight: '60 kg', rest: '90s', notes: 'Maintain strict form' },
    { name: 'Barbell Back Squats', category: 'Strength', muscleGroup: 'Legs', sets: 4, reps: '8-10', weight: '80 kg', rest: '120s', notes: 'Deep depth squats' },
    { name: 'Lat Pulldown', category: 'Hypertrophy', muscleGroup: 'Back', sets: 3, reps: '12', weight: '45 kg', rest: '60s', notes: 'Squeeze at bottom' }
  ]);
  const [startDate, setStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [durationDays, setDurationDays] = useState<number>(7);
  const [repeatFrequency, setRepeatFrequency] = useState('DAILY');
  const [assigning, setAssigning] = useState(false);

  // Exercise library picker modal state
  const [showPicker, setShowPicker] = useState(false);
  const [pickerSearch, setPickerSearch] = useState('');
  const [pickerCategory, setPickerCategory] = useState<string>('ALL');
  const [customExName, setCustomExName] = useState('');

  // Notifications
  const [toast, setToast] = useState<string | null>(null);

  const showToastMsg = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  };

  const fetchData = async () => {
    const sessionStr = localStorage.getItem('gym_session');
    if (!sessionStr) { navigate('/'); return; }
    const session = JSON.parse(sessionStr);
    setGymId(session.gymId);

    try {
      const [mRes, wRes, tRes, exRes] = await Promise.all([
        fetch(`/api/members/${session.gymId}`),
        fetch(`/api/owner/workouts/active/${session.gymId}`),
        fetch(`/api/owner/workouts/templates/${session.gymId}`),
        fetch(`/api/exercises/library`)
      ]);
      const mData = await mRes.json();
      const wData = await wRes.json();
      const tData = await tRes.json();
      const exData = await exRes.json();

      if (mData.success) {
        const activeMembers = (mData.members || []).filter((m: any) => m.status !== 'ARCHIVED');
        setMembers(activeMembers);

        if (preselectedMemberId) {
          const match = activeMembers.find((m: any) => m.id === preselectedMemberId);
          if (match) {
            setSelectedMember(match);
            setBuilderOpen(true);
          }
        }
      }
      if (wData.success) setActiveWorkouts(wData.workouts || []);
      if (tData.success) setTemplates(tData.templates || []);
      if (exData.success) setExerciseLibrary(exData.exercises || []);
    } catch (e) {
      console.error(e);
    } fontally: {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [preselectedMemberId]);

  const handleOpenBuilderForMember = (member: any) => {
    setSelectedMember(member);
    // Find existing workout if present
    const existing = activeWorkouts.find(w => w.memberId === member.id && w.status === 'ACTIVE');
    if (existing) {
      setWorkoutTitle(existing.name || 'Custom Routine');
      setWorkoutGoal(existing.goal || 'General Fitness');
      setBuilderExercises(existing.exercises || []);
      setDurationDays(existing.durationDays || 7);
      setRepeatFrequency(existing.repeatFrequency || 'DAILY');
    } else {
      setWorkoutTitle(`${member.fullName}'s Custom Routine`);
      setWorkoutGoal('Hypertrophy & General Strength');
      setBuilderExercises([
        { name: 'Barbell Bench Press', category: 'Strength', muscleGroup: 'Chest', sets: 4, reps: '10-12', weight: '60 kg', rest: '90s', notes: 'Warm up first' },
        { name: 'Barbell Back Squats', category: 'Strength', muscleGroup: 'Legs', sets: 4, reps: '8-10', weight: '70 kg', rest: '90s', notes: 'Keep back straight' }
      ]);
      setDurationDays(7);
      setRepeatFrequency('DAILY');
    }
    setBuilderOpen(true);
  };

  const handleAddExerciseFromLibrary = (ex: any) => {
    setBuilderExercises(prev => [
      ...prev,
      {
        id: `ex_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`,
        name: ex.name,
        category: ex.category || 'General',
        muscleGroup: ex.muscleGroup || 'General',
        sets: 3,
        reps: '10-12',
        weight: 'BW / Light',
        rest: '60s',
        notes: ''
      }
    ]);
    setShowPicker(false);
    showToastMsg(`Added ${ex.name} to workout!`);
  };

  const handleCreateCustomExercise = () => {
    if (!customExName.trim()) return;
    const newEx = {
      name: customExName.trim(),
      category: 'Custom',
      muscleGroup: 'General',
      sets: 3,
      reps: '10-12',
      weight: 'BW',
      rest: '60s'
    };
    handleAddExerciseFromLibrary(newEx);
    setCustomExName('');
  };

  const updateExercise = (index: number, field: keyof ExerciseItem, value: any) => {
    setBuilderExercises(prev => prev.map((ex, idx) => idx === index ? { ...ex, [field]: value } : ex));
  };

  const removeExercise = (index: number) => {
    setBuilderExercises(prev => prev.filter((_, idx) => idx !== index));
  };

  const handleAssignWorkoutSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMember) return;
    if (builderExercises.length === 0) {
      showToastMsg('Please add at least 1 exercise to assign routine');
      return;
    }

    setAssigning(true);
    try {
      const res = await fetch('/api/owner/workouts/assign', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          gymId,
          memberIds: [selectedMember.id],
          workout: {
            title: workoutTitle,
            goal: workoutGoal,
            exercises: builderExercises
          },
          startDate,
          durationDays,
          repeatFrequency
        })
      });
      const resData = await res.json();
      if (resData.success) {
        showToastMsg(`Workout routine assigned to ${selectedMember.fullName}!`);
        setBuilderOpen(false);
        fetchData();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setAssigning(false);
    }
  };

  const handleRevokeWorkout = async (workoutId: string) => {
    try {
      const res = await fetch('/api/owner/workouts/revoke', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ workoutId })
      });
      const resData = await res.json();
      if (resData.success) {
        showToastMsg('Workout routine revoked.');
        fetchData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Group members into categories
  const membersWithActiveWorkout = members.filter(m => activeWorkouts.some(w => w.memberId === m.id && w.status === 'ACTIVE'));
  const membersWithoutWorkout = members.filter(m => !activeWorkouts.some(w => w.memberId === m.id && w.status === 'ACTIVE'));
  const expiredWorkoutsList = activeWorkouts.filter(w => w.status === 'EXPIRED');

  // Filter based on search query
  const q = searchQuery.toLowerCase().trim();
  const filteredWithout = membersWithoutWorkout.filter(m => m.fullName?.toLowerCase().includes(q) || m.phone?.includes(q) || m.memberDisplayId?.toLowerCase().includes(q));
  const filteredActive = membersWithActiveWorkout.filter(m => m.fullName?.toLowerCase().includes(q) || m.phone?.includes(q) || m.memberDisplayId?.toLowerCase().includes(q));
  const filteredExpired = expiredWorkoutsList.filter(w => w.memberName?.toLowerCase().includes(q) || w.name?.toLowerCase().includes(q));

  if (loading) {
    return (
      <OwnerLayout>
        <div className="py-20 text-center flex flex-col items-center justify-center space-y-3">
          <Clock className="w-8 h-8 text-[var(--text-sec)] animate-spin" />
          <span className="text-xs font-bold uppercase tracking-widest text-[var(--text-sec)]">Loading Workout Engine...</span>
        </div>
      </OwnerLayout>
    );
  }

  return (
    <OwnerLayout>
      <div className="px-4 mt-6 space-y-6 pb-16 max-w-7xl mx-auto">
        {toast && (
          <div className="fixed top-5 right-5 z-50 bg-[#34A853] text-white px-4 py-3 rounded-2xl font-bold text-xs shadow-lg animate-bounce">
            ✓ {toast}
          </div>
        )}

        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <span className="text-[9px] font-black uppercase tracking-[0.2em] text-[var(--text-sec)]">GYM WORKOUT PRESCRIPTION ENGINE</span>
            <h1 className="text-2xl font-black uppercase tracking-wider text-[var(--text)]">Member Workout Routines</h1>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                if (membersWithoutWorkout.length > 0) handleOpenBuilderForMember(membersWithoutWorkout[0]);
                else if (members.length > 0) handleOpenBuilderForMember(members[0]);
              }}
              className="h-10 px-4 rounded-xl bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-wider flex items-center gap-1.5 cursor-pointer shadow-sm active:scale-95 transition-transform"
            >
              <Plus size={16} /> Assign Routine
            </button>
          </div>
        </div>

        {/* Category Count Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
          <div 
            onClick={() => setActiveTab('WITHOUT_WORKOUT')}
            className={`neo-raised p-4 rounded-[20px] cursor-pointer transition-all border ${
              activeTab === 'WITHOUT_WORKOUT' ? 'border-[#E3A008] bg-[#E3A008]/5 scale-[1.02]' : 'border-[var(--border)]'
            }`}
          >
            <span className="text-[9px] font-black uppercase tracking-wider text-[#E3A008]">Needs Workout Routine</span>
            <span className="text-2xl font-black font-mono text-[#E3A008] mt-1 block">
              {membersWithoutWorkout.length} Members
            </span>
            <span className="text-[9px] text-[var(--text-sec)] font-medium">No routine assigned</span>
          </div>

          <div 
            onClick={() => setActiveTab('ACTIVE_WORKOUT')}
            className={`neo-raised p-4 rounded-[20px] cursor-pointer transition-all border ${
              activeTab === 'ACTIVE_WORKOUT' ? 'border-[#34A853] bg-[#34A853]/5 scale-[1.02]' : 'border-[var(--border)]'
            }`}
          >
            <span className="text-[9px] font-black uppercase tracking-wider text-[#34A853]">Active Workouts</span>
            <span className="text-2xl font-black font-mono text-[#34A853] mt-1 block">
              {membersWithActiveWorkout.length} Members
            </span>
            <span className="text-[9px] text-[var(--text-sec)] font-medium">Currently following routine</span>
          </div>

          <div 
            onClick={() => setActiveTab('EXPIRED_WORKOUT')}
            className={`neo-raised p-4 rounded-[20px] cursor-pointer transition-all border ${
              activeTab === 'EXPIRED_WORKOUT' ? 'border-[var(--text)] bg-[var(--surface-sec)] scale-[1.02]' : 'border-[var(--border)]'
            }`}
          >
            <span className="text-[9px] font-black uppercase tracking-wider text-[var(--text-sec)]">Expired Routines</span>
            <span className="text-2xl font-black font-mono text-[var(--text)] mt-1 block">
              {expiredWorkoutsList.length} Routines
            </span>
            <span className="text-[9px] text-[var(--text-sec)] font-medium">Duration elapsed</span>
          </div>
        </div>

        {/* Tab Selection Bar & Search */}
        <div className="flex flex-col sm:flex-row gap-3 justify-between items-center">
          <div className="flex items-center gap-2 overflow-x-auto w-full sm:w-auto pb-1 scrollbar-none">
            {[
              { id: 'WITHOUT_WORKOUT', label: 'NEEDS WORKOUT', count: membersWithoutWorkout.length },
              { id: 'ACTIVE_WORKOUT', label: 'ACTIVE WORKOUTS', count: membersWithActiveWorkout.length },
              { id: 'EXPIRED_WORKOUT', label: 'EXPIRED ROUTINES', count: expiredWorkoutsList.length }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as ViewTab)}
                className={`px-4 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider transition-all whitespace-nowrap cursor-pointer flex items-center gap-2 ${
                  activeTab === tab.id
                    ? 'bg-[var(--btn-bg)] text-[var(--btn-text)] shadow-md scale-[1.02]'
                    : 'neo-raised text-[var(--text-sec)] hover:text-[var(--text)]'
                }`}
              >
                <span>{tab.label}</span>
                <span className={`px-2 py-0.5 rounded-md text-[10px] font-mono ${
                  activeTab === tab.id ? 'bg-white/20 text-white' : 'bg-[var(--surface)] text-[var(--text)]'
                }`}>
                  {tab.count}
                </span>
              </button>
            ))}
          </div>

          <div className="relative w-full sm:w-72">
            <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[var(--text-sec)]" />
            <input
              type="text"
              placeholder="Search member or routine..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full h-10 pl-10 pr-4 neo-pressed rounded-[14px] text-xs font-bold text-[var(--text)] outline-none"
            />
          </div>
        </div>

        {/* VIEW 1: MEMBERS WITHOUT WORKOUT (DEFAULT FOCUS!) */}
        {activeTab === 'WITHOUT_WORKOUT' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between text-xs font-bold text-[var(--text-sec)] px-1">
              <span>{filteredWithout.length} MEMBERS AWAITING WORKOUT ROUTINE</span>
              <span>1-CLICK ASSIGN WORKOUT BUILDER</span>
            </div>

            {filteredWithout.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredWithout.map((m: any) => (
                  <div key={m.id} className="clay-raised p-5 rounded-[24px] space-y-4 border border-[var(--border)]">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        {m.profileImage ? (
                          <img src={m.profileImage} alt={m.fullName} className="w-12 h-12 rounded-2xl object-cover border border-[var(--border)]" />
                        ) : (
                          <div className="w-12 h-12 rounded-2xl neo-raised flex items-center justify-center font-black text-sm uppercase text-[var(--text)]">
                            {m.fullName?.charAt(0) || 'M'}
                          </div>
                        )}
                        <div>
                          <h3 className="text-sm font-black uppercase text-[var(--text)]">{m.fullName}</h3>
                          <div className="flex items-center gap-2 mt-0.5">
                            <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-[var(--surface)] text-[var(--text-sec)]">
                              {m.memberDisplayId || 'MEM-0000'}
                            </span>
                            <span className="text-[10px] text-[var(--text-sec)] font-mono">{m.phone}</span>
                          </div>
                        </div>
                      </div>

                      <span className="px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-[#E3A008]/15 text-[#E3A008] border border-[#E3A008]">
                        NO ROUTINE
                      </span>
                    </div>

                    <div className="p-3 neo-pressed rounded-[16px] flex justify-between items-center text-xs font-mono">
                      <div>
                        <span className="text-[9px] text-[var(--text-sec)] font-bold uppercase block">Status</span>
                        <span className="font-bold text-[var(--text)]">{m.status || 'ACTIVE'}</span>
                      </div>
                      <div>
                        <span className="text-[9px] text-[var(--text-sec)] font-bold uppercase block">Start Date</span>
                        <span className="font-bold text-[var(--text)]">{m.startDate || 'N/A'}</span>
                      </div>
                      <div>
                        <span className="text-[9px] text-[var(--text-sec)] font-bold uppercase block">End Date</span>
                        <span className="font-bold text-[var(--text)]">{m.endDate || 'N/A'}</span>
                      </div>
                    </div>

                    <button
                      onClick={() => handleOpenBuilderForMember(m)}
                      className="w-full h-11 rounded-[16px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer shadow-sm active:scale-95 transition-transform"
                    >
                      <Plus size={16} /> Assign Custom Workout Routine
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="clay-raised p-12 rounded-[32px] text-center space-y-3">
                <Check className="w-10 h-10 text-[#34A853] mx-auto" />
                <h3 className="text-base font-black uppercase text-[var(--text)]">All Members Have Active Workouts!</h3>
                <p className="text-xs text-[var(--text-sec)]">Every member in your gym has been prescribed a workout routine.</p>
              </div>
            )}
          </div>
        )}

        {/* VIEW 2: MEMBERS WITH ACTIVE WORKOUT */}
        {activeTab === 'ACTIVE_WORKOUT' && (
          <div className="space-y-4">
            {filteredActive.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredActive.map((m: any) => {
                  const workout = activeWorkouts.find(w => w.memberId === m.id && w.status === 'ACTIVE');
                  return (
                    <div key={m.id} className="clay-raised p-5 rounded-[24px] space-y-4 border border-[#34A853]/40 bg-[#34A853]/5">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          {m.profileImage ? (
                            <img src={m.profileImage} alt={m.fullName} className="w-12 h-12 rounded-2xl object-cover border border-[var(--border)]" />
                          ) : (
                            <div className="w-12 h-12 rounded-2xl neo-raised flex items-center justify-center font-black text-sm uppercase text-[var(--text)]">
                              {m.fullName?.charAt(0) || 'M'}
                            </div>
                          )}
                          <div>
                            <h3 className="text-sm font-black uppercase text-[var(--text)]">{m.fullName}</h3>
                            <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-[var(--surface)] text-[var(--text-sec)]">
                              {m.memberDisplayId || 'MEM-0000'}
                            </span>
                          </div>
                        </div>

                        <span className="px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-[#34A853]/15 text-[#34A853] border border-[#34A853]">
                          ACTIVE ROUTINE
                        </span>
                      </div>

                      {workout && (
                        <div className="p-3.5 neo-pressed rounded-[18px] space-y-2 text-xs">
                          <div className="flex justify-between items-center border-b border-[var(--border)] pb-2">
                            <span className="font-black uppercase text-[var(--text)]">{workout.name}</span>
                            <span className="text-[10px] font-mono font-bold text-[#34A853]">{workout.durationDays || 7} Days</span>
                          </div>

                          <div className="space-y-1 pt-1">
                            {(workout.exercises || []).map((ex: any, idx: number) => (
                              <div key={idx} className="flex justify-between items-center text-[11px] font-mono">
                                <span>{ex.name}</span>
                                <span className="font-bold text-[var(--text-sec)]">{ex.sets} sets × {ex.reps} ({ex.weight})</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      <div className="flex gap-2">
                        <button
                          onClick={() => handleOpenBuilderForMember(m)}
                          className="flex-1 h-10 rounded-[14px] neo-raised text-xs font-bold uppercase text-[var(--text)] flex items-center justify-center gap-1.5 cursor-pointer"
                        >
                          <FileText size={14} /> Edit Routine
                        </button>

                        {workout && (
                          <button
                            onClick={() => handleRevokeWorkout(workout.id)}
                            className="h-10 px-3 rounded-[14px] neo-raised text-[#D64545] text-xs font-bold uppercase flex items-center justify-center gap-1 cursor-pointer"
                            title="Revoke Routine"
                          >
                            <Trash2 size={14} /> Revoke
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="clay-raised p-12 rounded-[32px] text-center space-y-3">
                <Dumbbell className="w-10 h-10 text-[var(--text-sec)] mx-auto" />
                <h3 className="text-base font-black uppercase text-[var(--text)]">No Active Workouts Prescribed</h3>
                <p className="text-xs text-[var(--text-sec)]">Switch to the Needs Workout tab to assign routines.</p>
              </div>
            )}
          </div>
        )}

        {/* VIEW 3: EXPIRED WORKOUTS */}
        {activeTab === 'EXPIRED_WORKOUT' && (
          <div className="space-y-4">
            {filteredExpired.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredExpired.map((w: any) => (
                  <div key={w.id} className="clay-raised p-5 rounded-[24px] space-y-3 border border-[var(--border)]">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-sm font-black uppercase text-[var(--text)]">{w.memberName}</h3>
                        <p className="text-[10px] text-[var(--text-sec)] font-mono">{w.name}</p>
                      </div>
                      <span className="px-2.5 py-1 rounded-full text-[10px] font-black uppercase bg-gray-500/15 text-gray-400 border border-gray-500">
                        EXPIRED
                      </span>
                    </div>

                    <div className="p-3 neo-pressed rounded-[16px] text-xs font-mono space-y-1">
                      <div className="flex justify-between">
                        <span className="text-[var(--text-sec)]">Start Date:</span>
                        <span className="font-bold text-[var(--text)]">{w.startDate}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-[var(--text-sec)]">End Date:</span>
                        <span className="font-bold text-[var(--text)]">{w.endDate}</span>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        const m = members.find(mem => mem.id === w.memberId);
                        if (m) handleOpenBuilderForMember(m);
                      }}
                      className="w-full h-10 rounded-[14px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-wider flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <RefreshCw size={14} /> Renew & Reassign Routine
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="clay-raised p-12 rounded-[32px] text-center space-y-3">
                <Check className="w-10 h-10 text-[var(--text-sec)] mx-auto" />
                <h3 className="text-base font-black uppercase text-[var(--text)]">No Expired Routines</h3>
              </div>
            )}
          </div>
        )}

        {/* WORKOUT BUILDER MODAL / DRAWER */}
        {builderOpen && selectedMember && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
            <div className="bg-[var(--bg)] border border-[var(--border)] p-6 rounded-[32px] w-full max-w-2xl max-h-[90vh] overflow-y-auto space-y-5 shadow-2xl">
              <div className="flex justify-between items-center border-b border-[var(--border)] pb-3">
                <div>
                  <span className="text-[9px] font-black uppercase tracking-widest text-[#34A853]">WORKOUT PRESCRIPTION ENGINE</span>
                  <h3 className="text-lg font-black uppercase text-[var(--text)]">Routine for {selectedMember.fullName}</h3>
                </div>
                <button onClick={() => setBuilderOpen(false)} className="text-[var(--text-sec)] hover:text-[var(--text)] p-1">
                  <X size={20} />
                </button>
              </div>

              <form onSubmit={handleAssignWorkoutSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">
                      Routine Title *
                    </label>
                    <input
                      type="text"
                      value={workoutTitle}
                      onChange={(e) => setWorkoutTitle(e.target.value)}
                      placeholder="e.g. Upper Body Hypertrophy"
                      className="w-full h-11 px-3.5 neo-pressed rounded-[14px] text-xs font-bold text-[var(--text)] outline-none"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">
                      Primary Goal
                    </label>
                    <select
                      value={workoutGoal}
                      onChange={(e) => setWorkoutGoal(e.target.value)}
                      className="w-full h-11 px-3.5 neo-pressed rounded-[14px] text-xs font-bold text-[var(--text)] bg-transparent outline-none"
                    >
                      <option value="Hypertrophy & Strength">Hypertrophy & Strength</option>
                      <option value="Fat Loss & Conditioning">Fat Loss & Conditioning</option>
                      <option value="Beginner Foundation">Beginner Foundation</option>
                      <option value="Athletic Endurance">Athletic Endurance</option>
                    </select>
                  </div>
                </div>

                {/* Exercises Section */}
                <div className="space-y-3 pt-2">
                  <div className="flex justify-between items-center">
                    <h4 className="text-xs font-black uppercase tracking-wider text-[var(--text)] flex items-center gap-1.5">
                      <Dumbbell size={16} /> Prescribed Exercises ({builderExercises.length})
                    </h4>

                    <button
                      type="button"
                      onClick={() => setShowPicker(true)}
                      className="px-3 py-1.5 rounded-xl neo-raised text-xs font-black uppercase text-[#4285F4] flex items-center gap-1 cursor-pointer"
                    >
                      <Plus size={14} /> Add From Exercise Library
                    </button>
                  </div>

                  <div className="space-y-3 max-h-72 overflow-y-auto pr-1">
                    {builderExercises.map((ex, idx) => (
                      <div key={idx} className="p-4 rounded-[18px] neo-pressed space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="font-black text-xs uppercase text-[var(--text)]">
                            {idx + 1}. {ex.name}
                          </span>
                          <button
                            type="button"
                            onClick={() => removeExercise(idx)}
                            className="text-[#D64545] p-1 cursor-pointer"
                          >
                            <Trash2 size={14} />
                          </button>
                        </div>

                        <div className="grid grid-cols-4 gap-2 text-xs">
                          <div>
                            <span className="text-[9px] font-bold text-[var(--text-sec)] uppercase block">Sets</span>
                            <input
                              type="number"
                              value={ex.sets}
                              onChange={(e) => updateExercise(idx, 'sets', Number(e.target.value))}
                              className="w-full h-8 px-2 neo-raised rounded-lg text-center font-mono font-bold text-[var(--text)]"
                            />
                          </div>

                          <div>
                            <span className="text-[9px] font-bold text-[var(--text-sec)] uppercase block">Reps</span>
                            <input
                              type="text"
                              value={ex.reps}
                              onChange={(e) => updateExercise(idx, 'reps', e.target.value)}
                              className="w-full h-8 px-2 neo-raised rounded-lg text-center font-mono text-[var(--text)]"
                            />
                          </div>

                          <div>
                            <span className="text-[9px] font-bold text-[var(--text-sec)] uppercase block">Weight</span>
                            <input
                              type="text"
                              value={ex.weight}
                              onChange={(e) => updateExercise(idx, 'weight', e.target.value)}
                              className="w-full h-8 px-2 neo-raised rounded-lg text-center font-mono text-[var(--text)]"
                            />
                          </div>

                          <div>
                            <span className="text-[9px] font-bold text-[var(--text-sec)] uppercase block">Rest</span>
                            <input
                              type="text"
                              value={ex.rest}
                              onChange={(e) => updateExercise(idx, 'rest', e.target.value)}
                              className="w-full h-8 px-2 neo-raised rounded-lg text-center font-mono text-[var(--text)]"
                            />
                          </div>
                        </div>

                        <div>
                          <input
                            type="text"
                            value={ex.notes || ''}
                            onChange={(e) => updateExercise(idx, 'notes', e.target.value)}
                            placeholder="Instructions (e.g. Pause at bottom for 2 sec)"
                            className="w-full h-8 px-3 neo-raised rounded-lg text-[11px] text-[var(--text)] outline-none"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Duration & Recurrence */}
                <div className="grid grid-cols-3 gap-3 pt-2">
                  <div>
                    <label className="block text-[10px] font-bold uppercase text-[var(--text-sec)] mb-1">Start Date</label>
                    <input
                      type="date"
                      value={startDate}
                      onChange={(e) => setStartDate(e.target.value)}
                      className="w-full h-10 px-2.5 neo-pressed rounded-xl text-xs font-mono text-[var(--text)]"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold uppercase text-[var(--text-sec)] mb-1">Duration (Days)</label>
                    <select
                      value={durationDays}
                      onChange={(e) => setDurationDays(Number(e.target.value))}
                      className="w-full h-10 px-2.5 neo-pressed rounded-xl text-xs font-bold text-[var(--text)] bg-transparent"
                    >
                      <option value={1}>1 Day</option>
                      <option value={3}>3 Days</option>
                      <option value={7}>7 Days (1 Week)</option>
                      <option value={14}>14 Days (2 Weeks)</option>
                      <option value={30}>30 Days (1 Month)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold uppercase text-[var(--text-sec)] mb-1">Recurrence</label>
                    <select
                      value={repeatFrequency}
                      onChange={(e) => setRepeatFrequency(e.target.value)}
                      className="w-full h-10 px-2.5 neo-pressed rounded-xl text-xs font-bold text-[var(--text)] bg-transparent"
                    >
                      <option value="DAILY">Daily</option>
                      <option value="EVERY_3_DAYS">Every 3 Days</option>
                      <option value="EVERY_7_DAYS">Weekly</option>
                      <option value="ONCE">Once Only</option>
                    </select>
                  </div>
                </div>

                <div className="pt-3 flex gap-2">
                  <button
                    type="button"
                    onClick={() => setBuilderOpen(false)}
                    className="flex-1 h-12 rounded-[16px] neo-raised text-xs font-bold uppercase cursor-pointer"
                  >
                    Cancel
                  </button>

                  <button
                    type="submit"
                    disabled={assigning}
                    className="flex-1 h-12 rounded-[16px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer shadow-md active:scale-95 transition-transform"
                  >
                    {assigning ? <Clock className="w-4 h-4 animate-spin" /> : <Send size={16} />} Assign Routine Now
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* EXERCISE LIBRARY PICKER MODAL */}
        {showPicker && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
            <div className="bg-[var(--bg)] border border-[var(--border)] p-6 rounded-[32px] w-full max-w-lg max-h-[85vh] overflow-y-auto space-y-4 shadow-2xl">
              <div className="flex justify-between items-center border-b border-[var(--border)] pb-3">
                <h3 className="text-base font-black uppercase tracking-wider text-[var(--text)]">Exercise Library</h3>
                <button onClick={() => setShowPicker(false)} className="text-[var(--text-sec)] p-1">
                  <X size={18} />
                </button>
              </div>

              {/* Search & Custom Add */}
              <div className="space-y-2">
                <input
                  type="text"
                  placeholder="Search exercise by name or muscle group..."
                  value={pickerSearch}
                  onChange={(e) => setPickerSearch(e.target.value)}
                  className="w-full h-10 px-3.5 neo-pressed rounded-xl text-xs font-bold text-[var(--text)] outline-none"
                />

                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Or type custom exercise name..."
                    value={customExName}
                    onChange={(e) => setCustomExName(e.target.value)}
                    className="flex-1 h-9 px-3 neo-pressed rounded-lg text-xs text-[var(--text)] outline-none"
                  />
                  <button
                    type="button"
                    onClick={handleCreateCustomExercise}
                    className="h-9 px-3 rounded-lg bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-bold uppercase cursor-pointer"
                  >
                    Add Custom
                  </button>
                </div>
              </div>

              {/* Exercise List */}
              <div className="space-y-2 max-h-60 overflow-y-auto">
                {exerciseLibrary
                  .filter(ex => !pickerSearch || ex.name.toLowerCase().includes(pickerSearch.toLowerCase()) || ex.muscleGroup?.toLowerCase().includes(pickerSearch.toLowerCase()))
                  .map(ex => (
                    <div
                      key={ex.id}
                      onClick={() => handleAddExerciseFromLibrary(ex)}
                      className="p-3 rounded-xl neo-pressed flex items-center justify-between cursor-pointer hover:scale-[1.01] transition-transform text-xs"
                    >
                      <div>
                        <h4 className="font-black uppercase text-[var(--text)]">{ex.name}</h4>
                        <span className="text-[10px] text-[var(--text-sec)] font-mono">{ex.muscleGroup} • {ex.equipment}</span>
                      </div>
                      <Plus size={16} className="text-[#34A853]" />
                    </div>
                  ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </OwnerLayout>
  );
}
