import React, { useState, useEffect } from 'react';
import { useNavigate } from '@/lib/router-compat';
import { 
  IndianRupee, Search, Filter, Plus, ArrowUpRight, Clock, AlertTriangle, 
  CheckCircle, FileText, Printer, Share2, X, Send, CreditCard, RefreshCw,
  User, Check, AlertCircle, MessageSquare
} from 'lucide-react';
import OwnerLayout from '../../components/OwnerLayout';

type FilterTab = 'ALL' | 'OVERDUE' | 'EXPIRING_SOON' | 'DUE' | 'PARTIAL' | 'PAID';
type ExpiryFilter = 'ALL' | 'EXPIRED' | 'TODAY' | '1_3_DAYS' | '4_7_DAYS' | '8_30_DAYS' | 'OVER_30';

export default function PaymentsDashboard() {
  const navigate = useNavigate();
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [activeTab, setActiveTab] = useState<FilterTab>('ALL');
  const [expiryFilter, setExpiryFilter] = useState<ExpiryFilter>('ALL');

  // Modals
  const [selectedInvoice, setSelectedInvoice] = useState<any | null>(null);
  const [recordingMember, setRecordingMember] = useState<any | null>(null);
  const [recordingAmount, setRecordingAmount] = useState<string>('');
  const [recordingMode, setRecordingMode] = useState<string>('UPI');
  const [recordingRef, setRecordingRef] = useState<string>('');
  const [recordingNote, setRecordingNote] = useState<string>('');
  const [recordingDate, setRecordingDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [submittingPayment, setSubmittingPayment] = useState(false);
  const [paymentSuccessMsg, setPaymentSuccessMsg] = useState('');
  const [paymentError, setPaymentError] = useState('');

  const fetchPayments = () => {
    const sessionStr = localStorage.getItem('gym_session');
    if (!sessionStr) { navigate('/'); return; }
    const session = JSON.parse(sessionStr);

    fetch(`/api/payments/summary/${session.gymId}`)
      .then(res => res.json())
      .then(d => {
        if (d.success) setData(d);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchPayments();
  }, [navigate]);

  const handleOpenRecordModal = (member: any) => {
    setRecordingMember(member);
    setRecordingAmount(member.remainingDue > 0 ? String(member.remainingDue) : String(member.planPrice || 1500));
    setRecordingMode('UPI');
    setRecordingRef('');
    setRecordingNote('');
    setRecordingDate(new Date().toISOString().split('T')[0]);
    setPaymentError('');
    setPaymentSuccessMsg('');
  };

  const handleSubmitPaymentRecord = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!recordingMember || !recordingAmount || Number(recordingAmount) <= 0) {
      setPaymentError('Please enter a valid positive payment amount.');
      return;
    }

    const sessionStr = localStorage.getItem('gym_session');
    if (!sessionStr) return;
    const session = JSON.parse(sessionStr);

    setSubmittingPayment(true);
    setPaymentError('');

    try {
      const res = await fetch('/api/payments/record', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          gymId: session.gymId,
          memberId: recordingMember.id,
          amount: Number(recordingAmount),
          paymentMode: recordingMode,
          reference: recordingRef,
          note: recordingNote,
          date: recordingDate
        })
      });
      const resData = await res.json();
      if (resData.success) {
        setPaymentSuccessMsg(`Successfully recorded payment of ₹${recordingAmount} for ${recordingMember.fullName}!`);
        fetchPayments();
        setTimeout(() => {
          setRecordingMember(null);
          setPaymentSuccessMsg('');
        }, 1500);
      } else {
        setPaymentError(resData.message || 'Failed to record payment.');
      }
    } catch {
      setPaymentError('Network connection error.');
    } finally {
      setSubmittingPayment(false);
    }
  };

  const handleOpenInvoice = async (paymentId: string) => {
    const sessionStr = localStorage.getItem('gym_session');
    if (!sessionStr) return;
    const session = JSON.parse(sessionStr);

    try {
      const res = await fetch(`/api/invoices/${session.gymId}/${paymentId}`);
      const json = await res.json();
      if (json.success) {
        setSelectedInvoice(json.invoice);
      }
    } catch (err) {
      console.error(err);
    }
  };

  if (loading) {
    return (
      <OwnerLayout>
        <div className="py-20 text-center flex flex-col items-center justify-center space-y-3">
          <Clock className="w-8 h-8 text-[var(--text-sec)] animate-spin" />
          <span className="text-xs font-bold uppercase tracking-widest text-[var(--text-sec)]">Loading Financial State...</span>
        </div>
      </OwnerLayout>
    );
  }

  const members = data?.members || [];
  const transactions = data?.transactions || [];

  // Filter members based on tabs, expiry filter, and search text
  const filteredMembers = members.filter((m: any) => {
    // Search match
    const q = search.toLowerCase().trim();
    if (q) {
      const matchName = m.fullName?.toLowerCase().includes(q);
      const matchPhone = m.phone?.includes(q);
      const matchId = m.memberDisplayId?.toLowerCase().includes(q);
      const matchPlan = m.planName?.toLowerCase().includes(q);
      if (!matchName && !matchPhone && !matchId && !matchPlan) return false;
    }

    // Main Tab Filter
    if (activeTab === 'OVERDUE' && m.paymentStatus !== 'OVERDUE') return false;
    if (activeTab === 'EXPIRING_SOON' && (m.daysRemaining < 0 || m.daysRemaining > 7)) return false;
    if (activeTab === 'DUE' && m.remainingDue <= 0) return false;
    if (activeTab === 'PARTIAL' && m.paymentStatus !== 'PARTIAL') return false;
    if (activeTab === 'PAID' && m.paymentStatus !== 'PAID') return false;

    // Expiry Dropdown Sub-filter
    if (expiryFilter === 'EXPIRED' && !m.isExpired) return false;
    if (expiryFilter === 'TODAY' && !m.isExpiresToday) return false;
    if (expiryFilter === '1_3_DAYS' && (m.daysRemaining < 1 || m.daysRemaining > 3)) return false;
    if (expiryFilter === '4_7_DAYS' && (m.daysRemaining < 4 || m.daysRemaining > 7)) return false;
    if (expiryFilter === '8_30_DAYS' && (m.daysRemaining < 8 || m.daysRemaining > 30)) return false;
    if (expiryFilter === 'OVER_30' && m.daysRemaining <= 30) return false;

    return true;
  });

  return (
    <OwnerLayout>
      <div className="px-4 mt-6 space-y-6 pb-16 max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <span className="text-[9px] font-black uppercase tracking-[0.2em] text-[var(--text-sec)]">GYM FINANCIAL ENGINE</span>
            <h1 className="text-2xl font-black uppercase tracking-wider text-[var(--text)]">Payments & Member Dues</h1>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => navigate('/owner/plans')}
              className="h-10 px-4 rounded-xl neo-raised text-xs font-bold uppercase tracking-wider text-[var(--text)] flex items-center gap-1.5 cursor-pointer"
            >
              Manage Plans
            </button>
          </div>
        </div>

        {/* Real Revenue & Dues KPI Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
          <div className="neo-raised p-4 rounded-[20px]">
            <span className="text-[9px] font-black uppercase tracking-wider text-[var(--text-sec)]">This Month Revenue</span>
            <span className="text-xl sm:text-2xl font-black font-mono text-[#34A853] mt-1 block">
              ₹{(data?.monthlyRevenue || 0).toLocaleString('en-IN')}
            </span>
            <span className="text-[9px] text-[var(--text-sec)] font-medium">Realized collected payments</span>
          </div>

          <div className="neo-raised p-4 rounded-[20px]">
            <span className="text-[9px] font-black uppercase tracking-wider text-[#D64545]">Overdue Members</span>
            <span className="text-xl sm:text-2xl font-black font-mono text-[#D64545] mt-1 block">
              {data?.overdueCount || 0} Members
            </span>
            <span className="text-[9px] text-[var(--text-sec)] font-medium">Expired or unpaid</span>
          </div>

          <div className="neo-raised p-4 rounded-[20px]">
            <span className="text-[9px] font-black uppercase tracking-wider text-[#E3A008]">Pending Dues Count</span>
            <span className="text-xl sm:text-2xl font-black font-mono text-[#E3A008] mt-1 block">
              {data?.pendingCount || 0} Pending
            </span>
            <span className="text-[9px] text-[var(--text-sec)] font-medium">Require owner follow-up</span>
          </div>

          <div className="neo-raised p-4 rounded-[20px]">
            <span className="text-[9px] font-black uppercase tracking-wider text-[var(--text-sec)]">Total Lifetime Revenue</span>
            <span className="text-xl sm:text-2xl font-black font-mono text-[var(--text)] mt-1 block">
              ₹{(data?.totalRevenue || 0).toLocaleString('en-IN')}
            </span>
            <span className="text-[9px] text-[var(--text-sec)] font-medium">{transactions.length} total payments</span>
          </div>
        </div>

        {/* Filter Controls Bar */}
        <div className="space-y-3">
          {/* Main Filter Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {[
              { id: 'ALL', label: 'ALL MEMBERS', count: members.length },
              { id: 'OVERDUE', label: 'OVERDUE', count: members.filter((m: any) => m.paymentStatus === 'OVERDUE').length, badge: 'red' },
              { id: 'EXPIRING_SOON', label: 'EXPIRING (≤7 DAYS)', count: members.filter((m: any) => m.daysRemaining >= 0 && m.daysRemaining <= 7).length, badge: 'yellow' },
              { id: 'DUE', label: 'PENDING DUES', count: members.filter((m: any) => m.remainingDue > 0).length },
              { id: 'PARTIAL', label: 'PARTIAL PAID', count: members.filter((m: any) => m.paymentStatus === 'PARTIAL').length },
              { id: 'PAID', label: 'FULLY PAID', count: members.filter((m: any) => m.paymentStatus === 'PAID').length }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as FilterTab)}
                className={`px-3.5 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
                  activeTab === tab.id
                    ? 'bg-[var(--btn-bg)] text-[var(--btn-text)] shadow-md scale-[1.02]'
                    : 'neo-raised text-[var(--text-sec)] hover:text-[var(--text)]'
                }`}
              >
                <span>{tab.label}</span>
                <span className={`px-1.5 py-0.2 rounded-md text-[10px] font-mono ${
                  activeTab === tab.id ? 'bg-white/20 text-white' : 'bg-[var(--surface)] text-[var(--text)]'
                }`}>
                  {tab.count}
                </span>
              </button>
            ))}
          </div>

          {/* Search Bar & Expiry Dropdown */}
          <div className="flex flex-col sm:flex-row gap-2.5">
            <div className="relative flex-1">
              <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[var(--text-sec)]" />
              <input
                type="text"
                placeholder="Search member by name, phone, member ID, or plan..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full h-11 pl-10 pr-9 neo-pressed rounded-[14px] text-xs font-bold text-[var(--text)] outline-none focus:ring-1 focus:ring-[var(--text)]"
              />
              {search && (
                <button 
                  onClick={() => setSearch('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[var(--text-sec)] hover:text-[var(--text)] p-0.5"
                >
                  <X size={14} />
                </button>
              )}
            </div>

            <div className="flex items-center gap-2">
              <Filter size={16} className="text-[var(--text-sec)] hidden sm:block" />
              <select
                value={expiryFilter}
                onChange={(e) => setExpiryFilter(e.target.value as ExpiryFilter)}
                className="h-11 px-3 neo-pressed rounded-[14px] text-xs font-bold text-[var(--text)] bg-transparent outline-none cursor-pointer"
              >
                <option value="ALL">All Expiries</option>
                <option value="EXPIRED">Expired</option>
                <option value="TODAY">Expires Today</option>
                <option value="1_3_DAYS">Expires 1–3 Days</option>
                <option value="4_7_DAYS">Expires 4–7 Days</option>
                <option value="8_30_DAYS">Expires 8–30 Days</option>
                <option value="OVER_30">30+ Days Remaining</option>
              </select>
            </div>
          </div>
        </div>

        {/* Member Payment Status Grid */}
        <div className="space-y-3">
          <div className="flex items-center justify-between text-xs font-bold text-[var(--text-sec)] px-1">
            <span>SHOWING {filteredMembers.length} MEMBERS</span>
            <span>PERSISTED BACKEND REALTIME DATA</span>
          </div>

          {filteredMembers.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredMembers.map((m: any) => {
                const isOverdue = m.paymentStatus === 'OVERDUE' || m.isExpired;
                const isPartial = m.paymentStatus === 'PARTIAL';
                const isPaid = m.paymentStatus === 'PAID';

                return (
                  <div 
                    key={m.id}
                    className={`clay-raised p-5 rounded-[24px] space-y-4 border transition-all ${
                      isOverdue ? 'border-[#D64545]/40 bg-[#D64545]/5' :
                      isPartial ? 'border-[#E3A008]/40 bg-[#E3A008]/5' :
                      'border-[var(--border)]'
                    }`}
                  >
                    {/* Header Row */}
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-3">
                        {m.profileImage ? (
                          <img src={m.profileImage} alt={m.fullName} className="w-12 h-12 rounded-2xl object-cover border border-[var(--border)]" />
                        ) : (
                          <div className="w-12 h-12 rounded-2xl neo-raised flex items-center justify-center font-black text-sm uppercase text-[var(--text)]">
                            {m.fullName?.charAt(0) || 'M'}
                          </div>
                        )}
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="text-sm font-black uppercase text-[var(--text)]">{m.fullName}</h3>
                            <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-[var(--surface)] text-[var(--text-sec)]">
                              {m.memberDisplayId || 'MEM-0000'}
                            </span>
                          </div>
                          <p className="text-[11px] font-mono font-bold text-[var(--text-sec)] mt-0.5">{m.phone}</p>
                        </div>
                      </div>

                      {/* Payment Status Pill */}
                      <span className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider border ${
                        isPaid ? 'bg-[#34A853]/15 text-[#34A853] border-[#34A853]' :
                        isPartial ? 'bg-[#E3A008]/15 text-[#E3A008] border-[#E3A008]' :
                        'bg-[#D64545]/15 text-[#D64545] border-[#D64545]'
                      }`}>
                        {m.paymentStatus}
                      </span>
                    </div>

                    {/* Plan & Expiry Details */}
                    <div className="p-3 neo-pressed rounded-[16px] grid grid-cols-2 gap-2 text-xs font-mono">
                      <div>
                        <span className="text-[9px] font-bold text-[var(--text-sec)] uppercase block">Plan</span>
                        <span className="font-bold text-[var(--text)] truncate block">{m.planName}</span>
                      </div>

                      <div>
                        <span className="text-[9px] font-bold text-[var(--text-sec)] uppercase block">Plan Price</span>
                        <span className="font-bold text-[var(--text)]">₹{m.planPrice}</span>
                      </div>

                      <div className="pt-1.5 border-t border-[var(--border)]">
                        <span className="text-[9px] font-bold text-[var(--text-sec)] uppercase block">Expiry Date</span>
                        <span className="font-bold text-[var(--text)]">{m.endDate || 'N/A'}</span>
                      </div>

                      <div className="pt-1.5 border-t border-[var(--border)]">
                        <span className="text-[9px] font-bold text-[var(--text-sec)] uppercase block">Status / Days</span>
                        <span className={`font-black ${
                          m.daysRemaining < 0 ? 'text-[#D64545]' :
                          m.daysRemaining <= 3 ? 'text-[#E3A008]' :
                          'text-[#34A853]'
                        }`}>
                          {m.daysRemaining < 0 ? `${m.daysOverdue} Days Overdue` :
                           m.daysRemaining === 0 ? 'Expires Today' :
                           `${m.daysRemaining} Days Left`}
                        </span>
                      </div>
                    </div>

                    {/* Amount Breakdown */}
                    <div className="flex items-center justify-between text-xs px-1">
                      <div>
                        <span className="text-[10px] text-[var(--text-sec)] font-bold uppercase block">Total Paid</span>
                        <span className="text-sm font-black font-mono text-[#34A853]">₹{(m.totalPaid || 0).toLocaleString('en-IN')}</span>
                      </div>

                      <div className="text-right">
                        <span className="text-[10px] text-[var(--text-sec)] font-bold uppercase block">Remaining Due</span>
                        <span className={`text-sm font-black font-mono ${m.remainingDue > 0 ? 'text-[#D64545]' : 'text-[var(--text-sec)]'}`}>
                          ₹{(m.remainingDue || 0).toLocaleString('en-IN')}
                        </span>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center gap-2 pt-1">
                      <button
                        onClick={() => handleOpenRecordModal(m)}
                        className="flex-1 h-10 rounded-[14px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-[11px] font-black uppercase tracking-wider flex items-center justify-center gap-1.5 cursor-pointer shadow-sm active:scale-95 transition-transform"
                      >
                        <CreditCard size={14} /> Record Payment
                      </button>

                      <a
                        href={`https://wa.me/91${m.phone}?text=${encodeURIComponent(`Hello ${m.fullName}! Quick reminder regarding your ${m.planName} membership at our gym. Plan price: ₹${m.planPrice}, Remaining due: ₹${m.remainingDue}. Please clear your dues or renew your plan.`)}`}
                        target="_blank"
                        rel="noreferrer"
                        className="h-10 px-3 rounded-[14px] bg-[#25D366] text-white text-[11px] font-black uppercase tracking-wider flex items-center justify-center gap-1 cursor-pointer active:scale-95 transition-transform"
                        title="Send WhatsApp Reminder"
                      >
                        <MessageSquare size={14} /> WhatsApp
                      </a>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="clay-raised p-12 rounded-[32px] text-center space-y-3">
              <div className="w-12 h-12 rounded-2xl neo-raised flex items-center justify-center mx-auto text-[var(--text-sec)] font-black">
                <CheckCircle size={24} />
              </div>
              <h3 className="text-base font-black uppercase tracking-wider text-[var(--text)]">No Matching Member Payments</h3>
              <p className="text-xs text-[var(--text-sec)] max-w-sm mx-auto">
                No members match the selected tab filter or search query. Try clearing filters or searching for a different name.
              </p>
            </div>
          )}
        </div>

        {/* Recent Transactions Table */}
        <div className="clay-raised p-6 rounded-[28px] space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-black uppercase tracking-wider text-[var(--text)]">Recent Payment Receipts</h3>
            <span className="text-[10px] font-bold text-[var(--text-sec)]">{transactions.length} Total</span>
          </div>

          <div className="space-y-2.5">
            {transactions.slice(0, 10).map((t: any) => (
              <div key={t.id} className="p-3.5 rounded-[16px] neo-pressed flex items-center justify-between gap-3 text-xs">
                <div>
                  <h4 className="font-black uppercase text-[var(--text)]">{t.memberName}</h4>
                  <p className="text-[10px] text-[var(--text-sec)] font-mono">
                    {t.planName} • Mode: {t.paymentMode} {t.reference ? `• Ref: ${t.reference}` : ''}
                  </p>
                  <span className="text-[9px] text-[var(--text-sec)] font-mono">{t.date || t.createdAt?.split('T')[0]}</span>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <span className="font-black font-mono text-[#34A853] text-sm">₹{t.amount}</span>
                    <span className="text-[9px] font-bold text-[#34A853] uppercase block">PAID</span>
                  </div>

                  <button
                    onClick={() => handleOpenInvoice(t.id)}
                    className="p-2 rounded-xl neo-raised text-[var(--text)] hover:scale-105 active:scale-95 cursor-pointer"
                    title="Print Receipt"
                  >
                    <FileText size={14} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Record Payment Modal */}
        {recordingMember && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
            <div className="bg-[var(--bg)] border border-[var(--border)] p-6 rounded-[32px] w-full max-w-md space-y-5 shadow-2xl">
              <div className="flex justify-between items-center border-b border-[var(--border)] pb-3">
                <div>
                  <span className="text-[9px] font-black uppercase tracking-widest text-[#34A853]">RECORD MANUAL PAYMENT</span>
                  <h3 className="text-base font-black uppercase text-[var(--text)]">{recordingMember.fullName}</h3>
                </div>
                <button onClick={() => setRecordingMember(null)} className="text-[var(--text-sec)] hover:text-[var(--text)] p-1">
                  <X size={18} />
                </button>
              </div>

              {paymentSuccessMsg && (
                <div className="p-3.5 rounded-xl bg-[#34A853]/15 border border-[#34A853] text-[#34A853] text-xs font-bold flex items-center gap-2">
                  <Check size={16} /> {paymentSuccessMsg}
                </div>
              )}

              {paymentError && (
                <div className="p-3.5 rounded-xl bg-[#D64545]/15 border border-[#D64545] text-[#D64545] text-xs font-bold flex items-center gap-2">
                  <AlertCircle size={16} /> {paymentError}
                </div>
              )}

              <form onSubmit={handleSubmitPaymentRecord} className="space-y-4">
                <div className="p-3 neo-pressed rounded-[16px] space-y-1 text-xs font-mono">
                  <div className="flex justify-between text-[var(--text-sec)]">
                    <span>Plan:</span>
                    <span className="font-bold text-[var(--text)]">{recordingMember.planName}</span>
                  </div>
                  <div className="flex justify-between text-[var(--text-sec)]">
                    <span>Plan Price:</span>
                    <span className="font-bold text-[var(--text)]">₹{recordingMember.planPrice}</span>
                  </div>
                  <div className="flex justify-between text-[var(--text-sec)] border-t border-[var(--border)] pt-1">
                    <span>Remaining Due:</span>
                    <span className="font-bold text-[#D64545]">₹{recordingMember.remainingDue}</span>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">
                    Payment Amount Received (₹) *
                  </label>
                  <input
                    type="number"
                    value={recordingAmount}
                    onChange={(e) => setRecordingAmount(e.target.value)}
                    placeholder="Enter amount"
                    className="w-full h-12 px-4 neo-pressed rounded-[14px] outline-none text-base font-mono font-bold text-[var(--text)]"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">
                    Payment Method
                  </label>
                  <select
                    value={recordingMode}
                    onChange={(e) => setRecordingMode(e.target.value)}
                    className="w-full h-12 px-4 neo-pressed rounded-[14px] outline-none text-xs font-bold text-[var(--text)] bg-transparent"
                  >
                    <option value="UPI">UPI (GPay / PhonePe / Paytm)</option>
                    <option value="Cash">Cash Handover</option>
                    <option value="Card">Debit / Credit Card</option>
                    <option value="Bank Transfer">Bank Transfer / IMPS</option>
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">
                      Ref / UTR Number
                    </label>
                    <input
                      type="text"
                      value={recordingRef}
                      onChange={(e) => setRecordingRef(e.target.value)}
                      placeholder="e.g. 426189012"
                      className="w-full h-11 px-3 neo-pressed rounded-[12px] outline-none text-xs font-mono text-[var(--text)]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">
                      Payment Date
                    </label>
                    <input
                      type="date"
                      value={recordingDate}
                      onChange={(e) => setRecordingDate(e.target.value)}
                      className="w-full h-11 px-3 neo-pressed rounded-[12px] outline-none text-xs font-mono text-[var(--text)]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">
                    Internal Note (Optional)
                  </label>
                  <input
                    type="text"
                    value={recordingNote}
                    onChange={(e) => setRecordingNote(e.target.value)}
                    placeholder="e.g. Paid partial in cash"
                    className="w-full h-11 px-3 neo-pressed rounded-[12px] outline-none text-xs font-bold text-[var(--text)]"
                  />
                </div>

                <div className="pt-2 flex gap-2">
                  <button
                    type="button"
                    onClick={() => setRecordingMember(null)}
                    className="flex-1 h-12 rounded-[16px] neo-raised text-xs font-bold uppercase tracking-wider cursor-pointer"
                  >
                    Cancel
                  </button>

                  <button
                    type="submit"
                    disabled={submittingPayment}
                    className="flex-1 h-12 rounded-[16px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer shadow-md active:scale-95 transition-transform"
                  >
                    {submittingPayment ? <Clock className="w-4 h-4 animate-spin" /> : <Check size={16} />} Record & Save
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Invoice Modal */}
        {selectedInvoice && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
            <div className="bg-[var(--bg)] border border-[var(--border)] p-6 rounded-[28px] w-full max-w-md space-y-4 shadow-2xl">
              <div className="flex justify-between items-center border-b border-[var(--border)] pb-3">
                <span className="text-[9px] font-black uppercase tracking-widest text-[#34A853]">OFFICIAL PAYMENT RECEIPT</span>
                <button onClick={() => setSelectedInvoice(null)} className="text-[var(--text-sec)] hover:text-[var(--text)]">✕</button>
              </div>

              <div className="p-5 neo-pressed rounded-[20px] space-y-3 font-mono text-xs">
                <div className="text-center border-b border-[var(--border)] pb-3">
                  <h3 className="text-base font-black uppercase tracking-wider text-[var(--text)]">{selectedInvoice.gymName}</h3>
                  <p className="text-[10px] text-[var(--text-sec)]">{selectedInvoice.gymAddress}</p>
                  <span className="text-[10px] font-bold text-[#34A853] block mt-1">{selectedInvoice.invoiceNumber}</span>
                </div>

                <div className="space-y-1.5 pt-1">
                  <div className="flex justify-between">
                    <span className="text-[var(--text-sec)]">Date:</span>
                    <span className="font-bold text-[var(--text)]">{selectedInvoice.date}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[var(--text-sec)]">Member Name:</span>
                    <span className="font-bold text-[var(--text)]">{selectedInvoice.memberName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[var(--text-sec)]">Member ID:</span>
                    <span className="font-bold text-[var(--text)]">{selectedInvoice.memberId}</span>
                  </div>
                  <div className="flex justify-between border-t border-[var(--border)] pt-2">
                    <span className="text-[var(--text-sec)]">Plan Description:</span>
                    <span className="font-bold text-[var(--text)]">{selectedInvoice.planName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[var(--text-sec)]">Payment Method:</span>
                    <span className="font-bold text-[var(--text)]">{selectedInvoice.paymentMode}</span>
                  </div>
                  {selectedInvoice.utrNumber && (
                    <div className="flex justify-between">
                      <span className="text-[var(--text-sec)]">UTR Ref:</span>
                      <span className="font-bold text-[var(--text)]">{selectedInvoice.utrNumber}</span>
                    </div>
                  )}
                  <div className="flex justify-between border-t border-[var(--border)] pt-2 text-sm font-black">
                    <span className="text-[var(--text)]">Total Amount Paid:</span>
                    <span className="text-[#34A853]">₹{selectedInvoice.amount}</span>
                  </div>
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => window.print()}
                  className="flex-1 h-11 rounded-[14px] neo-pressed text-[var(--text)] text-xs font-bold uppercase flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Printer size={16} /> Print
                </button>
                <a
                  href={`https://wa.me/91${selectedInvoice.memberPhone}?text=${encodeURIComponent(`Here is your gym payment receipt from ${selectedInvoice.gymName}:\n\nInvoice: ${selectedInvoice.invoiceNumber}\nAmount Paid: ₹${selectedInvoice.amount}\nPlan: ${selectedInvoice.planName}\nDate: ${selectedInvoice.date}\n\nThank you!`)}`}
                  target="_blank"
                  rel="noreferrer"
                  className="flex-1 h-11 rounded-[14px] bg-[#25D366] text-white text-xs font-black uppercase flex items-center justify-center gap-2 cursor-pointer shadow-sm active:scale-95 transition-transform"
                >
                  <Share2 size={16} /> WhatsApp
                </a>
              </div>
            </div>
          </div>
        )}
      </div>
    </OwnerLayout>
  );
}
