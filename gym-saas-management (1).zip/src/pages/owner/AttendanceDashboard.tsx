import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from '@/lib/router-compat';
import { QrCode, CheckCircle, Clock, UserCheck, Search, Calendar, ChevronRight, Check } from 'lucide-react';
import OwnerLayout from '../../components/OwnerLayout';

export default function AttendanceDashboard() {
  const navigate = useNavigate();
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  const fetchAttendance = () => {
    const sessionStr = localStorage.getItem('gym_session');
    if (!sessionStr) { navigate('/'); return; }
    const session = JSON.parse(sessionStr);

    fetch(`/api/attendance/summary/${session.gymId}`)
      .then(res => res.json())
      .then(d => setData(d))
      .catch(console.error)
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchAttendance();
  }, [navigate]);

  if (loading) {
    return (
      <OwnerLayout>
        <div className="py-20 text-center text-4xl animate-pulse">🏋️</div>
      </OwnerLayout>
    );
  }

  const logs = data?.todayLogs || [];
  const filteredLogs = logs.filter((l: any) => 
    l.memberName?.toLowerCase().includes(search.toLowerCase()) ||
    l.checkIn?.includes(search)
  );

  return (
    <OwnerLayout>
      <div className="px-4 mt-6 space-y-6 pb-10">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)]">Live Tracker</span>
            <h1 className="text-2xl font-black uppercase tracking-wider text-[var(--text)]">Today's Attendance</h1>
          </div>
          <div className="flex items-center gap-2">
            <Link
              to="/owner/attendance/qr"
              className="h-11 px-4 rounded-[16px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 active:scale-95 transition-transform"
            >
              <QrCode size={16} /> DISPLAY QR
            </Link>
            <Link
              to="/owner/attendance/manual"
              className="h-11 px-4 rounded-[16px] neo-raised text-[var(--text)] text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 active:scale-95 transition-transform"
            >
              <UserCheck size={16} /> MANUAL CHECK-IN
            </Link>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="p-4 neo-raised rounded-[20px]">
            <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Present Today</span>
            <span className="text-2xl font-black font-mono text-[#34A853]">{data?.presentCount || 0}</span>
          </div>
          <div className="p-4 neo-raised rounded-[20px]">
            <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Total Active</span>
            <span className="text-2xl font-black font-mono text-[var(--text)]">{data?.totalActive || 0}</span>
          </div>
          <div className="p-4 neo-raised rounded-[20px]">
            <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Check-in Rate</span>
            <span className="text-2xl font-black font-mono text-[#4285F4]">
              {data?.totalActive > 0 ? Math.round((data.presentCount / data.totalActive) * 100) : 0}%
            </span>
          </div>
          <div className="p-4 neo-raised rounded-[20px]">
            <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">QR Scans</span>
            <span className="text-2xl font-black font-mono text-[var(--text)]">{logs.length}</span>
          </div>
        </div>

        {/* Search */}
        <div className="relative">
          <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-[var(--text-sec)]" />
          <input
            type="text"
            placeholder="Search today's check-ins by member name..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full h-12 pl-11 pr-4 neo-pressed rounded-[16px] text-xs font-bold text-[var(--text)] outline-none focus:ring-1 focus:ring-[var(--text)]"
          />
        </div>

        {/* Check-ins list */}
        <div className="clay-raised p-6 rounded-[24px] space-y-4">
          <h3 className="text-xs font-black uppercase tracking-wider text-[var(--text)]">Check-in Feed</h3>

          {filteredLogs.length > 0 ? (
            <div className="space-y-2">
              {filteredLogs.map((log: any) => (
                <div key={log.id} className="p-3.5 rounded-[16px] neo-pressed flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full bg-[#34A853]/20 text-[#34A853] flex items-center justify-center font-bold text-xs shrink-0">
                      <Check size={16} />
                    </div>
                    <div>
                      <h4 className="text-xs font-black uppercase text-[var(--text)]">{log.memberName}</h4>
                      <p className="text-[10px] text-[var(--text-sec)] font-mono">{log.method || 'QR Scan'}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-xs font-mono font-bold text-[var(--text)]">{log.checkIn}</span>
                    <span className="text-[9px] font-bold text-[#34A853] uppercase block">CHECKED IN</span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-8 text-center text-xs font-bold text-[var(--text-sec)] uppercase tracking-wider">
              No check-ins recorded for today yet.
            </div>
          )}
        </div>
      </div>
    </OwnerLayout>
  );
}
