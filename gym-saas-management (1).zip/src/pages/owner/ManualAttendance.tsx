import React, { useState, useEffect } from 'react';
import { useNavigate } from '@/lib/router-compat';
import { ArrowLeft, UserCheck, Search, Check, AlertCircle, Clock } from 'lucide-react';
import OwnerLayout from '../../components/OwnerLayout';

export default function ManualAttendance() {
  const navigate = useNavigate();
  const [members, setMembers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [markedIds, setMarkedIds] = useState<string[]>([]);
  const [statusMap, setStatusMap] = useState<Record<string, { success: boolean; msg: string; checkInTime?: string }>>({});

  useEffect(() => {
    const sessionStr = localStorage.getItem('gym_session');
    if (!sessionStr) { navigate('/'); return; }
    const session = JSON.parse(sessionStr);

    fetch(`/api/members/${session.gymId}`)
      .then(res => res.json())
      .then(data => {
        if (data && data.members) {
          setMembers(data.members.filter((m: any) => m.status !== 'ARCHIVED'));
        }
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [navigate]);

  const handleCheckIn = async (memberId: string) => {
    const sessionStr = localStorage.getItem('gym_session');
    if (!sessionStr) return;
    const session = JSON.parse(sessionStr);

    try {
      const res = await fetch(`/api/attendance/${session.gymId}/manual`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          memberId,
          method: 'MANUAL'
        })
      });
      const data = await res.json();
      if (data.success) {
        setMarkedIds(prev => [...prev, memberId]);
        setStatusMap(prev => ({
          ...prev,
          [memberId]: { success: true, msg: 'Marked Present', checkInTime: data.checkInTime }
        }));
      } else if (data.alreadyCheckedIn || data.code === 'ALREADY_CHECKED_IN') {
        setMarkedIds(prev => [...prev, memberId]);
        setStatusMap(prev => ({
          ...prev,
          [memberId]: { success: true, msg: `Already Checked In (${data.checkInTime || 'Recorded'})` }
        }));
      } else {
        setStatusMap(prev => ({
          ...prev,
          [memberId]: { success: false, msg: data.message || 'Check-in denied.' }
        }));
      }
    } catch (e) {
      console.error(e);
      setStatusMap(prev => ({
        ...prev,
        [memberId]: { success: false, msg: 'Network connection failed.' }
      }));
    }
  };

  const filtered = members.filter(m => 
    m.fullName?.toLowerCase().includes(search.toLowerCase()) ||
    m.phone?.includes(search) ||
    m.memberDisplayId?.toLowerCase().includes(search.toLowerCase()) ||
    m.id?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <OwnerLayout>
      <div className="px-4 mt-6 space-y-6 max-w-lg mx-auto pb-12">
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate('/owner/attendance')}
            className="w-10 h-10 rounded-full neo-raised flex items-center justify-center text-[var(--text)] active:scale-95 transition-transform cursor-pointer"
          >
            <ArrowLeft size={18} />
          </button>
          <div>
            <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)]">Reception Override</span>
            <h1 className="text-xl font-black uppercase tracking-wider text-[var(--text)]">Manual Check-In</h1>
          </div>
        </div>

        <div className="relative">
          <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-[var(--text-sec)]" />
          <input
            type="text"
            placeholder="Search member by name, ID or phone..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full h-12 pl-11 pr-4 neo-pressed rounded-[16px] text-xs font-bold text-[var(--text)] outline-none focus:ring-1 focus:ring-[var(--text)]"
          />
        </div>

        {loading ? (
          <div className="py-20 text-center text-xs font-mono text-[var(--text-sec)]">Loading member directory...</div>
        ) : (
          <div className="space-y-3">
            {filtered.map((m) => {
              const isMarked = markedIds.includes(m.id);
              const statusInfo = statusMap[m.id];
              const isBlocked = m.status === 'BLOCKED' || m.status === 'FROZEN';

              return (
                <div
                  key={m.id}
                  className="neo-raised p-4 rounded-[20px] space-y-2"
                >
                  <div className="flex items-center justify-between gap-4">
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="text-xs font-black uppercase text-[var(--text)]">{m.fullName}</h3>
                        {m.status && m.status !== 'ACTIVE' && (
                          <span className={`text-[8px] font-black uppercase px-2 py-0.5 rounded-full ${
                            m.status === 'BLOCKED' ? 'bg-[#D64545]/10 text-[#D64545]' : 'bg-amber-500/10 text-amber-500'
                          }`}>
                            {m.status}
                          </span>
                        )}
                      </div>
                      <p className="text-[10px] text-[var(--text-sec)] font-mono">
                        {m.memberDisplayId || m.id} • {m.phone || 'No phone'}
                      </p>
                    </div>

                    <button
                      onClick={() => handleCheckIn(m.id)}
                      disabled={isMarked || isBlocked}
                      className={`h-10 px-4 rounded-[14px] text-xs font-black uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer ${
                        isMarked
                          ? 'bg-[#34A853] text-white cursor-default'
                          : isBlocked
                          ? 'bg-neutral-300 dark:bg-neutral-800 text-neutral-500 cursor-not-allowed opacity-60'
                          : 'bg-[var(--btn-bg)] text-[var(--btn-text)] active:scale-95'
                      }`}
                    >
                      {isMarked ? (
                        <><Check size={16} /> CHECKED IN</>
                      ) : isBlocked ? (
                        'RESTRICTED'
                      ) : (
                        'CHECK IN'
                      )}
                    </button>
                  </div>

                  {statusInfo && (
                    <div className={`p-2.5 rounded-[12px] text-[11px] font-bold flex items-center gap-2 ${
                      statusInfo.success
                        ? 'bg-[#34A853]/10 text-[#34A853]'
                        : 'bg-[#D64545]/10 text-[#D64545]'
                    }`}>
                      {statusInfo.success ? <Check size={14} /> : <AlertCircle size={14} />}
                      <span>{statusInfo.msg}</span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </OwnerLayout>
  );
}

