import React, { useState, useEffect } from 'react';
import { useNavigate } from '@/lib/router-compat';
import { TrendingUp, Users, AlertCircle, Clock, Calendar, MessageSquare, DollarSign, Activity, ArrowRight } from 'lucide-react';
import OwnerLayout from '../../components/OwnerLayout';

export default function OwnerPerformance() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<any | null>(null);

  const fetchPerformance = async () => {
    const sessionStr = localStorage.getItem('gym_session');
    if (!sessionStr) { navigate('/'); return; }
    const session = JSON.parse(sessionStr);

    try {
      const res = await fetch(`/api/owner/performance/${session.gymId}`);
      const json = await res.json();
      if (json.success) {
        setData(json);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPerformance();
  }, []);

  if (loading || !data) {
    return (
      <OwnerLayout>
        <div className="py-20 text-center text-3xl animate-pulse">📊 Loading Performance Analytics...</div>
      </OwnerLayout>
    );
  }

  return (
    <OwnerLayout>
      <div className="px-4 mt-6 space-y-6 pb-12">
        <div>
          <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)]">Analytics & Health Score</span>
          <h1 className="text-2xl font-black uppercase tracking-wider text-[var(--text)]">Gym Performance</h1>
        </div>

        {/* Top Metric Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div className="p-4 rounded-[22px] neo-raised space-y-1">
            <span className="text-[9px] font-black uppercase tracking-widest text-[#34A853]">GYM HEALTH SCORE</span>
            <div className="flex items-baseline gap-1">
              <span className="text-2xl font-black text-[var(--text)]">{data.gymHealthScore}</span>
              <span className="text-xs font-bold text-[#34A853]">/100</span>
            </div>
            <span className="text-[9px] text-[var(--text-sec)] block font-mono">Based on active retention</span>
          </div>

          <div className="p-4 rounded-[22px] neo-raised space-y-1">
            <span className="text-[9px] font-black uppercase tracking-widest text-[var(--text-sec)]">TOTAL ACTIVE MEMBERS</span>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-black text-[var(--text)]">{data.activeCount}</span>
              <span className="text-[10px] text-[var(--text-sec)] font-mono">/ {data.totalMembers} total</span>
            </div>
            <span className="text-[9px] text-[var(--text-sec)] block font-mono">{data.frozenCount} frozen</span>
          </div>

          <div className="p-4 rounded-[22px] neo-raised space-y-1">
            <span className="text-[9px] font-black uppercase tracking-widest text-[#EA4335]">INACTIVE (7+ DAYS)</span>
            <span className="text-2xl font-black text-[#EA4335] block">{data.inactive7Days}</span>
            <span className="text-[9px] text-[var(--text-sec)] block font-mono">Members at risk</span>
          </div>

          <div className="p-4 rounded-[22px] neo-raised space-y-1">
            <span className="text-[9px] font-black uppercase tracking-widest text-[#E37400]">TOTAL COLLECTED</span>
            <span className="text-2xl font-black text-[var(--text)] block">₹{data.totalCollected.toLocaleString()}</span>
            <span className="text-[9px] text-[#EA4335] block font-mono">₹{data.totalPendingAmount} pending</span>
          </div>
        </div>

        {/* Inactive Members Section */}
        <div className="clay-raised p-6 rounded-[28px] space-y-4">
          <div className="flex justify-between items-center border-b border-[var(--border)] pb-3">
            <div>
              <span className="text-[9px] font-black uppercase tracking-widest text-[#EA4335]">RETENTION WARN</span>
              <h3 className="text-sm font-black uppercase tracking-wider text-[var(--text)]">
                Members Absent for 7+ Days ({data.inactiveMembersList?.length || 0})
              </h3>
            </div>
          </div>

          <div className="space-y-2">
            {(data.inactiveMembersList || []).map((m: any) => (
              <div key={m.id} className="p-3 neo-pressed rounded-[16px] flex justify-between items-center">
                <div>
                  <span className="text-xs font-black uppercase text-[var(--text)] block">{m.fullName}</span>
                  <span className="text-[9px] font-mono text-[var(--text-sec)]">Last visit: {m.lastVisit}</span>
                </div>

                <a
                  href={`https://wa.me/91${m.phone}?text=${encodeURIComponent(`Hi ${m.fullName}, we missed you at the gym! Come back for your workout routine today 💪`)}`}
                  target="_blank"
                  rel="noreferrer"
                  className="px-3 py-1.5 rounded-xl bg-[#25D366] text-white text-[10px] font-black uppercase flex items-center gap-1 cursor-pointer hover:scale-105 active:scale-95 transition-all"
                >
                  <MessageSquare size={12} /> WhatsApp
                </a>
              </div>
            ))}

            {(data.inactiveMembersList?.length || 0) === 0 && (
              <p className="text-xs font-bold text-[var(--text-sec)] text-center py-4">🎉 Excellent! No members are absent 7+ days.</p>
            )}
          </div>
        </div>

        {/* Membership Expiry Section */}
        <div className="neo-raised p-6 rounded-[28px] space-y-4">
          <h3 className="text-sm font-black uppercase tracking-wider text-[var(--text)] border-b border-[var(--border)] pb-3">
            Membership Expiry Pipeline
          </h3>

          <div className="grid grid-cols-3 gap-3">
            <div className="p-4 neo-pressed rounded-[20px] text-center">
              <span className="text-xs font-black text-[#EA4335] block text-xl">{data.expiringToday}</span>
              <span className="text-[9px] font-bold uppercase text-[var(--text-sec)]">Expiring Today</span>
            </div>

            <div className="p-4 neo-pressed rounded-[20px] text-center">
              <span className="text-xs font-black text-[#E37400] block text-xl">{data.expiring3Days}</span>
              <span className="text-[9px] font-bold uppercase text-[var(--text-sec)]">Within 3 Days</span>
            </div>

            <div className="p-4 neo-pressed rounded-[20px] text-center">
              <span className="text-xs font-black text-[var(--text)] block text-xl">{data.expiring7Days}</span>
              <span className="text-[9px] font-bold uppercase text-[var(--text-sec)]">Within 7 Days</span>
            </div>
          </div>
        </div>

        {/* Plan Distribution */}
        <div className="neo-raised p-6 rounded-[28px] space-y-4">
          <h3 className="text-sm font-black uppercase tracking-wider text-[var(--text)] border-b border-[var(--border)] pb-3">
            Plan Subscriptions Breakdown
          </h3>

          <div className="space-y-2">
            {(data.planDistribution || []).map((p: any) => (
              <div key={p.planId} className="p-3 neo-pressed rounded-[16px] flex justify-between items-center">
                <div>
                  <span className="text-xs font-black uppercase text-[var(--text)] block">{p.planName}</span>
                  <span className="text-[10px] font-mono text-[var(--text-sec)]">₹{p.price} / plan</span>
                </div>
                <div className="text-right">
                  <span className="text-sm font-black text-[var(--text)]">{p.count} Members</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </OwnerLayout>
  );
}
