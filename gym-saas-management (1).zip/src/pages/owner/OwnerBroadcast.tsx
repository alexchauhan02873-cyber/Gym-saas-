import React, { useState } from 'react';
import { useNavigate } from '@/lib/router-compat';
import { Send, Sparkles, Bell, CheckCircle } from 'lucide-react';
import OwnerLayout from '../../components/OwnerLayout';

export default function OwnerBroadcast() {
  const navigate = useNavigate();
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [targetGroup, setTargetGroup] = useState('ALL');
  const [sending, setSending] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');

  const handleSendBroadcast = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !body.trim()) return;

    setSending(true);
    setSuccessMsg('');

    const sessionStr = localStorage.getItem('gym_session');
    if (!sessionStr) return;
    const session = JSON.parse(sessionStr);

    try {
      const res = await fetch('/api/notifications/broadcast', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          gymId: session.gymId,
          title: title.trim(),
          body: body.trim(),
          targetGroup
        })
      });
      const data = await res.json();
      if (data.success) {
        setSuccessMsg(`Broadcast sent to ${data.recipientCount || 'all'} members!`);
        setTitle('');
        setBody('');
      }
    } catch (e) {
      console.error(e);
    } finally {
      setSending(false);
    }
  };

  return (
    <OwnerLayout>
      <div className="px-4 mt-6 space-y-6 max-w-lg mx-auto pb-10">
        <div>
          <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)]">Announcements</span>
          <h1 className="text-2xl font-black uppercase tracking-wider text-[var(--text)]">Gym Member Broadcast</h1>
        </div>

        {successMsg && (
          <div className="p-4 neo-pressed rounded-[20px] bg-[#34A853]/10 border border-[#34A853]/30 text-[#34A853] text-xs font-bold uppercase tracking-wider flex items-center gap-2">
            <CheckCircle size={18} /> {successMsg}
          </div>
        )}

        <div className="clay-raised p-6 sm:p-8 rounded-[28px] space-y-6">
          <form onSubmit={handleSendBroadcast} className="space-y-4">
            <div>
              <label className="block text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] mb-1">
                Target Audience
              </label>
              <select
                value={targetGroup}
                onChange={(e) => setTargetGroup(e.target.value)}
                className="w-full h-12 px-4 neo-pressed rounded-[14px] text-xs font-bold text-[var(--text)] bg-[var(--surface)] cursor-pointer"
              >
                <option value="ALL">All Registered Members</option>
                <option value="ACTIVE">Active Members Only</option>
                <option value="DUE">Members with Pending Dues</option>
              </select>
            </div>

            <div>
              <label className="block text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] mb-1">
                Broadcast Title *
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Gym Holiday Notice / Special Batch Timing"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full h-12 px-4 neo-pressed rounded-[14px] text-xs font-bold text-[var(--text)] outline-none focus:ring-1 focus:ring-[var(--text)]"
              />
            </div>

            <div>
              <label className="block text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] mb-1">
                Announcement Message *
              </label>
              <textarea
                rows={4}
                required
                placeholder="Type your message here. Members will receive this in their notification center and via Web Push..."
                value={body}
                onChange={(e) => setBody(e.target.value)}
                className="w-full p-4 neo-pressed rounded-[14px] text-xs font-medium text-[var(--text)] outline-none focus:ring-1 focus:ring-[var(--text)]"
              />
            </div>

            <div className="pt-2">
              <button
                type="submit"
                disabled={sending}
                className="w-full h-12 rounded-[16px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 active:scale-95 transition-transform cursor-pointer"
              >
                {sending ? 'SENDING BROADCAST...' : <><Send size={16} /> SEND BROADCAST NOTIFICATION</>}
              </button>
            </div>
          </form>
        </div>
      </div>
    </OwnerLayout>
  );
}
