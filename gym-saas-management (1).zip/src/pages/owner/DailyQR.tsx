import React, { useState, useEffect } from 'react';
import { useNavigate } from '@/lib/router-compat';
import { ArrowLeft, RefreshCw, QrCode, ShieldCheck, Sparkles, CheckCircle } from 'lucide-react';
import OwnerLayout from '../../components/OwnerLayout';

export default function DailyQR() {
  const navigate = useNavigate();
  const [qrData, setQrData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const fetchQR = () => {
    const sessionStr = localStorage.getItem('gym_session');
    if (!sessionStr) { navigate('/'); return; }
    const session = JSON.parse(sessionStr);

    setLoading(true);
    fetch(`/api/attendance/qr/${session.gymId}`)
      .then(res => res.json())
      .then(data => {
        if (data && data.success) {
          setQrData(data);
        }
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchQR();
    const interval = setInterval(fetchQR, 60000); // refresh every minute
    return () => clearInterval(interval);
  }, []);

  return (
    <OwnerLayout>
      <div className="px-4 mt-6 space-y-6 max-w-lg mx-auto pb-10 text-center">
        <div className="flex items-center justify-between">
          <button
            onClick={() => navigate('/owner/attendance')}
            className="w-10 h-10 rounded-full neo-raised flex items-center justify-center text-[var(--text)] active:scale-95 transition-transform cursor-pointer"
          >
            <ArrowLeft size={18} />
          </button>
          <div>
            <span className="text-[9px] font-bold uppercase tracking-widest text-[#34A853] bg-[#34A853]/10 px-2.5 py-0.5 rounded-full">
              LIVE CHECK-IN QR
            </span>
            <h1 className="text-xl font-black uppercase tracking-wider text-[var(--text)] mt-1">Today's Gym QR</h1>
          </div>
          <button
            onClick={fetchQR}
            className="w-10 h-10 rounded-full neo-raised flex items-center justify-center text-[var(--text)] active:scale-95 transition-transform cursor-pointer"
          >
            <RefreshCw size={18} className={loading ? 'animate-spin' : ''} />
          </button>
        </div>

        <div className="clay-raised p-8 rounded-[32px] space-y-6">
          <p className="text-xs text-[var(--text-sec)] font-medium leading-relaxed">
            Display this QR code at your gym reception. Members can scan this code using their Member App camera to mark daily attendance.
          </p>

          {loading ? (
            <div className="w-64 h-64 neo-pressed rounded-[24px] mx-auto flex items-center justify-center text-4xl animate-pulse">
              🏋️
            </div>
          ) : qrData ? (
            <div className="space-y-4">
              <div className="p-6 bg-white rounded-[24px] shadow-2xl inline-block border-4 border-black">
                {/* SVG or Image representation of QR */}
                <img
                  src={`https://api.qrserver.com/v1/create-qr-code/?size=240x240&data=${encodeURIComponent(qrData.qrPayload || '')}`}
                  alt="Daily Check-in QR"
                  className="w-60 h-60 mx-auto"
                />
              </div>

              <div className="neo-pressed p-4 rounded-[20px] text-center space-y-1">
                <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Gym Name</span>
                <span className="text-sm font-black uppercase tracking-wider text-[var(--text)] block">{qrData.gymName}</span>
                <span className="text-[10px] font-mono text-[var(--text-sec)] block mt-1">Date: {qrData.date}</span>
              </div>
            </div>
          ) : (
            <div className="p-8 text-xs font-bold text-[#D64545]">Failed to load QR code.</div>
          )}

          <div className="p-4 rounded-[18px] bg-[#34A853]/10 border border-[#34A853]/20 text-[11px] font-bold text-[#34A853] flex items-center justify-center gap-2">
            <ShieldCheck size={18} /> Dynamic Security: Code refreshes daily automatically.
          </div>
        </div>
      </div>
    </OwnerLayout>
  );
}
