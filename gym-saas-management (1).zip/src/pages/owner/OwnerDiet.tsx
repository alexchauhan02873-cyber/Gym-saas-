import React, { useState, useEffect } from 'react';
import { useNavigate } from '@/lib/router-compat';
import { Utensils, Plus, Check, Users, Send, Trash2, Flame } from 'lucide-react';
import OwnerLayout from '../../components/OwnerLayout';

export default function OwnerDiet() {
  const navigate = useNavigate();
  const [gymId, setGymId] = useState('');
  const [loading, setLoading] = useState(true);
  const [templates, setTemplates] = useState<any[]>([]);
  const [members, setMembers] = useState<any[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<any | null>(null);
  const [selectedMemberIds, setSelectedMemberIds] = useState<string[]>([]);
  const [assigning, setAssigning] = useState(false);
  const [toast, setToast] = useState<string | null>(null);

  // New Template Form State
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newCalories, setNewCalories] = useState(2300);
  const [newProtein, setNewProtein] = useState('140g');
  const [meals, setMeals] = useState([
    { time: 'Breakfast', title: 'Oats with Whey Protein & Almonds', calories: 450 },
    { time: 'Lunch', title: 'Grilled Chicken / Paneer Breast with Rice', calories: 650 },
    { time: 'Evening Snack', title: 'Greek Yogurt & Roasted Chana', calories: 200 },
    { time: 'Dinner', title: 'Steamed Fish / Tofu with Vegetables', calories: 500 }
  ]);

  const showToastMsg = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  };

  const fetchData = async () => {
    const sessionStr = localStorage.getItem('gym_session');
    if (!sessionStr) { navigate('/'); return; }
    const session = JSON.parse(sessionStr);
    setGymId(session.gymId);

    try {
      const [tRes, mRes] = await Promise.all([
        fetch(`/api/owner/diets/templates/${session.gymId}`),
        fetch(`/api/members/${session.gymId}`)
      ]);
      const tData = await tRes.json();
      const mData = await mRes.json();

      if (tData.success) {
        setTemplates(tData.templates || []);
      }
      if (mData.success) {
        setMembers((mData.members || []).filter((m: any) => m.status !== 'ARCHIVED'));
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleAddMealRow = () => {
    setMeals([...meals, { time: 'Snack', title: '', calories: 200 }]);
  };

  const handleCreateTemplate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    try {
      const res = await fetch('/api/owner/diets/templates', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          gymId,
          title: newTitle,
          calories: newCalories,
          protein: newProtein,
          meals: meals.filter(m => m.title.trim())
        })
      });
      const data = await res.json();
      if (data.success) {
        showToastMsg('Diet plan created successfully!');
        setShowCreateModal(false);
        setNewTitle('');
        fetchData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleAssignDiet = async () => {
    if (!selectedTemplate || selectedMemberIds.length === 0) return;
    setAssigning(true);

    try {
      const res = await fetch('/api/owner/diets/assign', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          gymId,
          memberIds: selectedMemberIds,
          diet: selectedTemplate
        })
      });
      const data = await res.json();
      if (data.success) {
        showToastMsg(`Diet plan assigned to ${data.count} member(s)!`);
        setSelectedMemberIds([]);
        setSelectedTemplate(null);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setAssigning(false);
    }
  };

  const toggleMemberSelection = (mId: string) => {
    if (selectedMemberIds.includes(mId)) {
      setSelectedMemberIds(selectedMemberIds.filter(id => id !== mId));
    } else {
      setSelectedMemberIds([...selectedMemberIds, mId]);
    }
  };

  const selectAllMembers = () => {
    if (selectedMemberIds.length === members.length) {
      setSelectedMemberIds([]);
    } else {
      setSelectedMemberIds(members.map(m => m.id));
    }
  };

  if (loading) {
    return (
      <OwnerLayout>
        <div className="py-20 text-center text-3xl animate-pulse">🥗 Loading Meal Plans...</div>
      </OwnerLayout>
    );
  }

  return (
    <OwnerLayout>
      <div className="px-4 mt-6 space-y-6 pb-12">
        {toast && (
          <div className="fixed top-5 right-5 z-50 bg-[#34A853] text-white px-4 py-3 rounded-2xl font-bold text-xs shadow-lg animate-bounce">
            ✓ {toast}
          </div>
        )}

        <div className="flex justify-between items-center">
          <div>
            <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)]">Nutrition & Diet</span>
            <h1 className="text-2xl font-black uppercase tracking-wider text-[var(--text)]">Assign Diet Plans</h1>
          </div>

          <button
            onClick={() => setShowCreateModal(true)}
            className="px-4 py-2.5 rounded-[16px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-wider flex items-center gap-2 cursor-pointer shadow-sm active:scale-95 transition-transform"
          >
            <Plus size={16} /> New Diet Plan
          </button>
        </div>

        {/* Section 1: Diet Templates */}
        <div className="space-y-3">
          <h3 className="text-xs font-black uppercase tracking-wider text-[var(--text)] px-1">
            Diet Templates ({templates.length})
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {templates.map(t => {
              const isSelected = selectedTemplate?.id === t.id;
              return (
                <div 
                  key={t.id}
                  onClick={() => setSelectedTemplate(t)}
                  className={`p-5 rounded-[22px] cursor-pointer transition-all ${
                    isSelected 
                      ? 'clay-raised border-2 border-[var(--text)] scale-[1.01]' 
                      : 'neo-raised hover:border-[var(--border)]'
                  }`}
                >
                  <div className="flex justify-between items-start mb-2">
                    <span className="text-[9px] font-black uppercase tracking-widest text-[#E37400] bg-[#E37400]/10 px-2.5 py-0.5 rounded-full flex items-center gap-1">
                      <Flame size={12} /> {t.calories} kcal • {t.protein}
                    </span>
                    {isSelected && <Check size={18} className="text-[#34A853]" />}
                  </div>

                  <h4 className="text-sm font-black uppercase tracking-wider text-[var(--text)]">{t.title}</h4>
                  <p className="text-[10px] text-[var(--text-sec)] font-mono mt-0.5">
                    {t.meals?.length || 0} Daily Meals
                  </p>

                  <div className="mt-3 space-y-1">
                    {(t.meals || []).slice(0, 3).map((m: any, idx: number) => (
                      <div key={idx} className="text-[11px] font-semibold text-[var(--text)] flex justify-between">
                        <span>• {m.time}: {m.title}</span>
                      </div>
                    ))}
                    {(t.meals?.length || 0) > 3 && (
                      <span className="text-[9px] text-[var(--text-sec)] font-mono block">
                        + {(t.meals.length - 3)} more meals
                      </span>
                    )}
                  </div>
                </div>
              );
            })}

            {templates.length === 0 && (
              <div className="col-span-2 neo-pressed p-8 rounded-[24px] text-center space-y-2">
                <Utensils size={28} className="mx-auto text-[var(--text-sec)]" />
                <h4 className="text-xs font-black uppercase text-[var(--text)]">No Meal Templates Created Yet</h4>
                <p className="text-[11px] text-[var(--text-sec)] font-medium">Create nutrition & meal plans to assign to your gym members.</p>
              </div>
            )}
          </div>
        </div>

        {/* Section 2: Assign To Members */}
        {selectedTemplate && (
          <div className="clay-raised p-6 rounded-[28px] space-y-4 animate-fade-in border-2 border-[var(--text)]">
            <div className="flex justify-between items-center border-b border-[var(--border)] pb-3">
              <div>
                <span className="text-[9px] font-black uppercase tracking-widest text-[#E37400]">ASSIGNING MEAL PLAN</span>
                <h3 className="text-sm font-black uppercase tracking-wider text-[var(--text)]">
                  {selectedTemplate.title} ({selectedTemplate.calories} kcal)
                </h3>
              </div>
              <button
                onClick={selectAllMembers}
                className="px-3 py-1.5 rounded-xl neo-pressed text-[10px] font-black uppercase text-[var(--text)] cursor-pointer"
              >
                {selectedMemberIds.length === members.length ? 'Deselect All' : 'Select All Members'}
              </button>
            </div>

            <div className="max-h-60 overflow-y-auto space-y-2 pr-1">
              {members.map(m => {
                const isChecked = selectedMemberIds.includes(m.id);
                return (
                  <div 
                    key={m.id}
                    onClick={() => toggleMemberSelection(m.id)}
                    className={`p-3 rounded-[16px] flex items-center justify-between cursor-pointer transition-all ${
                      isChecked ? 'bg-[var(--btn-bg)] text-[var(--btn-text)] shadow-sm' : 'neo-pressed text-[var(--text)]'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full neo-raised flex items-center justify-center font-bold text-xs uppercase">
                        {m.fullName?.charAt(0)}
                      </div>
                      <div>
                        <span className="text-xs font-black uppercase block">{m.fullName}</span>
                        <span className="text-[9px] font-mono opacity-80">{m.memberDisplayId || m.phone}</span>
                      </div>
                    </div>
                    {isChecked && <Check size={16} />}
                  </div>
                );
              })}
            </div>

            <button
              onClick={handleAssignDiet}
              disabled={assigning || selectedMemberIds.length === 0}
              className="w-full h-12 rounded-[16px] bg-[#E37400] text-white text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 cursor-pointer active:scale-95 transition-transform shadow-md"
            >
              <Send size={16} />
              {assigning ? 'Assigning...' : `Assign Meal Plan to ${selectedMemberIds.length} Member(s)`}
            </button>
          </div>
        )}

        {/* Modal: Create Diet Template */}
        {showCreateModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
            <div className="bg-[var(--bg)] border border-[var(--border)] p-6 rounded-[28px] w-full max-w-lg space-y-4 max-h-[90vh] overflow-y-auto shadow-2xl">
              <div className="flex justify-between items-center border-b border-[var(--border)] pb-3">
                <h3 className="text-sm font-black uppercase tracking-wider text-[var(--text)]">Create Diet Template</h3>
                <button onClick={() => setShowCreateModal(false)} className="text-[var(--text-sec)] hover:text-[var(--text)]">✕</button>
              </div>

              <form onSubmit={handleCreateTemplate} className="space-y-4">
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] mb-1">
                    Plan Title *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. High Protein Shred Plan"
                    value={newTitle}
                    onChange={e => setNewTitle(e.target.value)}
                    className="w-full h-11 px-4 neo-pressed rounded-[14px] text-xs font-bold text-[var(--text)] outline-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] mb-1">
                      Target Calories (kcal)
                    </label>
                    <input
                      type="number"
                      value={newCalories}
                      onChange={e => setNewCalories(Number(e.target.value))}
                      className="w-full h-11 px-4 neo-pressed rounded-[14px] text-xs font-bold text-[var(--text)] outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] mb-1">
                      Protein Target
                    </label>
                    <input
                      type="text"
                      value={newProtein}
                      onChange={e => setNewProtein(e.target.value)}
                      className="w-full h-11 px-4 neo-pressed rounded-[14px] text-xs font-bold text-[var(--text)] outline-none"
                    />
                  </div>
                </div>

                <div className="space-y-3 pt-2">
                  <div className="flex justify-between items-center">
                    <label className="text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)]">
                      Daily Meals ({meals.length})
                    </label>
                    <button
                      type="button"
                      onClick={handleAddMealRow}
                      className="text-[10px] font-black uppercase text-[#E37400] hover:underline"
                    >
                      + Add Meal
                    </button>
                  </div>

                  {meals.map((m, idx) => (
                    <div key={idx} className="p-3 neo-pressed rounded-[16px] space-y-2">
                      <div className="flex gap-2">
                        <input
                          type="text"
                          placeholder="Time (Breakfast/Lunch/Dinner)"
                          value={m.time}
                          onChange={e => {
                            const updated = [...meals];
                            updated[idx].time = e.target.value;
                            setMeals(updated);
                          }}
                          className="w-1/3 h-9 px-3 neo-raised rounded-[10px] text-xs font-bold text-[var(--text)] outline-none"
                        />
                        <input
                          type="text"
                          placeholder="Meal Description / Food Items"
                          value={m.title}
                          onChange={e => {
                            const updated = [...meals];
                            updated[idx].title = e.target.value;
                            setMeals(updated);
                          }}
                          className="flex-1 h-9 px-3 neo-raised rounded-[10px] text-xs font-bold text-[var(--text)] outline-none"
                        />
                        <button
                          type="button"
                          onClick={() => setMeals(meals.filter((_, i) => i !== idx))}
                          className="text-[#D64545] p-2 hover:bg-[#D64545]/10 rounded-lg"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="flex gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowCreateModal(false)}
                    className="flex-1 h-11 rounded-[14px] neo-pressed text-[var(--text-sec)] text-xs font-bold uppercase cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 h-11 rounded-[14px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-wider cursor-pointer shadow-sm active:scale-95 transition-transform"
                  >
                    Save Meal Plan
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </OwnerLayout>
  );
}
