import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from '@/lib/router-compat';
import { 
  History, Search, Filter, Calendar, IndianRupee, FileText, 
  CheckCircle, User, Activity, Clock, ChevronLeft, ChevronRight, RefreshCw, Shield
} from 'lucide-react';
import OwnerLayout from '../../components/OwnerLayout';

export default function CentralRecords() {
  const navigate = useNavigate();
  const location = useLocation();

  const [records, setRecords] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [category, setCategory] = useState<string>('ALL');
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalCount, setTotalCount] = useState(0);

  const fetchRecords = () => {
    const sessionStr = localStorage.getItem('gym_session');
    if (!sessionStr) { navigate('/'); return; }
    const session = JSON.parse(sessionStr);

    setLoading(true);
    const params = new URLSearchParams({
      page: page.toString(),
      limit: '15',
      category,
      search
    });

    fetch(`/api/owner/records/${session.gymId}?${params.toString()}`)
      .then(res => res.json())
      .then(data => {
        if (data && data.success) {
          setRecords(data.records || []);
          setTotalPages(data.pagination?.totalPages || 1);
          setTotalCount(data.pagination?.totalCount || 0);
        }
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchRecords();
  }, [category, page]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPage(1);
    fetchRecords();
  };

  const getCategoryBadge = (cat: string) => {
    switch (cat) {
      case 'PAYMENT':
        return <span className="px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-500/10 text-emerald-600 border border-emerald-500/30 flex items-center gap-1"><IndianRupee size={12} /> Payment</span>;
      case 'INVOICE':
        return <span className="px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-blue-500/10 text-blue-600 border border-blue-500/30 flex items-center gap-1"><FileText size={12} /> Invoice</span>;
      case 'ATTENDANCE':
        return <span className="px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-purple-500/10 text-purple-600 border border-purple-500/30 flex items-center gap-1"><CheckCircle size={12} /> Attendance</span>;
      case 'AUDIT':
        return <span className="px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-500/10 text-amber-600 border border-amber-500/30 flex items-center gap-1"><Shield size={12} /> System Audit</span>;
      default:
        return <span className="px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-[var(--surface-sec)] text-[var(--text)] border border-[var(--border)] flex items-center gap-1"><User size={12} /> Member</span>;
    }
  };

  return (
    <OwnerLayout>
      <div className="space-y-6 pb-12 animate-fade-in">
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-[var(--border)] pb-4">
          <div>
            <h1 className="text-xl sm:text-2xl font-black uppercase tracking-wider flex items-center gap-2">
              <History className="text-[var(--text)]" size={24} /> Records & History Center
            </h1>
            <p className="text-xs text-[var(--text-sec)] font-medium mt-1">
              Central immutable log of payments, invoices, attendance, and owner actions.
            </p>
          </div>

          <button
            onClick={fetchRecords}
            className="p-2.5 rounded-xl neo-raised text-[var(--text)] hover:scale-105 transition-transform flex items-center gap-2 text-xs font-bold uppercase cursor-pointer"
          >
            <RefreshCw size={15} className={loading ? 'animate-spin' : ''} /> Refresh Records
          </button>
        </div>

        {/* Category Tabs */}
        <div className="flex flex-wrap gap-2 border-b border-[var(--border)] pb-3">
          {[
            { id: 'ALL', label: 'All Activity Records' },
            { id: 'PAYMENT', label: 'Payments' },
            { id: 'INVOICE', label: 'Invoices' },
            { id: 'ATTENDANCE', label: 'Attendance' },
            { id: 'MEMBER', label: 'Member History' },
            { id: 'AUDIT', label: 'System Audit' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => { setCategory(tab.id); setPage(1); }}
              className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all cursor-pointer ${
                category === tab.id
                  ? 'bg-[var(--text)] text-[var(--bg)] shadow-md'
                  : 'neo-raised text-[var(--text-sec)] hover:text-[var(--text)]'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Search Bar */}
        <form onSubmit={handleSearchSubmit} className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[var(--text-sec)]" size={16} />
            <input
              type="text"
              placeholder="Search records by member name, action, details, or invoice #..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full h-11 pl-10 pr-4 neo-pressed rounded-xl text-xs font-bold outline-none text-[var(--text)]"
            />
          </div>
          <button
            type="submit"
            className="px-5 h-11 rounded-xl bg-[var(--text)] text-[var(--bg)] text-xs font-black uppercase tracking-wider cursor-pointer"
          >
            Search
          </button>
        </form>

        {/* Records Table / List */}
        <div className="neo-raised rounded-[24px] p-4 sm:p-6 space-y-4">
          <div className="flex justify-between items-center text-xs font-bold text-[var(--text-sec)] uppercase tracking-wider px-2">
            <span>Showing {records.length} of {totalCount} Records</span>
            <span>Page {page} of {totalPages}</span>
          </div>

          {loading ? (
            <div className="p-12 text-center text-xs font-bold text-[var(--text-sec)] uppercase tracking-widest animate-pulse">
              Loading Central History Records...
            </div>
          ) : records.length === 0 ? (
            <div className="p-12 text-center text-xs font-bold text-[var(--text-sec)] uppercase tracking-widest">
              No historical records found for this view.
            </div>
          ) : (
            <div className="space-y-3">
              {records.map((rec, idx) => (
                <div
                  key={rec.id || idx}
                  className="p-4 neo-pressed rounded-[18px] flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 transition-all hover:border-[var(--text)]"
                >
                  <div className="space-y-1 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      {getCategoryBadge(rec.category)}
                      <span className="text-xs font-black uppercase tracking-wider text-[var(--text)]">
                        {rec.action}
                      </span>
                      {rec.memberName && (
                        <span className="text-xs font-bold text-[var(--text-sec)]">
                          • {rec.memberName}
                        </span>
                      )}
                    </div>
                    <p className="text-xs font-medium text-[var(--text-sec)] leading-relaxed">
                      {rec.details}
                    </p>
                    <div className="flex items-center gap-3 text-[10px] font-bold text-[var(--text-sec)] uppercase tracking-wider">
                      <span className="flex items-center gap-1">
                        <Clock size={12} /> {new Date(rec.timestamp).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" })} at {new Date(rec.timestamp).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })}
                      </span>
                      <span>By: {rec.actor}</span>
                    </div>
                  </div>

                  {rec.amount !== undefined && rec.amount > 0 && (
                    <div className="text-right sm:self-center font-mono font-black text-sm text-[var(--text)]">
                      ₹{rec.amount}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

          {/* Pagination Controls */}
          {totalPages > 1 && (
            <div className="flex justify-between items-center pt-4 border-t border-[var(--border)]">
              <button
                disabled={page <= 1}
                onClick={() => setPage(p => Math.max(1, p - 1))}
                className="px-4 py-2 rounded-xl neo-raised text-xs font-bold uppercase flex items-center gap-1 disabled:opacity-40 cursor-pointer"
              >
                <ChevronLeft size={16} /> Previous
              </button>

              <span className="text-xs font-bold text-[var(--text-sec)]">
                Page {page} / {totalPages}
              </span>

              <button
                disabled={page >= totalPages}
                onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                className="px-4 py-2 rounded-xl neo-raised text-xs font-bold uppercase flex items-center gap-1 disabled:opacity-40 cursor-pointer"
              >
                Next <ChevronRight size={16} />
              </button>
            </div>
          )}
        </div>
      </div>
    </OwnerLayout>
  );
}
