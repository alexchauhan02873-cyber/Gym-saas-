import React, { useState, useEffect } from 'react';
import { useNavigate } from '@/lib/router-compat';
import { Plus, Check, Trash2, Tag, ArrowLeft, Edit2, Lock, Unlock, Archive, AlertTriangle } from 'lucide-react';
import OwnerLayout from '../../components/OwnerLayout';

export default function MembershipPlans() {
  const navigate = useNavigate();
  const [plans, setPlans] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingPlan, setEditingPlan] = useState<any | null>(null);

  // Form inputs
  const [planName, setPlanName] = useState('');
  const [durationValue, setDurationValue] = useState(1);
  const [durationUnit, setDurationUnit] = useState<'DAYS' | 'WEEKS' | 'MONTHS' | 'YEARS'>('MONTHS');
  const [price, setPrice] = useState('');
  const [description, setDescription] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [toast, setToast] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  };

  const fetchPlans = () => {
    const sessionStr = localStorage.getItem('gym_session');
    if (!sessionStr) { navigate('/'); return; }
    const session = JSON.parse(sessionStr);

    fetch(`/api/plans/${session.gymId}`)
      .then(res => res.json())
      .then(data => {
        const planList = data?.plans || (Array.isArray(data) ? data : []);
        setPlans(planList);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchPlans();
  }, []);

  const handleOpenCreateModal = () => {
    setEditingPlan(null);
    setPlanName('');
    setDurationValue(1);
    setDurationUnit('MONTHS');
    setPrice('');
    setDescription('');
    setModalOpen(true);
  };

  const handleOpenEditModal = (plan: any) => {
    setEditingPlan(plan);
    setPlanName(plan.planName || '');
    setDurationValue(plan.durationValue || plan.durationMonths || 1);
    setDurationUnit((plan.durationUnit || 'MONTHS') as any);
    setPrice(plan.price?.toString() || '');
    setDescription(plan.description || '');
    setModalOpen(true);
  };

  const handleSavePlan = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!planName.trim() || !price) return;
    setSubmitting(true);

    const sessionStr = localStorage.getItem('gym_session');
    if (!sessionStr) return;
    const session = JSON.parse(sessionStr);

    try {
      if (editingPlan) {
        // Update Plan
        const res = await fetch(`/api/plans/${session.gymId}/${editingPlan.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            planName: planName.trim(),
            durationValue: Number(durationValue) || 1,
            durationUnit,
            price: parseFloat(price) || 0,
            description: description.trim()
          })
        });
        const data = await res.json();
        if (data.success) {
          showToast('Plan updated successfully!');
          setModalOpen(false);
          fetchPlans();
        }
      } else {
        // Create Plan
        const res = await fetch('/api/plans/create', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            gymId: session.gymId,
            planName: planName.trim(),
            durationValue: Number(durationValue) || 1,
            durationUnit,
            price: parseFloat(price) || 0,
            description: description.trim()
          })
        });
        const data = await res.json();
        if (data.success) {
          showToast('New membership plan created!');
          setModalOpen(false);
          fetchPlans();
        }
      }
    } catch (e) {
      console.error(e);
    } finally {
      setSubmitting(false);
    }
  };

  const handleToggleStatus = async (plan: any) => {
    const sessionStr = localStorage.getItem('gym_session');
    if (!sessionStr) return;
    const session = JSON.parse(sessionStr);

    const nextStatus = plan.status === 'INACTIVE' ? 'ACTIVE' : 'INACTIVE';
    try {
      const res = await fetch(`/api/plans/${session.gymId}/${plan.id}/status`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: nextStatus })
      });
      const data = await res.json();
      if (data.success) {
        showToast(`Plan status set to ${nextStatus}`);
        fetchPlans();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleArchivePlan = async (plan: any) => {
    if (!confirm(`Archive plan "${plan.planName}"? Existing member history using this plan will be retained.`)) return;

    const sessionStr = localStorage.getItem('gym_session');
    if (!sessionStr) return;
    const session = JSON.parse(sessionStr);

    try {
      const res = await fetch(`/api/plans/${session.gymId}/${plan.id}/archive`, {
        method: 'POST'
      });
      const data = await res.json();
      if (data.success) {
        showToast('Plan archived.');
        fetchPlans();
      }
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <OwnerLayout>
      <div className="px-4 mt-6 space-y-6 pb-10">
        {toast && (
          <div className="fixed top-5 right-5 z-50 bg-[#34A853] text-white px-4 py-3 rounded-2xl font-bold text-xs shadow-lg animate-bounce">
            ✓ {toast}
          </div>
        )}

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)]">Pricing Catalog</span>
            <h1 className="text-2xl font-black uppercase tracking-wider text-[var(--text)]">Membership Plans Catalog ({plans.length})</h1>
          </div>

          <button
            onClick={handleOpenCreateModal}
            className="h-11 px-5 rounded-[16px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 active:scale-95 transition-transform cursor-pointer shadow-sm"
          >
            <Plus size={16} /> CREATE NEW PLAN
          </button>
        </div>

        {loading ? (
          <div className="py-20 text-center text-4xl animate-pulse">🏋️</div>
        ) : plans.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {plans.map((p) => {
              const durationLabel = `${p.durationValue || p.durationMonths || 1} ${p.durationUnit || 'MONTHS'}`;
              const isActive = p.status !== 'INACTIVE';

              return (
                <div key={p.id} className="clay-raised p-6 rounded-[24px] space-y-4 relative flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-start gap-2">
                      <span className="text-[9px] font-black uppercase tracking-widest text-[#34A853] bg-[#34A853]/10 px-2.5 py-1 rounded-full">
                        {durationLabel}
                      </span>

                      <span className={`text-[9px] font-black uppercase px-2.5 py-1 rounded-full ${
                        isActive ? 'bg-[#34A853]/20 text-[#34A853]' : 'bg-[#E3A008]/20 text-[#E3A008]'
                      }`}>
                        {isActive ? 'ACTIVE' : 'INACTIVE'}
                      </span>
                    </div>

                    <h3 className="text-lg font-black uppercase tracking-wider mt-3">{p.planName}</h3>
                    <div className="text-3xl font-black font-mono mt-1 text-[var(--text)]">
                      ₹{p.price.toLocaleString('en-IN')}
                    </div>
                    {p.description && (
                      <p className="text-xs text-[var(--text-sec)] font-medium mt-2 leading-relaxed">
                        {p.description}
                      </p>
                    )}
                  </div>

                  <div className="pt-4 border-t border-[var(--border)] flex justify-between items-center gap-2">
                    <button
                      onClick={() => handleOpenEditModal(p)}
                      className="px-3 py-1.5 neo-raised text-[10px] font-bold uppercase rounded-xl flex items-center gap-1.5 text-[var(--text)] cursor-pointer"
                    >
                      <Edit2 size={12} /> Edit
                    </button>

                    <button
                      onClick={() => handleToggleStatus(p)}
                      className={`px-3 py-1.5 neo-raised text-[10px] font-bold uppercase rounded-xl flex items-center gap-1.5 cursor-pointer ${
                        isActive ? 'text-[#E3A008]' : 'text-[#34A853]'
                      }`}
                    >
                      {isActive ? <Lock size={12} /> : <Unlock size={12} />}
                      {isActive ? 'Deactivate' : 'Reactivate'}
                    </button>

                    <button
                      onClick={() => handleArchivePlan(p)}
                      className="p-2 neo-raised text-[10px] font-bold uppercase rounded-xl text-[#D64545] cursor-pointer"
                      title="Archive Plan"
                    >
                      <Archive size={14} />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="neo-pressed p-8 rounded-[24px] text-center space-y-2">
            <AlertTriangle size={32} className="mx-auto text-[var(--text-sec)] opacity-50" />
            <p className="text-xs font-black uppercase tracking-wider text-[var(--text-sec)]">No plans created yet</p>
            <button
              onClick={handleOpenCreateModal}
              className="px-4 py-2 neo-raised text-xs font-bold uppercase cursor-pointer mt-2"
            >
              + Create First Plan
            </button>
          </div>
        )}

        {/* Create / Edit Plan Modal */}
        {modalOpen && (
          <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="w-full max-w-md bg-[var(--surface)] p-6 rounded-[28px] neo-raised space-y-4 shadow-2xl">
              <h3 className="text-base font-black uppercase tracking-wider">
                {editingPlan ? 'Edit Membership Plan' : 'Create Membership Plan'}
              </h3>

              <form onSubmit={handleSavePlan} className="space-y-3">
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] mb-1">
                    Plan Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Quarterly Pro Pass"
                    value={planName}
                    onChange={(e) => setPlanName(e.target.value)}
                    className="w-full h-11 px-3 neo-pressed rounded-[12px] text-xs font-bold text-[var(--text)] outline-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] mb-1">
                      Duration Value *
                    </label>
                    <input
                      type="number"
                      required
                      min={1}
                      max={365}
                      value={durationValue}
                      onChange={(e) => setDurationValue(parseInt(e.target.value, 10) || 1)}
                      className="w-full h-11 px-3 neo-pressed rounded-[12px] text-xs font-bold font-mono text-[var(--text)] outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] mb-1">
                      Duration Unit *
                    </label>
                    <select
                      value={durationUnit}
                      onChange={(e) => setDurationUnit(e.target.value as any)}
                      className="w-full h-11 px-3 neo-pressed rounded-[12px] text-xs font-bold text-[var(--text)] bg-[var(--surface)] cursor-pointer outline-none"
                    >
                      <option value="DAYS">Days</option>
                      <option value="WEEKS">Weeks</option>
                      <option value="MONTHS">Months</option>
                      <option value="YEARS">Years</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] mb-1">
                    Price (₹) *
                  </label>
                  <input
                    type="number"
                    required
                    placeholder="2500"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    className="w-full h-11 px-3 neo-pressed rounded-[12px] text-xs font-bold font-mono text-[var(--text)] outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] mb-1">
                    Description / Included Perks
                  </label>
                  <textarea
                    rows={2}
                    placeholder="e.g. Unlimited gym floor access + complimentary trainer consultation"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="w-full p-3 neo-pressed rounded-[12px] text-xs font-medium text-[var(--text)] outline-none"
                  />
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setModalOpen(false)}
                    className="w-1/2 h-11 rounded-[14px] neo-raised text-xs font-bold uppercase cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={submitting}
                    className="w-1/2 h-11 rounded-[14px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-bold uppercase cursor-pointer"
                  >
                    {submitting ? 'Saving...' : editingPlan ? 'Update Plan' : 'Create Plan'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </OwnerLayout>
  );
}

