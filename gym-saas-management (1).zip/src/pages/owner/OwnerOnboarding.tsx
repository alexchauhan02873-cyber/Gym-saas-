import React, { useState, useEffect } from 'react';
import { useNavigate } from '@/lib/router-compat';
import { motion, AnimatePresence } from 'motion/react';
import { 
  User, Building2, CreditCard, Award, UserPlus, CheckCircle2, 
  ArrowRight, ArrowLeft, Plus, Copy, Check, Share2, Sparkles, Loader2,
  Clock, Trash2, Upload, Trash, ShieldCheck, AlertCircle, X
} from 'lucide-react';
import LanguageSelector from '@/components/LanguageSelector';
import { t, getStoredLanguage, type Language } from '@/lib/i18n';

interface PlanDraft {
  planName: string;
  price: number;
  duration: number;
  durationUnit: 'Days' | 'Weeks' | 'Months' | 'Years';
  description: string;
}

interface ScheduleSession {
  open: string;
  close: string;
}

interface DaySchedule {
  day: string;
  isOpen: boolean;
  sessions: ScheduleSession[];
}

const DEFAULT_WEEKDAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

export default function OwnerOnboarding() {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [lang, setLang] = useState<Language>(getStoredLanguage());
  const [submitting, setSubmitting] = useState(false);
  const [completed, setCompleted] = useState(false);
  const [completedData, setCompletedData] = useState<any>(null);
  const [error, setError] = useState('');

  // Step 1: Owner Details
  const [ownerName, setOwnerName] = useState('');
  const [ownerPhone, setOwnerPhone] = useState('');
  const [ownerPhoto, setOwnerPhoto] = useState('');

  // Step 2: Gym Details
  const [gymName, setGymName] = useState('');
  const [gymPhone, setGymPhone] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [email, setEmail] = useState('');
  const [gymType, setGymType] = useState('Unisex');
  const [gymLogo, setGymLogo] = useState('');
  const [weeklyOff, setWeeklyOff] = useState('Sunday');
  const [timezone] = useState('Asia/Kolkata');

  // Multi-session Schedule - Default ALL days (including Sunday) to OPEN
  const [schedule, setSchedule] = useState<DaySchedule[]>(
    DEFAULT_WEEKDAYS.map(day => ({
      day,
      isOpen: true,
      sessions: [
        { open: '06:00', close: '11:00' },
        { open: '16:00', close: '22:00' }
      ]
    }))
  );

  // Step 3: Payment Setup
  const [upiId, setUpiId] = useState('');
  const [upiDisplayName, setUpiDisplayName] = useState('');
  const [upiQr, setUpiQr] = useState('');
  const [paymentInstructions, setPaymentInstructions] = useState('');
  const [onlinePaymentEnabled, setOnlinePaymentEnabled] = useState(true);

  // Step 4: Membership Plans - No prefilled plans
  const [plans, setPlans] = useState<PlanDraft[]>([]);
  const [isPlanModalOpen, setIsPlanModalOpen] = useState(false);
  const [modalPlanName, setModalPlanName] = useState('');
  const [modalPlanPrice, setModalPlanPrice] = useState('');
  const [modalPlanDuration, setModalPlanDuration] = useState('');
  const [modalPlanUnit, setModalPlanUnit] = useState<'Days' | 'Weeks' | 'Months' | 'Years'>('Months');
  const [modalPlanDesc, setModalPlanDesc] = useState('');
  const [modalPlanError, setModalPlanError] = useState('');

  // Step 5: Add First Member
  const [memberName, setMemberName] = useState('');
  const [memberPhone, setMemberPhone] = useState('');
  const [memberAge, setMemberAge] = useState('');
  const [memberGender, setMemberGender] = useState('Male');
  const [memberLocation, setMemberLocation] = useState('');
  const [memberPhoto, setMemberPhoto] = useState('');
  const [selectedPlanIndex, setSelectedPlanIndex] = useState(0);
  const [createdMemberCode, setCreatedMemberCode] = useState<string | null>(null);
  const [codeCopied, setCodeCopied] = useState(false);

  // Load draft from localStorage on mount
  useEffect(() => {
    try {
      const draft = localStorage.getItem('owner_onboarding_draft');
      if (draft) {
        const parsed = JSON.parse(draft);
        if (parsed.ownerName) setOwnerName(parsed.ownerName);
        if (parsed.ownerPhone) setOwnerPhone(parsed.ownerPhone);
        if (parsed.ownerPhoto) setOwnerPhoto(parsed.ownerPhoto);
        if (parsed.gymName) setGymName(parsed.gymName);
        if (parsed.gymPhone) setGymPhone(parsed.gymPhone);
        if (parsed.address) setAddress(parsed.address);
        if (parsed.city) setCity(parsed.city);
        if (parsed.email) setEmail(parsed.email);
        if (parsed.gymLogo) setGymLogo(parsed.gymLogo);
        if (parsed.upiId) setUpiId(parsed.upiId);
        if (parsed.upiDisplayName) setUpiDisplayName(parsed.upiDisplayName);
        if (parsed.plans && Array.isArray(parsed.plans)) setPlans(parsed.plans);
        if (parsed.schedule && Array.isArray(parsed.schedule)) setSchedule(parsed.schedule);
        if (parsed.step && typeof parsed.step === 'number') setStep(Math.min(parsed.step, 6));
      }
    } catch {
      // ignore parse error
    }
  }, []);

  // Save draft whenever state changes
  useEffect(() => {
    try {
      const draftData = {
        step,
        ownerName,
        ownerPhone,
        ownerPhoto,
        gymName,
        gymPhone,
        address,
        city,
        email,
        gymLogo,
        upiId,
        upiDisplayName,
        plans,
        schedule
      };
      localStorage.setItem('owner_onboarding_draft', JSON.stringify(draftData));
    } catch {
      // ignore
    }
  }, [step, ownerName, ownerPhone, ownerPhoto, gymName, gymPhone, address, city, email, gymLogo, upiId, upiDisplayName, plans, schedule]);

  const handleImageUpload = (file: File, target: 'owner' | 'logo' | 'qr' | 'member') => {
    if (file.size > 5 * 1024 * 1024) {
      setError('File size must be less than 5MB');
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      if (target === 'owner') setOwnerPhoto(result);
      if (target === 'logo') setGymLogo(result);
      if (target === 'qr') setUpiQr(result);
      if (target === 'member') setMemberPhoto(result);
    };
    reader.readAsDataURL(file);
  };

  const toggleDayOpen = (dayIndex: number) => {
    setSchedule(prev => prev.map((d, idx) => {
      if (idx !== dayIndex) return d;
      const newOpen = !d.isOpen;
      return {
        ...d,
        isOpen: newOpen,
        sessions: newOpen && d.sessions.length === 0 
          ? [{ open: '06:00', close: '11:00' }, { open: '16:00', close: '22:00' }]
          : d.sessions
      };
    }));
  };

  const addSession = (dayIndex: number) => {
    setSchedule(prev => prev.map((d, idx) => {
      if (idx !== dayIndex) return d;
      return {
        ...d,
        sessions: [...d.sessions, { open: '12:00', close: '15:00' }]
      };
    }));
  };

  const removeSession = (dayIndex: number, sessionIndex: number) => {
    setSchedule(prev => prev.map((d, idx) => {
      if (idx !== dayIndex) return d;
      return {
        ...d,
        sessions: d.sessions.filter((_, sIdx) => sIdx !== sessionIndex)
      };
    }));
  };

  const updateSessionTime = (dayIndex: number, sessionIndex: number, field: 'open' | 'close', val: string) => {
    setSchedule(prev => prev.map((d, idx) => {
      if (idx !== dayIndex) return d;
      const updated = [...d.sessions];
      updated[sessionIndex] = { ...updated[sessionIndex], [field]: val };
      return { ...d, sessions: updated };
    }));
  };

  const applyMondayToWeekdays = () => {
    const mondaySched = schedule.find(d => d.day === 'Monday');
    if (!mondaySched) return;
    setSchedule(prev => prev.map(d => {
      if (['Tuesday', 'Wednesday', 'Thursday', 'Friday'].includes(d.day)) {
        return {
          ...d,
          isOpen: mondaySched.isOpen,
          sessions: JSON.parse(JSON.stringify(mondaySched.sessions))
        };
      }
      return d;
    }));
  };

  const handleNextStep = () => {
    setError('');
    if (step === 1) {
      if (!ownerName.trim()) {
        setError('Owner Full Name is required.');
        return;
      }
    } else if (step === 2) {
      if (!gymName.trim() || !address.trim()) {
        setError('Gym Name and Address are required.');
        return;
      }
    }
    setStep(prev => Math.min(prev + 1, 6));
  };

  const openCreatePlanModal = () => {
    setModalPlanName('');
    setModalPlanPrice('');
    setModalPlanDuration('');
    setModalPlanUnit('Months');
    setModalPlanDesc('');
    setModalPlanError('');
    setIsPlanModalOpen(true);
  };

  const handleCreateModalPlan = () => {
    setModalPlanError('');
    if (!modalPlanName.trim()) {
      setModalPlanError('Please enter a Plan Name.');
      return;
    }

    const priceNum = Number(modalPlanPrice);
    if (isNaN(priceNum) || priceNum <= 0) {
      setModalPlanError('Please enter a valid positive Rupee amount for the plan price.');
      return;
    }

    const durationNum = Number(modalPlanDuration);
    if (isNaN(durationNum) || durationNum <= 0) {
      setModalPlanError('Please enter a valid positive duration value.');
      return;
    }

    // Validate bounds according to duration unit
    if (modalPlanUnit === 'Days' && (durationNum < 1 || durationNum > 31)) {
      setModalPlanError('Days duration must be between 1 and 31 days.');
      return;
    }
    if (modalPlanUnit === 'Weeks' && (durationNum < 1 || durationNum > 12)) {
      setModalPlanError('Weeks duration must be between 1 and 12 weeks.');
      return;
    }
    if (modalPlanUnit === 'Months' && (durationNum < 1 || durationNum > 12)) {
      setModalPlanError('Months duration must be between 1 and 12 months.');
      return;
    }
    if (modalPlanUnit === 'Years' && (durationNum < 1 || durationNum > 5)) {
      setModalPlanError('Years duration must be between 1 and 5 years.');
      return;
    }

    // Check duplicate
    const exists = plans.some(p => p.planName.toLowerCase() === modalPlanName.trim().toLowerCase());
    if (exists) {
      setModalPlanError('A plan with this name already exists. Please use a unique plan name.');
      return;
    }

    setPlans(prev => [
      ...prev,
      {
        planName: modalPlanName.trim(),
        price: priceNum,
        duration: durationNum,
        durationUnit: modalPlanUnit,
        description: modalPlanDesc.trim()
      }
    ]);

    setIsPlanModalOpen(false);
  };

  const handleCreateFirstMember = () => {
    if (!memberName.trim() || !memberPhone.trim()) {
      setError('Member Full Name and Phone number are required.');
      return;
    }
    const sampleCode = Math.floor(100000 + Math.random() * 900000).toString();
    setCreatedMemberCode(sampleCode);
  };

  const handleCopyCode = () => {
    if (createdMemberCode) {
      navigator.clipboard.writeText(createdMemberCode);
      setCodeCopied(true);
      setTimeout(() => setCodeCopied(false), 2000);
    }
  };

  const handleFinishOnboarding = async () => {
    setSubmitting(true);
    setError('');

    const activePlan = plans[selectedPlanIndex] || plans[0] || { planName: 'Monthly Pass', price: 1500, duration: 1, durationUnit: 'Months' };

    const payload = {
      owner: { fullName: ownerName, phone: ownerPhone, photo: ownerPhoto },
      gym: { gymName, phone: gymPhone, address, city, email, gymType, logo: gymLogo, schedule, weeklyOff, timezone },
      payment: { upiId, upiDisplayName: upiDisplayName || gymName, upiQr, paymentInstructions, isEnabled: onlinePaymentEnabled },
      plans,
      firstMember: memberName.trim() ? {
        fullName: memberName,
        phone: memberPhone,
        age: memberAge,
        gender: memberGender,
        location: memberLocation,
        photo: memberPhoto,
        plan: activePlan
      } : null
    };

    try {
      const response = await fetch('/api/owner/onboarding', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await response.json();

      if (data?.success) {
        localStorage.removeItem('owner_onboarding_draft');
        localStorage.setItem('gym_session', JSON.stringify({
          gymId: data.gymId,
          gymName: data.gymName,
          role: 'owner'
        }));
        setCompletedData(data);
        setCompleted(true);
      } else {
        setError(data?.message || 'Onboarding submission failed.');
      }
    } catch {
      setError('Connection error. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  // Step 7: Completed Screen
  if (completed) {
    const gymCode = completedData?.accessCode || 'A6N4K8';
    const memberObj = completedData?.firstMember;

    return (
      <div className="min-h-screen bg-[var(--bg)] text-[var(--text)] py-12 px-4 flex flex-col items-center justify-center">
        <div className="w-full max-w-lg clay-raised p-8 rounded-[32px] text-center space-y-6 animate-fade-in">
          <div className="text-6xl animate-bounce">🎉</div>
          <div>
            <span className="text-[10px] font-black uppercase tracking-widest text-[#34A853]">ONBOARDING COMPLETE</span>
            <h1 className="text-3xl font-black uppercase tracking-wider text-[var(--text)] mt-1">Your Gym Is Ready!</h1>
            <p className="text-xs text-[var(--text-sec)] font-medium mt-1">
              Welcome aboard, <strong className="text-[var(--text)]">{ownerName || 'Gym Owner'}</strong>. Your digital gym workspace has been provisioned.
            </p>
          </div>

          <div className="p-4 neo-pressed rounded-[20px] space-y-2 text-left">
            <div className="flex justify-between items-center text-xs">
              <span className="text-[var(--text-sec)] font-bold uppercase">Gym Name</span>
              <span className="font-black text-[var(--text)] uppercase">{completedData?.gymName || gymName}</span>
            </div>
            <div className="flex justify-between items-center text-xs">
              <span className="text-[var(--text-sec)] font-bold uppercase">Owner Access Code</span>
              <span className="font-mono font-black text-[var(--text)] tracking-widest text-sm bg-[var(--surface)] px-2.5 py-0.5 rounded border border-[var(--border)]">{gymCode}</span>
            </div>
            {memberObj && (
              <div className="flex justify-between items-center text-xs pt-1 border-t border-[var(--border)]">
                <span className="text-[var(--text-sec)] font-bold uppercase">First Member Added</span>
                <span className="font-bold text-[#34A853]">{memberObj.fullName} ({memberObj.memberAccessCode})</span>
              </div>
            )}
          </div>

          <div className="space-y-3 pt-2">
            <button
              onClick={() => navigate('/owner/dashboard')}
              className="w-full h-14 rounded-[20px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 active:scale-95 transition-transform cursor-pointer shadow-lg"
            >
              Go to Owner Dashboard <ArrowRight size={18} />
            </button>

            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => navigate('/owner/members')}
                className="h-12 rounded-[16px] neo-raised text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 transition-transform"
              >
                <UserPlus size={16} /> View Members
              </button>
              <button
                onClick={() => navigate('/owner/plans')}
                className="h-12 rounded-[16px] neo-raised text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 transition-transform"
              >
                <Award size={16} /> View Plans
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[var(--bg)] text-[var(--text)] py-8 px-4 flex flex-col items-center relative">
      <div className="absolute top-4 right-4 z-20">
        <LanguageSelector onLanguageChange={(newLang) => setLang(newLang)} variant="compact" />
      </div>

      <div className="w-full max-w-xl space-y-6">
        {/* Step Indicator Header */}
        <div className="text-center space-y-2">
          <span className="text-[9px] font-black uppercase tracking-[0.25em] text-[var(--text-sec)]">GYM OWNER ONBOARDING</span>
          <h1 className="text-2xl font-black uppercase tracking-wider text-[var(--text)]">Setup Your Gym Workspace</h1>
          
          <div className="flex justify-center items-center gap-2 pt-2">
            {[1, 2, 3, 4, 5, 6].map(i => (
              <div 
                key={i} 
                className={`h-2 rounded-full transition-all duration-300 ${
                  i === step ? 'w-8 bg-[var(--text)]' : i < step ? 'w-4 bg-[#34A853]' : 'w-4 bg-[var(--border)]'
                }`}
              />
            ))}
          </div>
          <p className="text-[11px] font-bold uppercase tracking-wider text-[var(--text-sec)]">
            Step {step} of 6: {
              step === 1 ? 'Owner Profile' :
              step === 2 ? 'Gym Details & Hours' :
              step === 3 ? 'Payment Setup' :
              step === 4 ? 'Membership Plans' :
              step === 5 ? 'First Member Setup' : 'Review & Submit'
            }
          </p>
        </div>

        {error && (
          <div className="p-4 rounded-2xl bg-[#D64545]/15 border border-[#D64545] text-[#D64545] text-xs font-bold flex items-center gap-2">
            <AlertCircle size={16} /> {error}
          </div>
        )}

        {/* STEP 1: OWNER DETAILS */}
        {step === 1 && (
          <div className="clay-raised p-6 sm:p-8 rounded-[32px] space-y-6 animate-fade-in">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl neo-raised flex items-center justify-center font-black">
                <User size={20} />
              </div>
              <div>
                <h2 className="text-lg font-black uppercase tracking-wider">Owner Profile</h2>
                <p className="text-xs text-[var(--text-sec)] font-medium">Your personal account details as owner</p>
              </div>
            </div>

            {/* Photo Upload */}
            <div className="flex flex-col sm:flex-row items-center gap-4 p-4 neo-pressed rounded-[20px]">
              {ownerPhoto ? (
                <img src={ownerPhoto} alt="Owner" className="w-20 h-20 rounded-full object-cover border-2 border-[var(--text)]" />
              ) : (
                <div className="w-20 h-20 rounded-full bg-[var(--surface)] border-2 border-dashed border-[var(--border)] flex items-center justify-center font-black text-2xl uppercase text-[var(--text-sec)]">
                  {ownerName?.charAt(0) || 'O'}
                </div>
              )}

              <div className="space-y-1 text-center sm:text-left">
                <p className="text-xs font-bold uppercase tracking-wider text-[var(--text)]">Owner Photo (Optional)</p>
                <p className="text-[10px] text-[var(--text-sec)] font-medium">Upload photo from gallery or camera</p>
                <div className="flex gap-2 justify-center sm:justify-start pt-1">
                  <label className="px-3 py-1.5 rounded-xl neo-raised text-[11px] font-bold uppercase tracking-wider flex items-center gap-1 cursor-pointer">
                    <Upload size={14} /> Upload Image
                    <input type="file" accept="image/*" className="hidden" onChange={(e) => e.target.files?.[0] && handleImageUpload(e.target.files[0], 'owner')} />
                  </label>
                  {ownerPhoto && (
                    <button type="button" onClick={() => setOwnerPhoto('')} className="px-3 py-1.5 rounded-xl neo-raised text-[#D64545] text-[11px] font-bold uppercase cursor-pointer">
                      <Trash2 size={14} />
                    </button>
                  )}
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">Owner Full Name *</label>
                <input
                  type="text"
                  value={ownerName}
                  onChange={(e) => setOwnerName(e.target.value)}
                  placeholder="e.g. Vikram Singh"
                  className="w-full h-12 px-4 neo-pressed rounded-[14px] outline-none text-sm font-bold text-[var(--text)]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">Mobile Phone Number (+91) *</label>
                <input
                  type="text"
                  value={ownerPhone}
                  onChange={(e) => setOwnerPhone(e.target.value)}
                  placeholder="e.g. 9876543210"
                  className="w-full h-12 px-4 neo-pressed rounded-[14px] outline-none text-sm font-mono font-bold text-[var(--text)]"
                />
              </div>
            </div>

            <button
              onClick={handleNextStep}
              className="w-full h-14 rounded-[20px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 cursor-pointer shadow-md active:scale-95 transition-transform"
            >
              Continue to Gym Details <ArrowRight size={18} />
            </button>
          </div>
        )}

        {/* STEP 2: GYM DETAILS & MULTI-SESSION SCHEDULE */}
        {step === 2 && (
          <div className="clay-raised p-6 sm:p-8 rounded-[32px] space-y-6 animate-fade-in">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl neo-raised flex items-center justify-center font-black">
                <Building2 size={20} />
              </div>
              <div>
                <h2 className="text-lg font-black uppercase tracking-wider">Gym Details & Operating Hours</h2>
                <p className="text-xs text-[var(--text-sec)] font-medium">Basic information and multi-session schedule</p>
              </div>
            </div>

            {/* Logo Upload */}
            <div className="flex flex-col sm:flex-row items-center gap-4 p-4 neo-pressed rounded-[20px]">
              {gymLogo ? (
                <img src={gymLogo} alt="Gym Logo" className="w-20 h-20 rounded-2xl object-cover border-2 border-[var(--text)]" />
              ) : (
                <div className="w-20 h-20 rounded-2xl bg-[var(--surface)] border-2 border-dashed border-[var(--border)] flex items-center justify-center font-black text-2xl uppercase text-[var(--text-sec)]">
                  {gymName?.charAt(0) || 'G'}
                </div>
              )}

              <div className="space-y-1 text-center sm:text-left">
                <p className="text-xs font-bold uppercase tracking-wider text-[var(--text)]">Gym Logo (Optional)</p>
                <p className="text-[10px] text-[var(--text-sec)] font-medium">Appears on receipts and member ID cards</p>
                <div className="flex gap-2 justify-center sm:justify-start pt-1">
                  <label className="px-3 py-1.5 rounded-xl neo-raised text-[11px] font-bold uppercase tracking-wider flex items-center gap-1 cursor-pointer">
                    <Upload size={14} /> Upload Logo
                    <input type="file" accept="image/*" className="hidden" onChange={(e) => e.target.files?.[0] && handleImageUpload(e.target.files[0], 'logo')} />
                  </label>
                  {gymLogo && (
                    <button type="button" onClick={() => setGymLogo('')} className="px-3 py-1.5 rounded-xl neo-raised text-[#D64545] text-[11px] font-bold uppercase cursor-pointer">
                      <Trash2 size={14} />
                    </button>
                  )}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="sm:col-span-2">
                <label className="block text-xs font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">Gym Name *</label>
                <input
                  type="text"
                  value={gymName}
                  onChange={(e) => setGymName(e.target.value)}
                  placeholder="e.g. Apex Fitness Club"
                  className="w-full h-12 px-4 neo-pressed rounded-[14px] outline-none text-sm font-bold text-[var(--text)]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">Gym Phone / Landline</label>
                <input
                  type="text"
                  value={gymPhone}
                  onChange={(e) => setGymPhone(e.target.value)}
                  placeholder="e.g. 9876543210"
                  className="w-full h-12 px-4 neo-pressed rounded-[14px] outline-none text-sm font-mono font-bold text-[var(--text)]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">Gym Email</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="e.g. info@apexfitness.com"
                  className="w-full h-12 px-4 neo-pressed rounded-[14px] outline-none text-sm font-bold text-[var(--text)]"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">Address *</label>
                <input
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="e.g. Main Road, Kankarbagh"
                  className="w-full h-12 px-4 neo-pressed rounded-[14px] outline-none text-sm font-bold text-[var(--text)]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">City *</label>
                <input
                  type="text"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  placeholder="e.g. Patna"
                  className="w-full h-12 px-4 neo-pressed rounded-[14px] outline-none text-sm font-bold text-[var(--text)]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">Gym Type</label>
                <select
                  value={gymType}
                  onChange={(e) => setGymType(e.target.value)}
                  className="w-full h-12 px-4 neo-pressed rounded-[14px] outline-none text-sm font-bold text-[var(--text)] bg-transparent"
                >
                  <option value="Unisex">Unisex (Men & Women)</option>
                  <option value="Men Only">Men Only</option>
                  <option value="Women Only">Women Only</option>
                  <option value="Crossfit Studio">Crossfit Studio</option>
                </select>
              </div>
            </div>

            {/* Multi-session Weekly Schedule */}
            <div className="space-y-4 pt-4 border-t border-[var(--border)]">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <h3 className="text-xs font-black uppercase tracking-wider text-[var(--text)] flex items-center gap-1.5">
                    <Clock size={16} /> Opening & Closing Schedule (Multi-Session)
                  </h3>
                  <p className="text-[10px] text-[var(--text-sec)]">Set per-weekday operating sessions</p>
                </div>
                <button
                  type="button"
                  onClick={applyMondayToWeekdays}
                  className="px-2.5 py-1.5 rounded-xl neo-raised text-[10px] font-bold uppercase tracking-wider text-[#4285F4] hover:underline cursor-pointer"
                >
                  Apply Mon schedule to Tue–Fri
                </button>
              </div>

              <div className="space-y-3">
                {schedule.map((daySched, dayIdx) => (
                  <div key={daySched.day} className="p-3.5 neo-pressed rounded-[16px] space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xs uppercase text-[var(--text)]">{daySched.day}</span>
                      <button
                        type="button"
                        onClick={() => toggleDayOpen(dayIdx)}
                        className={`px-2.5 py-0.5 rounded-lg text-[10px] font-black uppercase border cursor-pointer ${
                          daySched.isOpen 
                            ? 'bg-[#34A853]/15 text-[#34A853] border-[#34A853]' 
                            : 'bg-[#D64545]/15 text-[#D64545] border-[#D64545]'
                        }`}
                      >
                        {daySched.isOpen ? 'OPEN' : 'CLOSED / OFF'}
                      </button>
                    </div>

                    {daySched.isOpen && (
                      <div className="space-y-2 pt-1">
                        {daySched.sessions.map((sess, sessIdx) => (
                          <div key={sessIdx} className="flex items-center gap-2 text-xs">
                            <span className="text-[9px] font-bold text-[var(--text-sec)] uppercase">Batch {sessIdx + 1}:</span>
                            <input
                              type="time"
                              value={sess.open}
                              onChange={(e) => updateSessionTime(dayIdx, sessIdx, 'open', e.target.value)}
                              className="h-8 px-2 neo-raised rounded-lg outline-none font-mono text-xs text-[var(--text)]"
                            />
                            <span className="text-[var(--text-sec)] font-bold">-</span>
                            <input
                              type="time"
                              value={sess.close}
                              onChange={(e) => updateSessionTime(dayIdx, sessIdx, 'close', e.target.value)}
                              className="h-8 px-2 neo-raised rounded-lg outline-none font-mono text-xs text-[var(--text)]"
                            />
                            {daySched.sessions.length > 1 && (
                              <button type="button" onClick={() => removeSession(dayIdx, sessIdx)} className="p-1 text-[#D64545] cursor-pointer">
                                <Trash size={12} />
                              </button>
                            )}
                          </div>
                        ))}
                        <button
                          type="button"
                          onClick={() => addSession(dayIdx)}
                          className="text-[10px] font-bold uppercase text-[#4285F4] flex items-center gap-1 cursor-pointer"
                        >
                          <Plus size={12} /> Add Session
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setStep(1)}
                className="h-14 px-5 rounded-[20px] neo-raised text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-1 cursor-pointer"
              >
                <ArrowLeft size={16} /> Back
              </button>
              <button
                onClick={handleNextStep}
                className="flex-1 h-14 rounded-[20px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 cursor-pointer shadow-md active:scale-95 transition-transform"
              >
                Continue to Payment Setup <ArrowRight size={18} />
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: PAYMENT SETUP */}
        {step === 3 && (
          <div className="clay-raised p-6 sm:p-8 rounded-[32px] space-y-6 animate-fade-in">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl neo-raised flex items-center justify-center font-black text-[#FBBC05]">
                <ShieldCheck size={20} />
              </div>
              <div>
                <h2 className="text-lg font-black uppercase tracking-wider">UPI & Online Payment Setup</h2>
                <p className="text-xs text-[var(--text-sec)] font-medium">Configure UPI ID and QR code for member dues</p>
              </div>
            </div>

            {/* Banner Warning Note */}
            <div className="p-4 rounded-2xl bg-[#FBBC05]/15 border-2 border-[#FBBC05] space-y-1 text-xs text-[var(--text)]">
              <p className="font-black uppercase tracking-wider text-[#FBBC05] flex items-center gap-1.5">
                <AlertCircle size={15} /> Payment Verification Protocol
              </p>
              <p className="font-medium text-[11px] leading-relaxed">
                Online payment se member aapke configured UPI/payment method par redirect hoga. UPI app open hona payment complete hone ka proof nahi hai. Payment PAID tabhi maana jayega jab owner manually confirm kare ya connected payment gateway se real confirmation aaye.
              </p>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between p-3.5 neo-pressed rounded-[16px]">
                <span className="text-xs font-bold uppercase tracking-wider text-[var(--text)]">Enable Online UPI Payments</span>
                <input
                  type="checkbox"
                  checked={onlinePaymentEnabled}
                  onChange={(e) => setOnlinePaymentEnabled(e.target.checked)}
                  className="w-5 h-5 accent-[var(--text)] cursor-pointer"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">Gym UPI ID (VPA)</label>
                <input
                  type="text"
                  value={upiId}
                  onChange={(e) => setUpiId(e.target.value)}
                  placeholder="e.g. apexfitness@upi or 9876543210@ybl"
                  className="w-full h-12 px-4 neo-pressed rounded-[14px] outline-none text-sm font-mono font-bold text-[var(--text)]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">Receiver Display Name</label>
                <input
                  type="text"
                  value={upiDisplayName}
                  onChange={(e) => setUpiDisplayName(e.target.value)}
                  placeholder="e.g. Apex Fitness Club"
                  className="w-full h-12 px-4 neo-pressed rounded-[14px] outline-none text-sm font-bold text-[var(--text)]"
                />
              </div>

              {/* QR Upload */}
              <div className="p-4 neo-pressed rounded-[20px] space-y-2">
                <p className="text-xs font-bold uppercase tracking-wider text-[var(--text)]">Standee QR Code Image (Optional)</p>
                <div className="flex items-center gap-4">
                  {upiQr ? (
                    <img src={upiQr} alt="QR" className="w-20 h-20 object-contain rounded-xl border border-[var(--border)] bg-white p-1" />
                  ) : (
                    <div className="w-20 h-20 rounded-xl bg-[var(--surface)] border border-dashed border-[var(--border)] flex items-center justify-center text-[10px] font-bold text-[var(--text-sec)] uppercase text-center p-1">
                      No Image
                    </div>
                  )}

                  <label className="px-3 py-2 rounded-xl neo-raised text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 cursor-pointer">
                    <Upload size={14} /> Upload QR Image
                    <input type="file" accept="image/*" className="hidden" onChange={(e) => e.target.files?.[0] && handleImageUpload(e.target.files[0], 'qr')} />
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">Payment Instructions</label>
                <input
                  type="text"
                  value={paymentInstructions}
                  onChange={(e) => setPaymentInstructions(e.target.value)}
                  placeholder="e.g. Show payment confirmation screenshot at gym reception."
                  className="w-full h-12 px-4 neo-pressed rounded-[14px] outline-none text-xs font-medium text-[var(--text)]"
                />
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setStep(2)}
                className="h-14 px-5 rounded-[20px] neo-raised text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-1 cursor-pointer"
              >
                <ArrowLeft size={16} /> Back
              </button>
              <button
                onClick={handleNextStep}
                className="flex-1 h-14 rounded-[20px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 cursor-pointer shadow-md active:scale-95 transition-transform"
              >
                Continue to Membership Plans <ArrowRight size={18} />
              </button>
            </div>
          </div>
        )}

        {/* STEP 4: MEMBERSHIP PLANS */}
        {step === 4 && (
          <div className="clay-raised p-6 sm:p-8 rounded-[32px] space-y-6 animate-fade-in">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[var(--border)] pb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl neo-raised flex items-center justify-center font-black text-[#4285F4]">
                  <Award size={20} />
                </div>
                <div>
                  <h2 className="text-lg font-black uppercase tracking-wider">Membership Plans</h2>
                  <p className="text-xs text-[var(--text-sec)] font-medium">Create custom membership passes for your gym</p>
                </div>
              </div>

              <button
                type="button"
                onClick={openCreatePlanModal}
                className="h-11 px-5 rounded-[16px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 active:scale-95 transition-transform cursor-pointer shadow-md shrink-0"
              >
                <Plus size={18} /> Add Plan
              </button>
            </div>

            {/* Plans Card List */}
            {plans.length > 0 ? (
              <div className="space-y-3">
                {plans.map((p, idx) => (
                  <div key={idx} className="p-4 neo-pressed rounded-[20px] flex items-center justify-between gap-4">
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2">
                        <h3 className="font-black text-sm uppercase text-[var(--text)]">{p.planName}</h3>
                        <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-[var(--surface)] text-[var(--text-sec)] border border-[var(--border)]">
                          {p.duration} {p.durationUnit}
                        </span>
                      </div>
                      <p className="text-xs font-black text-[#34A853] font-mono">
                        ₹{p.price.toLocaleString('en-IN')}
                      </p>
                      {p.description && (
                        <p className="text-[11px] text-[var(--text-sec)] font-medium line-clamp-1">{p.description}</p>
                      )}
                    </div>
                    <button
                      type="button"
                      onClick={() => setPlans(prev => prev.filter((_, i) => i !== idx))}
                      className="p-2.5 rounded-xl neo-raised text-[#D64545] hover:bg-[#D64545]/10 cursor-pointer active:scale-95 transition-transform"
                      title="Delete plan"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-8 rounded-[24px] neo-pressed text-center space-y-2">
                <div className="w-12 h-12 rounded-full neo-raised mx-auto flex items-center justify-center text-[var(--text-sec)]">
                  <Award size={24} />
                </div>
                <h3 className="text-xs font-black uppercase tracking-wider text-[var(--text)]">No Membership Plans Created</h3>
                <p className="text-[11px] text-[var(--text-sec)] font-medium max-w-xs mx-auto">
                  There are no plans setup yet. Tap "+ Add Plan" above to create your first membership pass.
                </p>
              </div>
            )}

            <div className="flex gap-3 pt-2">
              <button
                onClick={() => setStep(3)}
                className="h-14 px-5 rounded-[20px] neo-raised text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-1 cursor-pointer"
              >
                <ArrowLeft size={16} /> Back
              </button>
              <button
                onClick={handleNextStep}
                className="flex-1 h-14 rounded-[20px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 cursor-pointer shadow-md active:scale-95 transition-transform"
              >
                Continue to First Member <ArrowRight size={18} />
              </button>
            </div>
          </div>
        )}

        {/* CREATE MEMBERSHIP PLAN MODAL */}
        {isPlanModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
            <div className="bg-[var(--surface)] text-[var(--text)] w-full max-w-md rounded-[28px] border border-[var(--border)] shadow-2xl p-6 sm:p-8 space-y-5">
              <div className="flex items-center justify-between border-b border-[var(--border)] pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-[var(--text)] text-[var(--bg)] flex items-center justify-center font-black">
                    <Plus size={18} />
                  </div>
                  <div>
                    <h2 className="text-sm font-black uppercase tracking-wider">Create Membership Plan</h2>
                    <p className="text-[10px] text-[var(--text-sec)] font-mono uppercase">Setup pricing & duration</p>
                  </div>
                </div>
                <button
                  onClick={() => setIsPlanModalOpen(false)}
                  className="p-2 rounded-xl neo-pressed text-[var(--text-sec)] hover:text-[var(--text)] cursor-pointer"
                >
                  <X size={18} />
                </button>
              </div>

              {modalPlanError && (
                <div className="p-3 rounded-xl bg-[#D64545]/10 border border-[#D64545]/30 text-[#D64545] text-xs font-bold flex items-center gap-2">
                  <AlertCircle size={16} className="shrink-0" />
                  <span>{modalPlanError}</span>
                </div>
              )}

              <div className="space-y-4">
                <div>
                  <label className="block text-[11px] font-black uppercase tracking-wider text-[var(--text-sec)] mb-1">
                    Plan Name *
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Quarterly Pro Pass"
                    value={modalPlanName}
                    onChange={(e) => setModalPlanName(e.target.value)}
                    className="w-full h-11 px-4 neo-pressed rounded-xl text-xs font-bold text-[var(--text)] outline-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-black uppercase tracking-wider text-[var(--text-sec)] mb-1">
                      Duration Value *
                    </label>
                    <input
                      type="number"
                      placeholder="e.g. 3"
                      value={modalPlanDuration}
                      onChange={(e) => setModalPlanDuration(e.target.value)}
                      className="w-full h-11 px-4 neo-pressed rounded-xl text-xs font-mono font-bold text-[var(--text)] outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-black uppercase tracking-wider text-[var(--text-sec)] mb-1">
                      Duration Unit *
                    </label>
                    <select
                      value={modalPlanUnit}
                      onChange={(e) => setModalPlanUnit(e.target.value as any)}
                      className="w-full h-11 px-3 neo-pressed rounded-xl text-xs font-bold text-[var(--text)] outline-none bg-transparent"
                    >
                      <option value="Days">Days (1–31)</option>
                      <option value="Weeks">Weeks (1–12)</option>
                      <option value="Months">Months (1–12)</option>
                      <option value="Years">Years (1–5)</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-black uppercase tracking-wider text-[var(--text-sec)] mb-1">
                    Amount (₹) *
                  </label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 font-mono font-black text-xs text-[var(--text-sec)]">
                      ₹
                    </span>
                    <input
                      type="number"
                      placeholder="e.g. 2500"
                      value={modalPlanPrice}
                      onChange={(e) => setModalPlanPrice(e.target.value)}
                      className="w-full h-11 pl-9 pr-4 neo-pressed rounded-xl text-xs font-mono font-bold text-[var(--text)] outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-black uppercase tracking-wider text-[var(--text-sec)] mb-1">
                    Description / Included Perks (Optional)
                  </label>
                  <textarea
                    placeholder="e.g. Full access to gym floor, locker room + complimentary diet consultation"
                    value={modalPlanDesc}
                    onChange={(e) => setModalPlanDesc(e.target.value)}
                    rows={2}
                    className="w-full p-3 neo-pressed rounded-xl text-xs font-medium text-[var(--text)] outline-none resize-none"
                  />
                </div>
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsPlanModalOpen(false)}
                  className="flex-1 h-12 rounded-[16px] neo-raised text-xs font-bold uppercase tracking-wider text-[var(--text)] active:scale-95 transition-transform cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleCreateModalPlan}
                  className="flex-1 h-12 rounded-[16px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-wider active:scale-95 transition-transform cursor-pointer shadow-md"
                >
                  Create Plan
                </button>
              </div>
            </div>
          </div>
        )}

        {/* STEP 5: FIRST MEMBER */}
        {step === 5 && (
          <div className="clay-raised p-6 sm:p-8 rounded-[32px] space-y-6 animate-fade-in">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl neo-raised flex items-center justify-center font-black text-[#34A853]">
                <UserPlus size={20} />
              </div>
              <div>
                <h2 className="text-lg font-black uppercase tracking-wider">Add First Member</h2>
                <p className="text-xs text-[var(--text-sec)] font-medium">Add your first active member to test credentials</p>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">Member Full Name *</label>
                <input
                  type="text"
                  value={memberName}
                  onChange={(e) => setMemberName(e.target.value)}
                  placeholder="e.g. Rahul Kumar"
                  className="w-full h-12 px-4 neo-pressed rounded-[14px] outline-none text-sm font-bold text-[var(--text)]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">Mobile (+91) *</label>
                <input
                  type="text"
                  value={memberPhone}
                  onChange={(e) => setMemberPhone(e.target.value)}
                  placeholder="e.g. 9876543210"
                  className="w-full h-12 px-4 neo-pressed rounded-[14px] outline-none text-sm font-mono font-bold text-[var(--text)]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">Age</label>
                  <input
                    type="number"
                    value={memberAge}
                    onChange={(e) => setMemberAge(e.target.value)}
                    placeholder="25"
                    className="w-full h-12 px-4 neo-pressed rounded-[14px] outline-none text-sm font-bold text-[var(--text)]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">Gender</label>
                  <select
                    value={memberGender}
                    onChange={(e) => setMemberGender(e.target.value)}
                    className="w-full h-12 px-4 neo-pressed rounded-[14px] outline-none text-sm font-bold text-[var(--text)] bg-transparent"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">Assigned Plan</label>
                <select
                  value={selectedPlanIndex}
                  onChange={(e) => setSelectedPlanIndex(Number(e.target.value))}
                  className="w-full h-12 px-4 neo-pressed rounded-[14px] outline-none text-sm font-bold text-[var(--text)] bg-transparent"
                >
                  {plans.map((p, idx) => (
                    <option key={idx} value={idx}>{p.planName} - ₹{p.price} ({p.duration} {p.durationUnit})</option>
                  ))}
                </select>
              </div>

              {!createdMemberCode ? (
                <button
                  type="button"
                  onClick={handleCreateFirstMember}
                  className="w-full h-12 rounded-[16px] neo-raised text-xs font-black uppercase tracking-wider flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Sparkles size={16} /> Generate Member Access Credentials
                </button>
              ) : (
                <div className="p-4 rounded-2xl bg-[#34A853]/15 border border-[#34A853] space-y-2">
                  <div className="flex justify-between items-center text-xs font-black uppercase text-[#34A853]">
                    <span>Credentials Generated!</span>
                    <span>Ready</span>
                  </div>
                  <div className="p-3 bg-[var(--surface)] rounded-xl flex items-center justify-between font-mono">
                    <span className="text-xs text-[var(--text-sec)]">6-Digit Code:</span>
                    <span className="text-xl font-black text-[var(--text)] tracking-widest">{createdMemberCode}</span>
                    <button type="button" onClick={handleCopyCode} className="p-1.5 neo-raised rounded-lg text-xs cursor-pointer">
                      {codeCopied ? <Check size={14} className="text-[#34A853]" /> : <Copy size={14} />}
                    </button>
                  </div>
                </div>
              )}
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setStep(4)}
                className="h-14 px-5 rounded-[20px] neo-raised text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-1 cursor-pointer"
              >
                <ArrowLeft size={16} /> Back
              </button>
              <button
                onClick={handleNextStep}
                className="flex-1 h-14 rounded-[20px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 cursor-pointer shadow-md active:scale-95 transition-transform"
              >
                Review Workspace Setup <ArrowRight size={18} />
              </button>
            </div>
          </div>
        )}

        {/* STEP 6: REVIEW & FINAL SUBMIT */}
        {step === 6 && (
          <div className="clay-raised p-6 sm:p-8 rounded-[32px] space-y-6 animate-fade-in">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl neo-raised flex items-center justify-center font-black text-[#34A853]">
                <CheckCircle2 size={20} />
              </div>
              <div>
                <h2 className="text-lg font-black uppercase tracking-wider">Review & Finish Setup</h2>
                <p className="text-xs text-[var(--text-sec)] font-medium">Verify all information before provisioning</p>
              </div>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-4 neo-pressed rounded-[20px] space-y-2">
                <h3 className="font-black uppercase tracking-wider text-[var(--text-sec)] text-[10px]">1. Owner Info</h3>
                <p className="font-bold text-sm text-[var(--text)]">{ownerName || 'Gym Owner'}</p>
                <p className="font-mono text-[var(--text-sec)]">{ownerPhone || 'No phone'}</p>
              </div>

              <div className="p-4 neo-pressed rounded-[20px] space-y-2">
                <h3 className="font-black uppercase tracking-wider text-[var(--text-sec)] text-[10px]">2. Gym & Location</h3>
                <p className="font-bold text-sm text-[var(--text)]">{gymName || 'Apex Gym'}</p>
                <p className="text-[var(--text-sec)]">{address}, {city}</p>
                <p className="text-[10px] text-[var(--text-sec)] font-bold">Type: {gymType} | Weekly Off: {weeklyOff}</p>
              </div>

              <div className="p-4 neo-pressed rounded-[20px] space-y-2">
                <h3 className="font-black uppercase tracking-wider text-[var(--text-sec)] text-[10px]">3. Payment Setup</h3>
                <p className="font-mono font-bold text-[var(--text)]">UPI: {upiId || 'Not configured yet'}</p>
              </div>

              <div className="p-4 neo-pressed rounded-[20px] space-y-2">
                <h3 className="font-black uppercase tracking-wider text-[var(--text-sec)] text-[10px]">4. Plans Created ({plans.length})</h3>
                <div className="flex flex-wrap gap-2 pt-1">
                  {plans.map((p, i) => (
                    <span key={i} className="px-2.5 py-1 rounded-lg bg-[var(--surface)] text-[10px] font-bold border border-[var(--border)]">
                      {p.planName} (₹{p.price})
                    </span>
                  ))}
                </div>
              </div>

              {memberName && (
                <div className="p-4 neo-pressed rounded-[20px] space-y-1">
                  <h3 className="font-black uppercase tracking-wider text-[var(--text-sec)] text-[10px]">5. First Member</h3>
                  <p className="font-bold text-[var(--text)]">{memberName} ({memberPhone})</p>
                </div>
              )}
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setStep(5)}
                disabled={submitting}
                className="h-14 px-5 rounded-[20px] neo-raised text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-1 cursor-pointer disabled:opacity-50"
              >
                <ArrowLeft size={16} /> Edit
              </button>
              <button
                onClick={handleFinishOnboarding}
                disabled={submitting}
                className="flex-1 h-14 rounded-[20px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 cursor-pointer shadow-lg active:scale-95 transition-transform disabled:opacity-50"
              >
                {submitting ? (
                  <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1, ease: "linear" }}>
                    <Loader2 size={20} />
                  </motion.div>
                ) : (
                  <>Finish & Open Dashboard <CheckCircle2 size={18} /></>
                )}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
