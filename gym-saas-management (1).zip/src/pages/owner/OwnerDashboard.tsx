import React, { useEffect, useState } from 'react';
import { useNavigate, Link } from '@/lib/router-compat';
import { 
  IndianRupee, Activity, 
  ArrowRight, ShieldAlert, BarChart, QrCode, AlertTriangle, Sparkles, Check, UserPlus,
  Download, FileSpreadsheet, Bell, Send, CreditCard, UserCheck, FileText, Calendar, Users, Filter
} from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Tooltip } from 'recharts';
import OwnerLayout from '../../components/OwnerLayout';
import { getGreetingLine, firstName } from '@/lib/greeting';
import { TaskDetailModal, AnimatedToast } from '../../components/ui/Motion';
import { exportMembersToCSV, exportAttendanceToCSV } from '@/lib/csv-exporter';
import RecordPaymentModal from '../../components/RecordPaymentModal';
import ManualCheckInModal from '../../components/ManualCheckInModal';
import GenerateInvoiceModal from '../../components/GenerateInvoiceModal';
import CreateNoticeModal from '../../components/CreateNoticeModal';

export default function OwnerDashboard() {
  const navigate = useNavigate();
  const [data, setData] = useState<any>(null);
  const [tasks, setTasks] = useState<any[]>([]);
  const [status, setStatus] = useState<'loading' | 'loaded' | 'error'>('loading');
  const [selectedTask, setSelectedTask] = useState<any | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [exportingMembers, setExportingMembers] = useState(false);
  const [exportingAttendance, setExportingAttendance] = useState(false);
  const [sendingReminders, setSendingReminders] = useState(false);

  // Gym Closure State
  const [activeClosure, setActiveClosure] = useState<any>(null);
  const [showClosureModal, setShowClosureModal] = useState(false);
  const [closureReason, setClosureReason] = useState('Facility Maintenance');
  const [closingGym, setClosingGym] = useState(false);

  // Modal Control States
  const [showRecordPaymentModal, setShowRecordPaymentModal] = useState(false);
  const [paymentPreselectedMemberId, setPaymentPreselectedMemberId] = useState<string | undefined>(undefined);
  
  const [showManualCheckInModal, setShowManualCheckInModal] = useState(false);
  
  const [showInvoiceModal, setShowInvoiceModal] = useState(false);
  const [invoiceMemberId, setInvoiceMemberId] = useState<string>('');
  const [invoicePaymentId, setInvoicePaymentId] = useState<string | undefined>(undefined);

  const [showNoticeModal, setShowNoticeModal] = useState(false);

  const fetchDashboardData = () => {
    const sessionStr = localStorage.getItem('gym_session');
    if (!sessionStr) {
      navigate('/');
      return;
    }
    const session = JSON.parse(sessionStr);
    
    setStatus('loading');
    Promise.all([
      fetch(`/api/dashboard/${session.gymId}`).then(async res => {
        if (!res.ok) throw new Error('API Error');
        return res.json();
      }),
      fetch(`/api/owner-daily-tasks/${session.gymId}`).then(async res => {
        if (!res.ok) return { success: false, tasks: [] };
        return res.json();
      }),
      fetch(`/api/gym-closures/active/${session.gymId}`).then(async res => {
        if (!res.ok) return { success: false, isClosedToday: false };
        return res.json();
      })
    ])
      .then(([dashData, taskData, closureData]) => {
        if (dashData && dashData.gym) {
          setData(dashData);
          if (taskData && taskData.success && taskData.tasks) {
            setTasks(taskData.tasks);
          }
          if (closureData && closureData.isClosedToday) {
            setActiveClosure(closureData.closure);
          } else {
            setActiveClosure(null);
          }
          setStatus('loaded');
        } else {
          setStatus('error');
        }
      })
      .catch(err => {
        console.error(err);
        setStatus('error');
      });
  };

  const handleCloseGymToday = async () => {
    const sessionStr = localStorage.getItem('gym_session');
    if (!sessionStr) return;
    const session = JSON.parse(sessionStr);

    setClosingGym(true);
    try {
      const res = await fetch('/api/owner/gym-closures/close', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          gymId: session.gymId,
          reason: closureReason.trim() || 'Facility Maintenance',
          closureType: 'TODAY'
        })
      });
      const resData = await res.json();
      if (resData.success) {
        setActiveClosure(resData.closure);
        setShowClosureModal(false);
        setToastMessage(`Gym closed today. Notified ${resData.membersNotified || 0} active member(s).`);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setClosingGym(false);
    }
  };

  const handleReopenGym = async () => {
    const sessionStr = localStorage.getItem('gym_session');
    if (!sessionStr) return;
    const session = JSON.parse(sessionStr);

    setClosingGym(true);
    try {
      const res = await fetch('/api/owner/gym-closures/reopen', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ gymId: session.gymId })
      });
      const resData = await res.json();
      if (resData.success) {
        setActiveClosure(null);
        setToastMessage('Gym has been reopened! Normal schedule restored.');
      }
    } catch (e) {
      console.error(e);
    } finally {
      setClosingGym(false);
    }
  };

  const handleCompleteTask = async (taskId: string) => {
    const sessionStr = localStorage.getItem('gym_session');
    if (!sessionStr) return;
    const session = JSON.parse(sessionStr);
    try {
      const res = await fetch(`/api/owner-daily-tasks/${session.gymId}/${taskId}/complete`, {
        method: 'POST'
      });
      const resData = await res.json();
      if (resData.success) {
        setTasks(prev => prev.map(t => t.id === taskId ? { ...t, status: 'COMPLETED' } : t));
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleExportMembersCSV = async () => {
    const sessionStr = localStorage.getItem('gym_session');
    if (!sessionStr) return;
    const session = JSON.parse(sessionStr);

    setExportingMembers(true);
    try {
      const res = await fetch(`/api/members/${session.gymId}`);
      const resData = await res.json();
      if (resData && resData.members) {
        exportMembersToCSV(resData.members, data?.gym?.gymName || 'Gym');
        setToastMessage(`Exported ${resData.members.length} member records to CSV`);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setExportingMembers(false);
    }
  };

  const handleExportAttendanceCSV = async () => {
    const sessionStr = localStorage.getItem('gym_session');
    if (!sessionStr) return;
    const session = JSON.parse(sessionStr);

    setExportingAttendance(true);
    try {
      const res = await fetch(`/api/owner/attendance/${session.gymId}`);
      const resData = await res.json();
      const records = resData.logs || resData.attendance || data?.todaysAttendanceList || [];
      exportAttendanceToCSV(records, data?.gym?.gymName || 'Gym');
      setToastMessage(`Exported ${records.length} attendance records to CSV`);
    } catch (e) {
      console.error(e);
      exportAttendanceToCSV(data?.todaysAttendanceList || [], data?.gym?.gymName || 'Gym');
      setToastMessage('Exported attendance records to CSV');
    } finally {
      setExportingAttendance(false);
    }
  };

  const handleSendPaymentReminders = async () => {
    const sessionStr = localStorage.getItem('gym_session');
    if (!sessionStr) return;
    const session = JSON.parse(sessionStr);

    setSendingReminders(true);
    try {
      const res = await fetch('/api/owner/broadcast/payment-reminders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ gymId: session.gymId })
      });
      const resData = await res.json();
      if (resData.success) {
        setToastMessage(`Payment reminders broadcast sent to ${resData.recipientCount} member(s)!`);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setSendingReminders(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, [navigate]);

  if (status === 'loading') {
    return (
      <OwnerLayout>
        <div className="flex items-center justify-center py-20 text-[var(--text)]">
          <Activity className="animate-spin" size={28} />
        </div>
      </OwnerLayout>
    );
  }

  if (status === 'error' || !data || !data.gym) {
    return (
      <OwnerLayout>
        <div className="flex flex-col items-center justify-center py-20 text-[var(--text)] text-center px-4">
          <ShieldAlert size={48} className="text-[#D64545] mb-4" />
          <h2 className="text-2xl font-bold mb-2 uppercase tracking-widest">Something went wrong</h2>
          <p className="text-[10px] uppercase tracking-widest text-[var(--text-sec)] mb-6">Unable to load dashboard data. Please try again.</p>
          <div className="flex gap-4">
            <button onClick={fetchDashboardData} className="px-6 py-3 bg-[var(--btn-bg)] text-[var(--btn-text)] rounded-xl text-xs uppercase tracking-widest font-bold cursor-pointer">
              Retry
            </button>
            <button onClick={() => { window.location.reload(); }} className="px-6 py-3 bg-[var(--surface-sec)] text-[var(--text)] rounded-xl text-xs uppercase tracking-widest font-bold cursor-pointer">
              Reload Dashboard
            </button>
          </div>
        </div>
      </OwnerLayout>
    );
  }

  const chartData = data.chartData || [
    { name: 'Mon', rev: 0, att: 0 },
    { name: 'Tue', rev: 0, att: 0 },
    { name: 'Wed', rev: 0, att: 0 },
    { name: 'Thu', rev: 0, att: 0 },
    { name: 'Fri', rev: 0, att: 0 },
    { name: 'Sat', rev: 0, att: 0 },
    { name: 'Sun', rev: 0, att: 0 },
  ];

  const ownerDisplayName = firstName(data.owner?.fullName || data.owner?.name || data.gym?.ownerName || '');
  const moneySnapshot = data.moneySnapshot || {
    todayCollection: data.overview?.revenue || 0,
    monthRevenue: data.overview?.revenue || 0,
    pendingDues: 0,
    overdueDues: 0,
    expectedRevenue: data.overview?.revenue || 0
  };

  const memberAttention = data.memberAttention || {
    expiringSoonCount: data.overview?.expiringMembers || 0,
    overdueCount: data.overview?.pendingPayments || 0,
    inactiveCount: 0,
    noWorkoutCount: 0,
    pendingPaymentCount: data.overview?.pendingPayments || 0
  };

  const focusItems = data.focusItems || [];
  const sessionGymId = data.gym?.id || 'demo_gym_1';

  return (
    <OwnerLayout>
      <div className="px-4 mt-6 space-y-8 pb-10">
        {toastMessage && (
          <AnimatedToast message={toastMessage} type="success" onClose={() => setToastMessage(null)} />
        )}

        {/* 1. GREETING AREA */}
        <section className="clay-raised p-6 rounded-[24px] relative overflow-hidden flex flex-col justify-between space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <span className="text-[10px] font-black uppercase tracking-widest text-[#34A853] bg-[#34A853]/10 px-2.5 py-0.5 rounded-full border border-[#34A853]/20">
                OPERATIONS FIRST DASHBOARD
              </span>
              <h1 className="text-2xl sm:text-3xl font-black uppercase tracking-wider mt-2">
                {getGreetingLine(ownerDisplayName)}
              </h1>
              <p className="text-xs text-[var(--text-sec)] font-bold uppercase tracking-widest mt-0.5">
                {data.gym?.gymName || 'YOUR GYM'} • {new Date().toLocaleDateString('en-IN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
              </p>
            </div>
            
            <div className="flex flex-wrap items-center gap-2">
              <Link 
                to="/owner/attendance/qr" 
                className="px-4 py-2.5 rounded-[16px] neo-raised text-[var(--text)] text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 active:scale-95 transition-transform shrink-0 cursor-pointer"
              >
                <QrCode size={16} /> DAILY QR
              </Link>
            </div>
          </div>
        </section>

        {/* 2. GYM STATUS CARD */}
        {activeClosure ? (
          <section className="p-5 rounded-[24px] bg-red-500/10 border-2 border-red-500/40 text-red-600 dark:text-red-400 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-2xl bg-red-500 text-white flex items-center justify-center font-bold shrink-0 shadow-md">
                  <AlertTriangle size={22} />
                </div>
                <div>
                  <span className="text-[10px] font-black uppercase tracking-widest bg-red-500/20 px-2 py-0.5 rounded-md">
                    GYM TEMPORARILY CLOSED TODAY
                  </span>
                  <h3 className="text-sm font-black uppercase tracking-wider mt-1">Reason: {activeClosure.reason || 'Facility Maintenance'}</h3>
                  <p className="text-[11px] font-medium opacity-90 mt-0.5">Check-ins blocked for members today. Active members have been notified in app.</p>
                </div>
              </div>
              <button
                type="button"
                onClick={handleReopenGym}
                disabled={closingGym}
                className="px-5 py-3 rounded-2xl bg-red-600 text-white font-black text-xs uppercase tracking-wider hover:bg-red-700 transition-all shadow-md active:scale-95 shrink-0 cursor-pointer disabled:opacity-50"
              >
                {closingGym ? 'Reopening Gym...' : 'REOPEN GYM NOW'}
              </button>
            </div>
          </section>
        ) : (
          <section className="clay-raised p-4 rounded-[20px] flex items-center justify-between border border-[var(--border)]">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold">
                <Sparkles size={18} />
              </div>
              <div>
                <p className="text-xs font-bold uppercase tracking-wider flex items-center gap-2">
                  Gym Status: <span className="text-emerald-600 dark:text-emerald-400 font-black">OPEN</span>
                </p>
                <p className="text-[10px] text-[var(--text-sec)]">24x7 Gym Hours Active (Normal Operations)</p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setShowClosureModal(true)}
              className="px-3.5 py-2 rounded-xl bg-red-50 dark:bg-red-950/30 text-red-600 dark:text-red-400 border border-red-200 dark:border-red-900 text-[11px] font-black uppercase tracking-wider hover:bg-red-100 transition-all cursor-pointer"
            >
              CLOSE GYM TODAY
            </button>
          </section>
        )}

        {/* 3. TODAY'S FOCUS SECTION */}
        <section className="clay-raised p-6 rounded-[24px] space-y-4">
          <div className="flex justify-between items-center border-b border-[var(--border)] pb-3">
            <div>
              <h3 className="text-sm font-black uppercase tracking-wider text-[var(--text)] flex items-center gap-2">
                <AlertTriangle size={18} className="text-[#E3A008]" /> Today's Operational Focus
              </h3>
              <p className="text-[10px] uppercase font-bold text-[var(--text-sec)]">Prioritized items requiring gym owner action today</p>
            </div>
            <span className="text-[10px] font-black uppercase tracking-widest text-[var(--text-sec)] font-mono">
              {focusItems.length} Focus Items
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {focusItems.length > 0 ? (
              focusItems.map((item: any) => (
                <div
                  key={item.id}
                  className="p-4 rounded-[18px] neo-raised flex items-center justify-between gap-3"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className={`text-[8px] font-black uppercase px-2 py-0.5 rounded-md ${
                        item.priority === 'URGENT' ? 'bg-red-500 text-white' :
                        item.priority === 'HIGH' ? 'bg-amber-500 text-white' :
                        'bg-[var(--surface-sec)] text-[var(--text-sec)]'
                      }`}>
                        {item.priority}
                      </span>
                      <span className="text-xs font-black uppercase text-[var(--text)]">{item.title}</span>
                    </div>
                    <p className="text-[11px] text-[var(--text-sec)] font-medium">{item.reason}</p>
                  </div>

                  {item.actionUrl && (
                    <Link
                      to={item.actionUrl}
                      className="px-3.5 py-2 bg-[var(--btn-bg)] text-[var(--btn-text)] rounded-[12px] text-[10px] font-black uppercase tracking-wider shrink-0 flex items-center gap-1 active:scale-95 transition-transform cursor-pointer"
                    >
                      Action <ArrowRight size={12} />
                    </Link>
                  )}
                </div>
              ))
            ) : (
              <div className="col-span-2 p-4 rounded-[18px] neo-pressed text-center text-xs font-bold text-[#34A853] uppercase tracking-wider flex items-center justify-center gap-2">
                <Sparkles size={16} /> All daily operational items are clear and up to date!
              </div>
            )}
          </div>
        </section>

        {/* 4. QUICK ACTIONS BAR (6 PRIMARY ACTIONS) */}
        <section className="space-y-3">
          <h3 className="text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] px-1">Quick Action Controls</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            <Link
              to="/owner/members/add"
              className="p-4 rounded-[20px] neo-raised flex flex-col items-center justify-center text-center hover:scale-105 active:scale-95 transition-all cursor-pointer group"
            >
              <div className="w-10 h-10 rounded-2xl bg-[var(--text)] text-[var(--bg)] flex items-center justify-center mb-2 shadow-sm group-hover:rotate-6 transition-transform">
                <UserPlus size={20} />
              </div>
              <span className="text-xs font-black uppercase tracking-wider text-[var(--text)]">+ Add Member</span>
              <span className="text-[9px] text-[var(--text-sec)] uppercase mt-0.5">Onboard New</span>
            </Link>

            <button
              onClick={() => {
                setPaymentPreselectedMemberId(undefined);
                setShowRecordPaymentModal(true);
              }}
              className="p-4 rounded-[20px] neo-raised flex flex-col items-center justify-center text-center hover:scale-105 active:scale-95 transition-all cursor-pointer group"
            >
              <div className="w-10 h-10 rounded-2xl bg-emerald-500 text-white flex items-center justify-center mb-2 shadow-sm group-hover:rotate-6 transition-transform">
                <IndianRupee size={20} />
              </div>
              <span className="text-xs font-black uppercase tracking-wider text-[var(--text)]">Record Payment</span>
              <span className="text-[9px] text-[var(--text-sec)] uppercase mt-0.5">Manual Entry</span>
            </button>

            <button
              onClick={() => setShowManualCheckInModal(true)}
              className="p-4 rounded-[20px] neo-raised flex flex-col items-center justify-center text-center hover:scale-105 active:scale-95 transition-all cursor-pointer group"
            >
              <div className="w-10 h-10 rounded-2xl bg-blue-500 text-white flex items-center justify-center mb-2 shadow-sm group-hover:rotate-6 transition-transform">
                <UserCheck size={20} />
              </div>
              <span className="text-xs font-black uppercase tracking-wider text-[var(--text)]">Manual Check-In</span>
              <span className="text-[9px] text-[var(--text-sec)] uppercase mt-0.5">Mark Attendance</span>
            </button>

            <Link
              to="/owner/workout"
              className="p-4 rounded-[20px] neo-raised flex flex-col items-center justify-center text-center hover:scale-105 active:scale-95 transition-all cursor-pointer group"
            >
              <div className="w-10 h-10 rounded-2xl bg-purple-500 text-white flex items-center justify-center mb-2 shadow-sm group-hover:rotate-6 transition-transform">
                <Activity size={20} />
              </div>
              <span className="text-xs font-black uppercase tracking-wider text-[var(--text)]">Assign Workout</span>
              <span className="text-[9px] text-[var(--text-sec)] uppercase mt-0.5">Daily Routines</span>
            </Link>

            <button
              onClick={() => {
                const firstMem = (data.members || [])[0]?.id || '';
                if (firstMem) {
                  setInvoiceMemberId(firstMem);
                  setShowInvoiceModal(true);
                } else {
                  setShowRecordPaymentModal(true);
                }
              }}
              className="p-4 rounded-[20px] neo-raised flex flex-col items-center justify-center text-center hover:scale-105 active:scale-95 transition-all cursor-pointer group"
            >
              <div className="w-10 h-10 rounded-2xl bg-amber-500 text-white flex items-center justify-center mb-2 shadow-sm group-hover:rotate-6 transition-transform">
                <FileText size={20} />
              </div>
              <span className="text-xs font-black uppercase tracking-wider text-[var(--text)]">Create Invoice</span>
              <span className="text-[9px] text-[var(--text-sec)] uppercase mt-0.5">Tax Receipt</span>
            </button>

            <button
              onClick={() => setShowNoticeModal(true)}
              className="p-4 rounded-[20px] neo-raised flex flex-col items-center justify-center text-center hover:scale-105 active:scale-95 transition-all cursor-pointer group"
            >
              <div className="w-10 h-10 rounded-2xl bg-rose-500 text-white flex items-center justify-center mb-2 shadow-sm group-hover:rotate-6 transition-transform">
                <Bell size={20} />
              </div>
              <span className="text-xs font-black uppercase tracking-wider text-[var(--text)]">Send Notice</span>
              <span className="text-[9px] text-[var(--text-sec)] uppercase mt-0.5">Gym Announcement</span>
            </button>
          </div>
        </section>

        {/* 5. MONEY SNAPSHOT */}
        <section className="neo-raised p-6 rounded-[24px] space-y-4">
          <div className="flex justify-between items-center border-b border-[var(--border)] pb-3">
            <div>
              <h3 className="text-sm font-black uppercase tracking-wider text-[var(--text)] flex items-center gap-2">
                <IndianRupee size={18} className="text-emerald-500" /> Money Snapshot
              </h3>
              <p className="text-[10px] uppercase font-bold text-[var(--text-sec)]">Live financial collection and receivables</p>
            </div>
            <Link to="/owner/dues" className="px-3.5 py-1.5 neo-raised text-[10px] font-bold uppercase tracking-wider text-[var(--text)] flex items-center gap-1 cursor-pointer">
              View Payments & Dues <ArrowRight size={12} />
            </Link>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="p-4 neo-pressed rounded-[16px]">
              <span className="text-[9px] uppercase font-bold tracking-widest text-[var(--text-sec)] block">Today's Collection</span>
              <span className="text-xl sm:text-2xl font-black font-mono text-emerald-600 dark:text-emerald-400">
                ₹{Number(moneySnapshot.todayCollection || 0).toLocaleString('en-IN')}
              </span>
            </div>
            <div className="p-4 neo-pressed rounded-[16px]">
              <span className="text-[9px] uppercase font-bold tracking-widest text-[var(--text-sec)] block">This Month Revenue</span>
              <span className="text-xl sm:text-2xl font-black font-mono text-[var(--text)]">
                ₹{Number(moneySnapshot.monthRevenue || 0).toLocaleString('en-IN')}
              </span>
            </div>
            <div className="p-4 neo-pressed rounded-[16px]">
              <span className="text-[9px] uppercase font-bold tracking-widest text-amber-500 block">Pending Dues</span>
              <span className="text-xl sm:text-2xl font-black font-mono text-amber-500">
                ₹{Number(moneySnapshot.pendingDues || 0).toLocaleString('en-IN')}
              </span>
            </div>
            <div className="p-4 neo-pressed rounded-[16px]">
              <span className="text-[9px] uppercase font-bold tracking-widest text-red-500 block">Overdue Dues</span>
              <span className="text-xl sm:text-2xl font-black font-mono text-red-500">
                ₹{Number(moneySnapshot.overdueDues || 0).toLocaleString('en-IN')}
              </span>
            </div>
          </div>
        </section>

        {/* 6. MEMBER ATTENTION CARD */}
        <section className="clay-raised p-6 rounded-[24px] space-y-4">
          <div className="flex justify-between items-center border-b border-[var(--border)] pb-3">
            <div>
              <h3 className="text-sm font-black uppercase tracking-wider text-[var(--text)] flex items-center gap-2">
                <Users size={18} className="text-blue-500" /> Member Attention Center
              </h3>
              <p className="text-[10px] uppercase font-bold text-[var(--text-sec)]">Filter members requiring immediate gym owner review</p>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <Link
              to="/owner/members?filter=EXPIRING"
              className="p-4 rounded-[18px] neo-raised flex flex-col justify-between hover:border-[var(--text)] transition-all cursor-pointer"
            >
              <span className="text-[9px] font-bold uppercase text-red-500 tracking-wider">Expiring Soon (7d)</span>
              <span className="text-2xl font-black text-red-500 font-mono mt-1">{memberAttention.expiringSoonCount}</span>
              <span className="text-[9px] font-bold text-[var(--text-sec)] uppercase mt-1">Review Expiries →</span>
            </Link>

            <Link
              to="/owner/dues"
              className="p-4 rounded-[18px] neo-raised flex flex-col justify-between hover:border-[var(--text)] transition-all cursor-pointer"
            >
              <span className="text-[9px] font-bold uppercase text-amber-500 tracking-wider">Overdue Dues</span>
              <span className="text-2xl font-black text-amber-500 font-mono mt-1">{memberAttention.overdueCount}</span>
              <span className="text-[9px] font-bold text-[var(--text-sec)] uppercase mt-1">Collect Dues →</span>
            </Link>

            <Link
              to="/owner/members?filter=INACTIVE"
              className="p-4 rounded-[18px] neo-raised flex flex-col justify-between hover:border-[var(--text)] transition-all cursor-pointer"
            >
              <span className="text-[9px] font-bold uppercase text-purple-500 tracking-wider">Inactive (7+ Days)</span>
              <span className="text-2xl font-black text-purple-500 font-mono mt-1">{memberAttention.inactiveCount}</span>
              <span className="text-[9px] font-bold text-[var(--text-sec)] uppercase mt-1">Follow Up →</span>
            </Link>

            <Link
              to="/owner/workout"
              className="p-4 rounded-[18px] neo-raised flex flex-col justify-between hover:border-[var(--text)] transition-all cursor-pointer"
            >
              <span className="text-[9px] font-bold uppercase text-blue-500 tracking-wider">Without Workout Plan</span>
              <span className="text-2xl font-black text-blue-500 font-mono mt-1">{memberAttention.noWorkoutCount}</span>
              <span className="text-[9px] font-bold text-[var(--text-sec)] uppercase mt-1">Assign Routine →</span>
            </Link>
          </div>
        </section>

        {/* 7. ATTENDANCE & WORKOUT SUMMARY */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <section className="neo-raised p-6 rounded-[24px] space-y-4">
            <div className="flex justify-between items-center border-b border-[var(--border)] pb-3">
              <div>
                <h3 className="text-sm font-black uppercase tracking-wider text-[var(--text)] flex items-center gap-2">
                  <Activity size={18} className="text-[#4285F4]" /> Attendance Today
                </h3>
                <p className="text-[10px] uppercase font-bold text-[var(--text-sec)]">Live check-in participation</p>
              </div>
              <button
                onClick={() => setShowManualCheckInModal(true)}
                className="px-3 py-1.5 bg-[var(--text)] text-[var(--bg)] rounded-xl text-[10px] font-black uppercase tracking-wider cursor-pointer"
              >
                + Check In
              </button>
            </div>

            <div className="flex items-center gap-6">
              <div className="relative w-24 h-24 flex items-center justify-center shrink-0">
                <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                  <path className="text-[var(--surface-sec)]" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="currentColor" strokeWidth="3" />
                  <path className="text-[#4285F4]" strokeDasharray={`${data.attendanceOverview?.percentage || 0}, 100`} d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="currentColor" strokeWidth="3" />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center font-mono font-bold">
                  <span className="text-xl">{data.attendanceOverview?.percentage || 0}%</span>
                </div>
              </div>
              <div className="flex-1 grid grid-cols-2 gap-3">
                <div className="p-3 neo-pressed rounded-[14px]">
                  <p className="text-[9px] uppercase tracking-widest text-[var(--text-sec)] font-bold">Present Today</p>
                  <p className="font-bold font-mono text-lg text-[#34A853]">{data.attendanceOverview?.present || 0}</p>
                </div>
                <div className="p-3 neo-pressed rounded-[14px]">
                  <p className="text-[9px] uppercase tracking-widest text-[var(--text-sec)] font-bold">Total Active</p>
                  <p className="font-bold font-mono text-lg text-[var(--text)]">{data.attendanceOverview?.totalActive || 0}</p>
                </div>
              </div>
            </div>

            {/* Today's Live Check-ins Stream */}
            <div className="space-y-2 pt-2 border-t border-[var(--border)]">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-black uppercase tracking-wider text-[var(--text-sec)]">
                  Today's Check-ins ({ (data.todaysAttendanceList || []).length })
                </span>
                <Link to="/owner/attendance" className="text-[10px] font-bold text-[#4285F4] uppercase tracking-wider hover:underline">
                  View All Log →
                </Link>
              </div>

              <div className="max-h-48 overflow-y-auto space-y-2 pr-1">
                {(data.todaysAttendanceList || []).length > 0 ? (
                  (data.todaysAttendanceList || []).map((log: any, idx: number) => (
                    <div key={log.id || idx} className="p-2.5 neo-pressed rounded-[14px] flex items-center justify-between gap-3 text-xs">
                      <div className="flex items-center gap-2.5 min-w-0">
                        {log.memberPhoto ? (
                          <img src={log.memberPhoto} alt={log.memberName} className="w-7 h-7 rounded-full object-cover shrink-0 border border-[var(--border)]" />
                        ) : (
                          <div className="w-7 h-7 rounded-full bg-[var(--surface)] font-black text-[10px] flex items-center justify-center text-[var(--text)] shrink-0 border border-[var(--border)]">
                            {(log.memberName || 'M').charAt(0)}
                          </div>
                        )}
                        <div className="min-w-0">
                          <p className="font-bold text-[var(--text)] truncate text-[11px]">{log.memberName}</p>
                          <p className="text-[9px] font-mono text-[var(--text-sec)] font-bold">{log.memberDisplayId || ''}</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0 text-right">
                        <span className="text-[10px] font-mono font-bold text-[var(--text-sec)]">
                          {log.time || log.checkIn || ''}
                        </span>
                        <span className={`text-[8px] font-black px-1.5 py-0.5 rounded ${
                          log.method === 'QR' ? 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20' : 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20'
                        }`}>
                          {log.method || 'PRESENT'}
                        </span>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-[11px] text-[var(--text-sec)] font-medium text-center py-3">
                    No check-ins recorded yet today.
                  </p>
                )}
              </div>
            </div>
          </section>

          <section className="neo-raised p-6 rounded-[24px] space-y-4">
            <div className="flex justify-between items-center border-b border-[var(--border)] pb-3">
              <div>
                <h3 className="text-sm font-black uppercase tracking-wider text-[var(--text)] flex items-center gap-2">
                  <Activity size={18} className="text-purple-500" /> Workout Assignments
                </h3>
                <p className="text-[10px] uppercase font-bold text-[var(--text-sec)]">Member workout status</p>
              </div>
              <Link
                to="/owner/workout"
                className="px-3 py-1.5 bg-[var(--text)] text-[var(--bg)] rounded-xl text-[10px] font-black uppercase tracking-wider cursor-pointer"
              >
                Assign
              </Link>
            </div>

            <div className="grid grid-cols-2 gap-4 pt-2">
              <div className="p-4 neo-pressed rounded-[16px]">
                <span className="text-[9px] uppercase font-bold tracking-widest text-emerald-500 block">Active Workouts</span>
                <span className="text-2xl font-black font-mono text-emerald-500">{(data.members || []).length - memberAttention.noWorkoutCount}</span>
                <span className="text-[9px] text-[var(--text-sec)] uppercase block mt-1">Assigned & Active</span>
              </div>

              <div className="p-4 neo-pressed rounded-[16px]">
                <span className="text-[9px] uppercase font-bold tracking-widest text-amber-500 block">Without Workout</span>
                <span className="text-2xl font-black font-mono text-amber-500">{memberAttention.noWorkoutCount}</span>
                <span className="text-[9px] text-[var(--text-sec)] uppercase block mt-1">Need Routine</span>
              </div>
            </div>
          </section>
        </div>

        {/* 8. EXPORT & BROADCAST TOOLS */}
        <section className="clay-raised p-5 rounded-[24px] space-y-3 border border-[var(--border)]">
          <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2 border-b border-[var(--border)] pb-3">
            <div>
              <h3 className="text-xs font-black uppercase tracking-wider text-[var(--text)] flex items-center gap-2">
                <FileSpreadsheet size={16} className="text-[#34A853]" /> Gym Export & Broadcast Tools
              </h3>
              <p className="text-[9px] uppercase font-bold tracking-widest text-[var(--text-sec)]">Export CSV data files or broadcast payment due alerts</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <button
              onClick={handleExportMembersCSV}
              disabled={exportingMembers}
              className="px-4 py-3 neo-raised rounded-[16px] text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 text-[var(--text)] hover:bg-[var(--surface-sec)] transition-colors cursor-pointer active:scale-95 disabled:opacity-50"
            >
              <Download size={16} className="text-[#34A853]" />
              {exportingMembers ? 'Exporting CSV...' : 'Export Members CSV'}
            </button>

            <button
              onClick={handleExportAttendanceCSV}
              disabled={exportingAttendance}
              className="px-4 py-3 neo-raised rounded-[16px] text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 text-[var(--text)] hover:bg-[var(--surface-sec)] transition-colors cursor-pointer active:scale-95 disabled:opacity-50"
            >
              <Download size={16} className="text-[#4285F4]" />
              {exportingAttendance ? 'Exporting CSV...' : 'Export Attendance CSV'}
            </button>

            <button
              onClick={handleSendPaymentReminders}
              disabled={sendingReminders}
              className="px-4 py-3 neo-raised rounded-[16px] text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 text-[#E3A008] hover:bg-[#E3A008]/10 transition-colors cursor-pointer active:scale-95 disabled:opacity-50"
            >
              <Bell size={16} className="text-[#E3A008]" />
              {sendingReminders ? 'Sending Alerts...' : 'Send Due Reminders'}
            </button>
          </div>
        </section>

        {/* 9. GYM PERFORMANCE TREND */}
        <section className="neo-raised p-6 rounded-[24px] space-y-4">
          <div className="flex justify-between items-center border-b border-[var(--border)] pb-3">
            <div>
              <h3 className="text-sm font-black uppercase tracking-wider text-[var(--text)] flex items-center gap-2">
                <BarChart size={18} /> Gym Performance Trends
              </h3>
              <p className="text-[10px] uppercase font-bold text-[var(--text-sec)] font-mono">Weekly Collections & Check-in Activity</p>
            </div>
          </div>

          <div className="h-48 w-full -ml-4">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: 'var(--text-sec)' }} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: 'var(--text-sec)' }} dx={-10} />
                <Tooltip 
                  contentStyle={{ backgroundColor: 'var(--surface)', border: '1px solid var(--border)', borderRadius: '12px' }}
                  itemStyle={{ color: 'var(--text)' }}
                  cursor={{ stroke: 'var(--border)' }}
                />
                <Line type="monotone" dataKey="rev" stroke="var(--text)" strokeWidth={3} dot={false} activeDot={{ r: 6, fill: 'var(--text)', stroke: 'var(--bg)', strokeWidth: 2 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </section>

        {/* MODAL DIALOGS */}
        <RecordPaymentModal
          gymId={sessionGymId}
          isOpen={showRecordPaymentModal}
          onClose={() => setShowRecordPaymentModal(false)}
          preselectedMemberId={paymentPreselectedMemberId}
          onSuccess={() => {
            fetchDashboardData();
            setToastMessage('Payment recorded successfully!');
          }}
          onGenerateInvoice={(mId, pId) => {
            setInvoiceMemberId(mId);
            setInvoicePaymentId(pId);
            setShowInvoiceModal(true);
          }}
        />

        <ManualCheckInModal
          gymId={sessionGymId}
          isOpen={showManualCheckInModal}
          onClose={() => setShowManualCheckInModal(false)}
          onSuccess={() => {
            fetchDashboardData();
            setToastMessage('Manual check-in completed!');
          }}
        />

        <GenerateInvoiceModal
          gymId={sessionGymId}
          memberId={invoiceMemberId}
          paymentId={invoicePaymentId}
          isOpen={showInvoiceModal}
          onClose={() => setShowInvoiceModal(false)}
        />

        <CreateNoticeModal
          gymId={sessionGymId}
          isOpen={showNoticeModal}
          onClose={() => setShowNoticeModal(false)}
          onSuccess={(notice) => {
            setToastMessage(`Notice "${notice.title}" published!`);
          }}
        />

        {/* CLOSURE CONFIRMATION MODAL */}
        {showClosureModal && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="clay-raised p-6 rounded-[28px] w-full max-w-md space-y-4 border border-neutral-200 dark:border-neutral-800 animate-fade-in bg-[var(--bg)] text-[var(--text)]">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-red-500">
                  <AlertTriangle size={20} />
                  <h3 className="text-sm font-black uppercase tracking-wider">Declare Temporary Gym Closure</h3>
                </div>
                <button 
                  onClick={() => setShowClosureModal(false)}
                  className="text-xs font-bold text-[var(--text-sec)] hover:text-[var(--text)]"
                >
                  CANCEL
                </button>
              </div>

              <p className="text-xs text-[var(--text-sec)] font-medium leading-relaxed">
                This will temporarily pause member check-ins for today and push an automated notice to all active gym members. Your weekly schedule remains intact.
              </p>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">
                  Closure Reason / Public Note
                </label>
                <input
                  type="text"
                  value={closureReason}
                  onChange={(e) => setClosureReason(e.target.value)}
                  placeholder="e.g. Facility Maintenance, Festival Holiday, Weather"
                  className="w-full h-12 px-4 neo-pressed rounded-2xl text-xs font-bold text-[var(--text)] outline-none border border-neutral-200 dark:border-neutral-800"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowClosureModal(false)}
                  className="flex-1 h-12 rounded-2xl neo-raised text-xs font-bold uppercase tracking-wider cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleCloseGymToday}
                  disabled={closingGym}
                  className="flex-1 h-12 rounded-2xl bg-red-600 text-white text-xs font-black uppercase tracking-wider shadow-md hover:bg-red-700 disabled:opacity-50 cursor-pointer"
                >
                  {closingGym ? 'Closing...' : 'Confirm Closure'}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Task Detail Modal */}
        {selectedTask && (
          <TaskDetailModal
            isOpen={!!selectedTask}
            onClose={() => setSelectedTask(null)}
            task={selectedTask}
            onAction={() => {
              handleCompleteTask(selectedTask.id);
              setSelectedTask(null);
            }}
            onDismiss={() => setSelectedTask(null)}
          />
        )}
      </div>
    </OwnerLayout>
  );
}

