import React, { useState, useEffect } from 'react';
import { useNavigate } from '@/lib/router-compat';
import { 
  User, Building2, Phone, MapPin, LogOut, Camera, Trash2, 
  Upload, Check, Clock, Plus, Trash, HelpCircle, Save, AlertCircle, ShieldCheck
} from 'lucide-react';
import OwnerLayout from '../../components/OwnerLayout';
import PWAInstallBanner from '../../components/PWAInstallBanner';
import { signOutEverything } from '@/lib/app-auth';

interface ScheduleSession {
  open: string;
  close: string;
}

interface DaySchedule {
  day: string;
  isOpen: boolean;
  sessions: ScheduleSession[];
}

const DEFAULT_WEEKDAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

export default function ProfileSettings() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'profile' | 'gym' | 'schedule' | 'payment' | 'support'>('profile');

  // Owner State
  const [ownerName, setOwnerName] = useState('');
  const [ownerPhone, setOwnerPhone] = useState('');
  const [ownerPhoto, setOwnerPhoto] = useState('');

  // Gym State
  const [gymName, setGymName] = useState('');
  const [gymPhone, setGymPhone] = useState('');
  const [gymEmail, setGymEmail] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [gymType, setGymType] = useState('Unisex');
  const [gymLogo, setGymLogo] = useState('');
  const [accessCode, setAccessCode] = useState('');

  // Multi-session Schedule
  const [schedule, setSchedule] = useState<DaySchedule[]>(
    DEFAULT_WEEKDAYS.map(day => ({
      day,
      isOpen: true,
      sessions: [
        { open: '00:00', close: '24:00' }
      ]
    }))
  );

  // Payment Setup
  const [upiId, setUpiId] = useState('');
  const [upiDisplayName, setUpiDisplayName] = useState('');
  const [upiQrImage, setUpiQrImage] = useState('');
  const [paymentInstructions, setPaymentInstructions] = useState('');
  const [onlinePaymentEnabled, setOnlinePaymentEnabled] = useState(true);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  };

  const fetchProfile = () => {
    const sessionStr = localStorage.getItem('gym_session');
    if (!sessionStr) { navigate('/'); return; }
    const session = JSON.parse(sessionStr);

    setLoading(true);
    fetch(`/api/owner/profile/${session.gymId}`)
      .then(res => res.json())
      .then(data => {
        if (data && data.success) {
          const g = data.gym || {};
          const o = data.owner || {};
          const p = data.paymentSetting || {};

          setGymName(g.gymName || '');
          setGymPhone(g.phone || '');
          setGymEmail(g.email || '');
          setAddress(g.address || '');
          setCity(g.city || '');
          setGymType(g.gymType || 'Unisex');
          setGymLogo(g.logo || '');
          setAccessCode(g.accessCode || g.gymCode || 'A6N4K8');

          setOwnerName(o.fullName || g.ownerName || '');
          setOwnerPhone(o.phone || g.phone || '');
          setOwnerPhoto(o.photo || '');

          if (g.schedule && Array.isArray(g.schedule) && g.schedule.length > 0) {
            setSchedule(g.schedule);
          }

          setUpiId(p.upiId || '');
          setUpiDisplayName(p.upiDisplayName || g.gymName || '');
          setUpiQrImage(p.upiQrImage || '');
          setPaymentInstructions(p.paymentInstructions || '');
          setOnlinePaymentEnabled(p.isEnabled !== false);
        }
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchProfile();
  }, []);

  const handleImageUpload = (file: File, target: 'owner' | 'logo' | 'qr') => {
    if (file.size > 5 * 1024 * 1024) {
      alert('File size must be less than 5MB');
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      if (target === 'owner') setOwnerPhoto(result);
      if (target === 'logo') setGymLogo(result);
      if (target === 'qr') setUpiQrImage(result);
    };
    reader.readAsDataURL(file);
  };

  const toggleDayOpen = (dayIndex: number) => {
    setSchedule(prev => prev.map((d, idx) => {
      if (idx !== dayIndex) return d;
      const newOpen = !d.isOpen;
      return {
        ...d,
        isOpen: newOpen,
        sessions: newOpen && d.sessions.length === 0 
          ? [{ open: '06:00', close: '11:00' }, { open: '16:00', close: '22:00' }]
          : d.sessions
      };
    }));
  };

  const addSession = (dayIndex: number) => {
    setSchedule(prev => prev.map((d, idx) => {
      if (idx !== dayIndex) return d;
      return {
        ...d,
        sessions: [...d.sessions, { open: '12:00', close: '15:00' }]
      };
    }));
  };

  const removeSession = (dayIndex: number, sessionIndex: number) => {
    setSchedule(prev => prev.map((d, idx) => {
      if (idx !== dayIndex) return d;
      return {
        ...d,
        sessions: d.sessions.filter((_, sIdx) => sIdx !== sessionIndex)
      };
    }));
  };

  const updateSessionTime = (dayIndex: number, sessionIndex: number, field: 'open' | 'close', val: string) => {
    setSchedule(prev => prev.map((d, idx) => {
      if (idx !== dayIndex) return d;
      const updated = [...d.sessions];
      updated[sessionIndex] = { ...updated[sessionIndex], [field]: val };
      return { ...d, sessions: updated };
    }));
  };

  const applyMondayToWeekdays = () => {
    const mondaySched = schedule.find(d => d.day === 'Monday');
    if (!mondaySched) return;
    setSchedule(prev => prev.map(d => {
      if (['Tuesday', 'Wednesday', 'Thursday', 'Friday'].includes(d.day)) {
        return {
          ...d,
          isOpen: mondaySched.isOpen,
          sessions: JSON.parse(JSON.stringify(mondaySched.sessions))
        };
      }
      return d;
    }));
    showToast('Applied Monday schedule to Tuesday – Friday!');
  };

  const handleSaveAll = async () => {
    const sessionStr = localStorage.getItem('gym_session');
    if (!sessionStr) return;
    const session = JSON.parse(sessionStr);

    setSaving(true);
    try {
      const payload = {
        gym: {
          gymName,
          phone: gymPhone,
          email: gymEmail,
          address,
          city,
          gymType,
          logo: gymLogo,
          schedule
        },
        owner: {
          fullName: ownerName,
          phone: ownerPhone,
          photo: ownerPhoto
        },
        paymentSetting: {
          upiId,
          upiDisplayName: upiDisplayName || gymName,
          upiQrImage,
          paymentInstructions,
          isEnabled: onlinePaymentEnabled
        }
      };

      const res = await fetch(`/api/owner/profile/${session.gymId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const resData = await res.json();

      if (resData.success) {
        // Update local storage session gymName if changed
        localStorage.setItem('gym_session', JSON.stringify({
          ...session,
          gymName
        }));
        showToast('Profile & Gym Settings saved successfully!');
        fetchProfile();
      }
    } catch (e) {
      console.error(e);
      showToast('Error saving settings. Please retry.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <OwnerLayout>
      <div className="px-4 mt-6 space-y-6 max-w-2xl mx-auto pb-16">
        {toast && (
          <div className="fixed top-5 right-5 z-50 bg-[#34A853] text-white px-5 py-3 rounded-2xl font-bold text-xs shadow-xl animate-bounce flex items-center gap-2">
            <Check size={18} /> {toast}
          </div>
        )}

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)]">Owner Control Panel</span>
            <h1 className="text-2xl font-black uppercase tracking-wider text-[var(--text)]">Gym & Owner Profile</h1>
          </div>

          <button
            onClick={handleSaveAll}
            disabled={saving}
            className="h-11 px-6 rounded-[16px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 shadow-md active:scale-95 transition-all cursor-pointer disabled:opacity-50"
          >
            <Save size={16} /> {saving ? 'Saving Changes...' : 'Save Settings'}
          </button>
        </div>

        <PWAInstallBanner />

        {/* Tab Switcher */}
        <div className="flex gap-1.5 overflow-x-auto pb-1 no-scrollbar border-b border-[var(--border)]">
          {[
            { id: 'profile', label: 'Owner Profile', icon: User },
            { id: 'gym', label: 'Gym Details', icon: Building2 },
            { id: 'schedule', label: 'Schedule', icon: Clock },
            { id: 'payment', label: 'UPI / Payment', icon: HelpCircle },
            { id: 'support', label: 'Support', icon: HelpCircle },
          ].map(tab => {
            const IconComponent = tab.icon;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-4 py-2.5 rounded-t-xl text-xs font-bold uppercase tracking-wider whitespace-nowrap flex items-center gap-2 transition-all cursor-pointer ${
                  active 
                    ? 'bg-[var(--surface)] text-[var(--text)] border-t-2 border-[var(--text)] neo-raised font-black' 
                    : 'text-[var(--text-sec)] hover:text-[var(--text)]'
                }`}
              >
                <IconComponent size={14} /> {tab.label}
              </button>
            );
          })}
        </div>

        {loading ? (
          <div className="py-20 text-center text-4xl animate-pulse">🏋️ Loading Profile...</div>
        ) : (
          <div className="space-y-6">
            {/* TAB 1: OWNER PROFILE */}
            {activeTab === 'profile' && (
              <div className="clay-raised p-6 rounded-[28px] space-y-6">
                <h3 className="text-sm font-black uppercase tracking-wider text-[var(--text)] flex items-center gap-2">
                  <User size={18} /> Owner Personal Profile
                </h3>

                {/* Photo Upload */}
                <div className="flex flex-col sm:flex-row items-center gap-6 p-4 neo-pressed rounded-[20px]">
                  <div className="relative">
                    {ownerPhoto ? (
                      <img src={ownerPhoto} alt="Owner" className="w-24 h-24 rounded-full object-cover border-2 border-[var(--text)]" />
                    ) : (
                      <div className="w-24 h-24 rounded-full bg-[var(--surface)] border-2 border-dashed border-[var(--border)] flex items-center justify-center font-black text-3xl uppercase text-[var(--text-sec)]">
                        {ownerName?.charAt(0) || 'O'}
                      </div>
                    )}
                  </div>

                  <div className="space-y-2 text-center sm:text-left">
                    <p className="text-xs font-bold uppercase tracking-wider text-[var(--text)]">Owner Photo</p>
                    <p className="text-[10px] text-[var(--text-sec)]">JPEG, PNG or WEBP (Max 5MB)</p>
                    <div className="flex flex-wrap gap-2 justify-center sm:justify-start">
                      <label className="px-3 py-1.5 rounded-xl neo-raised text-[11px] font-bold uppercase tracking-wider flex items-center gap-1.5 cursor-pointer hover:bg-[var(--surface-sec)]">
                        <Upload size={14} /> Upload / Change
                        <input type="file" accept="image/*" className="hidden" onChange={(e) => e.target.files?.[0] && handleImageUpload(e.target.files[0], 'owner')} />
                      </label>
                      {ownerPhoto && (
                        <button
                          type="button"
                          onClick={() => setOwnerPhoto('')}
                          className="px-3 py-1.5 rounded-xl neo-raised text-[#D64545] text-[11px] font-bold uppercase tracking-wider flex items-center gap-1 cursor-pointer"
                        >
                          <Trash2 size={14} /> Remove
                        </button>
                      )}
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">Owner Full Name *</label>
                    <input
                      type="text"
                      value={ownerName}
                      onChange={(e) => setOwnerName(e.target.value)}
                      placeholder="e.g. Vikram Singh"
                      className="w-full h-12 px-4 neo-pressed rounded-[14px] outline-none text-sm font-bold text-[var(--text)]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">Mobile Number (+91) *</label>
                    <input
                      type="text"
                      value={ownerPhone}
                      onChange={(e) => setOwnerPhone(e.target.value)}
                      placeholder="e.g. 9876543210"
                      className="w-full h-12 px-4 neo-pressed rounded-[14px] outline-none text-sm font-mono font-bold text-[var(--text)]"
                    />
                  </div>

                  <div className="p-3 neo-pressed rounded-[14px] flex justify-between items-center text-xs">
                    <span className="text-[var(--text-sec)] font-bold uppercase">Owner Access Code</span>
                    <span className="font-mono font-black text-[var(--text)] tracking-widest text-sm bg-[var(--surface)] px-3 py-1 rounded-lg border border-[var(--border)]">
                      {accessCode}
                    </span>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 2: GYM DETAILS */}
            {activeTab === 'gym' && (
              <div className="clay-raised p-6 rounded-[28px] space-y-6">
                <h3 className="text-sm font-black uppercase tracking-wider text-[var(--text)] flex items-center gap-2">
                  <Building2 size={18} /> Gym Brand & Location
                </h3>

                {/* Gym Logo Upload */}
                <div className="flex flex-col sm:flex-row items-center gap-6 p-4 neo-pressed rounded-[20px]">
                  <div className="relative">
                    {gymLogo ? (
                      <img src={gymLogo} alt="Gym Logo" className="w-24 h-24 rounded-2xl object-cover border-2 border-[var(--text)]" />
                    ) : (
                      <div className="w-24 h-24 rounded-2xl bg-[var(--surface)] border-2 border-dashed border-[var(--border)] flex items-center justify-center font-black text-3xl uppercase text-[var(--text-sec)]">
                        {gymName?.charAt(0) || 'G'}
                      </div>
                    )}
                  </div>

                  <div className="space-y-2 text-center sm:text-left">
                    <p className="text-xs font-bold uppercase tracking-wider text-[var(--text)]">Gym Brand Logo</p>
                    <p className="text-[10px] text-[var(--text-sec)] font-medium">Appears on Member ID Cards & Receipts</p>
                    <div className="flex flex-wrap gap-2 justify-center sm:justify-start">
                      <label className="px-3 py-1.5 rounded-xl neo-raised text-[11px] font-bold uppercase tracking-wider flex items-center gap-1.5 cursor-pointer hover:bg-[var(--surface-sec)]">
                        <Upload size={14} /> Upload Logo
                        <input type="file" accept="image/*" className="hidden" onChange={(e) => e.target.files?.[0] && handleImageUpload(e.target.files[0], 'logo')} />
                      </label>
                      {gymLogo && (
                        <button
                          type="button"
                          onClick={() => setGymLogo('')}
                          className="px-3 py-1.5 rounded-xl neo-raised text-[#D64545] text-[11px] font-bold uppercase tracking-wider flex items-center gap-1 cursor-pointer"
                        >
                          <Trash2 size={14} /> Remove
                        </button>
                      )}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">Gym Name *</label>
                    <input
                      type="text"
                      value={gymName}
                      onChange={(e) => setGymName(e.target.value)}
                      placeholder="e.g. Apex Fitness Club"
                      className="w-full h-12 px-4 neo-pressed rounded-[14px] outline-none text-sm font-bold text-[var(--text)]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">Gym Helpline Phone</label>
                    <input
                      type="text"
                      value={gymPhone}
                      onChange={(e) => setGymPhone(e.target.value)}
                      placeholder="e.g. 9876543210"
                      className="w-full h-12 px-4 neo-pressed rounded-[14px] outline-none text-sm font-mono font-bold text-[var(--text)]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">Gym Official Email</label>
                    <input
                      type="email"
                      value={gymEmail}
                      onChange={(e) => setGymEmail(e.target.value)}
                      placeholder="e.g. info@apexfitness.com"
                      className="w-full h-12 px-4 neo-pressed rounded-[14px] outline-none text-sm font-bold text-[var(--text)]"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-xs font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">Address *</label>
                    <input
                      type="text"
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      placeholder="e.g. Plot 42, Main Road, Kankarbagh"
                      className="w-full h-12 px-4 neo-pressed rounded-[14px] outline-none text-sm font-bold text-[var(--text)]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">City *</label>
                    <input
                      type="text"
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      placeholder="e.g. Patna"
                      className="w-full h-12 px-4 neo-pressed rounded-[14px] outline-none text-sm font-bold text-[var(--text)]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">Gym Type</label>
                    <select
                      value={gymType}
                      onChange={(e) => setGymType(e.target.value)}
                      className="w-full h-12 px-4 neo-pressed rounded-[14px] outline-none text-sm font-bold text-[var(--text)] bg-transparent"
                    >
                      <option value="Unisex">Unisex (Men & Women)</option>
                      <option value="Men Only">Men Only</option>
                      <option value="Women Only">Women Only</option>
                      <option value="Crossfit Studio">Crossfit Studio</option>
                    </select>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 3: SCHEDULE (MULTI-SESSION PER DAY) */}
            {activeTab === 'schedule' && (
              <div className="clay-raised p-6 rounded-[28px] space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[var(--border)] pb-4">
                  <div>
                    <h3 className="text-sm font-black uppercase tracking-wider text-[var(--text)] flex items-center gap-2">
                      <Clock size={18} /> Gym Operating Hours (Multi-Session Schedule)
                    </h3>
                    <p className="text-[11px] text-[var(--text-sec)] mt-0.5">Define opening & closing sessions per weekday</p>
                  </div>
                  <button
                    type="button"
                    onClick={applyMondayToWeekdays}
                    className="px-3 py-2 rounded-xl neo-raised text-[11px] font-bold uppercase tracking-wider text-[#4285F4] flex items-center gap-1.5 active:scale-95 transition-transform cursor-pointer"
                  >
                    Copy Monday Schedule to Tue–Fri
                  </button>
                </div>

                <div className="space-y-4">
                  {schedule.map((daySched, dayIdx) => (
                    <div key={daySched.day} className="p-4 neo-pressed rounded-[20px] space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <span className="font-black text-sm uppercase text-[var(--text)]">{daySched.day}</span>
                          <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider ${
                            daySched.isOpen ? 'bg-[#34A853]/20 text-[#34A853]' : 'bg-[#D64545]/20 text-[#D64545]'
                          }`}>
                            {daySched.isOpen ? 'OPEN' : 'CLOSED / OFF'}
                          </span>
                        </div>

                        <button
                          type="button"
                          onClick={() => toggleDayOpen(dayIdx)}
                          className={`px-3 py-1 rounded-xl text-xs font-bold uppercase tracking-wider border cursor-pointer ${
                            daySched.isOpen 
                              ? 'border-[#D64545] text-[#D64545] hover:bg-[#D64545]/10' 
                              : 'border-[#34A853] text-[#34A853] hover:bg-[#34A853]/10'
                          }`}
                        >
                          {daySched.isOpen ? 'Set Closed' : 'Set Open'}
                        </button>
                      </div>

                      {daySched.isOpen && (
                        <div className="space-y-2 pt-2 border-t border-[var(--border)]">
                          {daySched.sessions.map((sess, sessIdx) => (
                            <div key={sessIdx} className="flex flex-wrap items-center gap-2 text-xs">
                              <span className="text-[10px] font-bold text-[var(--text-sec)] w-16 uppercase">Session {sessIdx + 1}:</span>
                              <div className="flex items-center gap-1.5">
                                <span className="text-[10px] text-[var(--text-sec)] uppercase font-bold">Open</span>
                                <input
                                  type="time"
                                  value={sess.open}
                                  onChange={(e) => updateSessionTime(dayIdx, sessIdx, 'open', e.target.value)}
                                  className="h-9 px-2 neo-raised rounded-lg outline-none font-mono text-xs text-[var(--text)]"
                                />
                              </div>
                              <span className="text-[var(--text-sec)] font-bold">—</span>
                              <div className="flex items-center gap-1.5">
                                <span className="text-[10px] text-[var(--text-sec)] uppercase font-bold">Close</span>
                                <input
                                  type="time"
                                  value={sess.close}
                                  onChange={(e) => updateSessionTime(dayIdx, sessIdx, 'close', e.target.value)}
                                  className="h-9 px-2 neo-raised rounded-lg outline-none font-mono text-xs text-[var(--text)]"
                                />
                              </div>
                              {daySched.sessions.length > 1 && (
                                <button
                                  type="button"
                                  onClick={() => removeSession(dayIdx, sessIdx)}
                                  className="p-2 text-[#D64545] hover:opacity-80 cursor-pointer ml-auto"
                                  title="Delete Session"
                                >
                                  <Trash size={14} />
                                </button>
                              )}
                            </div>
                          ))}

                          <button
                            type="button"
                            onClick={() => addSession(dayIdx)}
                            className="mt-2 text-[11px] font-bold uppercase tracking-wider text-[#4285F4] flex items-center gap-1 hover:underline cursor-pointer"
                          >
                            <Plus size={14} /> Add Session (e.g. Evening Batch)
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 4: PAYMENT / UPI SETUP */}
            {activeTab === 'payment' && (
              <div className="clay-raised p-6 rounded-[28px] space-y-6">
                <h3 className="text-sm font-black uppercase tracking-wider text-[var(--text)] flex items-center gap-2">
                  <ShieldCheck size={18} /> UPI Payment Setup & Direct QR Code
                </h3>

                {/* Explanatory Banner Note */}
                <div className="p-4 rounded-2xl bg-[#FBBC05]/15 border-2 border-[#FBBC05] space-y-1.5 text-xs text-[var(--text)]">
                  <p className="font-black uppercase tracking-wider text-[#FBBC05] flex items-center gap-1.5">
                    <AlertCircle size={16} /> Important Online Payment Verification Rule
                  </p>
                  <p className="font-medium text-[11px] leading-relaxed">
                    Online payment se member aapke configured UPI/payment method par redirect hoga. UPI app open hona payment complete hone ka proof nahi hai. Payment PAID tabhi maana jayega jab owner manually confirm kare ya connected payment gateway se real confirmation aaye.
                  </p>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 neo-pressed rounded-[16px]">
                    <div>
                      <p className="text-xs font-bold uppercase tracking-wider text-[var(--text)]">Enable Online UPI Payments</p>
                      <p className="text-[10px] text-[var(--text-sec)] font-medium">Allows members to view QR and pay via PhonePe / GPay / Paytm</p>
                    </div>
                    <input
                      type="checkbox"
                      checked={onlinePaymentEnabled}
                      onChange={(e) => setOnlinePaymentEnabled(e.target.checked)}
                      className="w-5 h-5 accent-[var(--text)] cursor-pointer"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">Gym UPI ID (VPA) *</label>
                    <input
                      type="text"
                      value={upiId}
                      onChange={(e) => setUpiId(e.target.value)}
                      placeholder="e.g. apexfitness@upi or 9876543210@ybl"
                      className="w-full h-12 px-4 neo-pressed rounded-[14px] outline-none text-sm font-mono font-bold text-[var(--text)]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">UPI Receiver Display Name</label>
                    <input
                      type="text"
                      value={upiDisplayName}
                      onChange={(e) => setUpiDisplayName(e.target.value)}
                      placeholder="e.g. Apex Fitness Club"
                      className="w-full h-12 px-4 neo-pressed rounded-[14px] outline-none text-sm font-bold text-[var(--text)]"
                    />
                  </div>

                  {/* QR Code Upload */}
                  <div className="p-4 neo-pressed rounded-[20px] space-y-3">
                    <p className="text-xs font-bold uppercase tracking-wider text-[var(--text)]">Gym UPI Standee QR Image (Optional)</p>
                    <div className="flex flex-col sm:flex-row items-center gap-4">
                      {upiQrImage ? (
                        <img src={upiQrImage} alt="UPI QR" className="w-28 h-28 object-contain rounded-xl border border-[var(--border)] bg-white p-1" />
                      ) : (
                        <div className="w-28 h-28 rounded-xl bg-[var(--surface)] border-2 border-dashed border-[var(--border)] flex items-center justify-center text-xs font-bold text-[var(--text-sec)] uppercase text-center p-2">
                          No QR Image Uploaded
                        </div>
                      )}

                      <div className="space-y-2">
                        <label className="px-3 py-2 rounded-xl neo-raised text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 cursor-pointer">
                          <Upload size={14} /> Upload QR Standee Image
                          <input type="file" accept="image/*" className="hidden" onChange={(e) => e.target.files?.[0] && handleImageUpload(e.target.files[0], 'qr')} />
                        </label>
                        {upiQrImage && (
                          <button
                            type="button"
                            onClick={() => setUpiQrImage('')}
                            className="px-3 py-1.5 rounded-xl neo-raised text-[#D64545] text-xs font-bold uppercase tracking-wider flex items-center gap-1 cursor-pointer"
                          >
                            <Trash2 size={14} /> Remove QR
                          </button>
                        )}
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">Payment Instructions for Members</label>
                    <textarea
                      rows={3}
                      value={paymentInstructions}
                      onChange={(e) => setPaymentInstructions(e.target.value)}
                      placeholder="e.g. Please share UTR / Transaction reference number at gym reception or upload screenshot after paying."
                      className="w-full p-3 neo-pressed rounded-[14px] outline-none text-xs font-medium text-[var(--text)]"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* TAB 5: SUPPORT & LOGOUT */}
            {activeTab === 'support' && (
              <div className="space-y-4">
                <div className="neo-raised p-6 rounded-[28px] space-y-4">
                  <h3 className="text-sm font-black uppercase tracking-wider text-[var(--text)] flex items-center gap-2">
                    <HelpCircle size={18} strokeWidth={2.5} /> Support & Technical Helpline
                  </h3>
                  <p className="text-xs text-[var(--text-sec)] leading-relaxed font-medium">
                    Have questions regarding your subscription, WhatsApp broadcast integration, or custom feature requests? Our technical team is available 24/7 on WhatsApp.
                  </p>

                  <a
                    href="https://wa.me/919263604732?text=Hello%20Support%2C%20I%20am%20a%20Gym%20Owner%20needing%20assistance."
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full h-12 rounded-[16px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 cursor-pointer shadow-md"
                  >
                    CONNECT ON WHATSAPP (+91 9263604732)
                  </a>
                </div>

                <button
                  type="button"
                  onClick={() => void signOutEverything()}
                  className="w-full h-14 rounded-[20px] neo-raised text-[#D64545] text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 active:scale-95 transition-transform cursor-pointer"
                >
                  <LogOut size={18} /> LOGOUT OF OWNER WORKSPACE
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </OwnerLayout>
  );
}
