import React, { useState, useEffect } from 'react';
import { useNavigate } from '@/lib/router-compat';
import { CheckCircle2, Clock, AlertTriangle, ArrowRight, Filter, RefreshCw, Check, AlertCircle } from 'lucide-react';
import OwnerLayout from '../../components/OwnerLayout';

export default function OwnerWorkload() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [tasks, setTasks] = useState<any[]>([]);
  const [filter, setFilter] = useState<'ALL' | 'TODO' | 'COMPLETED'>('TODO');
  const [toast, setToast] = useState<string | null>(null);

  const showToastMsg = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  };

  const fetchTasks = async () => {
    const sessionStr = localStorage.getItem('gym_session');
    if (!sessionStr) { navigate('/'); return; }
    const session = JSON.parse(sessionStr);

    try {
      const res = await fetch(`/api/owner-daily-tasks/${session.gymId}`);
      const data = await res.json();
      if (data.success) {
        setTasks(data.tasks || []);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTasks();
  }, []);

  const handleCompleteTask = async (taskId: string) => {
    const sessionStr = localStorage.getItem('gym_session');
    if (!sessionStr) return;
    const session = JSON.parse(sessionStr);

    try {
      const res = await fetch(`/api/owner-daily-tasks/${session.gymId}/${taskId}/complete`, {
        method: 'POST'
      });
      const data = await res.json();
      if (data.success) {
        showToastMsg('Task completed!');
        setTasks(tasks.map(t => t.id === taskId ? { ...t, status: 'COMPLETED' } : t));
      }
    } catch (err) {
      console.error(err);
    }
  };

  const filteredTasks = tasks.filter(t => {
    if (filter === 'TODO') return t.status === 'TODO';
    if (filter === 'COMPLETED') return t.status === 'COMPLETED';
    return true;
  });

  const todoCount = tasks.filter(t => t.status === 'TODO').length;
  const completedCount = tasks.filter(t => t.status === 'COMPLETED').length;

  if (loading) {
    return (
      <OwnerLayout>
        <div className="py-20 text-center text-3xl animate-pulse">⚡ Loading Daily Workload...</div>
      </OwnerLayout>
    );
  }

  return (
    <OwnerLayout>
      <div className="px-4 mt-6 space-y-6 pb-12">
        {toast && (
          <div className="fixed top-5 right-5 z-50 bg-[#34A853] text-white px-4 py-3 rounded-2xl font-bold text-xs shadow-lg animate-bounce">
            ✓ {toast}
          </div>
        )}

        <div className="flex justify-between items-center">
          <div>
            <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)]">Urgent Attention & Operations</span>
            <h1 className="text-2xl font-black uppercase tracking-wider text-[var(--text)]">Daily Workload</h1>
          </div>

          <button
            onClick={fetchTasks}
            className="p-2.5 rounded-[16px] neo-raised text-[var(--text)] hover:scale-105 active:scale-95 transition-all cursor-pointer"
          >
            <RefreshCw size={18} />
          </button>
        </div>

        {/* Stats Summary Row */}
        <div className="grid grid-cols-2 gap-3">
          <div className="p-4 rounded-[22px] neo-raised flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#EA4335]/10 text-[#EA4335] flex items-center justify-center font-black">
              <AlertTriangle size={20} />
            </div>
            <div>
              <span className="text-xl font-black text-[var(--text)]">{todoCount}</span>
              <span className="text-[10px] font-bold uppercase text-[var(--text-sec)] block">Pending Action Tasks</span>
            </div>
          </div>

          <div className="p-4 rounded-[22px] neo-raised flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#34A853]/10 text-[#34A853] flex items-center justify-center font-black">
              <CheckCircle2 size={20} />
            </div>
            <div>
              <span className="text-xl font-black text-[var(--text)]">{completedCount}</span>
              <span className="text-[10px] font-bold uppercase text-[var(--text-sec)] block">Completed Today</span>
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="flex gap-2 border-b border-[var(--border)] pb-2">
          <button
            onClick={() => setFilter('TODO')}
            className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider cursor-pointer transition-all ${
              filter === 'TODO' ? 'bg-[var(--btn-bg)] text-[var(--btn-text)] shadow-sm' : 'neo-pressed text-[var(--text-sec)]'
            }`}
          >
            Pending ({todoCount})
          </button>

          <button
            onClick={() => setFilter('COMPLETED')}
            className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider cursor-pointer transition-all ${
              filter === 'COMPLETED' ? 'bg-[var(--btn-bg)] text-[var(--btn-text)] shadow-sm' : 'neo-pressed text-[var(--text-sec)]'
            }`}
          >
            Completed ({completedCount})
          </button>

          <button
            onClick={() => setFilter('ALL')}
            className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider cursor-pointer transition-all ${
              filter === 'ALL' ? 'bg-[var(--btn-bg)] text-[var(--btn-text)] shadow-sm' : 'neo-pressed text-[var(--text-sec)]'
            }`}
          >
            All ({tasks.length})
          </button>
        </div>

        {/* Task List */}
        <div className="space-y-3">
          {filteredTasks.map(task => {
            const isTodo = task.status === 'TODO';
            const priorityColors: Record<string, string> = {
              URGENT: 'bg-[#EA4335] text-white',
              HIGH: 'bg-[#E37400] text-white',
              NORMAL: 'bg-[var(--btn-bg)] text-[var(--btn-text)]',
              LOW: 'bg-[var(--text-sec)] text-white'
            };

            return (
              <div 
                key={task.id}
                className={`p-5 rounded-[24px] space-y-3 transition-all ${
                  isTodo ? 'neo-raised' : 'neo-pressed opacity-65'
                }`}
              >
                <div className="flex justify-between items-start gap-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className={`text-[8px] font-black uppercase tracking-widest px-2 py-0.5 rounded-full ${priorityColors[task.priority] || priorityColors.NORMAL}`}>
                        {task.priority}
                      </span>
                      <span className="text-[9px] font-mono text-[var(--text-sec)]">{task.taskType}</span>
                    </div>

                    <h4 className={`text-sm font-black uppercase tracking-wider ${isTodo ? 'text-[var(--text)]' : 'text-[var(--text-sec)] line-through'}`}>
                      {task.title}
                    </h4>
                    <p className="text-[11px] text-[var(--text-sec)] font-medium">
                      {task.description}
                    </p>
                  </div>

                  {isTodo && (
                    <button
                      onClick={() => handleCompleteTask(task.id)}
                      className="w-9 h-9 rounded-full neo-raised hover:scale-110 active:scale-95 text-[#34A853] flex items-center justify-center cursor-pointer transition-all"
                      title="Mark Done"
                    >
                      <Check size={18} />
                    </button>
                  )}
                </div>

                {isTodo && task.actionRoute && (
                  <button
                    onClick={() => navigate(task.actionRoute)}
                    className="px-4 py-2 rounded-xl bg-[var(--btn-bg)] text-[var(--btn-text)] text-[11px] font-black uppercase tracking-wider flex items-center gap-2 cursor-pointer shadow-sm active:scale-95 transition-transform"
                  >
                    {task.actionText || 'Take Action'} <ArrowRight size={14} />
                  </button>
                )}
              </div>
            );
          })}

          {filteredTasks.length === 0 && (
            <div className="neo-pressed p-10 rounded-[28px] text-center space-y-2">
              <CheckCircle2 size={32} className="mx-auto text-[#34A853]" />
              <h4 className="text-xs font-black uppercase text-[var(--text)]">No tasks in this view</h4>
              <p className="text-[11px] text-[var(--text-sec)] font-medium">Great job! All operational tasks are currently clear.</p>
            </div>
          )}
        </div>
      </div>
    </OwnerLayout>
  );
}
