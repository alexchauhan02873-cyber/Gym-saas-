import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from '@/lib/router-compat';
import { Search, Plus, Filter, AlertCircle, Phone, ArrowRight, ShieldCheck, Download, Calendar, X, ArrowUpDown } from 'lucide-react';
import OwnerLayout from '../../components/OwnerLayout';
import { exportMembersToCSV } from '@/lib/csv-exporter';

export default function MembersList() {
  const navigate = useNavigate();
  const [members, setMembers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'ACTIVE' | 'DUE' | 'EXPIRED' | 'FROZEN' | 'BLOCKED' | 'ARCHIVED'>('ALL');
  const [dateFilter, setDateFilter] = useState<'ALL_TIME' | 'TODAY' | 'THIS_WEEK' | 'THIS_MONTH' | 'LAST_30_DAYS'>('ALL_TIME');
  const [sortBy, setSortBy] = useState<'NEWEST' | 'OLDEST' | 'NAME' | 'EXPIRY'>('NEWEST');
  const [gymName, setGymName] = useState('Gym');

  useEffect(() => {
    const sessionStr = localStorage.getItem('gym_session');
    if (!sessionStr) {
      navigate('/');
      return;
    }
    const session = JSON.parse(sessionStr);
    setGymName(session.gymName || 'Gym');

    fetch(`/api/members/${session.gymId}`)
      .then(res => res.json())
      .then(data => {
        if (data && data.members) {
          setMembers(data.members);
        }
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [navigate]);

  const now = new Date();
  const todayStr = now.toISOString().split('T')[0];

  const filteredMembers = members.filter(m => {
    // 1. Search filter
    const searchLower = search.toLowerCase().trim();
    const matchesSearch = !searchLower || (
      m.fullName?.toLowerCase().includes(searchLower) ||
      m.phone?.includes(searchLower) ||
      m.memberCode?.toLowerCase().includes(searchLower) ||
      m.memberDisplayId?.toLowerCase().includes(searchLower) ||
      m.location?.toLowerCase().includes(searchLower)
    );

    if (!matchesSearch) return false;

    // 2. Status filter
    const statusUpper = (m.status || 'ACTIVE').toUpperCase();
    if (statusFilter === 'ALL') {
      if (statusUpper === 'ARCHIVED') return false;
    } else if (statusFilter === 'ACTIVE') {
      if (statusUpper !== 'ACTIVE') return false;
      if (m.due || m.paymentStatus === 'DUE') return false;
    } else if (statusFilter === 'DUE') {
      if (!m.due && m.paymentStatus !== 'DUE') return false;
    } else if (statusFilter === 'EXPIRED') {
      if (statusUpper !== 'EXPIRED') return false;
    } else if (statusFilter === 'FROZEN') {
      if (statusUpper !== 'FROZEN') return false;
    } else if (statusFilter === 'BLOCKED') {
      if (statusUpper !== 'BLOCKED') return false;
    } else if (statusFilter === 'ARCHIVED') {
      if (statusUpper !== 'ARCHIVED') return false;
    }

    // 3. Signup date filter
    const joinedStr = m.joinedDate || m.createdAt?.split('T')[0];
    if (joinedStr) {
      const joinedD = new Date(joinedStr);
      if (dateFilter === 'TODAY') {
        if (joinedStr !== todayStr) return false;
      } else if (dateFilter === 'THIS_WEEK') {
        const sevenDaysAgo = new Date();
        sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
        if (joinedD < sevenDaysAgo) return false;
      } else if (dateFilter === 'THIS_MONTH') {
        if (joinedD.getMonth() !== now.getMonth() || joinedD.getFullYear() !== now.getFullYear()) return false;
      } else if (dateFilter === 'LAST_30_DAYS') {
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
        if (joinedD < thirtyDaysAgo) return false;
      }
    }

    return true;
  }).sort((a, b) => {
    if (sortBy === 'NEWEST') {
      const dA = new Date(a.joinedDate || a.createdAt || 0).getTime();
      const dB = new Date(b.joinedDate || b.createdAt || 0).getTime();
      return dB - dA;
    } else if (sortBy === 'OLDEST') {
      const dA = new Date(a.joinedDate || a.createdAt || 0).getTime();
      const dB = new Date(b.joinedDate || b.createdAt || 0).getTime();
      return dA - dB;
    } else if (sortBy === 'NAME') {
      return (a.fullName || '').localeCompare(b.fullName || '');
    } else if (sortBy === 'EXPIRY') {
      const eA = a.membershipExpiry || a.endDate || '9999-99-99';
      const eB = b.membershipExpiry || b.endDate || '9999-99-99';
      return eA.localeCompare(eB);
    }
    return 0;
  });

  const clearFilters = () => {
    setSearch('');
    setStatusFilter('ALL');
    setDateFilter('ALL_TIME');
    setSortBy('NEWEST');
  };

  const isFiltered = search || statusFilter !== 'ALL' || dateFilter !== 'ALL_TIME';

  return (
    <OwnerLayout>
      <div className="px-4 mt-6 space-y-6 pb-10">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)]">Directory</span>
            <h1 className="text-2xl font-black uppercase tracking-wider text-[var(--text)]">Gym Members ({filteredMembers.length} / {members.length})</h1>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => exportMembersToCSV(filteredMembers, gymName)}
              className="h-11 px-4 rounded-[16px] neo-raised text-[var(--text)] text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 active:scale-95 transition-transform shrink-0 cursor-pointer"
            >
              <Download size={16} className="text-[#34A853]" /> Export CSV
            </button>
            <Link
              to="/owner/members/add"
              className="h-11 px-5 rounded-[16px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 active:scale-95 transition-transform shrink-0 shadow-sm cursor-pointer"
            >
              <Plus size={16} /> ADD MEMBER
            </Link>
          </div>
        </div>

        {/* Search & Comprehensive Filter Controls */}
        <div className="clay-raised p-5 rounded-[24px] space-y-4">
          {/* Search bar */}
          <div className="relative">
            <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-[var(--text-sec)]" />
            <input
              type="text"
              placeholder="Search member by name, phone, member ID (e.g. MEM-0001)..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full h-12 pl-11 pr-10 neo-pressed rounded-[16px] text-xs font-bold text-[var(--text)] outline-none focus:ring-1 focus:ring-[var(--text)]"
            />
            {search && (
              <button
                onClick={() => setSearch('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-[var(--text-sec)] hover:text-[var(--text)] cursor-pointer"
              >
                <X size={16} />
              </button>
            )}
          </div>

          {/* Filter Rows: Membership Status & Signup Date & Sorting */}
          <div className="space-y-3 pt-1">
            {/* Status Filter Pills */}
            <div className="space-y-1">
              <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">
                Membership Status Filter
              </span>
              <div className="flex gap-2 overflow-x-auto pb-1 hide-scrollbar">
                {[
                  { id: 'ALL', label: 'ALL MEMBERS' },
                  { id: 'ACTIVE', label: 'ACTIVE' },
                  { id: 'DUE', label: 'DUE PENDING' },
                  { id: 'EXPIRED', label: 'EXPIRED' },
                  { id: 'FROZEN', label: 'FROZEN' },
                  { id: 'BLOCKED', label: 'BLOCKED' },
                  { id: 'ARCHIVED', label: 'ARCHIVED' }
                ].map((f) => (
                  <button
                    key={f.id}
                    onClick={() => setStatusFilter(f.id as any)}
                    className={`px-3.5 py-1.5 rounded-[12px] text-[10px] font-black uppercase tracking-wider shrink-0 transition-all cursor-pointer ${
                      statusFilter === f.id
                        ? 'bg-[var(--btn-bg)] text-[var(--btn-text)] shadow-sm'
                        : 'neo-pressed text-[var(--text-sec)] hover:text-[var(--text)]'
                    }`}
                  >
                    {f.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Signup Date Filter & Sorting */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-[var(--border)]">
              <div>
                <label className="block text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] mb-1">
                  Signup Date Filter
                </label>
                <select
                  value={dateFilter}
                  onChange={(e) => setDateFilter(e.target.value as any)}
                  className="w-full h-10 px-3 neo-pressed rounded-[12px] text-xs font-bold text-[var(--text)] bg-[var(--surface)] outline-none cursor-pointer"
                >
                  <option value="ALL_TIME">All Time Signup Dates</option>
                  <option value="TODAY">Signed Up Today</option>
                  <option value="THIS_WEEK">Signed Up This Week (7 Days)</option>
                  <option value="THIS_MONTH">Signed Up This Month</option>
                  <option value="LAST_30_DAYS">Signed Up Last 30 Days</option>
                </select>
              </div>

              <div>
                <label className="block text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] mb-1">
                  Sort Members By
                </label>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="w-full h-10 px-3 neo-pressed rounded-[12px] text-xs font-bold text-[var(--text)] bg-[var(--surface)] outline-none cursor-pointer"
                >
                  <option value="NEWEST">Signup Date (Newest First)</option>
                  <option value="OLDEST">Signup Date (Oldest First)</option>
                  <option value="NAME">Member Name (A-Z)</option>
                  <option value="EXPIRY">Plan Expiry Date</option>
                </select>
              </div>
            </div>

            {isFiltered && (
              <div className="flex justify-between items-center pt-2">
                <span className="text-[10px] font-mono text-[var(--text-sec)]">
                  Filtered Results: {filteredMembers.length} member(s) found
                </span>
                <button
                  onClick={clearFilters}
                  className="text-[10px] font-black uppercase text-[#D64545] underline cursor-pointer"
                >
                  Reset All Filters
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Members List Cards */}
        {loading ? (
          <div className="py-20 text-center text-4xl animate-pulse">🏋️ Loading Directory...</div>
        ) : filteredMembers.length > 0 ? (
          <div className="space-y-3">
            {filteredMembers.map((m) => {
              const displayCode = m.memberDisplayId || m.memberCode || `MEM-${m.id?.slice(-4)}`;
              const statusStr = (m.status || 'Active').toUpperCase();
              const isDue = m.due || m.paymentStatus === 'DUE';

              return (
                <div
                  key={m.id}
                  onClick={() => navigate(`/owner/members/${m.id}`)}
                  className="neo-raised p-4 rounded-[20px] flex items-center justify-between gap-4 cursor-pointer hover:scale-[1.01] transition-all"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    {m.profileImage ? (
                      <img src={m.profileImage} alt={m.fullName} className="w-12 h-12 rounded-full object-cover neo-pressed shrink-0" />
                    ) : (
                      <div className="w-12 h-12 rounded-full neo-pressed flex items-center justify-center font-black text-sm uppercase shrink-0 text-[var(--text)]">
                        {m.fullName?.charAt(0) || 'M'}
                      </div>
                    )}
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <h3 className="text-xs font-black uppercase tracking-wider text-[var(--text)] truncate">{m.fullName}</h3>
                        <span className="text-[9px] font-mono px-2 py-0.5 rounded bg-[var(--surface-sec)] text-[var(--text-sec)] shrink-0 font-bold">
                          {displayCode}
                        </span>
                      </div>
                      <p className="text-[10px] text-[var(--text-sec)] font-mono mt-0.5">
                        {m.phone} • {m.planName || 'Monthly Plan'}
                      </p>
                      {m.joinedDate && (
                        <p className="text-[9px] text-[var(--text-sec)] font-mono mt-0.5">
                          Joined: {m.joinedDate}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-3 shrink-0">
                    <div className="text-right hidden sm:block">
                      <span className={`text-[9px] font-black uppercase px-2.5 py-0.5 rounded-full ${
                        statusStr === 'FROZEN'
                          ? 'bg-amber-500/20 text-amber-500'
                          : statusStr === 'BLOCKED'
                          ? 'bg-[#D64545]/20 text-[#D64545]'
                          : statusStr === 'ARCHIVED'
                          ? 'bg-neutral-500/20 text-neutral-400'
                          : isDue
                          ? 'bg-[#E3A008]/20 text-[#E3A008]'
                          : 'bg-[#34A853]/20 text-[#34A853]'
                      }`}>
                        {statusStr === 'ACTIVE' && isDue ? 'DUE PENDING' : statusStr}
                      </span>
                      <p className="text-[9px] font-mono text-[var(--text-sec)] mt-1">Exp: {m.membershipExpiry || m.endDate || 'N/A'}</p>
                    </div>
                    <ArrowRight size={16} className="text-[var(--text-sec)]" />
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="neo-pressed p-8 rounded-[24px] text-center space-y-2">
            <AlertCircle size={32} className="mx-auto text-[var(--text-sec)] opacity-50" />
            <p className="text-xs font-black uppercase tracking-wider text-[var(--text-sec)]">No matching members found</p>
            {isFiltered && (
              <button
                onClick={clearFilters}
                className="text-xs font-bold uppercase text-[#34A853] underline cursor-pointer mt-2"
              >
                Clear all active search and filters
              </button>
            )}
          </div>
        )}
      </div>
    </OwnerLayout>
  );
}
