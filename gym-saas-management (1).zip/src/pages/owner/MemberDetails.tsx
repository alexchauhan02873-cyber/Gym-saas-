import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from '@/lib/router-compat';
import { 
  ArrowLeft, Calendar, IndianRupee, Dumbbell, 
  ShieldCheck, RefreshCw, Key, CreditCard, Lock, Unlock, 
  Trash2, Eye, EyeOff, Copy, Phone, Share2, Sparkles, Check, AlertTriangle, Printer, X
} from 'lucide-react';
import OwnerLayout from '../../components/OwnerLayout';
import MemberAttendanceCalendar from '../../components/MemberAttendanceCalendar';
import DigitalIdCard from '../../components/DigitalIdCard';
import MemberPrintModal from '../../components/MemberPrintModal';
import AddMember from './AddMember';

export default function MemberDetails() {
  const { id } = useParams();
  const navigate = useNavigate();

  if (id === 'add' || id === 'new') {
    return <AddMember />;
  }
  const [member, setMember] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  
  // Modals
  const [renewModalOpen, setRenewModalOpen] = useState(false);
  const [paymentModalOpen, setPaymentModalOpen] = useState(false);
  const [idCardOpen, setIdCardOpen] = useState(false);
  const [printModalOpen, setPrintModalOpen] = useState(false);
  const [statusModalOpen, setStatusModalOpen] = useState(false);
  
  // Status Modal Inputs
  const [statusAction, setStatusAction] = useState<'FREEZE' | 'UNFREEZE' | 'BLOCK' | 'UNBLOCK' | 'ARCHIVE' | 'RESTORE'>('FREEZE');
  const [statusReasonCode, setStatusReasonCode] = useState('TEMPORARY_RESTRICTION');
  const [statusCustomReason, setStatusCustomReason] = useState('');
  const [statusHistory, setStatusHistory] = useState<any[]>([]);

  // Modal Inputs
  const [renewPlanId, setRenewPlanId] = useState('');
  const [renewAmount, setRenewAmount] = useState('');
  const [renewMode, setRenewMode] = useState('UPI');
  const [paymentAmount, setPaymentAmount] = useState('');
  const [paymentMode, setPaymentMode] = useState('UPI');

  const [plans, setPlans] = useState<any[]>([]);
  const [showCode, setShowCode] = useState(false);
  const [toast, setToast] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  };

  const [memberHistory, setMemberHistory] = useState<any[]>([]);

  const fetchMemberStatusHistory = () => {
    if (!id) return;
    fetch(`/api/owner/members/${id}/status-history`)
      .then(res => res.json())
      .then(data => {
        if (data && data.success) {
          setStatusHistory(data.history || []);
        }
      })
      .catch(console.error);
  };

  const fetchMemberHistory = () => {
    fetch(`/api/members/${id}/history`)
      .then(res => res.json())
      .then(data => {
        if (data && data.success) {
          setMemberHistory(data.history || []);
        }
      })
      .catch(console.error);
  };

  const fetchMember = () => {
    const sessionStr = localStorage.getItem('gym_session');
    if (!sessionStr) return;
    const session = JSON.parse(sessionStr);

    setLoading(true);
    fetch(`/api/members/${session.gymId}`)
      .then(res => res.json())
      .then(data => {
        const memberList = data?.members || (Array.isArray(data) ? data : []);
        const found = memberList.find((m: any) => m.id === id);
        if (found) {
          setMember(found);
        }
      })
      .catch(console.error)
      .finally(() => setLoading(false));

    fetchMemberHistory();
    fetchMemberStatusHistory();

    fetch(`/api/plans/${session.gymId}`)
      .then(res => res.json())
      .then(data => {
        const planList = data?.plans || (Array.isArray(data) ? data : []);
        if (planList && planList.length > 0) {
          setPlans(planList);
          setRenewPlanId(planList[0].id);
          setRenewAmount(planList[0].price?.toString() || '0');
        }
      })
      .catch(console.error);
  };

  useEffect(() => {
    fetchMember();
  }, [id]);

  const handleRenew = async () => {
    const sessionStr = localStorage.getItem('gym_session');
    if (!sessionStr || !member) return;
    const session = JSON.parse(sessionStr);

    setActionLoading(true);
    try {
      const res = await fetch('/api/members/renew', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          gymId: session.gymId,
          memberId: member.id,
          planId: renewPlanId,
          amount: parseFloat(renewAmount) || 0,
          paymentMode: renewMode
        })
      });
      const data = await res.json();
      if (data.success) {
        setRenewModalOpen(false);
        showToast('Membership renewed successfully!');
        fetchMember();
      }
    } catch (e) {
      console.error(e);
    } finally {
      setActionLoading(false);
    }
  };

  const handleCollectPayment = async () => {
    const sessionStr = localStorage.getItem('gym_session');
    if (!sessionStr || !member) return;
    const session = JSON.parse(sessionStr);

    setActionLoading(true);
    try {
      const res = await fetch(`/api/payments/${session.gymId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          memberId: member.id,
          memberName: member.fullName,
          amount: parseFloat(paymentAmount) || 0,
          paymentMode,
          status: 'PAID'
        })
      });
      const data = await res.json();
      if (data) {
        setPaymentModalOpen(false);
        showToast('Payment recorded successfully!');
        fetchMember();
      }
    } catch (e) {
      console.error(e);
    } finally {
      setActionLoading(false);
    }
  };

  const openStatusModal = (action: 'FREEZE' | 'UNFREEZE' | 'BLOCK' | 'UNBLOCK' | 'ARCHIVE' | 'RESTORE') => {
    setStatusAction(action);
    setStatusReasonCode(
      action === 'FREEZE' ? 'TEMPORARY_RESTRICTION' :
      action === 'BLOCK' ? 'CONDUCT_ISSUE' :
      action === 'ARCHIVE' ? 'MEMBERSHIP_ISSUE' : 'RESTORED'
    );
    setStatusCustomReason('');
    setStatusModalOpen(true);
  };

  const handleConfirmStatusAction = async () => {
    const sessionStr = localStorage.getItem('gym_session');
    if (!sessionStr || !member) return;
    const session = JSON.parse(sessionStr);

    setActionLoading(true);
    try {
      const res = await fetch(`/api/owner/members/${member.id}/status`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          gymId: session.gymId,
          action: statusAction,
          reasonCode: statusReasonCode,
          customReason: statusCustomReason,
          actorId: session.ownerId || session.gymId,
          actorType: 'owner',
          actorName: session.fullName || session.gymName || 'Gym Owner'
        })
      });
      const data = await res.json();
      if (data.success) {
        setMember({
          ...member,
          status: data.newStatus,
          status_reason: data.finalReason,
          statusReason: data.finalReason
        });
        setStatusModalOpen(false);
        showToast(`Member account status changed to ${data.newStatus}`);
        fetchMemberStatusHistory();
        fetchMemberHistory();
      } else {
        alert(data.message || 'Failed to update member status.');
      }
    } catch (e) {
      console.error(e);
      alert('Error updating member status.');
    } finally {
      setActionLoading(false);
    }
  };

  const handleStatusChange = async (newStatus: string) => {
    const sessionStr = localStorage.getItem('gym_session');
    if (!sessionStr || !member) return;
    const session = JSON.parse(sessionStr);

    try {
      const res = await fetch(`/api/members/${session.gymId}/${member.id}/status`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus })
      });
      const data = await res.json();
      if (data.success) {
        setMember({ ...member, status: newStatus });
        showToast(`Member status set to ${newStatus}`);
        fetchMemberStatusHistory();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleRegenerateCode = async () => {
    if (!confirm('Regenerate Member Access Code? This will IMMEDIATELY revoke the member\'s current code.')) return;
    const sessionStr = localStorage.getItem('gym_session');
    if (!sessionStr || !member) return;
    const session = JSON.parse(sessionStr);

    try {
      const res = await fetch(`/api/members/${session.gymId}/${member.id}/regenerate-code`, {
        method: 'POST'
      });
      const data = await res.json();
      if (data?.success && data?.memberAccessCode) {
        setMember({ ...member, memberAccessCode: data.memberAccessCode });
        setShowCode(true);
        showToast(`New 6-Digit Member Access Code: ${data.memberAccessCode}`);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleRevokeAccess = async () => {
    if (!confirm('Revoke access for this member? They will be blocked from logging in.')) return;
    await handleStatusChange('BLOCKED');
  };

  if (loading) {
    return (
      <OwnerLayout>
        <div className="py-20 text-center text-4xl animate-pulse">🏋️</div>
      </OwnerLayout>
    );
  }

  if (!member) {
    return (
      <OwnerLayout>
        <div className="p-8 text-center space-y-4">
          <p className="text-xs font-bold uppercase tracking-wider text-[var(--text-sec)]">Member not found</p>
          <button onClick={() => navigate('/owner/members')} className="px-4 py-2 neo-raised text-xs font-bold uppercase cursor-pointer">
            Back to Directory
          </button>
        </div>
      </OwnerLayout>
    );
  }

  const accessCode = member.memberAccessCode || member.memberCode || '483921';
  const displayId = member.memberDisplayId || `MEM-${member.id?.replace(/\D/g, '').slice(-4) || '0042'}`;
  const status = (member.status || 'ACTIVE').toUpperCase();

  return (
    <OwnerLayout>
      <div className="px-4 mt-6 space-y-6 pb-10">
        {toast && (
          <div className="fixed top-5 right-5 z-50 bg-[#34A853] text-white px-4 py-3 rounded-2xl font-bold text-xs shadow-lg animate-bounce">
            ✓ {toast}
          </div>
        )}

        {/* Top Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate('/owner/members')}
              className="w-10 h-10 rounded-full neo-raised flex items-center justify-center text-[var(--text)] active:scale-95 transition-transform cursor-pointer"
            >
              <ArrowLeft size={18} />
            </button>
            <div>
              <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)]">Member Profile</span>
              <h1 className="text-xl font-black uppercase tracking-wider text-[var(--text)]">{member.fullName}</h1>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setPrintModalOpen(true)}
              className="h-10 px-3.5 rounded-[14px] neo-raised text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 cursor-pointer active:scale-95 transition-transform"
            >
              <Printer size={16} className="text-[#4285F4]" /> Print Label / Summary
            </button>

            <button
              onClick={() => setIdCardOpen(true)}
              className="h-10 px-3.5 rounded-[14px] neo-raised text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 cursor-pointer active:scale-95 transition-transform"
            >
              <ShieldCheck size={16} className="text-[#34A853]" /> Digital ID Card
            </button>

            <button
              onClick={() => setRenewModalOpen(true)}
              className="h-10 px-4 rounded-[14px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-wider flex items-center gap-1.5 active:scale-95 transition-transform cursor-pointer shadow-sm"
            >
              <RefreshCw size={14} /> Renew Plan
            </button>
          </div>
        </div>

        {/* Member Profile Card & Access Code Box */}
        <div className="clay-raised p-6 rounded-[24px] space-y-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-[var(--border)] pb-5">
            <div className="flex items-center gap-4">
              {member.profileImage ? (
                <img src={member.profileImage} alt={member.fullName} className="w-16 h-16 rounded-full object-cover neo-pressed" />
              ) : (
                <div className="w-16 h-16 rounded-full neo-pressed flex items-center justify-center text-2xl font-black uppercase text-[var(--text)]">
                  {member.fullName?.charAt(0)}
                </div>
              )}
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-xl font-black uppercase tracking-wider">{member.fullName}</h2>
                  <span className="text-[9px] font-mono px-2 py-0.5 rounded bg-[var(--btn-bg)] text-[var(--btn-text)] font-bold">
                    {displayId}
                  </span>
                </div>
                <p className="text-xs text-[var(--text-sec)] font-mono mt-0.5">
                  {member.phone} {member.email ? `• ${member.email}` : ''}
                </p>
                <p className="text-[10px] text-[var(--text-sec)] font-medium mt-0.5">
                  {member.location ? `Locality: ${member.location} • ` : ''}{member.gender || 'Male'}, {member.age ? `${member.age} yrs` : ''}
                </p>
              </div>
            </div>

            {/* Access Code Management Box */}
            <div className="neo-pressed p-4 rounded-[20px] text-center shrink-0 space-y-2 min-w-[220px]">
              <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">
                MEMBER ACCESS CODE
              </span>
              <div className="flex items-center justify-center gap-2">
                <span className="text-2xl font-black font-mono tracking-widest text-[var(--text)]">
                  {showCode ? accessCode : '••••••'}
                </span>
                <button
                  type="button"
                  onClick={() => setShowCode(!showCode)}
                  className="p-1.5 neo-raised rounded-lg text-[var(--text-sec)] hover:text-[var(--text)] cursor-pointer"
                  title={showCode ? 'Hide Code' : 'Show Code'}
                >
                  {showCode ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>

              <div className="flex justify-center gap-1.5 pt-1">
                <button
                  type="button"
                  onClick={() => {
                    navigator.clipboard.writeText(accessCode);
                    showToast('Access Code copied to clipboard!');
                  }}
                  className="px-2 py-1 neo-raised text-[9px] font-bold uppercase rounded-lg flex items-center gap-1 cursor-pointer"
                >
                  <Copy size={12} /> Copy
                </button>
                <button
                  type="button"
                  onClick={handleRegenerateCode}
                  className="px-2 py-1 neo-raised text-[9px] font-bold uppercase text-[#34A853] rounded-lg cursor-pointer"
                >
                  Regenerate
                </button>
                <button
                  type="button"
                  onClick={handleRevokeAccess}
                  className="px-2 py-1 neo-raised text-[9px] font-bold uppercase text-[#D64545] rounded-lg cursor-pointer"
                >
                  Revoke
                </button>
              </div>
            </div>
          </div>

          {/* Quick Metrics & Dates */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3 neo-pressed rounded-[14px]">
              <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Status</span>
              <span className={`text-xs font-black uppercase px-2.5 py-0.5 rounded-full inline-block mt-1 ${
                status === 'ACTIVE' ? 'bg-[#34A853]/20 text-[#34A853]' :
                status === 'FROZEN' ? 'bg-[#E3A008]/20 text-[#E3A008]' :
                'bg-[#D64545]/20 text-[#D64545]'
              }`}>
                {status}
              </span>
            </div>
            <div className="p-3 neo-pressed rounded-[14px]">
              <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Current Plan</span>
              <span className="text-xs font-bold text-[var(--text)] block mt-1">{member.planName || 'Monthly'}</span>
            </div>
            <div className="p-3 neo-pressed rounded-[14px]">
              <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Plan Expiry</span>
              <span className="text-xs font-bold font-mono text-[var(--text)] block mt-1">{member.endDate || member.membershipExpiry || 'N/A'}</span>
            </div>
            <div className="p-3 neo-pressed rounded-[14px]">
              <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Payment Status</span>
              <span className={`text-xs font-black font-mono block mt-1 ${member.paymentStatus === 'PAID' ? 'text-[#34A853]' : 'text-[#E3A008]'}`}>
                {member.paymentStatus || 'PAID'}
              </span>
            </div>
          </div>

          {/* Member Fitness Requirements & Onboarding Data */}
          <div className="pt-4 border-t border-[var(--border)] space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-black uppercase tracking-widest text-[var(--text-sec)] flex items-center gap-1.5">
                <Dumbbell size={14} className="text-[#4285F4]" /> MEMBER FITNESS REQUIREMENTS & GOALS
              </span>
              <span className={`text-[9px] font-bold uppercase px-2 py-0.5 rounded-md ${
                member.onboardingCompleted ? 'bg-[#34A853]/15 text-[#34A853]' : 'bg-[#E3A008]/15 text-[#E3A008]'
              }`}>
                {member.onboardingCompleted ? 'ONBOARDING COMPLETED' : 'ONBOARDING PENDING'}
              </span>
            </div>

            {member.fitnessPreferences || member.onboardingCompleted ? (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div className="p-3 neo-pressed rounded-[14px] space-y-1">
                  <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Body Build & Physique</span>
                  <div className="text-xs font-bold text-[var(--text)]">
                    Current: <span className="text-[#4285F4]">{member.fitnessPreferences?.currentBuild || 'Toned / Medium'}</span>
                  </div>
                  <div className="text-xs font-bold text-[var(--text)]">
                    Target: <span className="text-[#34A853]">{member.fitnessPreferences?.desiredPhysique || 'Muscular Master / Athletic'}</span>
                  </div>
                </div>

                <div className="p-3 neo-pressed rounded-[14px] space-y-1">
                  <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Primary Goal & Focus</span>
                  <div className="text-xs font-bold text-[var(--text)]">
                    Goal: <span className="text-[var(--text)]">{member.fitnessPreferences?.primaryGoal || 'Hypertrophy & Strength'}</span>
                  </div>
                  <div className="text-xs font-bold text-[var(--text-sec)]">
                    Focus: {member.fitnessPreferences?.trainingFocus || 'Heavy Weightlifting / HIIT'}
                  </div>
                </div>

                <div className="p-3 neo-pressed rounded-[14px] space-y-1">
                  <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Experience & Schedule</span>
                  <div className="text-xs font-bold text-[var(--text)]">
                    Level: {member.fitnessPreferences?.experienceLevel || 'Intermediate'}
                  </div>
                  <div className="text-xs font-bold text-[var(--text-sec)]">
                    {member.fitnessPreferences?.frequency || '4-5 days/week'} • {member.fitnessPreferences?.sessionDuration || '45-60 mins'}
                  </div>
                </div>

                {member.trainingLimitations && (member.trainingLimitations.conditions?.length > 0 || member.trainingLimitations.notes) && (
                  <div className="md:col-span-3 p-3 bg-[#D64545]/10 border border-[#D64545]/20 rounded-[14px] space-y-1">
                    <span className="text-[9px] font-black uppercase tracking-widest text-[#D64545] flex items-center gap-1">
                      <AlertTriangle size={12} /> SAFETY & PHYSICAL LIMITATIONS
                    </span>
                    <p className="text-xs font-medium text-[var(--text)]">
                      {member.trainingLimitations.conditions?.join(', ') || member.trainingLimitations.notes || 'No physical limitations reported.'}
                    </p>
                    {member.trainingLimitations.emergencyContact && (
                      <p className="text-[10px] font-mono text-[var(--text-sec)]">
                        Emergency Contact: {member.trainingLimitations.emergencyContact}
                      </p>
                    )}
                  </div>
                )}
              </div>
            ) : (
              <p className="text-xs text-[var(--text-sec)] font-medium italic">
                Member has not completed first-time fitness onboarding setup yet.
              </p>
            )}
          </div>

          {/* Owner Quick Administrative Actions */}
          <div className="space-y-2 pt-2 border-t border-[var(--border)]">
            <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Member Status Actions</span>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => setPaymentModalOpen(true)}
                className="px-3 py-2 neo-raised text-[10px] font-black uppercase tracking-wider rounded-xl flex items-center gap-1.5 text-[#34A853] cursor-pointer"
              >
                <CreditCard size={14} /> Collect Payment
              </button>
              {status === 'FROZEN' ? (
                <button
                  onClick={() => openStatusModal('UNFREEZE')}
                  className="px-3 py-2 neo-raised text-[10px] font-black uppercase tracking-wider rounded-xl flex items-center gap-1.5 text-[#34A853] cursor-pointer"
                >
                  <Unlock size={14} /> Unfreeze Membership
                </button>
              ) : (
                <button
                  onClick={() => openStatusModal('FREEZE')}
                  className="px-3 py-2 neo-raised text-[10px] font-black uppercase tracking-wider rounded-xl flex items-center gap-1.5 text-[#E3A008] cursor-pointer"
                >
                  <Lock size={14} /> Freeze Membership
                </button>
              )}
              {status === 'BLOCKED' ? (
                <button
                  onClick={() => openStatusModal('UNBLOCK')}
                  className="px-3 py-2 neo-raised text-[10px] font-black uppercase tracking-wider rounded-xl flex items-center gap-1.5 text-[#34A853] cursor-pointer"
                >
                  <Unlock size={14} /> Unblock Member
                </button>
              ) : (
                <button
                  onClick={() => openStatusModal('BLOCK')}
                  className="px-3 py-2 neo-raised text-[10px] font-black uppercase tracking-wider rounded-xl flex items-center gap-1.5 text-[#D64545] cursor-pointer"
                >
                  <Lock size={14} /> Block Access
                </button>
              )}
              {status === 'ARCHIVED' ? (
                <button
                  onClick={() => openStatusModal('RESTORE')}
                  className="px-3 py-2 neo-raised text-[10px] font-black uppercase tracking-wider rounded-xl flex items-center gap-1.5 text-[#34A853] cursor-pointer"
                >
                  <RefreshCw size={14} /> Restore Member
                </button>
              ) : (
                <button
                  onClick={() => openStatusModal('ARCHIVE')}
                  className="px-3 py-2 neo-raised text-[10px] font-black uppercase tracking-wider rounded-xl flex items-center gap-1.5 text-[var(--text-sec)] cursor-pointer"
                >
                  <Trash2 size={14} /> Archive Member
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Member Attendance Calendar Component */}
        <MemberAttendanceCalendar
          attendanceRecords={member.attendanceRecords || []}
          currentStreak={member.attendanceStreak || 0}
          bestStreak={member.bestStreak || member.attendanceStreak || 0}
          lastVisit={member.lastVisit || 'Today'}
          memberName={member.fullName}
        />

        {/* Member Activity History Timeline */}
        <div className="neo-raised rounded-[24px] p-6 space-y-4">
          <div className="flex justify-between items-center border-b border-[var(--border)] pb-3">
            <h3 className="text-sm font-black uppercase tracking-wider text-[var(--text)] flex items-center gap-2">
              <Calendar size={16} /> Chronological Activity History
            </h3>
            <span className="text-[10px] font-bold text-[var(--text-sec)] uppercase">
              {memberHistory.length} Recorded Events
            </span>
          </div>

          {memberHistory.length === 0 ? (
            <p className="text-xs font-bold text-[var(--text-sec)] text-center py-6 uppercase tracking-wider">
              No activity logs recorded for this member yet.
            </p>
          ) : (
            <div className="space-y-3 max-h-96 overflow-y-auto pr-1">
              {memberHistory.map((item, idx) => (
                <div key={item.id || idx} className="p-3.5 neo-pressed rounded-[16px] flex justify-between items-start gap-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-black uppercase tracking-wider text-[var(--text)]">
                        {item.action}
                      </span>
                      <span className="text-[10px] font-bold text-[var(--text-sec)] uppercase">
                        • {item.actor || 'System'}
                      </span>
                    </div>
                    <p className="text-xs font-medium text-[var(--text-sec)]">
                      {item.details}
                    </p>
                  </div>
                  <span className="text-[10px] font-mono text-[var(--text-sec)] shrink-0">
                    {new Date(item.timestamp).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" })}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Member Account Status Audit Trail */}
        {statusHistory.length > 0 && (
          <div className="neo-raised rounded-[24px] p-6 space-y-4">
            <div className="flex justify-between items-center border-b border-[var(--border)] pb-3">
              <h3 className="text-sm font-black uppercase tracking-wider text-[var(--text)] flex items-center gap-2">
                <ShieldCheck size={16} className="text-[#4285F4]" /> Account Status Audit Trail
              </h3>
              <span className="text-[10px] font-bold text-[var(--text-sec)] uppercase">
                {statusHistory.length} Status Changes
              </span>
            </div>

            <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
              {statusHistory.map((h) => (
                <div key={h.id} className="p-3.5 neo-pressed rounded-[16px] space-y-1.5 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-[var(--surface-sec)] text-[var(--text)]">
                      {h.previousStatus || 'ACTIVE'} ➔ {h.newStatus}
                    </span>
                    <span className="text-[10px] font-mono text-[var(--text-sec)]">
                      {new Date(h.timestamp).toLocaleString('en-IN')}
                    </span>
                  </div>
                  <p className="font-bold text-[var(--text)] text-[11px]">
                    Reason: {h.finalReason || 'Status update'}
                  </p>
                  <p className="text-[9px] text-[var(--text-sec)] font-mono">
                    Performer: {h.actorName || 'Gym Owner'} ({h.actorType || 'owner'})
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Renewal Modal */}
        {renewModalOpen && (
          <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="w-full max-w-md bg-[var(--surface)] p-6 rounded-[24px] neo-raised space-y-4">
              <h3 className="text-base font-black uppercase tracking-wider">Renew Membership Plan</h3>
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] mb-1">
                  Select Membership Plan
                </label>
                <select
                  value={renewPlanId}
                  onChange={(e) => {
                    setRenewPlanId(e.target.value);
                    const p = plans.find(x => x.id === e.target.value);
                    if (p) setRenewAmount(p.price?.toString() || '0');
                  }}
                  className="w-full h-11 px-3 neo-pressed rounded-[12px] text-xs font-bold bg-[var(--surface)] text-[var(--text)] outline-none"
                >
                  {plans.map(p => (
                    <option key={p.id} value={p.id}>{p.planName} - ₹{p.price}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] mb-1">
                  Payment Amount Received (₹)
                </label>
                <input
                  type="number"
                  value={renewAmount}
                  onChange={(e) => setRenewAmount(e.target.value)}
                  className="w-full h-11 px-3 neo-pressed rounded-[12px] text-xs font-bold text-[var(--text)] font-mono outline-none"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] mb-1">
                  Payment Mode
                </label>
                <select
                  value={renewMode}
                  onChange={(e) => setRenewMode(e.target.value)}
                  className="w-full h-11 px-3 neo-pressed rounded-[12px] text-xs font-bold bg-[var(--surface)] text-[var(--text)] outline-none"
                >
                  <option value="UPI">UPI / QR</option>
                  <option value="CASH">Cash</option>
                  <option value="CARD">Debit / Credit Card</option>
                  <option value="BANK_TRANSFER">Bank Transfer</option>
                </select>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  onClick={() => setRenewModalOpen(false)}
                  className="w-1/2 h-11 rounded-[14px] neo-raised text-xs font-bold uppercase cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  onClick={handleRenew}
                  disabled={actionLoading}
                  className="w-1/2 h-11 rounded-[14px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-bold uppercase cursor-pointer"
                >
                  {actionLoading ? 'Saving...' : 'Confirm Renewal'}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Collect Payment Modal */}
        {paymentModalOpen && (
          <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="w-full max-w-md bg-[var(--surface)] p-6 rounded-[24px] neo-raised space-y-4">
              <h3 className="text-base font-black uppercase tracking-wider">Record Manual Payment</h3>
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] mb-1">
                  Payment Amount (₹)
                </label>
                <input
                  type="number"
                  placeholder="e.g. 1500"
                  value={paymentAmount}
                  onChange={(e) => setPaymentAmount(e.target.value)}
                  className="w-full h-11 px-3 neo-pressed rounded-[12px] text-xs font-bold text-[var(--text)] font-mono outline-none"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] mb-1">
                  Payment Method
                </label>
                <select
                  value={paymentMode}
                  onChange={(e) => setPaymentMode(e.target.value)}
                  className="w-full h-11 px-3 neo-pressed rounded-[12px] text-xs font-bold bg-[var(--surface)] text-[var(--text)] outline-none"
                >
                  <option value="UPI">UPI / QR Code</option>
                  <option value="CASH">Cash</option>
                  <option value="CARD">Debit / Credit Card</option>
                  <option value="BANK_TRANSFER">Bank Transfer</option>
                </select>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  onClick={() => setPaymentModalOpen(false)}
                  className="w-1/2 h-11 rounded-[14px] neo-raised text-xs font-bold uppercase cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  onClick={handleCollectPayment}
                  disabled={actionLoading}
                  className="w-1/2 h-11 rounded-[14px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-bold uppercase cursor-pointer"
                >
                  {actionLoading ? 'Saving...' : 'Save Payment'}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Member Status Action Modal */}
        {statusModalOpen && (
          <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="w-full max-w-md bg-[var(--surface)] p-6 rounded-[28px] neo-raised space-y-4 text-[var(--text)]">
              <div className="flex items-center justify-between pb-2 border-b border-[var(--border)]">
                <h3 className="text-sm font-black uppercase tracking-wider">{statusAction} Member Account</h3>
                <button onClick={() => setStatusModalOpen(false)} className="p-1 rounded-full neo-pressed text-[var(--text-sec)]">
                  <X size={18} />
                </button>
              </div>

              <div className="neo-pressed p-3 rounded-xl text-xs space-y-0.5">
                <p className="font-bold text-[var(--text)]">{member.fullName}</p>
                <p className="text-[10px] text-[var(--text-sec)] font-mono">{member.phone} • Code: {member.memberAccessCode || member.memberCode}</p>
              </div>

              <div className="space-y-3 text-xs font-bold">
                <div>
                  <label className="block text-[10px] font-black uppercase tracking-widest text-[var(--text-sec)] mb-1">
                    Select Reason Code *
                  </label>
                  <select
                    value={statusReasonCode}
                    onChange={(e) => setStatusReasonCode(e.target.value)}
                    className="w-full h-10 px-3 neo-pressed rounded-xl bg-[var(--surface)] text-[var(--text)] outline-none"
                  >
                    <option value="TEMPORARY_RESTRICTION">Temporary Membership Restriction</option>
                    <option value="PAYMENT_ISSUE">Membership Payment Overdue / Pending</option>
                    <option value="CONDUCT_ISSUE">Gym Rules or Conduct Violation</option>
                    <option value="MEMBERSHIP_ISSUE">Membership Terms Non-Compliance</option>
                    <option value="ADMINISTRATIVE_ACTION">Administrative Status Update</option>
                    <option value="RESTORED">Restored to Active Membership</option>
                    <option value="OTHER">Custom Reason Note</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-black uppercase tracking-widest text-[var(--text-sec)] mb-1">
                    Custom Reason / Internal Notes
                  </label>
                  <textarea
                    rows={3}
                    placeholder="Enter specific details or notes for audit trail..."
                    value={statusCustomReason}
                    onChange={(e) => setStatusCustomReason(e.target.value)}
                    className="w-full p-3 neo-pressed rounded-xl bg-[var(--surface)] text-[var(--text)] text-xs outline-none resize-none"
                  />
                </div>
              </div>

              <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-[10px] text-amber-500 font-semibold leading-relaxed">
                ⚠️ Changing member status to restricted state will invalidate active sessions, block QR check-ins, and restrict member dashboard access immediately.
              </div>

              <div className="flex gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setStatusModalOpen(false)}
                  className="w-1/2 h-11 rounded-xl neo-raised text-xs font-bold uppercase cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={actionLoading}
                  onClick={handleConfirmStatusAction}
                  className="w-1/2 h-11 rounded-xl bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-wider cursor-pointer shadow-sm"
                >
                  {actionLoading ? 'Updating...' : `Confirm ${statusAction}`}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Digital ID Card Modal */}
        <DigitalIdCard
          isOpen={idCardOpen}
          onClose={() => setIdCardOpen(false)}
          member={member}
        />

        {/* Member Print Modal */}
        <MemberPrintModal
          isOpen={printModalOpen}
          onClose={() => setPrintModalOpen(false)}
          member={member}
        />
      </div>
    </OwnerLayout>
  );
}
