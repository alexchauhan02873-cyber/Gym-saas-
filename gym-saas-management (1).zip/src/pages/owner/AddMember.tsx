import React, { useState, useEffect } from 'react';
import { useNavigate } from '@/lib/router-compat';
import { ArrowLeft, UserPlus, Check, Sparkles, Phone, Calendar, MapPin, IndianRupee, Shield, Copy, Eye, EyeOff, Dumbbell, Upload, Image } from 'lucide-react';
import OwnerLayout from '../../components/OwnerLayout';

export default function AddMember() {
  const navigate = useNavigate();
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [plans, setPlans] = useState<any[]>([]);
  
  // Form State - Step 1: Personal Details
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [age, setAge] = useState('');
  const [dob, setDob] = useState('');
  const [gender, setGender] = useState('Male');
  const [location, setLocation] = useState('');
  const [profileImage, setProfileImage] = useState('');

  // Form State - Step 2: Membership Details
  const [selectedPlanId, setSelectedPlanId] = useState('');
  const [startDate, setStartDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [endDate, setEndDate] = useState('');
  const [paymentAmount, setPaymentAmount] = useState('');
  const [paymentMode, setPaymentMode] = useState('UPI');

  // UI States
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [createdMember, setCreatedMember] = useState<any | null>(null);
  const [showCode, setShowCode] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);

  useEffect(() => {
    const sessionStr = localStorage.getItem('gym_session');
    if (!sessionStr) { navigate('/'); return; }
    const session = JSON.parse(sessionStr);

    fetch(`/api/plans/${session.gymId}`)
      .then(res => res.json())
      .then(data => {
        const planList = data?.plans || (Array.isArray(data) ? data : []);
        if (planList && planList.length > 0) {
          setPlans(planList);
          setSelectedPlanId(planList[0].id);
          setPaymentAmount(planList[0].price?.toString() || '0');
          calculateEndDate(startDate, planList[0]);
        }
      })
      .catch(console.error);
  }, [navigate]);

  const calculateEndDate = (start: string, plan: any) => {
    if (!start) return;
    const months = Number(plan?.durationMonths || 1);
    const d = new Date(start);
    d.setMonth(d.getMonth() + months);
    setEndDate(d.toISOString().split('T')[0]);
  };

  const handlePlanChange = (planId: string) => {
    setSelectedPlanId(planId);
    const p = plans.find(x => x.id === planId);
    if (p) {
      setPaymentAmount(p.price?.toString() || '0');
      calculateEndDate(startDate, p);
    }
  };

  const handleStartDateChange = (dateVal: string) => {
    setStartDate(dateVal);
    const p = plans.find(x => x.id === selectedPlanId);
    if (p) calculateEndDate(dateVal, p);
  };

  const validateStep1 = () => {
    if (!fullName.trim()) {
      setError('Please enter the member\'s full name.');
      return false;
    }
    const cleanPhone = phone.replace(/\D/g, '');
    if (!cleanPhone || cleanPhone.length < 10) {
      setError('Please enter a valid 10-digit phone number.');
      return false;
    }
    setError('');
    return true;
  };

  const validateStep2 = () => {
    if (!selectedPlanId) {
      setError('Please select a membership plan.');
      return false;
    }
    if (!startDate || !endDate) {
      setError('Please specify valid start and end dates.');
      return false;
    }
    if (new Date(endDate) < new Date(startDate)) {
      setError('Plan expiry date cannot be before start date.');
      return false;
    }
    setError('');
    return true;
  };

  const handleNextStep = () => {
    if (step === 1 && validateStep1()) {
      setStep(2);
    } else if (step === 2 && validateStep2()) {
      setStep(3);
    }
  };

  const handlePrevStep = () => {
    setError('');
    if (step === 2) setStep(1);
    if (step === 3) setStep(2);
  };

  const handleFinalSubmit = async () => {
    setLoading(true);
    setError('');

    const sessionStr = localStorage.getItem('gym_session');
    if (!sessionStr) return;
    const session = JSON.parse(sessionStr);

    try {
      const res = await fetch('/api/members/add', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          gymId: session.gymId,
          fullName: fullName.trim(),
          phone: phone.trim(),
          age: age ? Number(age) : null,
          dob,
          gender,
          location,
          profileImage,
          planId: selectedPlanId,
          startDate,
          endDate,
          paymentAmount: parseFloat(paymentAmount) || 0,
          paymentMode
        })
      });

      const data = await res.json();
      if (data.success && data.member) {
        setCreatedMember(data.member);
      } else {
        setError(data.message || 'Failed to register member.');
      }
    } catch (err) {
      setError('Server connection error. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const selectedPlanObj = plans.find(p => p.id === selectedPlanId);

  return (
    <OwnerLayout>
      <div className="px-4 mt-6 space-y-6 max-w-xl mx-auto pb-10">
        {/* Header */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate('/owner/members')}
            className="w-10 h-10 rounded-full neo-raised flex items-center justify-center text-[var(--text)] active:scale-95 transition-transform cursor-pointer"
          >
            <ArrowLeft size={18} />
          </button>
          <div>
            <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)]">Member Registration</span>
            <h1 className="text-xl font-black uppercase tracking-wider text-[var(--text)]">Add New Gym Member</h1>
          </div>
        </div>

        {/* Success Screen */}
        {createdMember ? (
          <div className="clay-raised p-6 sm:p-8 rounded-[28px] text-center space-y-6 animate-scale-up">
            <div className="w-16 h-16 rounded-full bg-[#34A853]/20 text-[#34A853] flex items-center justify-center mx-auto">
              <Check size={36} />
            </div>
            <div>
              <span className="text-[9px] font-black uppercase tracking-widest text-[#34A853] bg-[#34A853]/10 px-3 py-1 rounded-full">
                MEMBER REGISTERED ✓
              </span>
              <h2 className="text-2xl font-black uppercase tracking-wider mt-3">{createdMember.fullName}</h2>
              <p className="text-xs text-[var(--text-sec)] font-mono mt-1">
                ID: {createdMember.memberDisplayId || 'MEM-0042'} • {createdMember.phone}
              </p>
            </div>

            {/* Permanent Member Access Code Box */}
            <div className="neo-pressed p-5 rounded-[22px] text-center space-y-3">
              <span className="text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">
                PERMANENT MEMBER ACCESS CODE
              </span>
              <div className="flex items-center justify-center gap-3">
                <span className="text-3xl font-black font-mono tracking-widest text-[var(--text)]">
                  {showCode ? (createdMember.memberAccessCode || createdMember.memberCode) : '••••••'}
                </span>
                <button
                  onClick={() => setShowCode(!showCode)}
                  className="p-2 neo-raised rounded-xl text-[var(--text-sec)] hover:text-[var(--text)] cursor-pointer"
                  title="Toggle view"
                >
                  {showCode ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
              <p className="text-[10px] text-[var(--text-sec)] font-medium max-w-xs mx-auto">
                Share this 6-digit code with the member. They will use it to log into their Member App.
              </p>
              
              <div className="flex gap-2 justify-center pt-2">
                <button
                  onClick={() => {
                    const code = createdMember.memberAccessCode || createdMember.memberCode;
                    navigator.clipboard.writeText(code);
                    setCopiedCode(true);
                    setTimeout(() => setCopiedCode(false), 2000);
                  }}
                  className="px-4 py-2.5 rounded-xl neo-raised text-[10px] font-bold uppercase tracking-wider flex items-center gap-1.5 cursor-pointer"
                >
                  <Copy size={14} /> {copiedCode ? 'Copied!' : 'Copy Code'}
                </button>
                <a
                  href={`https://wa.me/91${createdMember.phone?.replace(/\D/g, '')}?text=Welcome%20to%20our%20Gym!%20Your%206-Digit%20Member%20Access%20Code%20is:%20${createdMember.memberAccessCode || createdMember.memberCode}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-2.5 rounded-xl bg-[#25D366] text-white text-[10px] font-bold uppercase tracking-wider flex items-center gap-1.5 cursor-pointer shadow-sm"
                >
                  WhatsApp Code
                </a>
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                onClick={() => {
                  setCreatedMember(null);
                  setStep(1);
                  setFullName('');
                  setPhone('');
                  setAge('');
                  setLocation('');
                  setProfileImage('');
                }}
                className="w-1/3 h-12 rounded-[16px] neo-raised text-xs font-bold uppercase tracking-widest cursor-pointer"
              >
                Add Another
              </button>
              <button
                onClick={() => navigate(`/owner/workout?memberId=${createdMember.id}`)}
                className="w-1/3 h-12 rounded-[16px] neo-raised text-xs font-bold uppercase tracking-widest text-[#34A853] flex items-center justify-center gap-1 cursor-pointer"
              >
                <Dumbbell size={16} /> Assign Workout
              </button>
              <button
                onClick={() => navigate(`/owner/members/${createdMember.id}`)}
                className="w-1/3 h-12 rounded-[16px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-bold uppercase tracking-widest cursor-pointer"
              >
                View Profile
              </button>
            </div>
          </div>
        ) : (
          <div className="clay-raised p-6 sm:p-8 rounded-[28px] space-y-6">
            {/* Wizard Step Progress Bar */}
            <div className="space-y-2">
              <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-widest text-[var(--text-sec)]">
                <span>Step {step} of 3</span>
                <span>
                  {step === 1 ? 'Personal Details' : step === 2 ? 'Membership & Plan' : 'Review & Confirm'}
                </span>
              </div>
              <div className="w-full h-2 rounded-full neo-pressed overflow-hidden flex">
                <div
                  className="h-full bg-[var(--text)] transition-all duration-300 rounded-full"
                  style={{ width: `${(step / 3) * 100}%` }}
                />
              </div>
            </div>

            {error && (
              <div className="p-3 neo-pressed rounded-[14px] text-xs font-bold text-[#D64545] text-center">
                {error}
              </div>
            )}

            {/* STEP 1: PERSONAL DETAILS */}
            {step === 1 && (
              <div className="space-y-4 animate-fade-in">
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] mb-1">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Rahul Verma"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full h-12 px-4 neo-pressed rounded-[14px] text-xs font-bold text-[var(--text)] outline-none focus:ring-1 focus:ring-[var(--text)]"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] mb-1">
                    Mobile Number (WhatsApp) *
                  </label>
                  <div className="flex items-center gap-2">
                    <span className="h-12 px-3 neo-pressed rounded-[14px] text-xs font-bold text-[var(--text-sec)] flex items-center shrink-0">
                      🇮🇳 +91
                    </span>
                    <input
                      type="tel"
                      required
                      placeholder="9876543210"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full h-12 px-4 neo-pressed rounded-[14px] text-xs font-bold font-mono text-[var(--text)] outline-none focus:ring-1 focus:ring-[var(--text)]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] mb-1">
                      Age
                    </label>
                    <input
                      type="number"
                      placeholder="e.g. 25"
                      value={age}
                      onChange={(e) => setAge(e.target.value)}
                      className="w-full h-12 px-4 neo-pressed rounded-[14px] text-xs font-bold text-[var(--text)] outline-none focus:ring-1 focus:ring-[var(--text)]"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] mb-1">
                      Gender
                    </label>
                    <select
                      value={gender}
                      onChange={(e) => setGender(e.target.value)}
                      className="w-full h-12 px-4 neo-pressed rounded-[14px] text-xs font-bold text-[var(--text)] bg-[var(--surface)] cursor-pointer outline-none"
                    >
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Other">Other</option>
                      <option value="Prefer not to say">Prefer not to say</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] mb-1">
                    Locality / City
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Bandra West, Mumbai"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="w-full h-12 px-4 neo-pressed rounded-[14px] text-xs font-bold text-[var(--text)] outline-none focus:ring-1 focus:ring-[var(--text)]"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] mb-1">
                    Profile Photo (Upload File or Enter URL)
                  </label>
                  <div className="space-y-2">
                    <div className="flex gap-2">
                      <label className="flex-1 h-12 px-4 neo-raised rounded-[14px] text-xs font-bold text-[var(--text)] flex items-center justify-center gap-2 cursor-pointer hover:bg-[var(--surface-sec)] transition-colors">
                        <Upload size={16} /> Select Photo File
                        <input
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) {
                              const reader = new FileReader();
                              reader.onload = (ev) => {
                                setProfileImage(ev.target?.result as string || '');
                              };
                              reader.readAsDataURL(file);
                            }
                          }}
                        />
                      </label>
                    </div>

                    <input
                      type="url"
                      placeholder="Or paste image URL (https://...)"
                      value={profileImage}
                      onChange={(e) => setProfileImage(e.target.value)}
                      className="w-full h-11 px-4 neo-pressed rounded-[14px] text-xs font-bold text-[var(--text)] outline-none focus:ring-1 focus:ring-[var(--text)]"
                    />

                    {profileImage && (
                      <div className="mt-2 flex items-center gap-3 p-2 neo-pressed rounded-xl">
                        <img src={profileImage} alt="Preview" className="w-12 h-12 rounded-full object-cover neo-pressed" />
                        <span className="text-xs font-bold text-[var(--text)] flex-1 truncate">Photo Selected</span>
                        <button
                          type="button"
                          onClick={() => setProfileImage('')}
                          className="px-3 py-1 neo-raised rounded-lg text-[10px] text-[#D64545] font-bold uppercase cursor-pointer"
                        >
                          Remove
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleNextStep}
                  className="w-full h-12 rounded-[16px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-widest cursor-pointer mt-4 active:scale-95 transition-transform"
                >
                  Continue to Membership →
                </button>
              </div>
            )}

            {/* STEP 2: MEMBERSHIP & PLAN */}
            {step === 2 && (
              <div className="space-y-4 animate-fade-in">
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] mb-1">
                    Select Membership Plan *
                  </label>
                  <select
                    value={selectedPlanId}
                    onChange={(e) => handlePlanChange(e.target.value)}
                    className="w-full h-12 px-4 neo-pressed rounded-[14px] text-xs font-bold text-[var(--text)] bg-[var(--surface)] cursor-pointer outline-none"
                  >
                    {plans.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.planName} — ₹{p.price} ({p.durationMonths || 1} Month{p.durationMonths > 1 ? 's' : ''})
                      </option>
                    ))}
                  </select>
                </div>

                {selectedPlanObj && (
                  <div className="p-3 neo-pressed rounded-[14px] text-xs space-y-1">
                    <span className="text-[9px] font-bold uppercase text-[var(--text-sec)] block">Plan Details</span>
                    <p className="font-bold text-[var(--text)]">{selectedPlanObj.planName} - ₹{selectedPlanObj.price}</p>
                    <p className="text-[11px] text-[var(--text-sec)]">{selectedPlanObj.description || 'Full access to gym facilities.'}</p>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] mb-1">
                      Start Date
                    </label>
                    <input
                      type="date"
                      value={startDate}
                      onChange={(e) => handleStartDateChange(e.target.value)}
                      className="w-full h-12 px-3 neo-pressed rounded-[14px] text-xs font-bold text-[var(--text)] outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] mb-1">
                      Expiry Date
                    </label>
                    <input
                      type="date"
                      value={endDate}
                      onChange={(e) => setEndDate(e.target.value)}
                      className="w-full h-12 px-3 neo-pressed rounded-[14px] text-xs font-bold text-[var(--text)] outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] mb-1">
                      Payment Amount (₹)
                    </label>
                    <input
                      type="number"
                      value={paymentAmount}
                      onChange={(e) => setPaymentAmount(e.target.value)}
                      className="w-full h-12 px-4 neo-pressed rounded-[14px] text-xs font-bold font-mono text-[var(--text)] outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] mb-1">
                      Payment Mode
                    </label>
                    <select
                      value={paymentMode}
                      onChange={(e) => setPaymentMode(e.target.value)}
                      className="w-full h-12 px-4 neo-pressed rounded-[14px] text-xs font-bold text-[var(--text)] bg-[var(--surface)] cursor-pointer outline-none"
                    >
                      <option value="UPI">UPI / QR Code</option>
                      <option value="CASH">Cash</option>
                      <option value="CARD">Debit / Credit Card</option>
                      <option value="BANK_TRANSFER">Bank Transfer</option>
                    </select>
                  </div>
                </div>

                <div className="flex gap-3 pt-2">
                  <button
                    type="button"
                    onClick={handlePrevStep}
                    className="w-1/3 h-12 rounded-[16px] neo-raised text-xs font-bold uppercase tracking-widest cursor-pointer"
                  >
                    ← Back
                  </button>
                  <button
                    type="button"
                    onClick={handleNextStep}
                    className="w-2/3 h-12 rounded-[16px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-widest cursor-pointer active:scale-95 transition-transform"
                  >
                    Review Details →
                  </button>
                </div>
              </div>
            )}

            {/* STEP 3: REVIEW & CONFIRM */}
            {step === 3 && (
              <div className="space-y-4 animate-fade-in">
                <div className="neo-pressed p-4 rounded-[20px] space-y-3">
                  <h3 className="text-xs font-black uppercase tracking-wider text-[var(--text)] border-b border-[var(--border)] pb-2">
                    Member Registration Summary
                  </h3>
                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div>
                      <span className="text-[9px] font-bold uppercase text-[var(--text-sec)] block">Full Name</span>
                      <span className="font-bold text-[var(--text)]">{fullName}</span>
                    </div>
                    <div>
                      <span className="text-[9px] font-bold uppercase text-[var(--text-sec)] block">Phone</span>
                      <span className="font-bold font-mono text-[var(--text)]">{phone}</span>
                    </div>
                    <div>
                      <span className="text-[9px] font-bold uppercase text-[var(--text-sec)] block">Age & Gender</span>
                      <span className="font-bold text-[var(--text)]">{age || 'N/A'} yrs • {gender}</span>
                    </div>
                    <div>
                      <span className="text-[9px] font-bold uppercase text-[var(--text-sec)] block">Location</span>
                      <span className="font-bold text-[var(--text)]">{location || 'N/A'}</span>
                    </div>
                    <div>
                      <span className="text-[9px] font-bold uppercase text-[var(--text-sec)] block">Membership Plan</span>
                      <span className="font-bold text-[var(--text)]">{selectedPlanObj?.planName || 'Standard'}</span>
                    </div>
                    <div>
                      <span className="text-[9px] font-bold uppercase text-[var(--text-sec)] block">Plan Duration</span>
                      <span className="font-bold text-[var(--text)]">{startDate} to {endDate}</span>
                    </div>
                    <div>
                      <span className="text-[9px] font-bold uppercase text-[var(--text-sec)] block">Payment Collected</span>
                      <span className="font-black font-mono text-[#34A853]">₹{paymentAmount} ({paymentMode})</span>
                    </div>
                  </div>
                </div>

                <div className="flex gap-3 pt-2">
                  <button
                    type="button"
                    onClick={handlePrevStep}
                    disabled={loading}
                    className="w-1/3 h-12 rounded-[16px] neo-raised text-xs font-bold uppercase tracking-widest cursor-pointer"
                  >
                    ← Edit
                  </button>
                  <button
                    type="button"
                    onClick={handleFinalSubmit}
                    disabled={loading}
                    className="w-2/3 h-12 rounded-[16px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 cursor-pointer active:scale-95 transition-transform"
                  >
                    {loading ? 'Creating Member...' : '✓ Create Member & Generate Code'}
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </OwnerLayout>
  );
}
