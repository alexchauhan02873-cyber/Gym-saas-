import React from 'react';
import { Link } from '@/lib/router-compat';
import { ArrowRight, KeyRound } from 'lucide-react';

export default function MemberDirectLinkHandler() {
  return (
    <div className="min-h-screen bg-[var(--bg)] text-[var(--text)] flex items-center justify-center p-4">
      <div className="w-full max-w-sm clay-raised p-8 rounded-[28px] text-center space-y-6">
        <div className="w-16 h-16 rounded-full bg-[#D64545]/10 text-[#D64545] flex items-center justify-center mx-auto">
          <KeyRound size={32} />
        </div>
        <div>
          <h2 className="text-base font-black uppercase tracking-wider text-[var(--text)]">SYSTEM UPGRADE NOTICE</h2>
          <p className="text-xs font-medium text-[var(--text-sec)] mt-2 leading-relaxed">
            Member login links have been updated. All gym members now log in using a secure <span className="font-bold text-[var(--text)]">6-Character Member Access Code</span> provided by your gym owner.
          </p>
        </div>
        <div className="pt-2">
          <Link
            to="/"
            className="w-full h-12 rounded-[16px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-bold uppercase tracking-widest flex items-center justify-center gap-2 active:scale-95 transition-transform"
          >
            ENTER MEMBER CODE <ArrowRight size={16} />
          </Link>
        </div>
      </div>
    </div>
  );
}
