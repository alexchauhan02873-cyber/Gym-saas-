import React from 'react';
import { ShieldAlert, Headset, LogOut, Clock, AlertTriangle } from 'lucide-react';
import { useSearchParams } from '@/lib/router-compat';
import { accessMessage } from '@/lib/access-status';
import { signOutEverything } from '@/lib/app-auth';

export default function AccessBlocked() {
  const [params] = useSearchParams();
  const code = params.get('code') || 'SESSION_EXPIRED';
  const reasonParam = params.get('reason');
  const dateParam = params.get('date') || new Date().toISOString().split('T')[0];
  const copy = accessMessage(code);

  const displayReason = reasonParam || copy.body || 'Account access has been restricted by platform administration.';

  return (
    <div className="min-h-screen bg-[var(--bg)] text-[var(--text)] flex items-center justify-center px-5 py-12">
      <div className="w-full max-w-md clay-raised rounded-[28px] p-8 space-y-6 text-center animate-in fade-in duration-300">
        <div className="w-16 h-16 rounded-full neo-pressed mx-auto flex items-center justify-center text-[#D64545]">
          <ShieldAlert size={32} />
        </div>

        <div className="space-y-2">
          <span className="text-[9px] font-black uppercase tracking-widest text-[#D64545] bg-[#D64545]/10 px-3 py-1 rounded-full border border-[#D64545]/20 inline-block">
            STATUS: BLOCKED
          </span>
          <h1 className="text-xl font-black uppercase tracking-wider text-[var(--text)] pt-2">
            Account Access Restricted
          </h1>
          <p className="text-xs text-[var(--text-sec)]">
            Your account is currently blocked from accessing platform features.
          </p>
        </div>

        <div className="neo-pressed p-4 rounded-[18px] text-left space-y-2.5">
          <div>
            <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Restriction Reason</span>
            <p className="text-xs font-semibold text-[var(--text)] mt-0.5">{displayReason}</p>
          </div>
          <div className="flex items-center justify-between pt-2 border-t border-[var(--border)] text-[10px]">
            <span className="text-[var(--text-sec)] font-bold uppercase tracking-wider">Blocked Date:</span>
            <span className="font-mono font-bold text-[var(--text)]">{dateParam}</span>
          </div>
        </div>

        <div className="flex flex-col gap-3">
          <a
            href="https://wa.me/919263604732?text=Hello%20Support%2C%20my%20account%20access%20is%20restricted.%20Please%20help."
            target="_blank"
            rel="noopener noreferrer"
            className="h-12 rounded-[16px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-bold uppercase tracking-widest flex items-center justify-center gap-2"
          >
            <Headset size={16} /> Contact Support
          </a>
          <button
            onClick={() => void signOutEverything()}
            className="h-12 rounded-[16px] neo-raised text-xs font-bold uppercase tracking-widest flex items-center justify-center gap-2 active:scale-95 transition-transform cursor-pointer"
          >
            <LogOut size={16} /> Sign Out
          </button>
        </div>
      </div>
    </div>
  );
}
