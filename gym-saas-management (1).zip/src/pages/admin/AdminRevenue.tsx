import React, { useState, useEffect } from 'react';
import { IndianRupee, TrendingUp, Calendar } from 'lucide-react';
import AdminLayout from '../../components/admin/AdminLayout';

export default function AdminRevenue() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/admin/overview')
      .then(res => res.json())
      .then(d => {
        if (d) setData(d);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div>
          <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)]">Financial Analytics</span>
          <h1 className="text-2xl font-black uppercase tracking-wider text-[var(--text)]">Platform Revenue Analytics</h1>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="clay-raised p-6 rounded-[24px]">
            <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Total Gross Revenue</span>
            <span className="text-3xl font-black font-mono text-[#34A853] mt-2 block">
              ₹{(data?.totalRevenue || 0).toLocaleString('en-IN')}
            </span>
          </div>
          <div className="clay-raised p-6 rounded-[24px]">
            <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Avg Revenue Per Gym</span>
            <span className="text-3xl font-black font-mono text-[var(--text)] mt-2 block">
              ₹{data?.totalGyms > 0 ? Math.round((data.totalRevenue || 0) / data.totalGyms).toLocaleString('en-IN') : 0}
            </span>
          </div>
          <div className="clay-raised p-6 rounded-[24px]">
            <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">SaaS Platform MRR</span>
            <span className="text-3xl font-black font-mono text-[#4285F4] mt-2 block">
              ₹{(data?.totalGyms * 2999 || 0).toLocaleString('en-IN')}
            </span>
          </div>
        </div>

        <div className="clay-raised p-6 rounded-[28px] space-y-4">
          <h3 className="text-sm font-black uppercase tracking-wider text-[var(--text)]">Tenant Revenue Breakdown</h3>
          <div className="space-y-3">
            {data?.gyms?.map((gym: any) => (
              <div key={gym.gymId} className="neo-pressed p-4 rounded-[20px] flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-black uppercase text-[var(--text)]">{gym.gymName}</h4>
                  <p className="text-[10px] text-[var(--text-sec)] font-mono">{gym.ownerName} • {gym.city}</p>
                </div>
                <div className="text-right">
                  <span className="text-sm font-black font-mono text-[#34A853]">₹{gym.revenue?.toLocaleString('en-IN')}</span>
                  <span className="text-[9px] font-bold text-[var(--text-sec)] block font-mono">{gym.memberCount} Members</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}
