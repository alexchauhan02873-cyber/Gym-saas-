import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from '@/lib/router-compat';
import { Building2, IndianRupee, Users, Activity, Megaphone, ArrowRight, ShieldCheck } from 'lucide-react';
import AdminLayout from '../../components/admin/AdminLayout';

export default function AdminDashboard() {
  const navigate = useNavigate();
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/admin/overview')
      .then(res => res.json())
      .then(d => {
        if (d && d.success) setData(d);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <AdminLayout>
        <div className="py-20 text-center text-4xl animate-pulse">🛡️</div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div>
          <span className="text-[9px] font-bold uppercase tracking-widest text-[#34A853] bg-[#34A853]/10 px-2.5 py-0.5 rounded-full border border-[#34A853]/20">
            PLATFORM OVERVIEW
          </span>
          <h1 className="text-2xl font-black uppercase tracking-wider text-[var(--text)] mt-2">Super Admin Control Center</h1>
          <p className="text-xs text-[var(--text-sec)] font-medium">Monitoring all registered gym tenants and platform metrics across India.</p>
        </div>

        {/* Global Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="clay-raised p-5 rounded-[22px]">
            <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Total Gym Tenants</span>
            <span className="text-3xl font-black font-mono text-[var(--text)] mt-2 block">{data?.totalGyms || 0}</span>
          </div>
          <div className="clay-raised p-5 rounded-[22px]">
            <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Active Members</span>
            <span className="text-3xl font-black font-mono text-[#4285F4] mt-2 block">{data?.totalMembers || 0}</span>
          </div>
          <div className="clay-raised p-5 rounded-[22px]">
            <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Platform Revenue</span>
            <span className="text-3xl font-black font-mono text-[#34A853] mt-2 block">
              ₹{(data?.totalRevenue || 0).toLocaleString('en-IN')}
            </span>
          </div>
          <div className="clay-raised p-5 rounded-[22px]">
            <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Today Check-ins</span>
            <span className="text-3xl font-black font-mono text-[#E3A008] mt-2 block">{data?.todayAttendance || 0}</span>
          </div>
        </div>

        {/* Gym Tenants Table */}
        <div className="clay-raised p-6 rounded-[28px] space-y-4">
          <div className="flex justify-between items-center border-b border-[var(--border)] pb-3">
            <h3 className="text-sm font-black uppercase tracking-wider text-[var(--text)] flex items-center gap-2">
              <Building2 size={18} /> Gym Workspaces
            </h3>
            <Link to="/admin/gyms" className="text-xs font-bold uppercase text-[var(--text)] flex items-center gap-1 hover:underline">
              Manage All <ArrowRight size={14} />
            </Link>
          </div>

          <div className="space-y-3">
            {data?.gyms?.map((gym: any) => (
              <div key={gym.gymId} className="neo-raised p-4 rounded-[20px] flex items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="text-xs font-black uppercase text-[var(--text)]">{gym.gymName}</h4>
                    <span className="text-[9px] font-mono px-2 py-0.5 rounded bg-[var(--surface-sec)] text-[var(--text-sec)] font-bold">
                      Code: {gym.ownerCode}
                    </span>
                  </div>
                  <p className="text-[10px] text-[var(--text-sec)] font-mono mt-0.5">Owner: {gym.ownerName} • {gym.city}</p>
                </div>

                <div className="text-right shrink-0">
                  <span className="text-xs font-black font-mono text-[var(--text)]">{gym.memberCount} Members</span>
                  <span className="text-[9px] font-bold text-[#34A853] uppercase block mt-0.5">₹{gym.revenue?.toLocaleString('en-IN')} Rev</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}
