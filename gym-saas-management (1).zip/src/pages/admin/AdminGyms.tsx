import React, { useState, useEffect } from 'react';
import {
  Building2, Search, ShieldAlert, Snowflake, Archive, CheckCircle2,
  X, History, AlertTriangle, Headset, Lock, Unlock, RefreshCw
} from 'lucide-react';
import AdminLayout from '../../components/admin/AdminLayout';

export default function AdminGyms() {
  const [gyms, setGyms] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'ACTIVE' | 'FROZEN' | 'BLOCKED' | 'ARCHIVED'>('ALL');

  // Modals
  const [selectedGym, setSelectedGym] = useState<any>(null);
  const [actionModalOpen, setActionModalOpen] = useState(false);
  const [historyModalOpen, setHistoryModalOpen] = useState(false);

  // Status Action Form State
  const [actionType, setActionType] = useState<'FREEZE' | 'UNFREEZE' | 'BLOCK' | 'UNBLOCK' | 'ARCHIVE' | 'RESTORE'>('FREEZE');
  const [reasonCode, setReasonCode] = useState<string>('TEMPORARY_ADMIN_RESTRICTION');
  const [customReason, setCustomReason] = useState<string>('');
  const [actionLoading, setActionLoading] = useState(false);
  const [statusHistory, setStatusHistory] = useState<any[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [toast, setToast] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  };

  const fetchGyms = () => {
    setLoading(true);
    fetch('/api/admin/gyms')
      .then((res) => res.json())
      .then((data) => {
        if (data && data.gyms) {
          setGyms(data.gyms);
        }
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchGyms();
  }, []);

  const openActionModal = (gym: any, defaultAction: 'FREEZE' | 'UNFREEZE' | 'BLOCK' | 'UNBLOCK' | 'ARCHIVE' | 'RESTORE') => {
    setSelectedGym(gym);
    setActionType(defaultAction);
    setReasonCode(
      defaultAction === 'FREEZE'
        ? 'TEMPORARY_ADMIN_RESTRICTION'
        : defaultAction === 'BLOCK'
        ? 'POLICY_VIOLATION'
        : defaultAction === 'ARCHIVE'
        ? 'OTHER'
        : 'RESTORED'
    );
    setCustomReason('');
    setActionModalOpen(true);
  };

  const openHistoryModal = async (gym: any) => {
    setSelectedGym(gym);
    setHistoryModalOpen(true);
    setHistoryLoading(true);
    try {
      const res = await fetch(`/api/admin/owners/${gym.ownerId || gym.id}/status-history`);
      const data = await res.json();
      if (data && data.success) {
        setStatusHistory(data.history || []);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setHistoryLoading(false);
    }
  };

  const handleApplyStatusAction = async () => {
    if (!selectedGym) return;
    setActionLoading(true);

    try {
      const res = await fetch(`/api/admin/owners/${selectedGym.ownerId || selectedGym.id}/status`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: actionType,
          reasonCode,
          customReason,
          actorId: 'admin_1',
          actorType: 'super_admin',
        }),
      });

      const data = await res.json();
      if (data.success) {
        showToast(`Gym status updated to ${data.newStatus}`);
        setActionModalOpen(false);
        fetchGyms();
      } else {
        alert(data.message || 'Failed to update gym status.');
      }
    } catch (e) {
      console.error(e);
      alert('Network error while updating status.');
    } finally {
      setActionLoading(false);
    }
  };

  const filtered = gyms.filter((g) => {
    const q = search.toLowerCase().trim();
    const matchesSearch =
      !q ||
      g.gymName?.toLowerCase().includes(q) ||
      g.ownerName?.toLowerCase().includes(q) ||
      g.accessCode?.toLowerCase().includes(q) ||
      g.city?.toLowerCase().includes(q);

    const statusUpper = (g.status || 'ACTIVE').toUpperCase();
    const matchesStatus =
      statusFilter === 'ALL' ||
      statusUpper === statusFilter;

    return matchesSearch && matchesStatus;
  });

  return (
    <AdminLayout>
      <div className="space-y-6 pb-12">
        {toast && (
          <div className="fixed top-5 right-5 z-50 bg-[#34A853] text-white px-4 py-3 rounded-2xl font-bold text-xs shadow-lg animate-bounce">
            ✓ {toast}
          </div>
        )}

        <div>
          <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)]">Directory</span>
          <h1 className="text-2xl font-black uppercase tracking-wider text-[var(--text)]">
            Gym Tenants ({gyms.length})
          </h1>
        </div>

        {/* Search & Status Filters */}
        <div className="clay-raised p-5 rounded-[24px] space-y-4">
          <div className="relative">
            <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-[var(--text-sec)]" />
            <input
              type="text"
              placeholder="Search gym by name, owner, city, or access code..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full h-12 pl-11 pr-4 neo-pressed rounded-[16px] text-xs font-bold text-[var(--text)] outline-none"
            />
          </div>

          <div className="flex gap-2 overflow-x-auto pb-1 hide-scrollbar">
            {[
              { id: 'ALL', label: 'ALL TENANTS' },
              { id: 'ACTIVE', label: 'ACTIVE' },
              { id: 'FROZEN', label: 'FROZEN' },
              { id: 'BLOCKED', label: 'BLOCKED' },
              { id: 'ARCHIVED', label: 'ARCHIVED' },
            ].map((f) => (
              <button
                key={f.id}
                onClick={() => setStatusFilter(f.id as any)}
                className={`px-3.5 py-1.5 rounded-[12px] text-[10px] font-black uppercase tracking-wider shrink-0 cursor-pointer ${
                  statusFilter === f.id
                    ? 'bg-[var(--btn-bg)] text-[var(--btn-text)] shadow-sm'
                    : 'neo-pressed text-[var(--text-sec)] hover:text-[var(--text)]'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>

        {loading ? (
          <div className="py-20 text-center text-4xl animate-pulse">🛡️</div>
        ) : filtered.length > 0 ? (
          <div className="space-y-3">
            {filtered.map((gym) => {
              const statusStr = (gym.status || 'ACTIVE').toUpperCase();

              return (
                <div
                  key={gym.id || gym.gymId}
                  className="clay-raised p-5 rounded-[24px] flex flex-col md:flex-row md:items-center justify-between gap-4"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-2xl neo-pressed flex items-center justify-center font-black text-sm uppercase shrink-0 text-[var(--text)]">
                      {gym.gymName?.charAt(0) || 'G'}
                    </div>
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="text-xs font-black uppercase tracking-wider text-[var(--text)]">
                          {gym.gymName}
                        </h3>
                        <span className="text-[9px] font-mono px-2 py-0.5 rounded bg-[var(--surface-sec)] text-[var(--text-sec)] font-bold">
                          Code: {gym.accessCode || gym.gymCode}
                        </span>

                        <span
                          className={`text-[9px] font-black uppercase px-2.5 py-0.5 rounded-full ${
                            statusStr === 'ACTIVE'
                              ? 'bg-[#34A853]/20 text-[#34A853]'
                              : statusStr === 'FROZEN'
                              ? 'bg-amber-500/20 text-amber-500'
                              : statusStr === 'BLOCKED'
                              ? 'bg-[#D64545]/20 text-[#D64545]'
                              : 'bg-neutral-500/20 text-neutral-400'
                          }`}
                        >
                          {statusStr}
                        </span>
                      </div>

                      <p className="text-[10px] text-[var(--text-sec)] font-mono mt-0.5">
                        Owner: {gym.ownerName} • {gym.phone} • {gym.city}
                      </p>

                      {gym.statusReason && statusStr !== 'ACTIVE' && (
                        <p className="text-[10px] text-red-500 dark:text-red-400 font-semibold mt-1">
                          Reason: {gym.statusReason}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Actions & Metrics */}
                  <div className="flex items-center justify-between md:justify-end gap-3 pt-3 md:pt-0 border-t md:border-t-0 border-[var(--border)]">
                    <div className="text-left md:text-right shrink-0 pr-2">
                      <span className="text-xs font-black font-mono text-[var(--text)] block">
                        {gym.memberCount || 0} Members
                      </span>
                      <span className="text-[9px] font-bold text-[#34A853] uppercase block mt-0.5">
                        ₹{(gym.currentRevenue || 0).toLocaleString('en-IN')} Revenue
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={() => openHistoryModal(gym)}
                        className="p-2 neo-raised rounded-xl text-[var(--text-sec)] hover:text-[var(--text)] cursor-pointer"
                        title="View Audit Status History"
                      >
                        <History size={16} />
                      </button>

                      {statusStr === 'ACTIVE' && (
                        <>
                          <button
                            type="button"
                            onClick={() => openActionModal(gym, 'FREEZE')}
                            className="px-2.5 py-1.5 neo-raised text-[9px] font-black uppercase text-amber-500 rounded-xl cursor-pointer"
                          >
                            Freeze
                          </button>
                          <button
                            type="button"
                            onClick={() => openActionModal(gym, 'BLOCK')}
                            className="px-2.5 py-1.5 neo-raised text-[9px] font-black uppercase text-[#D64545] rounded-xl cursor-pointer"
                          >
                            Block
                          </button>
                        </>
                      )}

                      {statusStr === 'FROZEN' && (
                        <button
                          type="button"
                          onClick={() => openActionModal(gym, 'UNFREEZE')}
                          className="px-3 py-1.5 bg-[#34A853] text-white text-[9px] font-black uppercase rounded-xl shadow-sm cursor-pointer"
                        >
                          Unfreeze
                        </button>
                      )}

                      {statusStr === 'BLOCKED' && (
                        <button
                          type="button"
                          onClick={() => openActionModal(gym, 'UNBLOCK')}
                          className="px-3 py-1.5 bg-[#34A853] text-white text-[9px] font-black uppercase rounded-xl shadow-sm cursor-pointer"
                        >
                          Unblock
                        </button>
                      )}

                      {statusStr !== 'ARCHIVED' ? (
                        <button
                          type="button"
                          onClick={() => openActionModal(gym, 'ARCHIVE')}
                          className="px-2 py-1.5 neo-raised text-[9px] font-black uppercase text-neutral-400 rounded-xl cursor-pointer"
                        >
                          Archive
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => openActionModal(gym, 'RESTORE')}
                          className="px-3 py-1.5 bg-[#34A853] text-white text-[9px] font-black uppercase rounded-xl shadow-sm cursor-pointer"
                        >
                          Restore
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="neo-pressed p-8 rounded-[24px] text-center space-y-2">
            <ShieldAlert size={32} className="mx-auto text-[var(--text-sec)] opacity-50" />
            <p className="text-xs font-black uppercase tracking-wider text-[var(--text-sec)]">
              No gym tenants found matching filter criteria
            </p>
          </div>
        )}

        {/* STATUS ACTION CONFIRMATION MODAL */}
        {actionModalOpen && selectedGym && (
          <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="w-full max-w-md clay-raised rounded-[28px] p-6 space-y-5 bg-[var(--surface)] text-[var(--text)] border border-[var(--border)] animate-fade-in">
              <div className="flex items-center justify-between pb-3 border-b border-[var(--border)]">
                <div className="flex items-center gap-2">
                  <ShieldAlert className="text-amber-500" size={20} />
                  <h3 className="text-sm font-black uppercase tracking-wider">
                    {actionType} Gym Tenant
                  </h3>
                </div>
                <button
                  onClick={() => setActionModalOpen(false)}
                  className="p-1 rounded-full neo-pressed text-[var(--text-sec)] hover:text-[var(--text)]"
                >
                  <X size={18} />
                </button>
              </div>

              <div className="neo-pressed p-3.5 rounded-xl space-y-1 text-xs">
                <p className="font-bold text-[var(--text)]">{selectedGym.gymName}</p>
                <p className="text-[10px] text-[var(--text-sec)]">
                  Owner: {selectedGym.ownerName} • Access Code: {selectedGym.accessCode}
                </p>
              </div>

              <div className="space-y-3 text-xs font-bold">
                <div>
                  <label className="block text-[10px] font-black uppercase tracking-widest text-[var(--text-sec)] mb-1">
                    Select Reason Code *
                  </label>
                  <select
                    value={reasonCode}
                    onChange={(e) => setReasonCode(e.target.value)}
                    className="w-full h-10 px-3 neo-pressed rounded-xl bg-[var(--surface)] text-[var(--text)] outline-none"
                  >
                    <option value="TEMPORARY_ADMIN_RESTRICTION">Temporary Administrative Restriction</option>
                    <option value="PAYMENT_COMPLIANCE_ISSUE">Payment & Billing Compliance Issue</option>
                    <option value="VERIFICATION_REQUIRED">KYC / Verification Required</option>
                    <option value="POLICY_VIOLATION">Platform Policy / Terms Violation</option>
                    <option value="SECURITY_REVIEW">Security Review / Suspicious Activity</option>
                    <option value="RESTORED">Account Restored to Active</option>
                    <option value="OTHER">Custom Reason Note</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-black uppercase tracking-widest text-[var(--text-sec)] mb-1">
                    Custom Reason / Internal Notes
                  </label>
                  <textarea
                    rows={3}
                    placeholder="Provide additional details or references for audit log..."
                    value={customReason}
                    onChange={(e) => setCustomReason(e.target.value)}
                    className="w-full p-3 neo-pressed rounded-xl bg-[var(--surface)] text-[var(--text)] text-xs outline-none resize-none"
                  />
                </div>
              </div>

              <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-[10px] text-red-500 font-semibold leading-relaxed">
                ⚠️ Changing status will immediately affect dashboard accessibility and revoke active user sessions where restricted.
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setActionModalOpen(false)}
                  className="flex-1 h-11 rounded-xl neo-raised text-xs font-bold uppercase tracking-wider"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={actionLoading}
                  onClick={handleApplyStatusAction}
                  className="flex-1 h-11 rounded-xl bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-wider shadow-sm"
                >
                  {actionLoading ? 'Updating...' : `Confirm ${actionType}`}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* AUDIT STATUS HISTORY MODAL */}
        {historyModalOpen && selectedGym && (
          <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="w-full max-w-lg clay-raised rounded-[28px] p-6 space-y-4 bg-[var(--surface)] text-[var(--text)] border border-[var(--border)] max-h-[85vh] flex flex-col animate-fade-in">
              <div className="flex items-center justify-between pb-3 border-b border-[var(--border)] shrink-0">
                <div className="flex items-center gap-2">
                  <History className="text-[#4285F4]" size={20} />
                  <h3 className="text-sm font-black uppercase tracking-wider">
                    Status Audit History
                  </h3>
                </div>
                <button
                  onClick={() => setHistoryModalOpen(false)}
                  className="p-1 rounded-full neo-pressed text-[var(--text-sec)] hover:text-[var(--text)]"
                >
                  <X size={18} />
                </button>
              </div>

              <div className="neo-pressed p-3 rounded-xl shrink-0 text-xs font-bold">
                <p className="text-[var(--text)]">{selectedGym.gymName}</p>
                <p className="text-[10px] text-[var(--text-sec)] font-mono">
                  Owner: {selectedGym.ownerName}
                </p>
              </div>

              <div className="overflow-y-auto space-y-3 pr-1 flex-1">
                {historyLoading ? (
                  <div className="py-12 text-center text-xs font-bold animate-pulse">Loading Audit Records...</div>
                ) : statusHistory.length > 0 ? (
                  statusHistory.map((h) => (
                    <div key={h.id} className="p-3.5 rounded-2xl neo-pressed border border-[var(--border)] space-y-1.5 text-xs">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-neutral-500/20 text-[var(--text)]">
                          {h.previousStatus || 'ACTIVE'} ➔ {h.newStatus}
                        </span>
                        <span className="text-[10px] font-mono text-[var(--text-sec)] font-bold">
                          {new Date(h.timestamp).toLocaleString('en-IN')}
                        </span>
                      </div>

                      <p className="font-bold text-[var(--text)] text-[11px] pt-1">
                        Reason: {h.finalReason || 'Administrative update'}
                      </p>

                      <div className="text-[9px] text-[var(--text-sec)] font-mono flex items-center justify-between pt-1 border-t border-[var(--border)]">
                        <span>Actor: {h.actorName || 'Super Admin'} ({h.actorType})</span>
                        <span>Action: {h.action}</span>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="py-12 text-center text-xs text-[var(--text-sec)] font-bold">
                    No prior status changes recorded for this tenant.
                  </div>
                )}
              </div>

              <div className="shrink-0 pt-2 border-t border-[var(--border)]">
                <button
                  type="button"
                  onClick={() => setHistoryModalOpen(false)}
                  className="w-full h-10 rounded-xl neo-raised text-xs font-bold uppercase tracking-wider"
                >
                  Close Audit Log
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </AdminLayout>
  );
}
