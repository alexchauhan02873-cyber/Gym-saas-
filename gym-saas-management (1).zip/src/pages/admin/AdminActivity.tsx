import React, { useState, useEffect } from 'react';
import { Activity, ShieldCheck, Clock } from 'lucide-react';
import AdminLayout from '../../components/admin/AdminLayout';

export default function AdminActivity() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/admin/overview')
      .then(res => res.json())
      .then(d => {
        if (d) setData(d);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div>
          <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)]">Security Audit</span>
          <h1 className="text-2xl font-black uppercase tracking-wider text-[var(--text)]">System Audit & Activity Logs</h1>
        </div>

        <div className="clay-raised p-6 rounded-[28px] space-y-4">
          <h3 className="text-sm font-black uppercase tracking-wider text-[var(--text)] flex items-center gap-2">
            <Activity size={18} /> Audit Trail
          </h3>

          <div className="space-y-3">
            <div className="p-4 rounded-[18px] neo-pressed flex items-start gap-3 border-l-4 border-l-[#34A853]">
              <div className="p-2 neo-pressed rounded-xl shrink-0 text-[#34A853]">
                <ShieldCheck size={18} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex justify-between items-center">
                  <h4 className="text-xs font-black uppercase">SYSTEM HEALTH OK</h4>
                  <span className="text-[9px] font-mono text-[var(--text-sec)]">Just now</span>
                </div>
                <p className="text-[11px] text-[var(--text-sec)] mt-1 font-medium">
                  All gym databases, in-memory store, Express API endpoints, and PWA Web Push workers operational.
                </p>
              </div>
            </div>

            {data?.gyms?.map((g: any) => (
              <div key={g.gymId} className="p-4 rounded-[18px] neo-pressed flex items-start gap-3">
                <div className="p-2 neo-pressed rounded-xl shrink-0 text-[var(--text)]">
                  <Clock size={18} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-center">
                    <h4 className="text-xs font-black uppercase">{g.gymName} Workspace Sync</h4>
                    <span className="text-[9px] font-mono text-[var(--text-sec)]">Active</span>
                  </div>
                  <p className="text-[11px] text-[var(--text-sec)] mt-1 font-medium">
                    Owner: {g.ownerName} • Total Members: {g.memberCount} • Code: {g.ownerCode}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}
