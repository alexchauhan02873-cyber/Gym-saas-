import React, { useState } from 'react';
import { Megaphone, Send, CheckCircle } from 'lucide-react';
import AdminLayout from '../../components/admin/AdminLayout';

export default function AdminBroadcast() {
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [sending, setSending] = useState(false);
  const [success, setSuccess] = useState('');

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !body.trim()) return;

    setSending(true);
    setSuccess('');

    try {
      const res = await fetch('/api/notifications/broadcast', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          gymId: 'GLOBAL',
          title: title.trim(),
          body: body.trim(),
          targetGroup: 'ALL'
        })
      });
      const data = await res.json();
      if (data.success) {
        setSuccess('System-wide platform broadcast sent to all gyms and members across India!');
        setTitle('');
        setBody('');
      }
    } catch (e) {
      console.error(e);
    } finally {
      setSending(false);
    }
  };

  return (
    <AdminLayout>
      <div className="space-y-6 max-w-xl mx-auto">
        <div>
          <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)]">Global Governance</span>
          <h1 className="text-2xl font-black uppercase tracking-wider text-[var(--text)]">Platform System Broadcast</h1>
        </div>

        {success && (
          <div className="p-4 neo-pressed rounded-[20px] bg-[#34A853]/10 border border-[#34A853]/30 text-[#34A853] text-xs font-bold uppercase flex items-center gap-2">
            <CheckCircle size={18} /> {success}
          </div>
        )}

        <div className="clay-raised p-6 sm:p-8 rounded-[28px] space-y-4">
          <form onSubmit={handleSend} className="space-y-4">
            <div>
              <label className="block text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] mb-1">
                System Broadcast Headline *
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Scheduled System Maintenance / Platform Upgrade Release"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full h-12 px-4 neo-pressed rounded-[14px] text-xs font-bold text-[var(--text)] outline-none"
              />
            </div>

            <div>
              <label className="block text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] mb-1">
                Broadcast Body *
              </label>
              <textarea
                rows={4}
                required
                placeholder="Broadcast message sent to every gym owner & member app..."
                value={body}
                onChange={(e) => setBody(e.target.value)}
                className="w-full p-4 neo-pressed rounded-[14px] text-xs font-medium text-[var(--text)] outline-none"
              />
            </div>

            <button
              type="submit"
              disabled={sending}
              className="w-full h-12 rounded-[16px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 active:scale-95 transition-transform cursor-pointer"
            >
              {sending ? 'DISPATCHING...' : <><Send size={16} /> BROADCAST SYSTEM-WIDE</>}
            </button>
          </form>
        </div>
      </div>
    </AdminLayout>
  );
}
