import React, { useState, useEffect } from 'react';
import { useNavigate } from '@/lib/router-compat';
import { QrCode, Check, AlertCircle, Camera, Upload } from 'lucide-react';
import MemberLayout from '../../components/MemberLayout';
import MemberAttendanceCalendar from '../../components/MemberAttendanceCalendar';
import MemberQRScannerModal from '../../components/MemberQRScannerModal';

export default function MemberAttendance() {
  const navigate = useNavigate();
  const [member, setMember] = useState<any>(null);
  const [sessionInfo, setSessionInfo] = useState<{ gymId: string; memberId: string } | null>(null);
  const [loading, setLoading] = useState(true);
  const [qrCodeInput, setQrCodeInput] = useState('');
  const [scanStatus, setScanStatus] = useState<'idle' | 'scanning' | 'success' | 'error'>('idle');
  const [scanMessage, setScanMessage] = useState('');
  const [isScannerOpen, setIsScannerOpen] = useState(false);

  const fetchMemberData = () => {
    const sessionStr = localStorage.getItem('member_session');
    if (!sessionStr) { navigate('/'); return; }
    const session = JSON.parse(sessionStr);
    setSessionInfo({ gymId: session.gymId, memberId: session.memberId });

    fetch(`/api/member/dashboard/${session.gymId}/${session.memberId}`)
      .then(res => res.json())
      .then(data => {
        if (data && data.member) {
          setMember(data.member);
        }
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchMemberData();
  }, []);

  const handleScanOrSubmit = async (payloadToVerify?: string) => {
    const payload = payloadToVerify || qrCodeInput.trim();
    if (!payload) return;

    setScanStatus('scanning');
    setScanMessage('');

    const sessionStr = localStorage.getItem('member_session');
    if (!sessionStr) return;
    const session = JSON.parse(sessionStr);

    try {
      const res = await fetch('/api/attendance/checkin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          gymId: session.gymId,
          memberId: session.memberId,
          qrPayload: payload,
          method: 'QR_MEMBER'
        })
      });
      const data = await res.json();
      if (data.success) {
        setScanStatus('success');
        setScanMessage('Attendance marked successfully!');
        setQrCodeInput('');
        fetchMemberData();
      } else {
        setScanStatus('error');
        setScanMessage(data.message || 'Invalid or expired QR code.');
      }
    } catch (e) {
      setScanStatus('error');
      setScanMessage('Server error checking in.');
    }
  };

  if (loading) {
    return (
      <MemberLayout>
        <div className="py-20 text-center text-4xl animate-pulse">🏋️</div>
      </MemberLayout>
    );
  }

  return (
    <MemberLayout>
      <div className="px-4 mt-6 space-y-6 pb-10 max-w-xl mx-auto">
        <div>
          <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)]">Attendance</span>
          <h1 className="text-2xl font-black uppercase tracking-wider text-[var(--text)]">Check-In & Calendar</h1>
        </div>

        {/* QR Scan Action Card */}
        <div className="clay-raised p-6 rounded-[28px] space-y-5 text-center">
          <div className="w-14 h-14 rounded-full neo-pressed mx-auto flex items-center justify-center text-[var(--text)]">
            <QrCode size={28} />
          </div>

          <div>
            <h3 className="text-sm font-black uppercase tracking-wider">Reception Attendance QR</h3>
            <p className="text-[11px] text-[var(--text-sec)] font-medium mt-1">
              Scan live QR code displayed at gym reception or upload a photo from gallery
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 pt-1">
            <button
              onClick={() => setIsScannerOpen(true)}
              className="flex-1 h-12 rounded-[16px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 active:scale-95 transition-transform cursor-pointer shadow-md"
            >
              <Camera size={18} /> OPEN CAMERA SCANNER
            </button>
            <button
              onClick={() => setIsScannerOpen(true)}
              className="h-12 px-5 rounded-[16px] neo-raised text-[var(--text)] text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 active:scale-95 transition-transform cursor-pointer"
            >
              <Upload size={18} /> GALLERY
            </button>
          </div>

          {scanStatus === 'success' && (
            <div className="p-3 neo-pressed rounded-[14px] bg-[#34A853]/10 border border-[#34A853]/30 text-[#34A853] text-xs font-bold uppercase flex items-center justify-center gap-2">
              <Check size={16} /> {scanMessage}
            </div>
          )}

          {scanStatus === 'error' && (
            <div className="p-3 neo-pressed rounded-[14px] bg-[#D64545]/10 border border-[#D64545]/30 text-[#D64545] text-xs font-bold uppercase flex items-center justify-center gap-2">
              <AlertCircle size={16} /> {scanMessage}
            </div>
          )}

          {/* Fallback Text Input */}
          <div className="pt-3 border-t border-[var(--border)] space-y-2">
            <span className="text-[10px] font-bold uppercase tracking-wider text-[var(--text-sec)] block text-left">
              Or paste reception payload manually:
            </span>
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="Paste reception QR payload string..."
                value={qrCodeInput}
                onChange={(e) => setQrCodeInput(e.target.value)}
                className="flex-1 h-10 px-3 neo-pressed rounded-[12px] text-xs font-mono font-bold text-[var(--text)] outline-none"
              />
              <button
                onClick={() => handleScanOrSubmit()}
                disabled={!qrCodeInput.trim() || scanStatus === 'scanning'}
                className="h-10 px-4 rounded-[12px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-wider active:scale-95 transition-transform cursor-pointer"
              >
                VERIFY
              </button>
            </div>
          </div>
        </div>

        {/* Member Calendar Component */}
        <MemberAttendanceCalendar
          attendanceRecords={member?.attendanceRecords || []}
          currentStreak={member?.attendanceStreak || 0}
          bestStreak={member?.bestStreak || member?.attendanceStreak || 0}
          lastVisit={member?.lastVisit || 'Today'}
          memberName={member?.fullName}
        />
      </div>

      {/* QR Scanner Modal */}
      {sessionInfo && (
        <MemberQRScannerModal
          isOpen={isScannerOpen}
          onClose={() => setIsScannerOpen(false)}
          gymId={sessionInfo.gymId}
          memberId={sessionInfo.memberId}
          onSuccess={() => {
            fetchMemberData();
            setScanStatus('success');
            setScanMessage('Attendance marked successfully!');
          }}
        />
      )}
    </MemberLayout>
  );
}
