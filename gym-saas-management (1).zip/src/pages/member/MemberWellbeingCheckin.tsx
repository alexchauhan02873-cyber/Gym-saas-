import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from '@/lib/router-compat';
import { motion } from 'motion/react';
import { Heart, ArrowLeft, Check, Calendar, Activity, Sparkles, Loader2, Award } from 'lucide-react';
import MemberLayout from '@/components/MemberLayout';

export default function MemberWellbeingCheckin() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const feelingParam = searchParams.get('feeling');

  const [memberSession, setMemberSession] = useState<any>(null);
  const [selectedFeeling, setSelectedFeeling] = useState<string | null>(feelingParam || null);
  const [saving, setSaving] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [confirmationMsg, setConfirmationMsg] = useState('');
  const [feelingsHistory, setFeelingsHistory] = useState<any[]>([]);
  const [counts, setCounts] = useState<Record<string, number>>({});

  const feelingsOptions = [
    { id: 'GREAT', label: 'Great', desc: 'Energized, strong & feeling fantastic', color: 'border-[#34A853] bg-[#34A853]/10 text-[#34A853]' },
    { id: 'GOOD', label: 'Good', desc: 'Solid workout & feeling positive', color: 'border-blue-500 bg-blue-500/10 text-blue-600 dark:text-blue-400' },
    { id: 'OKAY', label: 'Okay', desc: 'Showed up, average energy', color: 'border-amber-500 bg-amber-500/10 text-amber-600 dark:text-amber-400' },
    { id: 'LOW', label: 'Low', desc: 'Tired or low physical energy', color: 'border-orange-500 bg-orange-500/10 text-orange-600 dark:text-orange-400' },
    { id: 'NOT_GREAT', label: 'Not Great', desc: 'Struggling today, rest prioritized', color: 'border-red-500 bg-red-500/10 text-red-600 dark:text-red-400' },
  ];

  useEffect(() => {
    const raw = localStorage.getItem('member_session');
    if (!raw) {
      navigate('/?mode=code');
      return;
    }
    try {
      const parsed = JSON.parse(raw);
      setMemberSession(parsed);
      fetchHistory(parsed.gymId, parsed.memberId);
    } catch {
      navigate('/?mode=code');
    }
  }, [navigate]);

  useEffect(() => {
    if (feelingParam && memberSession) {
      handleSelectFeeling(feelingParam);
    }
  }, [feelingParam, memberSession]);

  const fetchHistory = async (gymId: string, memberId: string) => {
    try {
      const res = await fetch(`/api/member/feeling/${gymId}/${memberId}`);
      const data = await res.json();
      if (data?.success) {
        setFeelingsHistory(data.feelings || []);
        setCounts(data.counts || {});
      }
    } catch {}
  };

  const handleSelectFeeling = async (feelingId: string) => {
    if (!memberSession) return;
    setSelectedFeeling(feelingId);
    setSaving(true);

    try {
      const res = await fetch('/api/member/feeling', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          memberId: memberSession.memberId,
          gymId: memberSession.gymId,
          feeling: feelingId,
          source: 'APP'
        })
      });
      const data = await res.json();
      if (data?.success) {
        setSavedSuccess(true);
        setConfirmationMsg(data.confirmationMsg || 'Your feeling check-in is saved!');
        fetchHistory(memberSession.gymId, memberSession.memberId);
      }
    } catch {
    } finally {
      setSaving(false);
    }
  };

  return (
    <MemberLayout>
      <div className="max-w-md mx-auto space-y-6 pb-12 animate-fade-in">
        {/* Header Title */}
        <div className="flex items-center justify-between">
          <button
            onClick={() => navigate('/member/dashboard')}
            className="p-2.5 rounded-2xl neo-pressed text-[var(--text-sec)] hover:text-[var(--text)] transition-all cursor-pointer"
          >
            <ArrowLeft size={18} />
          </button>
          <div className="text-center flex-1 pr-10">
            <h1 className="text-base font-black uppercase tracking-wider text-[var(--text)]">Daily Check-In</h1>
            <p className="text-[10px] text-[var(--text-sec)] font-mono uppercase">Mind & Energy Wellbeing</p>
          </div>
        </div>

        {/* Confirmation Banner */}
        {savedSuccess && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="p-5 rounded-[24px] bg-[#34A853]/10 border border-[#34A853]/30 text-center space-y-2"
          >
            <div className="w-10 h-10 rounded-full bg-[#34A853] text-white flex items-center justify-center mx-auto shadow-md">
              <Check size={20} />
            </div>
            <p className="text-xs font-black uppercase tracking-wider text-[#34A853]">Check-In Complete</p>
            <p className="text-xs font-medium text-[var(--text)] leading-relaxed">{confirmationMsg}</p>
          </motion.div>
        )}

        {/* Question Card */}
        <div className="clay-raised p-6 rounded-[28px] space-y-5 border border-[var(--border)] relative overflow-hidden">
          <div className="space-y-1">
            <span className="text-[9px] font-black uppercase tracking-widest text-[#34A853] bg-[#34A853]/10 px-3 py-1 rounded-full">
              TODAY'S WELLBEING
            </span>
            <h2 className="text-lg font-black uppercase tracking-tight text-[var(--text)] pt-1">How do you feel today?</h2>
            <p className="text-xs text-[var(--text-sec)]">
              Self-reported check-in to track energy levels and personalize your reminders.
            </p>
          </div>

          <div className="space-y-3">
            {feelingsOptions.map((opt) => {
              const isSelected = selectedFeeling === opt.id;
              return (
                <button
                  key={opt.id}
                  onClick={() => handleSelectFeeling(opt.id)}
                  disabled={saving}
                  className={`w-full p-4 rounded-[20px] transition-all cursor-pointer flex items-center justify-between text-left border-2 ${
                    isSelected
                      ? opt.color + ' neo-raised font-bold'
                      : 'neo-pressed border-[var(--border)] hover:border-[var(--text-sec)]'
                  }`}
                >
                  <div className="space-y-0.5">
                    <p className="text-xs font-black uppercase tracking-wider">{opt.label}</p>
                    <p className="text-[10px] text-[var(--text-sec)]">{opt.desc}</p>
                  </div>
                  {isSelected && (
                    <div className="w-6 h-6 rounded-full bg-[#34A853] text-white flex items-center justify-center shrink-0">
                      <Check size={14} />
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* History Summary */}
        <div className="clay-raised p-6 rounded-[28px] space-y-4 border border-[var(--border)]">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Activity size={18} className="text-[#34A853]" />
              <h3 className="text-xs font-black uppercase tracking-widest text-[var(--text)]">Check-In History</h3>
            </div>
            <span className="text-[10px] font-mono font-bold text-[var(--text-sec)]">{feelingsHistory.length} Recorded</span>
          </div>

          <div className="grid grid-cols-5 gap-2 text-center">
            {feelingsOptions.map((opt) => (
              <div key={opt.id} className="p-2.5 rounded-[16px] neo-pressed space-y-1">
                <span className="text-[8px] font-black uppercase tracking-wider block text-[var(--text-sec)] truncate">{opt.label}</span>
                <span className="text-sm font-black text-[var(--text)]">{counts[opt.id] || 0}</span>
              </div>
            ))}
          </div>

          {feelingsHistory.length > 0 ? (
            <div className="space-y-2 pt-2">
              <p className="text-[10px] font-black uppercase tracking-wider text-[var(--text-sec)]">Recent Logs</p>
              <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                {feelingsHistory.slice(0, 10).map((item) => (
                  <div key={item.id} className="p-3 neo-pressed rounded-[16px] flex items-center justify-between text-xs">
                    <span className="font-mono text-[10px] text-[var(--text-sec)]">{item.date}</span>
                    <span className="font-black text-[11px] uppercase text-[#34A853]">{item.feeling}</span>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <p className="text-xs text-[var(--text-sec)] text-center py-4 font-mono">No previous check-ins recorded yet.</p>
          )}
        </div>
      </div>
    </MemberLayout>
  );
}
