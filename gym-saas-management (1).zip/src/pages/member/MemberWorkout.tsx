import React, { useState, useEffect } from 'react';
import { useNavigate } from '@/lib/router-compat';
import { Dumbbell, CheckCircle2, Clock, AlertCircle, RefreshCw, Check } from 'lucide-react';
import MemberLayout from '../../components/MemberLayout';

export default function MemberWorkout() {
  const navigate = useNavigate();
  const [workout, setWorkout] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [completingExId, setCompletingExId] = useState<string | null>(null);

  const fetchWorkout = async () => {
    const sessionStr = localStorage.getItem('member_session');
    if (!sessionStr) { navigate('/'); return; }
    const session = JSON.parse(sessionStr);

    try {
      const res = await fetch(`/api/workout/${session.gymId}/${session.memberId}`);
      const data = await res.json();
      if (data && data.success && data.workout) {
        setWorkout(data.workout);
      } else {
        setWorkout(null);
      }
    } catch (err) {
      console.error('Error fetching workout:', err);
      setWorkout(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchWorkout();
  }, []);

  const handleToggleExercise = async (exerciseId: string, currentStatus: boolean) => {
    if (!workout) return;
    setCompletingExId(exerciseId);

    const updatedExercises = (workout.exercises || []).map((ex: any) => {
      if (ex.id === exerciseId) return { ...ex, completed: !currentStatus };
      return ex;
    });

    setWorkout({ ...workout, exercises: updatedExercises });

    const sessionStr = localStorage.getItem('member_session');
    if (!sessionStr) return;
    const session = JSON.parse(sessionStr);

    try {
      await fetch(`/api/members/${session.gymId}/${session.memberId}/workout`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: workout.name || workout.title,
          goal: workout.goal,
          exercises: updatedExercises
        })
      });
    } catch (err) {
      console.error(err);
    } finally {
      setCompletingExId(null);
    }
  };

  if (loading) {
    return (
      <MemberLayout>
        <div className="py-20 text-center text-3xl animate-pulse">🏋️ Loading Workout...</div>
      </MemberLayout>
    );
  }

  const exercises = workout?.exercises || [];
  const completedCount = exercises.filter((e: any) => e.completed).length;

  return (
    <MemberLayout>
      <div className="px-4 mt-6 space-y-6 pb-12">
        {/* Header Title */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-black uppercase tracking-wider text-[var(--text)]">Today's Workout</h1>
            <p className="text-[10px] text-[var(--text-sec)] font-bold uppercase tracking-widest mt-0.5">
              Owner & Trainer Assigned Routine
            </p>
          </div>
          <button
            onClick={fetchWorkout}
            className="w-9 h-9 rounded-full neo-raised flex items-center justify-center text-[var(--text-sec)] hover:text-[var(--text)] active:scale-95 transition-transform"
          >
            <RefreshCw size={15} />
          </button>
        </div>

        {workout && exercises.length > 0 ? (
          <div className="space-y-4">
            {/* Workout Summary Card */}
            <div className="clay-raised p-6 rounded-[28px] space-y-3 relative overflow-hidden">
              <div className="flex justify-between items-start">
                <span className="text-[9px] font-black uppercase tracking-widest text-[#34A853] bg-[#34A853]/10 px-3 py-1 rounded-full border border-[#34A853]/20">
                  ASSIGNED BY GYM TRAINER
                </span>
                <span className="text-[10px] font-mono font-bold text-[var(--text-sec)]">
                  {completedCount} / {exercises.length} Completed
                </span>
              </div>

              <div>
                <h2 className="text-xl font-black uppercase tracking-wider text-[var(--text)]">
                  {workout.name || workout.title || 'Daily Training Program'}
                </h2>
                {workout.goal && (
                  <p className="text-xs font-semibold text-[var(--text-sec)] uppercase tracking-wider mt-0.5">
                    Goal: {workout.goal}
                  </p>
                )}
              </div>

              {/* Progress Bar */}
              <div className="w-full bg-[var(--surface)] h-2 rounded-full overflow-hidden neo-pressed">
                <div 
                  className="bg-[#34A853] h-full transition-all duration-300 rounded-full" 
                  style={{ width: `${exercises.length > 0 ? (completedCount / exercises.length) * 100 : 0}%` }}
                />
              </div>
            </div>

            {/* Exercise List */}
            <div className="space-y-3">
              <h3 className="text-xs font-black uppercase tracking-wider text-[var(--text)] px-1">
                Exercise Prescription ({exercises.length})
              </h3>
              {exercises.map((ex: any, idx: number) => {
                const isDone = !!ex.completed;
                return (
                  <div 
                    key={ex.id || idx} 
                    className={`neo-raised p-4 rounded-[22px] flex items-center justify-between gap-3 transition-all ${
                      isDone ? 'opacity-80 bg-[var(--surface)]' : ''
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <button
                        onClick={() => handleToggleExercise(ex.id || `e${idx}`, isDone)}
                        disabled={completingExId === ex.id}
                        className={`w-9 h-9 rounded-full flex items-center justify-center transition-transform active:scale-95 shrink-0 ${
                          isDone 
                            ? 'bg-[#34A853] text-white shadow-md' 
                            : 'neo-pressed text-[var(--text-sec)] hover:text-[var(--text)]'
                        }`}
                      >
                        {isDone ? <Check size={18} className="stroke-[3]" /> : <span className="font-mono text-xs font-bold">{idx + 1}</span>}
                      </button>
                      <div>
                        <h4 className={`text-xs font-black uppercase ${isDone ? 'line-through text-[var(--text-sec)]' : 'text-[var(--text)]'}`}>
                          {ex.name}
                        </h4>
                        <p className="text-[10px] text-[var(--text-sec)] font-mono mt-0.5">
                          {ex.targetArea || 'Target Area'} • Rest: {ex.rest || '60s'}
                        </p>
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <span className="text-xs font-black font-mono text-[var(--text)]">{ex.sets} SETS × {ex.reps}</span>
                      {ex.weight && (
                        <span className="text-[9px] font-bold text-amber-500 uppercase block mt-0.5">{ex.weight}</span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ) : (
          /* Empty State - OWNER ASSIGNED ONLY */
          <div className="neo-pressed p-8 rounded-[28px] text-center space-y-3 my-4">
            <div className="w-14 h-14 rounded-full neo-raised mx-auto flex items-center justify-center text-[var(--text-sec)]">
              <Dumbbell size={28} />
            </div>
            <div>
              <h3 className="text-sm font-black uppercase tracking-wider text-[var(--text)]">No Workout Assigned Yet</h3>
              <p className="text-xs text-[var(--text-sec)] font-medium max-w-xs mx-auto mt-1 leading-relaxed">
                Your gym owner or trainer has not assigned a workout routine for today yet. Please consult your gym instructor.
              </p>
            </div>
          </div>
        )}
      </div>
    </MemberLayout>
  );
}
