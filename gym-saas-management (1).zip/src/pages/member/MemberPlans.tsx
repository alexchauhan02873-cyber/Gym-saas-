import React, { useEffect, useState } from 'react';
import { useNavigate } from '@/lib/router-compat';
import { 
  CreditCard, ShieldCheck, CheckCircle2, Clock, AlertCircle, 
  QrCode, Copy, ExternalLink, ArrowRight, Sparkles, Check, RefreshCw
} from 'lucide-react';
import MemberLayout from '../../components/MemberLayout';

export default function MemberPlans() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [memberData, setMemberData] = useState<any>(null);
  const [plans, setPlans] = useState<any[]>([]);
  const [upiSettings, setUpiSettings] = useState<any>(null);

  // Modal State
  const [selectedPlan, setSelectedPlan] = useState<any>(null);
  const [paymentStep, setPaymentStep] = useState<'SUMMARY' | 'PAYMENT'>('SUMMARY');
  const [utrNumber, setUtrNumber] = useState('');
  const [submittingPayment, setSubmittingPayment] = useState(false);
  const [paymentSuccessMsg, setPaymentSuccessMsg] = useState('');
  const [paymentErrMsg, setPaymentErrMsg] = useState('');
  const [copiedUpi, setCopiedUpi] = useState(false);

  const loadData = async () => {
    const sessionStr = localStorage.getItem('member_session');
    if (!sessionStr) {
      navigate('/');
      return;
    }
    const session = JSON.parse(sessionStr);

    try {
      const [mRes, pRes, uRes] = await Promise.all([
        fetch(`/api/members/${session.gymId}/${session.memberId}`),
        fetch(`/api/plans/public/${session.gymId}`).catch(() => fetch(`/api/plans/${session.gymId}`)),
        fetch(`/api/gym-payment-settings/${session.gymId}`),
      ]);

      const mData = await mRes.json();
      const pData = await pRes.json();
      const uData = await uRes.json();

      setMemberData(mData);
      if (pData) {
        if (Array.isArray(pData.plans)) setPlans(pData.plans);
        else if (Array.isArray(pData)) setPlans(pData);
        if (pData.paymentSettings) setUpiSettings(pData.paymentSettings);
      }
      if (uData && uData.paymentSettings) setUpiSettings(uData.paymentSettings);
    } catch (err) {
      console.error('Error loading plans data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleCopyUpi = () => {
    if (upiSettings?.upiId) {
      navigator.clipboard.writeText(upiSettings.upiId);
      setCopiedUpi(true);
      setTimeout(() => setCopiedUpi(false), 2000);
    }
  };

  const handleSelectPlan = (plan: any) => {
    setSelectedPlan(plan);
    setPaymentStep('SUMMARY');
    setPaymentErrMsg('');
    setPaymentSuccessMsg('');
    setUtrNumber('');
  };

  const handleSubmitUpiPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPlan) return;

    const sessionStr = localStorage.getItem('member_session');
    if (!sessionStr) return;
    const session = JSON.parse(sessionStr);

    setSubmittingPayment(true);
    setPaymentErrMsg('');
    try {
      const res = await fetch('/api/payments/create-pending', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          gymId: session.gymId,
          memberId: session.memberId,
          planId: selectedPlan.id,
          amount: selectedPlan.price,
          utrNumber,
          paymentMode: 'UPI',
        }),
      });
      const d = await res.json();
      if (d && d.success) {
        setPaymentSuccessMsg(d.message || 'Payment Submitted for Verification. Your gym owner will verify and activate your plan.');
        setTimeout(() => {
          setSelectedPlan(null);
          setPaymentSuccessMsg('');
          setPaymentStep('SUMMARY');
          setUtrNumber('');
          loadData();
        }, 3500);
      } else {
        setPaymentErrMsg(d?.message || 'Payment submission failed. Please try again.');
      }
    } catch (err) {
      console.error('Payment error:', err);
      setPaymentErrMsg('Payment submission failed. Please check network connection and try again.');
    } finally {
      setSubmittingPayment(false);
    }
  };

  if (loading) {
    return (
      <MemberLayout>
        <div className="py-20 text-center text-3xl animate-pulse">💳 Loading Membership Plans...</div>
      </MemberLayout>
    );
  }

  const daysRemaining = memberData?.daysRemaining ?? 30;
  const currentStatus = (memberData?.status || 'ACTIVE').toUpperCase();

  return (
    <MemberLayout>
      <div className="px-4 mt-6 space-y-6 pb-12">
        {/* Header Title */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-black uppercase tracking-wider text-[var(--text)]">Membership Plans</h1>
            <p className="text-[10px] text-[var(--text-sec)] font-bold uppercase tracking-widest mt-0.5">
              {memberData?.gymName || 'Gym'} • Manage & Renew
            </p>
          </div>
          <button 
            onClick={loadData}
            className="w-9 h-9 rounded-full neo-raised flex items-center justify-center text-[var(--text-sec)] hover:text-[var(--text)] active:scale-95 transition-transform"
          >
            <RefreshCw size={15} />
          </button>
        </div>

        {/* Section A: CURRENT PLAN */}
        <div className="neo-raised p-6 rounded-[28px] space-y-4 relative overflow-hidden">
          <div className="flex justify-between items-start">
            <span className="text-[9px] font-black uppercase tracking-widest text-[#34A853] bg-[#34A853]/10 px-3 py-1 rounded-full border border-[#34A853]/20">
              SECTION A • YOUR CURRENT PLAN
            </span>
            <span className={`text-[9px] font-black uppercase px-2.5 py-0.5 rounded-full ${
              currentStatus === 'ACTIVE' ? 'bg-[#34A853] text-white' : 'bg-[#E3A008] text-black'
            }`}>
              {currentStatus}
            </span>
          </div>

          <div>
            <h2 className="text-2xl font-black uppercase tracking-wide text-[var(--text)]">
              {memberData?.planName || 'Standard Membership'}
            </h2>
            <p className="text-xs text-[var(--text-sec)] font-mono mt-1">
              Valid until: <span className="text-[var(--text)] font-bold">{memberData?.endDate || memberData?.membershipExpiry || 'Active'}</span>
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3 pt-1">
            <div className="p-3.5 neo-pressed rounded-[20px] flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-[#34A853]/10 text-[#34A853] flex items-center justify-center font-bold">
                <Clock size={18} />
              </div>
              <div>
                <span className="text-[9px] font-bold uppercase text-[var(--text-sec)] block">Days Remaining</span>
                <span className="text-sm font-black font-mono text-[var(--text)]">{daysRemaining} Days</span>
              </div>
            </div>

            <div className="p-3.5 neo-pressed rounded-[20px] flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-amber-500/10 text-amber-500 flex items-center justify-center font-bold">
                <ShieldCheck size={18} />
              </div>
              <div>
                <span className="text-[9px] font-bold uppercase text-[var(--text-sec)] block">Member Access</span>
                <span className="text-sm font-black uppercase text-[var(--text)]">Unrestricted</span>
              </div>
            </div>
          </div>
        </div>

        {/* Section B: AVAILABLE GYM PLANS */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-black uppercase tracking-wider text-[var(--text)] flex items-center gap-2">
              <Sparkles size={16} className="text-amber-500" /> Section B • Available Gym Plans
            </h2>
            <span className="text-[10px] text-[var(--text-sec)] font-mono">{plans.length} Available</span>
          </div>

          {plans.length === 0 ? (
            <div className="neo-pressed p-8 rounded-[24px] text-center space-y-2">
              <AlertCircle size={32} className="mx-auto text-[var(--text-sec)]" />
              <p className="text-xs font-bold uppercase text-[var(--text-sec)]">No membership plans published yet</p>
              <p className="text-[10px] text-[var(--text-sec)]">Contact your gym reception to inquire about plans.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {plans.map((plan) => (
                <div key={plan.id} className="neo-raised p-5 rounded-[24px] space-y-3 relative">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="text-base font-black uppercase tracking-wider text-[var(--text)]">{plan.planName}</h3>
                      <p className="text-xs text-[var(--text-sec)] font-semibold mt-0.5">
                        Duration: {plan.duration} {plan.durationUnit || 'Days'}
                      </p>
                    </div>
                    <div className="text-right">
                      <span className="text-xl font-black font-mono text-[var(--text)]">₹{plan.price}</span>
                    </div>
                  </div>

                  {plan.description && (
                    <p className="text-xs text-[var(--text-sec)] leading-relaxed">{plan.description}</p>
                  )}

                  <div className="pt-2 border-t border-[var(--border)] flex justify-end">
                    <button
                      onClick={() => handleSelectPlan(plan)}
                      className="h-10 px-5 rounded-[14px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-wider flex items-center gap-2 cursor-pointer active:scale-95 transition-transform"
                    >
                      Buy Now / Renew <ArrowRight size={14} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* BUY PLAN / GYM UPI PAYMENT MODAL */}
        {selectedPlan && (
          <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
            <div className="w-full max-w-md bg-[var(--surface)] rounded-[32px] neo-raised p-6 space-y-5 border border-[var(--border)] max-h-[90vh] overflow-y-auto">
              {/* Header */}
              <div className="flex justify-between items-center border-b border-[var(--border)] pb-3">
                <div>
                  <h3 className="text-base font-black uppercase tracking-wider text-[var(--text)]">
                    {paymentStep === 'SUMMARY' ? 'Confirm Plan Purchase' : `Pay ${memberData?.gymName || 'Gym'}`}
                  </h3>
                  <p className="text-[10px] text-[var(--text-sec)] uppercase font-bold">
                    {paymentStep === 'SUMMARY' ? 'Step 1 of 2 • Order Summary' : 'Step 2 of 2 • Direct Gym UPI Transfer'}
                  </p>
                </div>
                <button
                  onClick={() => { setSelectedPlan(null); setPaymentSuccessMsg(''); setPaymentErrMsg(''); }}
                  className="w-8 h-8 rounded-full neo-pressed flex items-center justify-center text-[var(--text-sec)] hover:text-[var(--text)] text-xs font-bold cursor-pointer"
                >
                  ✕
                </button>
              </div>

              {/* Success Message Banner */}
              {paymentSuccessMsg ? (
                <div className="p-5 bg-[#34A853]/10 border border-[#34A853]/30 rounded-[24px] text-center space-y-3">
                  <CheckCircle2 size={36} className="mx-auto text-[#34A853]" />
                  <p className="text-sm font-black uppercase text-[#34A853]">{paymentSuccessMsg}</p>
                  <p className="text-[11px] text-[var(--text-sec)]">
                    Status: <strong className="text-amber-500 font-mono">PENDING VERIFICATION</strong>
                  </p>
                </div>
              ) : paymentStep === 'SUMMARY' ? (
                /* STAGE 1: PLAN CONFIRMATION SUMMARY */
                <div className="space-y-4">
                  <div className="p-4 neo-pressed rounded-[20px] space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-[var(--text-sec)]">Gym Name</span>
                      <span className="text-xs font-black uppercase text-[var(--text)]">{memberData?.gymName || 'Gym'}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-[var(--text-sec)]">Selected Plan</span>
                      <span className="text-xs font-black uppercase text-[var(--text)]">{selectedPlan.planName}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-[var(--text-sec)]">Plan Duration</span>
                      <span className="text-xs font-black text-[var(--text)] font-mono">
                        {selectedPlan.duration || selectedPlan.durationValue || 30} {selectedPlan.durationUnit || 'Days'}
                      </span>
                    </div>
                    <div className="flex justify-between items-center border-t border-[var(--border)] pt-2">
                      <span className="text-xs font-black uppercase tracking-wider text-[var(--text)]">Total Amount</span>
                      <span className="text-xl font-black font-mono text-[#34A853]">₹{selectedPlan.price}</span>
                    </div>
                  </div>

                  <div className="flex gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => setSelectedPlan(null)}
                      className="w-1/3 h-12 rounded-[18px] neo-raised text-xs font-bold uppercase cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={() => setPaymentStep('PAYMENT')}
                      className="w-2/3 h-12 rounded-[18px] bg-[#34A853] text-white text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 shadow-md active:scale-95 transition-transform cursor-pointer"
                    >
                      Continue to Payment <ArrowRight size={16} />
                    </button>
                  </div>
                </div>
              ) : (
                /* STAGE 2: PAYMENT STEP */
                <>
                  {/* Selected Plan Summary Bar */}
                  <div className="p-3.5 neo-pressed rounded-[20px] flex justify-between items-center">
                    <div>
                      <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Selected Plan</span>
                      <span className="text-xs font-black uppercase text-[var(--text)]">{selectedPlan.planName}</span>
                    </div>
                    <span className="text-lg font-black font-mono text-[#34A853]">₹{selectedPlan.price}</span>
                  </div>

                  {/* Error Message */}
                  {paymentErrMsg && (
                    <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-[18px] text-red-500 text-xs font-bold flex items-center gap-2">
                      <AlertCircle size={16} className="shrink-0" />
                      <span>{paymentErrMsg}</span>
                    </div>
                  )}

                  {/* UPI Details */}
                  {!upiSettings || !upiSettings.upiId ? (
                    <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-[20px] space-y-2 text-center">
                      <AlertCircle size={24} className="mx-auto text-amber-500" />
                      <p className="text-xs font-bold uppercase text-amber-500">Online payment not configured</p>
                      <p className="text-[10px] text-[var(--text-sec)]">
                        Your gym owner has not added their UPI ID yet. Please pay in person at the gym reception desk.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {/* UPI ID Copy Box */}
                      <div className="p-4 neo-raised rounded-[20px] space-y-2">
                        <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Gym UPI ID</span>
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-mono text-sm font-black text-[var(--text)] select-all">{upiSettings.upiId}</span>
                          <button
                            type="button"
                            onClick={handleCopyUpi}
                            className="h-8 px-3 rounded-full neo-pressed text-[10px] font-bold uppercase flex items-center gap-1 active:scale-95 transition-transform cursor-pointer"
                          >
                            {copiedUpi ? <Check size={12} className="text-[#34A853]" /> : <Copy size={12} />}
                            {copiedUpi ? 'Copied' : 'Copy'}
                          </button>
                        </div>
                        {upiSettings.upiDisplayName && (
                          <p className="text-[10px] text-[var(--text-sec)] uppercase font-semibold">
                            Account Name: {upiSettings.upiDisplayName}
                          </p>
                        )}
                      </div>

                      {/* Direct UPI App Launch Link */}
                      <a
                        href={`upi://pay?pa=${encodeURIComponent(upiSettings.upiId)}&pn=${encodeURIComponent(upiSettings.upiDisplayName || memberData?.gymName || 'Gym')}&am=${selectedPlan.price}&tn=${encodeURIComponent('Membership Plan Renewal')}`}
                        className="w-full h-11 rounded-[16px] bg-[#34A853] text-white text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 shadow-md active:scale-95 transition-transform"
                      >
                        <ExternalLink size={16} /> Open UPI App to Pay ₹{selectedPlan.price}
                      </a>

                      {/* Form for UTR Entry */}
                      <form onSubmit={handleSubmitUpiPayment} className="space-y-3 pt-2">
                        <div>
                          <label className="text-[10px] font-bold uppercase tracking-wider text-[var(--text-sec)] block mb-1">
                            Transaction UTR / Reference Number (Optional)
                          </label>
                          <input
                            type="text"
                            value={utrNumber}
                            onChange={(e) => setUtrNumber(e.target.value)}
                            placeholder="e.g. 426819204851"
                            className="w-full h-11 px-4 rounded-[16px] neo-pressed text-xs font-mono border-none focus:outline-none focus:ring-2 focus:ring-[var(--text)]"
                          />
                        </div>

                        <p className="text-[9px] text-[var(--text-sec)] text-center leading-relaxed">
                          Payment will be submitted for verification. Your gym owner will confirm and activate your plan.
                        </p>

                        <div className="flex gap-2 pt-1">
                          <button
                            type="button"
                            onClick={() => setPaymentStep('SUMMARY')}
                            disabled={submittingPayment}
                            className="w-1/3 h-12 rounded-[20px] neo-raised text-xs font-bold uppercase cursor-pointer disabled:opacity-50"
                          >
                            Back
                          </button>
                          <button
                            type="submit"
                            disabled={submittingPayment}
                            className="w-2/3 h-12 rounded-[20px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer active:scale-95 transition-transform disabled:opacity-50"
                          >
                            {submittingPayment ? (
                              'Submitting Payment...'
                            ) : paymentErrMsg ? (
                              'Retry Submission'
                            ) : (
                              'Confirm Payment Submitted'
                            )}
                          </button>
                        </div>
                      </form>
                    </div>
                  )}
                </>
              )}
            </div>
          </div>
        )}
      </div>
    </MemberLayout>
  );
}
