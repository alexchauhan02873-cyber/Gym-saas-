import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Trophy, Flame, Award, TrendingUp, Calendar, CheckCircle2, 
  Target, Shield, EyeOff, Loader2
} from 'lucide-react';
import MemberLayout from '@/components/MemberLayout';

export default function MemberAnalytics() {
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<any>(null);

  const fetchAnalytics = async () => {
    const sessionStr = localStorage.getItem('member_session');
    if (!sessionStr) return;
    try {
      const session = JSON.parse(sessionStr);
      const res = await fetch(`/api/member/analytics/${session.gymId}/${session.memberId}`);
      const d = await res.json();
      if (d && d.success) {
        setData(d.analytics);
      }
    } catch (err) {
      console.error('Analytics fetch error:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAnalytics();
  }, []);

  if (loading) {
    return (
      <MemberLayout>
        <div className="p-6 flex flex-col items-center justify-center min-h-[60vh]">
          <Loader2 size={32} className="animate-spin text-[var(--text-sec)]" />
          <p className="text-xs font-bold uppercase tracking-widest text-[var(--text-sec)] mt-3">Loading Member Performance...</p>
        </div>
      </MemberLayout>
    );
  }

  const {
    level = 1,
    tier = 'BRONZE',
    levelTitle = 'BRONZE ATHLETE',
    progressPercent = 20,
    totalActivities = 5,
    activitiesToNextLevel = 10,
    currentStreak = 0,
    bestStreak = 0,
    attendancePercent = 0,
    workoutCompletionPct = 0,
    taskCompletionPct = 0,
    monthlyScore = 0,
    gymRank = 1,
    totalGymMembers = 1,
    achievements = [],
    leaderboard = []
  } = data || {};

  const getTierColor = (t: string) => {
    switch (t) {
      case 'MASTER': return 'text-purple-500 border-purple-500/30 bg-purple-500/10';
      case 'ELITE': return 'text-red-500 border-red-500/30 bg-red-500/10';
      case 'DIAMOND': return 'text-cyan-500 border-cyan-500/30 bg-cyan-500/10';
      case 'GOLD': return 'text-amber-500 border-amber-500/30 bg-amber-500/10';
      case 'SILVER': return 'text-slate-400 border-slate-400/30 bg-slate-400/10';
      default: return 'text-amber-700 border-amber-700/30 bg-amber-700/10';
    }
  };

  return (
    <MemberLayout>
      <div className="p-4 sm:p-6 space-y-6">
        {/* Page Title */}
        <div>
          <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block mb-0.5">
            MEMBER PERFORMANCE & RANKING
          </span>
          <h1 className="text-xl font-black uppercase tracking-wider text-[var(--text)]">
            ANALYTICS & LEADERBOARD
          </h1>
        </div>

        {/* Level & Tier Hero Banner */}
        <div className="clay-raised p-6 rounded-[28px] border border-[var(--border)] relative overflow-hidden space-y-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`w-14 h-14 rounded-2xl neo-pressed flex items-center justify-center border ${getTierColor(tier)}`}>
                <Award size={28} />
              </div>
              <div>
                <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">
                  Level {level} Athlete
                </span>
                <h2 className="text-base font-black uppercase tracking-wide text-[var(--text)]">
                  {tier} ATHLETE
                </h2>
                <p className="text-[10px] text-[var(--text-sec)] font-mono">{levelTitle}</p>
              </div>
            </div>

            <div className="text-right">
              <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Gym Rank</span>
              <span className="text-xl font-black text-[#34A853] font-mono">
                #{gymRank} <span className="text-xs text-[var(--text-sec)] font-normal">/ {totalGymMembers}</span>
              </span>
            </div>
          </div>

          {/* Level Progress Bar */}
          <div className="space-y-1.5 pt-2">
            <div className="flex justify-between text-[10px] font-mono font-bold uppercase text-[var(--text-sec)]">
              <span>Tier Progress ({totalActivities} Completed)</span>
              <span>{activitiesToNextLevel} to Next Tier</span>
            </div>
            <div className="h-3 w-full bg-[var(--surface-sec)] neo-pressed rounded-full overflow-hidden p-0.5 border border-[var(--border)]">
              <motion.div
                className="h-full bg-gradient-to-r from-[#34A853] to-[#4285F4] rounded-full"
                initial={{ width: 0 }}
                animate={{ width: `${Math.min(100, Math.max(5, progressPercent))}%` }}
                transition={{ duration: 0.8 }}
              />
            </div>
          </div>
        </div>

        {/* Streaks & Monthly Performance */}
        <div className="grid grid-cols-2 gap-4">
          <div className="clay-raised p-5 rounded-[24px] border border-[var(--border)] space-y-2">
            <div className="flex items-center gap-2 text-[#EA4335]">
              <Flame size={20} />
              <span className="text-[10px] font-bold uppercase tracking-wider text-[var(--text-sec)]">Current Streak</span>
            </div>
            <div className="flex items-baseline gap-1">
              <span className="text-2xl font-black font-mono text-[var(--text)]">{currentStreak}</span>
              <span className="text-xs font-bold uppercase text-[var(--text-sec)]">Days</span>
            </div>
            <p className="text-[9px] font-mono text-[var(--text-sec)]">Best: {bestStreak} Days</p>
          </div>

          <div className="clay-raised p-5 rounded-[24px] border border-[var(--border)] space-y-2">
            <div className="flex items-center gap-2 text-[#4285F4]">
              <TrendingUp size={20} />
              <span className="text-[10px] font-bold uppercase tracking-wider text-[var(--text-sec)]">Monthly Score</span>
            </div>
            <div className="flex items-baseline gap-1">
              <span className="text-2xl font-black font-mono text-[var(--text)]">{Math.round(monthlyScore)}</span>
              <span className="text-xs font-bold uppercase text-[var(--text-sec)]">Pts</span>
            </div>
            <p className="text-[9px] font-mono text-[var(--text-sec)]">Top {Math.max(1, Math.round((gymRank / totalGymMembers) * 100))}% Discipline</p>
          </div>
        </div>

        {/* Performance Breakdown % */}
        <div className="clay-raised p-6 rounded-[28px] border border-[var(--border)] space-y-4">
          <h3 className="text-xs font-black uppercase tracking-wider text-[var(--text)]">
            Performance Breakdown
          </h3>

          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-[10px] font-mono font-bold uppercase text-[var(--text-sec)] mb-1">
                <span className="flex items-center gap-1.5"><Calendar size={13} /> Attendance Rate</span>
                <span>{attendancePercent}%</span>
              </div>
              <div className="h-2 w-full bg-[var(--surface-sec)] neo-pressed rounded-full overflow-hidden border border-[var(--border)]">
                <div className="h-full bg-[#34A853]" style={{ width: `${attendancePercent}%` }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-[10px] font-mono font-bold uppercase text-[var(--text-sec)] mb-1">
                <span className="flex items-center gap-1.5"><Target size={13} /> Workout Completion</span>
                <span>{workoutCompletionPct}%</span>
              </div>
              <div className="h-2 w-full bg-[var(--surface-sec)] neo-pressed rounded-full overflow-hidden border border-[var(--border)]">
                <div className="h-full bg-[#4285F4]" style={{ width: `${workoutCompletionPct}%` }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-[10px] font-mono font-bold uppercase text-[var(--text-sec)] mb-1">
                <span className="flex items-center gap-1.5"><CheckCircle2 size={13} /> Task Consistency</span>
                <span>{taskCompletionPct}%</span>
              </div>
              <div className="h-2 w-full bg-[var(--surface-sec)] neo-pressed rounded-full overflow-hidden border border-[var(--border)]">
                <div className="h-full bg-[#FBBC05]" style={{ width: `${taskCompletionPct}%` }} />
              </div>
            </div>
          </div>
        </div>

        {/* GYM LEADERBOARD */}
        <div className="clay-raised p-6 rounded-[28px] border border-[var(--border)] space-y-4">
          <div className="flex items-center justify-between border-b border-[var(--border)] pb-3">
            <div>
              <h3 className="text-xs font-black uppercase tracking-wider text-[var(--text)] flex items-center gap-2">
                <Trophy size={18} className="text-[#FBBC05]" /> Gym Discipline Leaderboard
              </h3>
              <p className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)]">
                Calculated from attendance & workout consistency
              </p>
            </div>
          </div>

          <div className="space-y-2.5">
            {leaderboard.map((member: any) => (
              <div
                key={member.memberId}
                className={`p-3.5 rounded-[20px] flex items-center justify-between transition-all ${
                  member.isSelf
                    ? 'bg-[#34A853]/10 border-2 border-[#34A853]'
                    : 'neo-pressed border border-[var(--border)]'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-7 h-7 rounded-full flex items-center justify-center font-black font-mono text-xs ${
                    member.rank === 1 ? 'bg-[#FBBC05] text-black' :
                    member.rank === 2 ? 'bg-slate-300 text-black' :
                    member.rank === 3 ? 'bg-amber-700 text-white' :
                    'neo-raised text-[var(--text-sec)]'
                  }`}>
                    {member.rank}
                  </div>

                  <div className="flex items-center gap-2.5">
                    {member.profileImage ? (
                      <img src={member.profileImage} alt="" className="w-8 h-8 rounded-full object-cover border border-[var(--border)]" />
                    ) : (
                      <div className="w-8 h-8 rounded-full bg-[var(--surface-sec)] flex items-center justify-center text-[10px] font-bold text-[var(--text-sec)]">
                        {member.displayName === "Anonymous Gym Member" ? <EyeOff size={14} /> : member.displayName.charAt(0)}
                      </div>
                    )}

                    <div>
                      <p className={`text-xs font-black uppercase ${member.isSelf ? 'text-[#34A853]' : 'text-[var(--text)]'}`}>
                        {member.displayName} {member.isSelf && '(You)'}
                      </p>
                      <p className="text-[9px] text-[var(--text-sec)] font-mono">
                        Score: {member.score} pts
                      </p>
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-[10px] font-black font-mono text-[var(--text-sec)] uppercase">
                    Rank #{member.rank}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </MemberLayout>
  );
}
