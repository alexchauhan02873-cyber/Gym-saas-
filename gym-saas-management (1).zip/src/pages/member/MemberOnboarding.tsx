import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from '@/lib/router-compat';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Sparkles, Dumbbell, Heart, Bell, ArrowRight, ArrowLeft, Check, Loader2, 
  Shield, Camera, Trash2, Lock, Building2, Calendar, User, Phone, MapPin, 
  Trophy, Flame, Activity, Zap, Award, Eye, EyeOff, Smartphone, Clock
} from 'lucide-react';
import LanguageSelector from '@/components/LanguageSelector';
import { getStoredLanguage, type Language } from '@/lib/i18n';

interface MemberData {
  gymId: string;
  memberId: string;
  token?: string;
  gymName?: string;
}

export default function MemberOnboarding() {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [lang, setLang] = useState<Language>(getStoredLanguage());
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [completedCelebration, setCompletedCelebration] = useState(false);

  // Session & Gym Member State
  const [memberSession, setMemberSession] = useState<MemberData | null>(null);
  const [gymDetails, setGymDetails] = useState<any>(null);
  const [originalMember, setOriginalMember] = useState<any>(null);

  // Editable Profile Fields (Prefilled from Owner)
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [age, setAge] = useState('');
  const [dob, setDob] = useState('');
  const [gender, setGender] = useState('Male');
  const [location, setLocation] = useState('');
  const [profileImage, setProfileImage] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Fitness Questionnaire State
  const [physiqueGoal, setPhysiqueGoal] = useState('Athletic / Built');
  const [primaryGoal, setPrimaryGoal] = useState('Muscle Gain');
  const [trainingFocus, setTrainingFocus] = useState('Hypertrophy & Strength');
  const [activityLevel, setActivityLevel] = useState('Intermediate');
  const [sessionPreference, setSessionPreference] = useState('Standard 60 Mins');
  const [lifestyleActivity, setLifestyleActivity] = useState('Lightly Active');

  // Gym Timing & Schedule
  const [preferredTrainingTime, setPreferredTrainingTime] = useState('07:00 AM');
  const [timingSaved, setTimingSaved] = useState(false);
  const [pushSubscribed, setPushSubscribed] = useState(false);

  // Privacy Settings (Default Privacy-Safe)
  const [showProfileToMembers, setShowProfileToMembers] = useState(false);
  const [showNameOnLeaderboard, setShowNameOnLeaderboard] = useState(true);
  const [showPhotoOnLeaderboard, setShowPhotoOnLeaderboard] = useState(false);

  // Notification Preferences
  const [workoutReminders, setWorkoutReminders] = useState(true);
  const [attendanceReminders, setAttendanceReminders] = useState(true);
  const [expiryReminders, setExpiryReminders] = useState(true);
  const [paymentReminders, setPaymentReminders] = useState(true);
  const [achievementAlerts, setAchievementAlerts] = useState(true);
  const [announcements, setAnnouncements] = useState(true);

  useEffect(() => {
    const sessionRaw = localStorage.getItem('member_session');
    if (!sessionRaw) {
      navigate('/?mode=code');
      return;
    }
    try {
      const parsed = JSON.parse(sessionRaw);
      setMemberSession(parsed);

      if (parsed.gymId && parsed.memberId) {
        fetch(`/api/members/${parsed.gymId}/${parsed.memberId}`)
          .then(res => res.json())
          .then(data => {
            if (data && data.fullName) {
              setOriginalMember(data);
              setFullName(data.fullName || '');
              setPhone(data.phone || '');
              setAge(data.age ? String(data.age) : '');
              setDob(data.dob || '');
              setGender(data.gender || 'Male');
              setLocation(data.location || '');
              setProfileImage(data.profileImage || '');

              if (data.gymName) {
                setGymDetails({ gymName: data.gymName, planName: data.planName });
              }
            }
          })
          .catch(() => {});
      }
    } catch {
      navigate('/?mode=code');
    }
  }, [navigate]);

  // Anime Fitness Character Assets
  const maleMasterImg = '/src/assets/images/male_master_1789408339415.jpg';
  const femaleMasterImg = '/src/assets/images/female_master_1789408351612.jpg';
  const maleMuscularImg = '/src/assets/images/male_muscular_1789408367724.jpg';
  const femaleTonedImg = '/src/assets/images/female_toned_1789408381576.jpg';
  const maleAthleticImg = '/src/assets/images/male_athletic_1789408397194.jpg';
  const femaleStrongImg = '/src/assets/images/female_strong_1789408409151.jpg';

  // Gender-specific body goal cards with anime character assets
  const malePhysiqueGoals = [
    { id: 'Muscular / Bulk', title: 'Muscular & Massive', desc: 'Maximize muscle volume & hypertrophy', icon: Dumbbell, image: maleMuscularImg },
    { id: 'Strength / Heavy', title: 'Strength & Power', desc: 'Focus on heavy compound lifts', icon: Zap, image: maleAthleticImg },
    { id: 'Athletic / Built', title: 'Athletic & Built', desc: 'Balanced aesthetics & functional agility', icon: Activity, image: maleMasterImg },
    { id: 'Lean / Defined', title: 'Lean & Shredded', desc: 'Low body fat & defined muscle lines', icon: Flame, image: maleAthleticImg },
    { id: 'Fat Loss / Shred', title: 'Fat Loss & Recomp', desc: 'Burn fat while preserving lean tissue', icon: Heart, image: maleMasterImg },
    { id: 'Overall Fitness', title: 'Overall Conditioning', desc: 'Stamina, mobility & health longevity', icon: Trophy, image: maleMasterImg }
  ];

  const femalePhysiqueGoals = [
    { id: 'Lean & Toned', title: 'Lean & Toned', desc: 'Sculpted muscle definition & endurance', icon: Flame, image: femaleTonedImg },
    { id: 'Strength & Power', title: 'Strength & Athleticism', desc: 'Build functional core & lower body power', icon: Zap, image: femaleStrongImg },
    { id: 'Athletic / Fit', title: 'Athletic Fit', desc: 'Speed, stamina & full-body balance', icon: Activity, image: femaleMasterImg },
    { id: 'Muscle Building', title: 'Hypertrophy & Shape', desc: 'Add targeted lean muscle mass', icon: Dumbbell, image: femaleStrongImg },
    { id: 'Fat Loss / Slim', title: 'Fat Loss & Burn', desc: 'High-energy caloric burn & tone', icon: Heart, image: femaleMasterImg },
    { id: 'Overall Fitness', title: 'Flexibility & Longevity', desc: 'Mobility, joint stability & energy', icon: Trophy, image: femaleMasterImg }
  ];

  const genericPhysiqueGoals = [
    { id: 'Lean & Toned', title: 'Lean & Toned', desc: 'Tone muscles and build endurance', icon: Flame, image: femaleTonedImg },
    { id: 'Strength', title: 'Pure Strength', desc: 'Increase total force output', icon: Zap, image: maleMuscularImg },
    { id: 'Athletic Fit', title: 'Athletic Performance', desc: 'Agility, power & functional strength', icon: Activity, image: maleAthleticImg },
    { id: 'Muscle Building', title: 'Muscle Hypertrophy', desc: 'Build size and structural muscle', icon: Dumbbell, image: femaleStrongImg },
    { id: 'Fat Loss', title: 'Fat Loss', desc: 'Caloric burn and metabolic conditioning', icon: Heart, image: femaleMasterImg },
    { id: 'Overall Fitness', title: 'General Fitness', desc: 'Cardiovascular health and mobility', icon: Trophy, image: maleMasterImg }
  ];

  const activePhysiqueCards = gender === 'Male' ? malePhysiqueGoals : gender === 'Female' ? femalePhysiqueGoals : genericPhysiqueGoals;

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      setError('Photo size must be under 5MB');
      return;
    }
    const reader = new FileReader();
    reader.onloadend = () => {
      setProfileImage(reader.result as string);
      setError('');
    };
    reader.readAsDataURL(file);
  };

  const handleCompleteOnboarding = async () => {
    if (!fullName.trim()) {
      setError('Full Name is required');
      setStep(1);
      return;
    }

    setSubmitting(true);
    setError('');

    const payload = {
      memberId: memberSession?.memberId,
      gymId: memberSession?.gymId,
      profile: {
        fullName: fullName.trim(),
        phone: phone.trim(),
        age: age ? Number(age) : null,
        dob,
        gender,
        location: location.trim(),
        profileImage
      },
      fitnessPreferences: {
        physiqueGoal,
        primaryGoal,
        trainingFocus,
        activityLevel,
        sessionPreference,
        lifestyleActivity
      },
      privacySettings: {
        showProfileToMembers,
        showNameOnLeaderboard,
        showPhotoOnLeaderboard
      },
      notificationPreferences: {
        workoutReminders,
        attendanceReminders,
        expiryReminders,
        paymentReminders,
        achievementAlerts,
        announcements
      }
    };

    try {
      const res = await fetch('/api/member/onboarding/complete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();

      if (data?.success) {
        // Also update member profile endpoint as fallback
        await fetch('/api/member/profile', {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            memberId: memberSession?.memberId,
            fullName: fullName.trim(),
            phone: phone.trim(),
            gender,
            location: location.trim(),
            profileImage
          })
        }).catch(() => {});

        // Update local session to mark onboarding completed
        if (memberSession) {
          const updated = { ...memberSession, onboardingCompleted: true };
          localStorage.setItem('member_session', JSON.stringify(updated));
        }
        setCompletedCelebration(true);
      } else {
        setError(data?.message || 'Failed to complete member profile setup.');
      }
    } catch {
      setError('Communication error while connecting to server.');
    } finally {
      setSubmitting(false);
    }
  };

  const totalSteps = 7;
  const stepLabels = [
    'Profile Details',
    'Body Goal',
    'Training Focus',
    'Experience',
    'Gym Timing',
    'Privacy & Alerts',
    'Review Setup'
  ];

  if (completedCelebration) {
    return (
      <div className="min-h-screen bg-[var(--bg)] text-[var(--text)] flex flex-col items-center justify-center p-4 py-12 relative overflow-hidden">
        <div className="w-full max-w-md clay-raised p-8 rounded-[36px] text-center space-y-6 animate-fade-in relative z-10 border border-neutral-200 dark:border-neutral-800">
          <div className="relative w-24 h-24 mx-auto flex items-center justify-center">
            <div className="absolute inset-0 rounded-full bg-[#34A853]/10 animate-ping" />
            <div className="w-24 h-24 rounded-full bg-gradient-to-br from-[#34A853] to-[#2E7D32] text-white flex items-center justify-center shadow-lg">
              <Award size={48} />
            </div>
          </div>

          <div className="space-y-2">
            <span className="text-[10px] font-black uppercase tracking-[0.2em] text-[#34A853] bg-[#34A853]/10 px-3 py-1 rounded-full">
              INITIAL ACHIEVEMENT UNLOCKED
            </span>
            <h1 className="text-2xl font-black uppercase tracking-tight">
              BRONZE ATHLETE
            </h1>
            <p className="text-xs text-[var(--text-sec)] font-medium leading-relaxed max-w-xs mx-auto">
              Welcome to {gymDetails?.gymName || originalMember?.gymName || 'Apex Fitness Club'}, {fullName || 'Athlete'}! Your fitness profile and training program are ready.
            </p>
          </div>

          <div className="grid grid-cols-3 gap-3 p-4 bg-neutral-100 dark:bg-[#181818] rounded-2xl text-center border border-neutral-200 dark:border-neutral-800">
            <div>
              <p className="text-[10px] font-bold text-[var(--text-sec)] uppercase">LEVEL</p>
              <p className="text-sm font-black text-[var(--text)]">LVL 1</p>
            </div>
            <div>
              <p className="text-[10px] font-bold text-[var(--text-sec)] uppercase">BADGE</p>
              <p className="text-sm font-black text-[#34A853]">BRONZE</p>
            </div>
            <div>
              <p className="text-[10px] font-bold text-[var(--text-sec)] uppercase">STREAK</p>
              <p className="text-sm font-black text-[var(--text)]">0 DAYS</p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => navigate('/member/dashboard')}
            className="w-full h-14 rounded-2xl bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 cursor-pointer shadow-md hover:opacity-95 active:scale-95 transition-all"
          >
            Enter Member Dashboard <ArrowRight size={16} />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[var(--bg)] text-[var(--text)] flex flex-col items-center justify-center p-4 py-8 relative">
      {/* Header Bar */}
      <div className="w-full max-w-xl flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 flex items-center justify-center font-black shadow-sm">
            <Dumbbell size={20} />
          </div>
          <div>
            <h1 className="text-xs font-black uppercase tracking-wider">{gymDetails?.gymName || originalMember?.gymName || 'Member Onboarding'}</h1>
            <p className="text-[10px] text-[var(--text-sec)] font-mono font-bold">Step {step} of {totalSteps}: {stepLabels[step - 1]}</p>
          </div>
        </div>
        <LanguageSelector onLanguageChange={(l) => setLang(l)} variant="compact" />
      </div>

      {/* Progress Bar */}
      <div className="w-full max-w-xl mb-6">
        <div className="h-2 w-full bg-neutral-200 dark:bg-neutral-800 rounded-full overflow-hidden p-0.5">
          <motion.div 
            className="h-full bg-neutral-900 dark:bg-white rounded-full transition-all duration-300"
            animate={{ width: `${(step / totalSteps) * 100}%` }}
          />
        </div>
      </div>

      {/* Main Container */}
      <div className="w-full max-w-xl clay-raised p-6 sm:p-8 rounded-[32px] space-y-6 relative overflow-hidden">
        {error && (
          <div className="p-3 bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-900 rounded-2xl text-xs font-bold text-[#D64545] text-center animate-fade-in">
            {error}
          </div>
        )}

        <AnimatePresence mode="wait">
          {/* STEP 1: Owner-Prefilled Profile Verification */}
          {step === 1 && (
            <motion.div 
              key="step1" 
              initial={{ opacity: 0, x: 20 }} 
              animate={{ opacity: 1, x: 0 }} 
              exit={{ opacity: 0, x: -20 }}
              className="space-y-5"
            >
              <div className="space-y-1">
                <span className="text-[10px] uppercase font-bold tracking-widest text-[#34A853] bg-[#34A853]/10 px-2.5 py-0.5 rounded-full">
                  VERIFY PROFILE
                </span>
                <h2 className="text-lg font-black uppercase tracking-tight">Personal & Account Info</h2>
                <p className="text-xs text-[var(--text-sec)]">Review owner-entered record and update your personal details.</p>
              </div>

              {/* Read-Only Owner Controlled Membership Card */}
              <div className="p-4 bg-neutral-100 dark:bg-[#181818] rounded-2xl border border-neutral-200 dark:border-neutral-800 space-y-3">
                <div className="flex items-center justify-between text-xs font-bold text-[var(--text-sec)]">
                  <span className="flex items-center gap-1.5 uppercase tracking-wider text-[10px]"><Lock size={12} /> Owner Controlled Membership</span>
                  <span className="font-mono text-xs text-neutral-900 dark:text-white font-black">{originalMember?.memberDisplayId || originalMember?.memberAccessCode || 'MEM-001'}</span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="p-2.5 bg-white dark:bg-neutral-900 rounded-xl border border-neutral-200 dark:border-neutral-800">
                    <p className="text-[9px] font-bold text-[var(--text-sec)] uppercase">GYM WORKSPACE</p>
                    <p className="font-bold text-[var(--text)] truncate">{gymDetails?.gymName || originalMember?.gymName || 'Apex Fitness Club'}</p>
                  </div>
                  <div className="p-2.5 bg-white dark:bg-neutral-900 rounded-xl border border-neutral-200 dark:border-neutral-800">
                    <p className="text-[9px] font-bold text-[var(--text-sec)] uppercase">MEMBERSHIP PLAN</p>
                    <p className="font-bold text-[#34A853] truncate">{originalMember?.planName || 'Standard Plan'}</p>
                  </div>
                </div>
              </div>

              {/* Photo Upload Box */}
              <div className="flex items-center gap-4 p-3 bg-neutral-50 dark:bg-neutral-900/50 rounded-2xl border border-neutral-200 dark:border-neutral-800">
                <div className="relative">
                  {profileImage ? (
                    <img src={profileImage} alt="Profile" className="w-16 h-16 rounded-2xl object-cover border-2 border-neutral-900 dark:border-white shadow-sm" />
                  ) : (
                    <div className="w-16 h-16 rounded-2xl bg-neutral-200 dark:bg-neutral-800 flex items-center justify-center text-xl font-black text-neutral-600 dark:text-neutral-300">
                      {fullName ? fullName.charAt(0).toUpperCase() : <User size={24} />}
                    </div>
                  )}
                  <input ref={fileInputRef} type="file" accept="image/*" onChange={handlePhotoUpload} className="hidden" />
                </div>
                <div className="flex-1 space-y-1">
                  <p className="text-xs font-bold">Profile Photo</p>
                  <p className="text-[10px] text-[var(--text-sec)]">Upload real photo or keep default initials avatar</p>
                  <div className="flex gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="px-3 py-1.5 bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 rounded-xl text-[10px] font-black uppercase flex items-center gap-1 cursor-pointer"
                    >
                      <Camera size={12} /> Upload Photo
                    </button>
                    {profileImage && (
                      <button
                        type="button"
                        onClick={() => setProfileImage('')}
                        className="px-2 py-1.5 bg-red-100 text-red-700 dark:bg-red-950/40 dark:text-red-400 rounded-xl text-[10px] font-bold uppercase cursor-pointer"
                      >
                        Remove
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Editable Fields */}
              <div className="space-y-3">
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">
                    Full Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="Enter full name"
                    className="w-full h-12 px-4 neo-pressed rounded-2xl text-xs font-bold text-[var(--text)] outline-none border border-neutral-200 dark:border-neutral-800 focus:border-neutral-900 dark:focus:border-white"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">
                      Mobile Number
                    </label>
                    <input
                      type="tel"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="9876543210"
                      className="w-full h-12 px-4 neo-pressed rounded-2xl text-xs font-bold text-[var(--text)] outline-none border border-neutral-200 dark:border-neutral-800"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">
                      Gender
                    </label>
                    <select
                      value={gender}
                      onChange={(e) => setGender(e.target.value)}
                      className="w-full h-12 px-3 neo-pressed rounded-2xl text-xs font-bold text-[var(--text)] outline-none border border-neutral-200 dark:border-neutral-800"
                    >
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">
                      Age
                    </label>
                    <input
                      type="number"
                      value={age}
                      onChange={(e) => setAge(e.target.value)}
                      placeholder="e.g. 24"
                      className="w-full h-12 px-4 neo-pressed rounded-2xl text-xs font-bold text-[var(--text)] outline-none border border-neutral-200 dark:border-neutral-800"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">
                      Location / City
                    </label>
                    <input
                      type="text"
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                      placeholder="e.g. Patna"
                      className="w-full h-12 px-4 neo-pressed rounded-2xl text-xs font-bold text-[var(--text)] outline-none border border-neutral-200 dark:border-neutral-800"
                    />
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  if (!fullName.trim()) { setError('Full Name is required'); return; }
                  setError('');
                  setStep(2);
                }}
                className="w-full h-14 rounded-2xl bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 cursor-pointer shadow-md hover:opacity-95 active:scale-95 transition-all"
              >
                Continue to Body Goal <ArrowRight size={16} />
              </button>
            </motion.div>
          )}

          {/* STEP 2: Gender-Specific Body Goal */}
          {step === 2 && (
            <motion.div 
              key="step2" 
              initial={{ opacity: 0, x: 20 }} 
              animate={{ opacity: 1, x: 0 }} 
              exit={{ opacity: 0, x: -20 }}
              className="space-y-5"
            >
              <div className="space-y-1">
                <span className="text-[10px] uppercase font-bold tracking-widest text-[#34A853] bg-[#34A853]/10 px-2.5 py-0.5 rounded-full">
                  STEP 2 OF 6
                </span>
                <h2 className="text-lg font-black uppercase tracking-tight">Physique & Body Goal</h2>
                <p className="text-xs text-[var(--text-sec)]">Select your primary aesthetic & target physique outcome ({gender} specific options).</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                {activePhysiqueCards.map((card) => {
                  const Icon = card.icon;
                  const isSelected = physiqueGoal === card.id;
                  return (
                    <button
                      key={card.id}
                      type="button"
                      onClick={() => setPhysiqueGoal(card.id)}
                      className={`p-3.5 rounded-2xl text-left border-2 transition-all cursor-pointer flex items-center gap-3 ${
                        isSelected 
                          ? 'border-neutral-900 bg-neutral-900 text-white dark:border-white dark:bg-white dark:text-neutral-900 shadow-md scale-[1.02]' 
                          : 'border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-900/50 text-[var(--text)] hover:border-neutral-400'
                      }`}
                    >
                      {card.image ? (
                        <div className="w-14 h-18 rounded-xl overflow-hidden shrink-0 border border-neutral-300 dark:border-neutral-700 bg-neutral-100 dark:bg-neutral-800">
                          <img 
                            src={card.image} 
                            alt={card.title} 
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover object-top"
                          />
                        </div>
                      ) : (
                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                          isSelected ? 'bg-white/20 text-current' : 'bg-neutral-200 dark:bg-neutral-800 text-current'
                        }`}>
                          <Icon size={20} />
                        </div>
                      )}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <p className="text-xs font-black uppercase tracking-wide truncate">{card.title}</p>
                          {isSelected && <Check size={14} className="shrink-0 text-[#34A853]" />}
                        </div>
                        <p className={`text-[10px] font-medium leading-tight mt-1 ${isSelected ? 'opacity-90' : 'text-[var(--text-sec)]'}`}>
                          {card.desc}
                        </p>
                      </div>
                    </button>
                  );
                })}
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="h-14 px-5 rounded-2xl neo-raised text-xs font-bold uppercase tracking-wider flex items-center gap-2 cursor-pointer"
                >
                  <ArrowLeft size={16} /> Back
                </button>
                <button
                  type="button"
                  onClick={() => setStep(3)}
                  className="flex-1 h-14 rounded-2xl bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 cursor-pointer shadow-md"
                >
                  Continue <ArrowRight size={16} />
                </button>
              </div>
            </motion.div>
          )}

          {/* STEP 3: Training Focus & Goal */}
          {step === 3 && (
            <motion.div 
              key="step3" 
              initial={{ opacity: 0, x: 20 }} 
              animate={{ opacity: 1, x: 0 }} 
              exit={{ opacity: 0, x: -20 }}
              className="space-y-5"
            >
              <div className="space-y-1">
                <span className="text-[10px] uppercase font-bold tracking-widest text-[#34A853] bg-[#34A853]/10 px-2.5 py-0.5 rounded-full">
                  STEP 3 OF 6
                </span>
                <h2 className="text-lg font-black uppercase tracking-tight">Training Focus & Methodology</h2>
                <p className="text-xs text-[var(--text-sec)]">Tell your gym coach how you prefer to structure workouts.</p>
              </div>

              <div className="space-y-3 pt-1">
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">
                    Primary Fitness Goal
                  </label>
                  <select
                    value={primaryGoal}
                    onChange={(e) => setPrimaryGoal(e.target.value)}
                    className="w-full h-12 px-4 neo-pressed rounded-2xl text-xs font-bold text-[var(--text)] outline-none border border-neutral-200 dark:border-neutral-800"
                  >
                    <option value="Muscle Gain">Muscle Gain & Hypertrophy</option>
                    <option value="Strength">Strength & Heavy Lifts</option>
                    <option value="Fat Loss">Fat Loss & Caloric Burn</option>
                    <option value="General Fitness">General Fitness & Health</option>
                    <option value="Endurance">Endurance & Athletic Speed</option>
                    <option value="Flexibility">Flexibility & Core Stability</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">
                    Routine Focus Preference
                  </label>
                  <select
                    value={trainingFocus}
                    onChange={(e) => setTrainingFocus(e.target.value)}
                    className="w-full h-12 px-4 neo-pressed rounded-2xl text-xs font-bold text-[var(--text)] outline-none border border-neutral-200 dark:border-neutral-800"
                  >
                    <option value="Hypertrophy & Strength">Hypertrophy & Strength (Barbell/Dumbbell)</option>
                    <option value="Compound Heavy Lifts">Heavy Power Compounds (Squat, Deadlift, Bench)</option>
                    <option value="Functional Conditioning">HIIT & Functional Circuit Conditioning</option>
                    <option value="Calisthenics & Bodyweight">Calisthenics & Core Bodyweight</option>
                    <option value="Mobility & Recovery">Mobility, Flexibility & Active Recovery</option>
                    <option value="Mixed Hybrid Training">Mixed Hybrid Fitness Routine</option>
                  </select>
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="h-14 px-5 rounded-2xl neo-raised text-xs font-bold uppercase tracking-wider flex items-center gap-2 cursor-pointer"
                >
                  <ArrowLeft size={16} /> Back
                </button>
                <button
                  type="button"
                  onClick={() => setStep(4)}
                  className="flex-1 h-14 rounded-2xl bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 cursor-pointer shadow-md"
                >
                  Continue <ArrowRight size={16} />
                </button>
              </div>
            </motion.div>
          )}

          {/* STEP 4: Activity Level & Lifestyle */}
          {step === 4 && (
            <motion.div 
              key="step4" 
              initial={{ opacity: 0, x: 20 }} 
              animate={{ opacity: 1, x: 0 }} 
              exit={{ opacity: 0, x: -20 }}
              className="space-y-5"
            >
              <div className="space-y-1">
                <span className="text-[10px] uppercase font-bold tracking-widest text-[#34A853] bg-[#34A853]/10 px-2.5 py-0.5 rounded-full">
                  STEP 4 OF 6
                </span>
                <h2 className="text-lg font-black uppercase tracking-tight">Experience & Lifestyle</h2>
                <p className="text-xs text-[var(--text-sec)]">Help us tailor initial exercise weights and session duration.</p>
              </div>

              <div className="space-y-3 pt-1">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">
                      Gym Experience
                    </label>
                    <select
                      value={activityLevel}
                      onChange={(e) => setActivityLevel(e.target.value)}
                      className="w-full h-12 px-3 neo-pressed rounded-2xl text-xs font-bold text-[var(--text)] outline-none border border-neutral-200 dark:border-neutral-800"
                    >
                      <option value="Beginner">Beginner (0-6 Months)</option>
                      <option value="Intermediate">Intermediate (1-2 Years)</option>
                      <option value="Advanced">Advanced (3+ Years)</option>
                      <option value="Athlete">Competitive Athlete</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">
                      Session Preference
                    </label>
                    <select
                      value={sessionPreference}
                      onChange={(e) => setSessionPreference(e.target.value)}
                      className="w-full h-12 px-3 neo-pressed rounded-2xl text-xs font-bold text-[var(--text)] outline-none border border-neutral-200 dark:border-neutral-800"
                    >
                      <option value="Short 30-45 Mins">Short & Intense (30-45 Mins)</option>
                      <option value="Standard 60 Mins">Standard Balanced (60 Mins)</option>
                      <option value="Deep 75-90 Mins">Deep Focus (75-90 Mins)</option>
                      <option value="Flexible">Flexible / Varied</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1">
                    Daily Activity Level Outside Gym
                  </label>
                  <select
                    value={lifestyleActivity}
                    onChange={(e) => setLifestyleActivity(e.target.value)}
                    className="w-full h-12 px-4 neo-pressed rounded-2xl text-xs font-bold text-[var(--text)] outline-none border border-neutral-200 dark:border-neutral-800"
                  >
                    <option value="Sedentary">Desk Job / Mostly Sitting</option>
                    <option value="Lightly Active">Lightly Active / Walking Daily</option>
                    <option value="Active">Active / On Feet Most Day</option>
                    <option value="Very Active">Very Active / Heavy Physical Job</option>
                  </select>
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setStep(3)}
                  className="h-14 px-5 rounded-2xl neo-raised text-xs font-bold uppercase tracking-wider flex items-center gap-2 cursor-pointer"
                >
                  <ArrowLeft size={16} /> Back
                </button>
                <button
                  type="button"
                  onClick={() => setStep(5)}
                  className="flex-1 h-14 rounded-2xl bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 cursor-pointer shadow-md"
                >
                  Continue <ArrowRight size={16} />
                </button>
              </div>
            </motion.div>
          )}

          {/* STEP 5: Gym Schedule & Timing */}
          {step === 5 && (
            <motion.div
              key="step5"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-5"
            >
              <div className="space-y-1">
                <span className="text-[10px] uppercase font-bold tracking-widest text-[#34A853] bg-[#34A853]/10 px-2.5 py-0.5 rounded-full">
                  STEP 5 OF 7
                </span>
                <h2 className="text-lg font-black uppercase tracking-tight flex items-center gap-2">
                  <Clock size={20} className="text-[#34A853]" /> Set Up Your Gym Timing
                </h2>
                <p className="text-xs text-[var(--text-sec)]">
                  When do you usually plan to train? We will remind you 10 minutes prior so you never miss a session.
                </p>
              </div>

              {/* Time Selector & Chips */}
              <div className="space-y-4 pt-1">
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-[var(--text-sec)] mb-1.5">
                    Preferred Training Time (IST)
                  </label>
                  <input
                    type="text"
                    value={preferredTrainingTime}
                    onChange={(e) => setPreferredTrainingTime(e.target.value)}
                    placeholder="e.g. 07:00 AM"
                    className="w-full h-12 px-4 neo-pressed rounded-2xl text-sm font-black text-[var(--text)] outline-none border border-neutral-200 dark:border-neutral-800"
                  />
                </div>

                <div className="space-y-1.5">
                  <p className="text-[10px] font-bold uppercase tracking-wider text-[var(--text-sec)]">Quick Time Presets</p>
                  <div className="grid grid-cols-4 gap-2">
                    {['06:00 AM', '07:00 AM', '08:00 AM', '09:00 AM', '05:00 PM', '06:00 PM', '07:00 PM', '08:00 PM'].map((chip) => (
                      <button
                        key={chip}
                        type="button"
                        onClick={() => setPreferredTrainingTime(chip)}
                        className={`p-2 rounded-xl text-[11px] font-bold transition-all cursor-pointer border ${
                          preferredTrainingTime === chip
                            ? 'bg-[#34A853] text-white border-[#34A853] shadow-sm'
                            : 'neo-pressed text-[var(--text)] border-transparent hover:border-neutral-300 dark:hover:border-neutral-700'
                        }`}
                      >
                        {chip}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Stay On Track / Push Notification Box */}
                <div className="p-4 rounded-2xl bg-neutral-100 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 space-y-2">
                  <div className="flex items-center gap-2">
                    <Bell size={18} className="text-[#34A853]" />
                    <span className="text-xs font-black uppercase tracking-wider text-[var(--text)]">Stay On Track Alerts</span>
                  </div>
                  <p className="text-[11px] text-[var(--text-sec)] leading-relaxed">
                    We can send you a 10-minute pre-workout alert on your device and a daily feeling check-in after your session.
                  </p>
                  <button
                    type="button"
                    onClick={async () => {
                      if ('Notification' in window) {
                        const perm = await Notification.requestPermission();
                        if (perm === 'granted') {
                          setPushSubscribed(true);
                        }
                      }
                    }}
                    className={`w-full h-10 rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
                      pushSubscribed
                        ? 'bg-[#34A853]/20 text-[#34A853] border border-[#34A853]/30'
                        : 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 hover:opacity-90'
                    }`}
                  >
                    {pushSubscribed ? '✓ Push Alerts Activated' : 'Enable Device Push Alerts'}
                  </button>
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setStep(4)}
                  className="h-14 px-5 rounded-2xl neo-raised text-xs font-bold uppercase tracking-wider flex items-center gap-2 cursor-pointer"
                >
                  <ArrowLeft size={16} /> Back
                </button>
                <button
                  type="button"
                  onClick={() => setStep(6)}
                  className="flex-1 h-14 rounded-2xl bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 cursor-pointer shadow-md"
                >
                  Continue <ArrowRight size={16} />
                </button>
              </div>
            </motion.div>
          )}

          {/* STEP 6: Privacy Controls & Notifications */}
          {step === 6 && (
            <motion.div 
              key="step6" 
              initial={{ opacity: 0, x: 20 }} 
              animate={{ opacity: 1, x: 0 }} 
              exit={{ opacity: 0, x: -20 }}
              className="space-y-5"
            >
              <div className="space-y-1">
                <span className="text-[10px] uppercase font-bold tracking-widest text-[#34A853] bg-[#34A853]/10 px-2.5 py-0.5 rounded-full">
                  STEP 6 OF 7
                </span>
                <h2 className="text-lg font-black uppercase tracking-tight">Privacy & Alerts</h2>
                <p className="text-xs text-[var(--text-sec)]">You control what other members can see and which push notifications you receive.</p>
              </div>

              {/* Privacy Toggles */}
              <div className="space-y-3 pt-1">
                <p className="text-[10px] font-black uppercase tracking-wider text-[var(--text-sec)]">Privacy Controls (Default Privacy-Safe)</p>
                
                <div className="p-3 bg-neutral-50 dark:bg-neutral-900/50 rounded-2xl border border-neutral-200 dark:border-neutral-800 flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <Shield size={18} className="text-neutral-600 dark:text-neutral-400" />
                    <div>
                      <p className="text-xs font-bold">Public Profile Visibility</p>
                      <p className="text-[10px] text-[var(--text-sec)]">Allow gym members to view your fitness profile</p>
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={showProfileToMembers}
                    onChange={(e) => setShowProfileToMembers(e.target.checked)}
                    className="w-5 h-5 accent-neutral-900 dark:accent-white rounded cursor-pointer"
                  />
                </div>

                <div className="p-3 bg-neutral-50 dark:bg-neutral-900/50 rounded-2xl border border-neutral-200 dark:border-neutral-800 flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <Trophy size={18} className="text-neutral-600 dark:text-neutral-400" />
                    <div>
                      <p className="text-xs font-bold">Show Name on Gym Leaderboard</p>
                      <p className="text-[10px] text-[var(--text-sec)]">If off, displays as 'Anonymous Gym Member'</p>
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={showNameOnLeaderboard}
                    onChange={(e) => setShowNameOnLeaderboard(e.target.checked)}
                    className="w-5 h-5 accent-neutral-900 dark:accent-white rounded cursor-pointer"
                  />
                </div>
              </div>

              {/* Notification Toggles */}
              <div className="space-y-3 pt-1">
                <p className="text-[10px] font-black uppercase tracking-wider text-[var(--text-sec)]">Notification Preferences</p>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <label className="p-3 bg-neutral-50 dark:bg-neutral-900/50 rounded-2xl border border-neutral-200 dark:border-neutral-800 flex items-center justify-between cursor-pointer">
                    <span className="font-bold text-[11px]">Workout Alerts</span>
                    <input type="checkbox" checked={workoutReminders} onChange={(e) => setWorkoutReminders(e.target.checked)} className="accent-neutral-900 dark:accent-white" />
                  </label>
                  <label className="p-3 bg-neutral-50 dark:bg-neutral-900/50 rounded-2xl border border-neutral-200 dark:border-neutral-800 flex items-center justify-between cursor-pointer">
                    <span className="font-bold text-[11px]">Attendance Reminders</span>
                    <input type="checkbox" checked={attendanceReminders} onChange={(e) => setAttendanceReminders(e.target.checked)} className="accent-neutral-900 dark:accent-white" />
                  </label>
                  <label className="p-3 bg-neutral-50 dark:bg-neutral-900/50 rounded-2xl border border-neutral-200 dark:border-neutral-800 flex items-center justify-between cursor-pointer">
                    <span className="font-bold text-[11px]">Plan Expiry Alerts</span>
                    <input type="checkbox" checked={expiryReminders} onChange={(e) => setExpiryReminders(e.target.checked)} className="accent-neutral-900 dark:accent-white" />
                  </label>
                  <label className="p-3 bg-neutral-50 dark:bg-neutral-900/50 rounded-2xl border border-neutral-200 dark:border-neutral-800 flex items-center justify-between cursor-pointer">
                    <span className="font-bold text-[11px]">Gym Announcements</span>
                    <input type="checkbox" checked={announcements} onChange={(e) => setAnnouncements(e.target.checked)} className="accent-neutral-900 dark:accent-white" />
                  </label>
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setStep(5)}
                  className="h-14 px-5 rounded-2xl neo-raised text-xs font-bold uppercase tracking-wider flex items-center gap-2 cursor-pointer"
                >
                  <ArrowLeft size={16} /> Back
                </button>
                <button
                  type="button"
                  onClick={() => setStep(7)}
                  className="flex-1 h-14 rounded-2xl bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 cursor-pointer shadow-md"
                >
                  Review Setup <ArrowRight size={16} />
                </button>
              </div>
            </motion.div>
          )}

          {/* STEP 7: Review & Final Confirmation */}
          {step === 7 && (
            <motion.div 
              key="step7" 
              initial={{ opacity: 0, x: 20 }} 
              animate={{ opacity: 1, x: 0 }} 
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div className="space-y-1 text-center">
                <span className="text-[10px] uppercase font-bold tracking-widest text-[#34A853] bg-[#34A853]/10 px-2.5 py-0.5 rounded-full">
                  FINAL REVIEW
                </span>
                <h2 className="text-lg font-black uppercase tracking-tight">Confirm Your Setup</h2>
                <p className="text-xs text-[var(--text-sec)]">Review your profile choices before activating your member workspace.</p>
              </div>

              <div className="p-4 bg-neutral-100 dark:bg-[#181818] rounded-2xl border border-neutral-200 dark:border-neutral-800 space-y-3 text-xs">
                <div className="flex items-center justify-between border-b border-neutral-200 dark:border-neutral-800 pb-2">
                  <span className="text-[var(--text-sec)] font-bold">Full Name:</span>
                  <span className="font-black text-[var(--text)]">{fullName}</span>
                </div>
                <div className="flex items-center justify-between border-b border-neutral-200 dark:border-neutral-800 pb-2">
                  <span className="text-[var(--text-sec)] font-bold">Gender & Age:</span>
                  <span className="font-bold text-[var(--text)]">{gender}, {age || 'N/A'} yrs</span>
                </div>
                <div className="flex items-center justify-between border-b border-neutral-200 dark:border-neutral-800 pb-2">
                  <span className="text-[var(--text-sec)] font-bold">Target Physique:</span>
                  <span className="font-bold text-[#34A853]">{physiqueGoal}</span>
                </div>
                <div className="flex items-center justify-between border-b border-neutral-200 dark:border-neutral-800 pb-2">
                  <span className="text-[var(--text-sec)] font-bold">Preferred Gym Time:</span>
                  <span className="font-bold text-[#34A853]">{preferredTrainingTime}</span>
                </div>
                <div className="flex items-center justify-between border-b border-neutral-200 dark:border-neutral-800 pb-2">
                  <span className="text-[var(--text-sec)] font-bold">Training Focus:</span>
                  <span className="font-bold text-[var(--text)]">{primaryGoal}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[var(--text-sec)] font-bold">Leaderboard Status:</span>
                  <span className="font-mono text-xs font-bold">{showNameOnLeaderboard ? 'Public Name' : 'Anonymous'}</span>
                </div>
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setStep(6)}
                  className="h-14 px-5 rounded-2xl neo-raised text-xs font-bold uppercase tracking-wider flex items-center gap-2 cursor-pointer"
                >
                  <ArrowLeft size={16} /> Edit
                </button>
                <button
                  type="button"
                  onClick={handleCompleteOnboarding}
                  disabled={submitting}
                  className="flex-1 h-14 rounded-2xl bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 cursor-pointer shadow-md disabled:opacity-50 hover:opacity-95 active:scale-95 transition-all"
                >
                  {submitting ? (
                    <Loader2 size={18} className="animate-spin" />
                  ) : (
                    <>
                      <Sparkles size={16} /> Complete Setup & Unlock Badge
                    </>
                  )}
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
