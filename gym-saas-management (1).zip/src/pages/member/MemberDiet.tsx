import React, { useState, useEffect } from 'react';
import { useNavigate } from '@/lib/router-compat';
import { Utensils, Sparkles, RefreshCw, CheckCircle, Flame } from 'lucide-react';
import MemberLayout from '../../components/MemberLayout';

export default function MemberDiet() {
  const navigate = useNavigate();
  const [diet, setDiet] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [dietPref, setDietPref] = useState('veg');

  const fetchDiet = () => {
    const sessionStr = localStorage.getItem('member_session');
    if (!sessionStr) { navigate('/'); return; }
    const session = JSON.parse(sessionStr);

    fetch(`/api/diet/${session.gymId}/${session.memberId}`)
      .then(res => res.json())
      .then(data => {
        if (data && data.success) {
          setDiet(data.diet);
        }
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchDiet();
  }, []);

  const handleGenerate = async () => {
    setGenerating(true);
    const sessionStr = localStorage.getItem('member_session');
    if (!sessionStr) return;
    const session = JSON.parse(sessionStr);

    try {
      const res = await fetch('/api/diet/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          gymId: session.gymId,
          memberId: session.memberId,
          dietPref
        })
      });
      const data = await res.json();
      if (data.success && data.diet) {
        setDiet(data.diet);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setGenerating(false);
    }
  };

  if (loading) {
    return (
      <MemberLayout>
        <div className="py-20 text-center text-4xl animate-pulse">🥗</div>
      </MemberLayout>
    );
  }

  return (
    <MemberLayout>
      <div className="px-4 mt-6 space-y-6 pb-10">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)]">Nutrition</span>
            <h1 className="text-2xl font-black uppercase tracking-wider text-[var(--text)]">Daily Diet Plan</h1>
          </div>

          <button
            onClick={handleGenerate}
            disabled={generating}
            className="h-10 px-4 rounded-[14px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-wider flex items-center gap-1.5 active:scale-95 transition-transform cursor-pointer"
          >
            <Sparkles size={14} className={generating ? 'animate-spin' : ''} />
            {generating ? 'GENERATING...' : 'NEW AI DIET'}
          </button>
        </div>

        {/* Preference Selector */}
        <div className="neo-pressed p-3 rounded-[18px] flex items-center justify-between gap-2">
          <span className="text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] pl-2">Dietary Preference</span>
          <select
            value={dietPref}
            onChange={(e) => setDietPref(e.target.value)}
            className="h-9 px-3 rounded-[12px] bg-[var(--surface)] text-xs font-bold uppercase text-[var(--text)] outline-none cursor-pointer"
          >
            <option value="veg">Pure Vegetarian (Indian)</option>
            <option value="non_veg">High Protein Non-Veg</option>
            <option value="eggetarian">Eggetarian</option>
            <option value="vegan">Vegan</option>
          </select>
        </div>

        {diet ? (
          <div className="space-y-4">
            <div className="clay-raised p-6 rounded-[28px] space-y-3">
              <span className="text-[9px] font-black uppercase tracking-widest text-[#34A853] bg-[#34A853]/10 px-2.5 py-0.5 rounded-full">
                TARGET: {diet.calories || '2200'} KCAL / DAY
              </span>
              <h2 className="text-lg font-black uppercase tracking-wider">{diet.planTitle || 'HIGH PROTEIN PLAN'}</h2>
              <p className="text-xs text-[var(--text-sec)] font-medium leading-relaxed">{diet.overview}</p>

              <div className="grid grid-cols-3 gap-2 pt-2 text-center">
                <div className="p-2.5 neo-pressed rounded-[14px]">
                  <span className="text-[8px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Protein</span>
                  <span className="text-xs font-black font-mono text-[var(--text)]">{diet.macros?.protein || '130g'}</span>
                </div>
                <div className="p-2.5 neo-pressed rounded-[14px]">
                  <span className="text-[8px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Carbs</span>
                  <span className="text-xs font-black font-mono text-[var(--text)]">{diet.macros?.carbs || '210g'}</span>
                </div>
                <div className="p-2.5 neo-pressed rounded-[14px]">
                  <span className="text-[8px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Fats</span>
                  <span className="text-xs font-black font-mono text-[var(--text)]">{diet.macros?.fats || '55g'}</span>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <h3 className="text-xs font-black uppercase tracking-wider text-[var(--text)] px-1">Meal Schedule</h3>
              {diet.meals?.map((meal: any, idx: number) => (
                <div key={idx} className="neo-raised p-4 rounded-[20px] space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black uppercase tracking-wider text-[#34A853] bg-[#34A853]/10 px-2 py-0.5 rounded-md">
                      {meal.time || 'MEAL'}
                    </span>
                    <span className="text-xs font-black uppercase text-[var(--text)]">{meal.title}</span>
                  </div>
                  <p className="text-xs font-bold text-[var(--text)]">{meal.foodItems}</p>
                  {meal.tips && (
                    <p className="text-[10px] text-[var(--text-sec)] font-medium italic">{meal.tips}</p>
                  )}
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="neo-pressed p-8 rounded-[28px] text-center space-y-4">
            <Utensils size={36} className="mx-auto text-[var(--text-sec)] opacity-50" />
            <p className="text-xs font-bold uppercase tracking-wider text-[var(--text-sec)]">
              No active diet plan generated for today yet.
            </p>
            <button
              onClick={handleGenerate}
              className="px-6 py-3 bg-[var(--btn-bg)] text-[var(--btn-text)] rounded-[16px] text-xs font-black uppercase tracking-widest cursor-pointer"
            >
              GENERATE AI DIET PLAN
            </button>
          </div>
        )}
      </div>
    </MemberLayout>
  );
}
