import React, { useEffect, useState } from 'react';
import { useNavigate, Link } from '@/lib/router-compat';
import { 
  Flame, Dumbbell, Calendar, CreditCard, User,
  Sparkles, ArrowRight, CheckCircle2, ShieldCheck, QrCode, Award, Trophy, ChevronRight, RefreshCw,
  Target, TrendingUp, Check, Edit3, Activity, Loader2
} from 'lucide-react';
import MemberLayout from '../../components/MemberLayout';
import PWAInstallBanner from '../../components/PWAInstallBanner';
import LevelUpModal from '../../components/LevelUpModal';
import BadgeEarnedModal from '../../components/BadgeEarnedModal';

export default function MemberDashboard() {
  const navigate = useNavigate();
  const [data, setData] = useState<any>(null);
  const [leaderboardData, setLeaderboardData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  // Goal & Consistency State
  const [monthlyGoal, setMonthlyGoal] = useState<number>(() => {
    const saved = localStorage.getItem('member_monthly_goal');
    return saved ? parseInt(saved, 10) : 20;
  });
  const [isGoalModalOpen, setIsGoalModalOpen] = useState(false);
  const [tempGoal, setTempGoal] = useState<number>(20);

  const [memberTasks, setMemberTasks] = useState<any[]>([]);
  const [isGymOpenToday, setIsGymOpenToday] = useState(true);
  const [analyticsData, setAnalyticsData] = useState<any>(null);

  // Task Confirmation Modal state
  const [pendingTask, setPendingTask] = useState<any>(null);
  const [isCompletingTask, setIsCompletingTask] = useState(false);
  const [taskError, setTaskError] = useState<string | null>(null);

  // Modal triggers
  const [showLevelUp, setShowLevelUp] = useState(false);
  const [newLevelInfo, setNewLevelInfo] = useState<any>(null);
  const [showBadgeEarned, setShowBadgeEarned] = useState(false);
  const [newBadgeInfo, setNewBadgeInfo] = useState<any>(null);

  const fetchMemberDash = async () => {
    const sessionStr = localStorage.getItem('member_session');
    if (!sessionStr) { navigate('/'); return; }
    const session = JSON.parse(sessionStr);

    try {
      const [dashRes, appRes, lbRes, taskRes, anaRes] = await Promise.all([
        fetch(`/api/member/dashboard/${session.gymId}/${session.memberId}`),
        fetch(`/api/member-app/${session.gymId}/${session.memberId}`),
        fetch(`/api/member/leaderboard/${session.gymId}?memberId=${session.memberId}`),
        fetch(`/api/member/tasks/${session.gymId}/${session.memberId}`),
        fetch(`/api/member/analytics/${session.gymId}/${session.memberId}`)
      ]);

      const dashD = await dashRes.json();
      const appD = await appRes.json();
      const lbD = await lbRes.json();
      const taskD = await taskRes.json();
      const anaD = await anaRes.json();

      if (dashD && dashD.success) {
        if (dashD.member && dashD.member.onboardingCompleted === false) {
          navigate('/member/onboarding', { replace: true });
          return;
        }
        setData({
          ...dashD,
          appInfo: appD
        });
      }

      if (lbD && lbD.success) {
        setLeaderboardData(lbD);
      }

      if (taskD && taskD.success) {
        setMemberTasks(taskD.tasks || []);
        setIsGymOpenToday(taskD.isGymOpenToday !== false);
      }

      if (anaD && anaD.success) {
        setAnalyticsData(anaD.analytics);
        // Check for unseen achievement to celebrate
        const unseen = (anaD.analytics?.achievements || []).find((a: any) => !a.seen_at);
        if (unseen) {
          setNewBadgeInfo({
            id: unseen.id,
            name: unseen.title,
            description: unseen.subtitle
          });
          setShowBadgeEarned(true);
          // Mark seen
          fetch(`/api/member/achievements/${unseen.id}/seen`, { method: 'POST' });
        }
      }
    } catch (err) {
      console.error('Error fetching member dashboard:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleTaskClick = (t: any) => {
    if (t.nonCompletable || t.completed) return;
    setPendingTask(t);
    setTaskError(null);
  };

  const handleConfirmTaskCompletion = async () => {
    if (!pendingTask) return;
    const sessionStr = localStorage.getItem('member_session');
    if (!sessionStr) return;
    const session = JSON.parse(sessionStr);

    setIsCompletingTask(true);
    setTaskError(null);

    try {
      const res = await fetch(`/api/member/tasks/${pendingTask.id}/complete`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ gymId: session.gymId, memberId: session.memberId })
      });
      const d = await res.json();
      if (d && d.success) {
        if (d.newlyUnlockedAchievement) {
          setNewBadgeInfo({
            id: d.newlyUnlockedAchievement.id,
            name: d.newlyUnlockedAchievement.title,
            description: d.newlyUnlockedAchievement.subtitle
          });
          setShowBadgeEarned(true);
        }
        setMemberTasks(prev => prev.map(t => t.id === pendingTask.id ? { ...t, completed: true } : t));
        setPendingTask(null);
        fetchMemberDash();
      } else {
        setTaskError("Couldn't complete this action. Please try again.");
      }
    } catch (err) {
      console.error('Task completion error:', err);
      setTaskError("Couldn't complete this action. Please try again.");
    } finally {
      setIsCompletingTask(false);
    }
  };

  useEffect(() => {
    fetchMemberDash();
  }, []);

  if (loading) {
    return (
      <MemberLayout>
        <div className="py-20 text-center text-sm font-bold uppercase tracking-wider animate-pulse flex items-center justify-center gap-2">
          <Dumbbell className="animate-spin" size={20} /> Loading Dashboard...
        </div>
      </MemberLayout>
    );
  }

  const member = data?.member;
  const appInfo = data?.appInfo;

  // Real backend metrics (Strict Zero Fallback)
  const streak = member?.currentStreak ?? 0;
  const bestStreak = member?.bestStreak ?? 0;
  const isCheckedInToday = data?.checkedInToday;
  const levelInfo = appInfo?.member?.levelInfo || member?.levelInfo || { level: 1, title: 'Starter' };
  const rank = leaderboardData?.currentMemberRank || 1;
  const totalGymMembers = leaderboardData?.totalGymMembers || 1;

  const monthlyWorkoutCompleted = member?.monthlyWorkoutCompleted ?? 0;
  const monthlyAttendancePresent = member?.monthlyAttendancePresent ?? 0;
  const eligibleDays = member?.eligibleDays ?? 0;
  const attendancePercent = member?.attendancePercent ?? 0;
  const configuredGoal = member?.monthlyGoal ?? null;
  const goalProgressPct = configuredGoal && configuredGoal > 0
    ? Math.min(100, Math.round((monthlyWorkoutCompleted / configuredGoal) * 100))
    : 0;

  const consistencyPercent = member?.consistencyPercent ?? 0;

  // Real Current Week Days from Backend
  const weekDays = member?.currentWeekDays || [
    { label: 'Mon', active: false, isAttended: false, isWorkoutDone: false, date: '', isToday: false, isFuture: false, status: 'NO_ATTENDANCE' },
    { label: 'Tue', active: false, isAttended: false, isWorkoutDone: false, date: '', isToday: false, isFuture: false, status: 'NO_ATTENDANCE' },
    { label: 'Wed', active: false, isAttended: false, isWorkoutDone: false, date: '', isToday: false, isFuture: false, status: 'NO_ATTENDANCE' },
    { label: 'Thu', active: false, isAttended: false, isWorkoutDone: false, date: '', isToday: false, isFuture: false, status: 'NO_ATTENDANCE' },
    { label: 'Fri', active: false, isAttended: false, isWorkoutDone: false, date: '', isToday: false, isFuture: false, status: 'NO_ATTENDANCE' },
    { label: 'Sat', active: false, isAttended: false, isWorkoutDone: false, date: '', isToday: false, isFuture: false, status: 'NO_ATTENDANCE' },
    { label: 'Sun', active: false, isAttended: false, isWorkoutDone: false, date: '', isToday: false, isFuture: false, status: 'NO_ATTENDANCE' },
  ];

  // Calculate Streak Milestone and SVG Arc Offset
  const getNextMilestone = (s: number) => {
    const milestones = [3, 7, 14, 30, 60, 90, 180, 365];
    for (const m of milestones) {
      if (s < m) return m;
    }
    return s + 30;
  };
  const nextMilestone = getNextMilestone(streak);
  const streakProgressPct = Math.min(100, Math.round((streak / nextMilestone) * 100));

  const handleSaveGoal = async () => {
    setMonthlyGoal(tempGoal);
    localStorage.setItem('member_monthly_goal', tempGoal.toString());
    setIsGoalModalOpen(false);

    const sessionStr = localStorage.getItem('member_session');
    if (sessionStr) {
      try {
        const session = JSON.parse(sessionStr);
        await fetch('/api/member/goal', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ memberId: session.memberId, monthlyGoal: tempGoal })
        });
        fetchMemberDash();
      } catch (err) {
        console.error('Error saving goal:', err);
      }
    }
  };

  return (
    <MemberLayout>
      <div className="px-4 mt-6 space-y-6 pb-12">
        <PWAInstallBanner />

        {/* Level Up & Badge Modals */}
        <LevelUpModal
          isOpen={showLevelUp}
          onClose={() => setShowLevelUp(false)}
          levelInfo={newLevelInfo}
        />
        <BadgeEarnedModal
          isOpen={showBadgeEarned}
          onClose={() => setShowBadgeEarned(false)}
          badge={newBadgeInfo}
        />

        {/* Top Header Card */}
        <div className="clay-raised p-6 rounded-[28px] space-y-4 relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-[9px] font-black uppercase tracking-widest text-[#34A853] bg-[#34A853]/10 px-2.5 py-1 rounded-full border border-[#34A853]/20">
              {data?.gymName || 'MEMBER PORTAL'}
            </span>
            <div className={`flex items-center gap-1.5 px-3 py-1 rounded-full border ${
              streak > 0
                ? 'bg-[#EA4335]/10 border-[#EA4335]/20 text-[#EA4335]'
                : 'bg-neutral-100 dark:bg-neutral-800 border-neutral-300 dark:border-neutral-700 text-neutral-500'
            }`}>
              <Flame size={14} className={streak > 0 ? "fill-[#EA4335]" : "text-neutral-400"} />
              <span className="text-[10px] font-black font-mono tracking-wider">{streak} DAY STREAK</span>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-[20px] neo-pressed overflow-hidden flex items-center justify-center shrink-0 border border-[var(--border)]">
              {member?.profileImage ? (
                <img src={member.profileImage} alt={member.fullName} className="w-full h-full object-cover" />
              ) : (
                <User size={32} className="text-[var(--text-sec)]" />
              )}
            </div>
            <div>
              <h1 className="text-xl font-black uppercase tracking-wider text-[var(--text)]">
                {data?.greeting || `Welcome, ${member?.fullName || 'Member'}`}
              </h1>
              <p className="text-[11px] text-[var(--text-sec)] font-bold uppercase tracking-wider mt-0.5">
                Level {levelInfo.level} • {levelInfo.title}
              </p>
              <p className="text-[10px] text-[var(--text-sec)] font-mono mt-0.5">
                ID: <span className="text-[var(--text)] font-bold">{member?.memberDisplayId || member?.memberCode || 'MEM-0001'}</span>
              </p>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2 pt-2 border-t border-[var(--border)]">
            <div className="p-3 neo-pressed rounded-[16px] text-center">
              <span className="text-[8px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Gym Rank</span>
              <span className="text-xs font-black uppercase text-amber-500 font-mono inline-block mt-0.5">
                #{rank} / {totalGymMembers}
              </span>
            </div>
            <div className="p-3 neo-pressed rounded-[16px] text-center">
              <span className="text-[8px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Today Status</span>
              <span className={`text-[10px] font-black uppercase inline-block mt-0.5 ${isCheckedInToday ? 'text-[#34A853]' : 'text-[#E3A008]'}`}>
                {isCheckedInToday ? '✓ Checked In' : 'Pending'}
              </span>
            </div>
            <div className="p-3 neo-pressed rounded-[16px] text-center">
              <span className="text-[8px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Tier Badge</span>
              <span className="text-xs font-black uppercase text-[#34A853] font-mono inline-block mt-0.5">
                {analyticsData?.tier || 'BRONZE'}
              </span>
            </div>
          </div>
        </div>

        {/* GYM TIMING & DAILY WELLBEING BANNER */}
        <div className="clay-raised p-4 rounded-[24px] border border-[var(--border)] flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#34A853]/10 text-[#34A853] flex items-center justify-center shrink-0 border border-[#34A853]/20">
              <Calendar size={20} />
            </div>
            <div className="space-y-0.5">
              <div className="flex items-center gap-2">
                <span className="text-xs font-black uppercase tracking-wider text-[var(--text)]">
                  Preferred Gym Time: {member?.preferredTrainingTime || '07:00 AM'}
                </span>
                <span className="text-[9px] font-bold uppercase tracking-widest text-[#34A853] bg-[#34A853]/10 px-2 py-0.5 rounded-full">
                  10m Alert Active
                </span>
              </div>
              <p className="text-[10px] text-[var(--text-sec)]">
                Daily pre-gym reminder scheduled automatically for your workout.
              </p>
            </div>
          </div>
          <Link
            to="/member/wellbeing-checkin"
            className="px-3.5 py-2 rounded-xl bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 text-[10px] font-black uppercase tracking-wider hover:opacity-90 shrink-0 transition-all flex items-center gap-1.5"
          >
            <Activity size={14} className="text-[#34A853]" /> Daily Check-In
          </Link>
        </div>

        {/* TODAY'S GUIDANCE (TODAY'S WORK) */}
        <div className="clay-raised p-6 rounded-[28px] space-y-4 border border-[var(--border)]">
          <div className="flex items-center justify-between border-b border-[var(--border)] pb-3">
            <div>
              <h3 className="text-xs font-black uppercase tracking-wider text-[var(--text)] flex items-center gap-2">
                <CheckCircle2 size={18} className="text-[#34A853]" /> Today's Guidance (Today's Work)
              </h3>
              <p className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)]">
                {isGymOpenToday ? 'Confirm your daily gym & fitness actions' : 'Gym Rest Day Schedule'}
              </p>
            </div>
            <span className="text-[10px] font-black font-mono px-2.5 py-1 rounded-full bg-[#34A853]/10 text-[#34A853] border border-[#34A853]/20">
              {memberTasks.filter(t => t.completed).length} / {memberTasks.length} Done
            </span>
          </div>

          <div className="space-y-3">
            {memberTasks.map((t) => (
              <div 
                key={t.id}
                className={`p-4 rounded-[20px] flex items-center justify-between gap-3 transition-all ${
                  t.completed ? 'neo-pressed opacity-85' : 'neo-raised border border-[var(--border)]'
                }`}
              >
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    disabled={t.nonCompletable || t.completed}
                    onClick={() => handleTaskClick(t)}
                    aria-label={`Complete task ${t.title}`}
                    className={`w-6 h-6 rounded-lg flex items-center justify-center transition-all cursor-pointer border-2 ${
                      t.completed 
                        ? 'bg-[#34A853] dark:bg-[#34A853] text-white border-[#34A853]' 
                        : 'border-neutral-400 dark:border-neutral-500 bg-white dark:bg-[#181818] text-neutral-900 dark:text-white'
                    } ${t.nonCompletable ? 'cursor-not-allowed opacity-60' : ''}`}
                  >
                    {t.completed && <Check size={14} className="stroke-[3]" />}
                  </button>

                  <div>
                    <p className={`text-xs font-black uppercase ${t.completed ? 'line-through text-[var(--text-sec)]' : 'text-[var(--text)]'}`}>
                      {t.title}
                    </p>
                    <p className="text-[10px] text-[var(--text-sec)] font-medium mt-0.5">{t.subtitle}</p>
                  </div>
                </div>

                {t.url && !t.completed && (
                  <Link
                    to={t.url}
                    className="h-8 px-3 rounded-xl bg-[var(--btn-bg)] text-[var(--btn-text)] text-[10px] font-black uppercase tracking-wider flex items-center justify-center gap-1 shrink-0"
                  >
                    Action <ArrowRight size={12} />
                  </Link>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* GYM EMERGENCY CONTACT */}
        <div className="clay-raised p-4 rounded-[22px] flex items-center justify-between border border-[var(--border)]">
          <div>
            <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">
              Gym Emergency Assistance
            </span>
            {(data?.gymPhone || appInfo?.gym?.phone) ? (
              <a
                href={`tel:${data?.gymPhone || appInfo?.gym?.phone}`}
                className="text-xs font-black uppercase text-[#EA4335] hover:underline flex items-center gap-1.5 mt-0.5"
              >
                Emergency Contact: {data?.gymPhone || appInfo?.gym?.phone}
              </a>
            ) : (
              <span className="text-xs font-medium text-[var(--text-sec)] block mt-0.5">
                Gym emergency contact not configured
              </span>
            )}
          </div>
        </div>

        {/* PREMIUM VISUAL STREAK CARD */}
        <div className="clay-raised p-6 rounded-[28px] space-y-4 border border-[var(--border)] relative overflow-hidden">
          <div className="flex items-center justify-between border-b border-[var(--border)] pb-3">
            <div>
              <h3 className="text-xs font-black uppercase tracking-wider text-[var(--text)] flex items-center gap-2">
                <Flame size={18} className={streak > 0 ? "text-[#EA4335]" : "text-slate-400"} /> Streak Momentum
              </h3>
              <p className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)]">
                {streak > 0 ? 'Consecutive daily activity streak' : 'Start your streak journey'}
              </p>
            </div>
            <span className="text-[10px] font-mono font-bold uppercase tracking-wider px-2.5 py-1 rounded-full neo-pressed text-[var(--text-sec)]">
              Best: {bestStreak} Days
            </span>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-6 p-5 neo-pressed rounded-[24px]">
            {/* Animated SVG Radial Arc */}
            <div className="relative w-28 h-28 flex items-center justify-center shrink-0">
              <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                <circle
                  cx="50"
                  cy="50"
                  r="40"
                  stroke="currentColor"
                  strokeWidth="8"
                  className="text-neutral-200 dark:text-neutral-800 fill-none"
                />
                <circle
                  cx="50"
                  cy="50"
                  r="40"
                  stroke="currentColor"
                  strokeWidth="8"
                  strokeDasharray={2 * Math.PI * 40}
                  strokeDashoffset={(2 * Math.PI * 40) * (1 - (streakProgressPct / 100))}
                  strokeLinecap="round"
                  className={`fill-none transition-all duration-1000 ${
                    streak > 0 ? 'text-[#34A853]' : 'text-slate-300 dark:text-slate-700'
                  }`}
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                <span className={`text-2xl font-black font-mono leading-none ${streak > 0 ? 'text-[#34A853]' : 'text-[var(--text-sec)]'}`}>
                  {streak}
                </span>
                <span className="text-[8px] font-bold uppercase tracking-widest text-[var(--text-sec)] mt-1">
                  {streak === 1 ? 'DAY' : 'DAYS'}
                </span>
              </div>
            </div>

            <div className="space-y-2 text-center sm:text-left flex-1">
              {streak === 0 ? (
                <>
                  <p className="text-xs font-black uppercase text-[var(--text)] tracking-wider">
                    No Active Streak
                  </p>
                  <p className="text-[11px] text-[var(--text-sec)] leading-relaxed">
                    Complete your first qualifying check-in or workout task to start your streak momentum.
                  </p>
                  <p className="text-[10px] font-mono font-bold text-[#34A853] pt-1">
                    Next Goal: 3 Day Milestone
                  </p>
                </>
              ) : (
                <>
                  <p className="text-xs font-black uppercase text-[var(--text)] tracking-wider flex items-center justify-center sm:justify-start gap-1.5">
                    <Sparkles size={14} className="text-amber-500" /> {streak} Day Active Streak
                  </p>
                  <p className="text-[11px] text-[var(--text-sec)] leading-relaxed">
                    Keep your momentum going! Complete tomorrow's activity to maintain your streak.
                  </p>
                  <div className="flex items-center justify-center sm:justify-start gap-2 pt-1 text-[10px] font-mono font-bold">
                    <span className="text-[var(--text-sec)]">Next Milestone: {nextMilestone} Days</span>
                    <span className="text-[#34A853]">({streakProgressPct}% Progress)</span>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>

        {/* MONTHLY WORKOUT TARGET CARD */}
        <div className="clay-raised p-6 rounded-[28px] space-y-4 border border-[var(--border)]">
          <div className="flex items-center justify-between border-b border-[var(--border)] pb-3">
            <div>
              <h3 className="text-xs font-black uppercase tracking-wider text-[var(--text)] flex items-center gap-2">
                <Dumbbell size={18} className="text-[#34A853]" /> Monthly Workout Target
              </h3>
              <p className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)]">
                Track active completed workouts vs target goal
              </p>
            </div>
            <button
              onClick={() => {
                setTempGoal(configuredGoal || 20);
                setIsGoalModalOpen(true);
              }}
              className="px-3 py-1.5 rounded-[12px] neo-raised text-[10px] font-bold uppercase tracking-wider text-[var(--text)] flex items-center gap-1 cursor-pointer active:scale-95 transition-transform"
            >
              <Edit3 size={12} /> Set Goal
            </button>
          </div>

          <div className="space-y-3 p-4 neo-pressed rounded-[22px]">
            <div className="flex justify-between items-center text-xs font-bold font-mono">
              <span className="text-[var(--text-sec)] uppercase text-[10px]">Workouts Completed</span>
              <span className="text-[var(--text)] font-black">
                {configuredGoal ? `${monthlyWorkoutCompleted} / ${configuredGoal} Workouts (${goalProgressPct}%)` : `${monthlyWorkoutCompleted} Workouts Completed • Goal Not Set`}
              </span>
            </div>

            <div className="w-full h-3 rounded-full neo-pressed overflow-hidden bg-[var(--surface-sec)] relative">
              <div
                className="h-full bg-gradient-to-r from-[#34A853] to-[#4285F4] transition-all duration-700 rounded-full shadow-sm"
                style={{ width: `${goalProgressPct}%` }}
              />
            </div>

            <div className="flex justify-between items-center text-[10px] text-[var(--text-sec)] font-medium pt-0.5">
              <span>
                {!configuredGoal
                  ? 'Configure your monthly goal to measure workout progress.'
                  : goalProgressPct >= 100
                  ? 'Target Achieved! Outstanding workout discipline!'
                  : `${configuredGoal - monthlyWorkoutCompleted} workouts remaining to hit monthly target`}
              </span>
              <span className="font-mono font-bold text-[#34A853]">Consistency: {consistencyPercent}%</span>
            </div>
          </div>
        </div>

        {/* MONTHLY ATTENDANCE STATISTICS CARD */}
        <div className="clay-raised p-6 rounded-[28px] space-y-4 border border-[var(--border)]">
          <div className="flex items-center justify-between border-b border-[var(--border)] pb-3">
            <div>
              <h3 className="text-xs font-black uppercase tracking-wider text-[var(--text)] flex items-center gap-2">
                <Calendar size={18} className="text-[#4285F4]" /> Monthly Attendance Statistics
              </h3>
              <p className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)]">
                Actual reception check-in records
              </p>
            </div>
            <span className="text-[10px] font-mono font-bold uppercase tracking-wider px-2.5 py-1 rounded-full neo-pressed text-[#4285F4]">
              {attendancePercent}% Attendance
            </span>
          </div>

          {/* Real Attendance Stats Grid */}
          <div className="grid grid-cols-3 gap-2">
            <div className="p-3 neo-pressed rounded-[18px] text-center">
              <span className="text-[8px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Present</span>
              <span className="text-sm font-black font-mono text-[#34A853] mt-0.5 block">{monthlyAttendancePresent} Days</span>
            </div>
            <div className="p-3 neo-pressed rounded-[18px] text-center">
              <span className="text-[8px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Eligible</span>
              <span className="text-sm font-black font-mono text-[var(--text)] mt-0.5 block">{eligibleDays} Days</span>
            </div>
            <div className="p-3 neo-pressed rounded-[18px] text-center">
              <span className="text-[8px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Attendance</span>
              <span className="text-sm font-black font-mono text-[#4285F4] mt-0.5 block">{attendancePercent}%</span>
            </div>
          </div>

          {/* Current Week Day-by-Day Attendance Matrix */}
          <div className="space-y-2 pt-1">
            <div className="flex justify-between items-center">
              <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">
                Current Week Attendance Matrix
              </span>
              <span className="text-[9px] font-mono font-bold text-[var(--text-sec)]">
                Asia/Kolkata
              </span>
            </div>

            <div className="grid grid-cols-7 gap-1.5">
              {weekDays.map((d, i) => (
                <div
                  key={i}
                  className={`p-2.5 rounded-[14px] text-center space-y-1 transition-all ${
                    d.active
                      ? 'bg-[#34A853]/20 border border-[#34A853]/40 text-[#34A853]'
                      : d.isToday
                      ? 'border border-[#4285F4] text-[#4285F4] bg-[#4285F4]/10'
                      : d.isFuture
                      ? 'opacity-40 neo-pressed text-[var(--text-sec)]'
                      : 'neo-pressed text-[var(--text-sec)]'
                  }`}
                >
                  <span className="text-[9px] font-bold uppercase block">{d.label}</span>
                  <div className="flex items-center justify-center">
                    {d.active ? (
                      <CheckCircle2 size={14} className="text-[#34A853]" />
                    ) : d.isToday ? (
                      <div className="w-2 h-2 rounded-full bg-[#4285F4] animate-pulse" />
                    ) : (
                      <div className="w-2 h-2 rounded-full bg-[var(--border)]" />
                    )}
                  </div>
                </div>
              ))}
            </div>

            {monthlyAttendancePresent === 0 && (
              <p className="text-[10px] text-[var(--text-sec)] text-center font-medium pt-1">
                No attendance recorded yet. Scan reception QR code to mark present.
              </p>
            )}
          </div>
        </div>

        {/* Quick Nav Grid */}
        <div className="grid grid-cols-2 gap-3.5">
          <Link
            to="/member/workout"
            className="neo-raised p-4 rounded-[22px] space-y-2 hover:scale-[1.02] active:scale-95 transition-transform border border-[var(--border)]"
          >
            <div className="w-9 h-9 rounded-xl neo-pressed flex items-center justify-center text-[var(--text)]">
              <Dumbbell size={18} />
            </div>
            <div>
              <h3 className="text-xs font-black uppercase tracking-wider text-[var(--text)]">Today's Workout</h3>
              <p className="text-[9px] text-[var(--text-sec)] font-medium mt-0.5">Owner-assigned daily routine</p>
            </div>
          </Link>

          <Link
            to="/member/attendance"
            className="neo-raised p-4 rounded-[22px] space-y-2 hover:scale-[1.02] active:scale-95 transition-transform border border-[var(--border)]"
          >
            <div className="w-9 h-9 rounded-xl neo-pressed flex items-center justify-center text-[#34A853]">
              <QrCode size={18} />
            </div>
            <div>
              <h3 className="text-xs font-black uppercase tracking-wider text-[var(--text)]">Attendance QR</h3>
              <p className="text-[9px] text-[var(--text-sec)] font-medium mt-0.5">Scan gym reception code</p>
            </div>
          </Link>

          <Link
            to="/member/plans"
            className="neo-raised p-4 rounded-[22px] space-y-2 hover:scale-[1.02] active:scale-95 transition-transform border border-[var(--border)]"
          >
            <div className="w-9 h-9 rounded-xl neo-pressed flex items-center justify-center text-amber-500">
              <CreditCard size={18} />
            </div>
            <div>
              <h3 className="text-xs font-black uppercase tracking-wider text-[var(--text)]">Gym Plans</h3>
              <p className="text-[9px] text-[var(--text-sec)] font-medium mt-0.5">Membership & UPI payment</p>
            </div>
          </Link>

          <Link
            to="/member/profile"
            className="neo-raised p-4 rounded-[22px] space-y-2 hover:scale-[1.02] active:scale-95 transition-transform border border-[var(--border)]"
          >
            <div className="w-9 h-9 rounded-xl neo-pressed flex items-center justify-center text-[var(--text)]">
              <Award size={18} />
            </div>
            <div>
              <h3 className="text-xs font-black uppercase tracking-wider text-[var(--text)]">Digital ID & Badges</h3>
              <p className="text-[9px] text-[var(--text-sec)] font-medium mt-0.5">Profile card, level & settings</p>
            </div>
          </Link>
        </div>

        {/* Leaderboard Summary Banner */}
        {leaderboardData && leaderboardData.leaderboard && (
          <div className="neo-raised p-5 rounded-[28px] space-y-3">
            <div className="flex justify-between items-center border-b border-[var(--border)] pb-3">
              <div>
                <h3 className="text-xs font-black uppercase tracking-wider text-[var(--text)] flex items-center gap-2">
                  <Trophy size={16} className="text-amber-500" /> Gym Leaderboard
                </h3>
                <p className="text-[9px] text-[var(--text-sec)] uppercase font-bold mt-0.5">
                  Monthly Performance Rankings ({leaderboardData.monthKey})
                </p>
              </div>
              <span className="text-[10px] font-black uppercase tracking-wider bg-amber-500/10 text-amber-500 px-2.5 py-1 rounded-full border border-amber-500/20">
                Rank #{rank}
              </span>
            </div>

            <div className="space-y-2">
              {leaderboardData.leaderboard.slice(0, 3).map((item: any) => (
                <div 
                  key={item.memberId}
                  className={`p-3 rounded-[16px] flex items-center justify-between gap-3 text-xs ${
                    item.isSelf ? 'neo-pressed border border-amber-500/40' : 'neo-pressed'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className={`font-mono font-black text-xs w-5 text-center ${
                      item.rank === 1 ? 'text-amber-500' : item.rank === 2 ? 'text-slate-400' : 'text-amber-700'
                    }`}>
                      #{item.rank}
                    </span>
                    <div className="w-7 h-7 rounded-full bg-[var(--surface)] neo-raised overflow-hidden flex items-center justify-center shrink-0">
                      {item.profileImage ? (
                        <img src={item.profileImage} alt="" className="w-full h-full object-cover" />
                      ) : (
                        <User size={14} className="text-[var(--text-sec)]" />
                      )}
                    </div>
                    <div>
                      <span className="font-bold text-[var(--text)] block">{item.displayName} {item.isSelf && '(You)'}</span>
                      <span className="text-[9px] text-[var(--text-sec)] font-mono">Level {item.level} • {item.attendanceDays} Days Attended</span>
                    </div>
                  </div>

                  <span className="font-mono font-black text-xs text-[var(--text)] bg-[var(--surface)] px-2.5 py-1 rounded-full neo-raised">
                    {item.performanceScore} pts
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Primary QR CTA */}
        <div className="neo-raised p-5 rounded-[28px] space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-black uppercase text-[var(--text)]">Today's Attendance</p>
              <p className="text-[10px] text-[var(--text-sec)] font-medium mt-0.5">Scan gym reception QR code to mark present</p>
            </div>
            <Link
              to="/member/attendance"
              className="h-10 px-4 rounded-[16px] bg-[#34A853] text-white text-xs font-black uppercase tracking-wider flex items-center justify-center gap-1.5 shadow-md active:scale-95 transition-transform shrink-0"
            >
              <QrCode size={16} /> Scan QR
            </Link>
          </div>
        </div>

        {/* SET TARGET GOAL MODAL */}
        {isGoalModalOpen && (
          <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
            <div className="w-full max-w-sm bg-[var(--surface)] p-6 rounded-[28px] neo-raised space-y-5 border border-[var(--border)]">
              <div className="flex justify-between items-center border-b border-[var(--border)] pb-3">
                <div className="flex items-center gap-2">
                  <Target size={20} className="text-[#34A853]" />
                  <h3 className="text-sm font-black uppercase tracking-wider text-[var(--text)]">Monthly Goal Target</h3>
                </div>
                <button
                  onClick={() => setIsGoalModalOpen(false)}
                  className="w-8 h-8 rounded-full neo-pressed flex items-center justify-center text-[var(--text-sec)] cursor-pointer"
                >
                  ✕
                </button>
              </div>

              <div className="space-y-3">
                <label className="text-xs font-bold uppercase tracking-wider text-[var(--text-sec)] block">
                  Select Target Workouts / Month
                </label>
                <div className="grid grid-cols-5 gap-2">
                  {[12, 16, 20, 24, 28].map((g) => (
                    <button
                      key={g}
                      onClick={() => setTempGoal(g)}
                      className={`py-3 rounded-[16px] text-xs font-black font-mono transition-all cursor-pointer ${
                        tempGoal === g
                          ? 'bg-[var(--btn-bg)] text-[var(--btn-text)] shadow-md'
                          : 'neo-pressed text-[var(--text-sec)]'
                      }`}
                    >
                      {g}d
                    </button>
                  ))}
                </div>
                <p className="text-[10px] text-[var(--text-sec)] font-mono">
                  Targeting {tempGoal} workouts per month = ~{Math.round((tempGoal / 30) * 7)} workouts every week.
                </p>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  onClick={() => setIsGoalModalOpen(false)}
                  className="w-1/3 h-11 rounded-[16px] neo-raised text-xs font-bold uppercase cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSaveGoal}
                  className="w-2/3 h-11 rounded-[16px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-wider shadow-md active:scale-95 transition-transform cursor-pointer"
                >
                  Save Target Goal
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TASK COMPLETION CONFIRMATION MODAL */}
        {pendingTask && (
          <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
            <div className="w-full max-w-sm bg-[var(--surface)] p-6 rounded-[28px] neo-raised space-y-4 border border-[var(--border)]">
              <div className="flex justify-between items-center border-b border-[var(--border)] pb-3">
                <h3 className="text-sm font-black uppercase tracking-wider text-[var(--text)]">Complete Task?</h3>
                <button
                  onClick={() => { setPendingTask(null); setTaskError(null); }}
                  disabled={isCompletingTask}
                  className="w-8 h-8 rounded-full neo-pressed flex items-center justify-center text-[var(--text-sec)] cursor-pointer disabled:opacity-50"
                >
                  ✕
                </button>
              </div>

              <div className="space-y-2">
                <p className="text-xs text-[var(--text)] font-bold">
                  Are you sure you completed "{pendingTask.title}"?
                </p>
                <p className="text-[10px] text-[var(--text-sec)]">
                  {pendingTask.subtitle || 'Your gym streak and activity tier progress will be updated.'}
                </p>

                {taskError && (
                  <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-xl text-red-500 text-[11px] font-bold">
                    {taskError}
                  </div>
                )}
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  onClick={() => { setPendingTask(null); setTaskError(null); }}
                  disabled={isCompletingTask}
                  className="w-1/2 h-11 rounded-[16px] neo-raised text-xs font-bold uppercase cursor-pointer disabled:opacity-50"
                >
                  Cancel
                </button>
                <button
                  onClick={handleConfirmTaskCompletion}
                  disabled={isCompletingTask}
                  className="w-1/2 h-11 rounded-[16px] bg-[#34A853] text-white text-xs font-black uppercase tracking-wider shadow-md active:scale-95 transition-transform cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {isCompletingTask ? (
                    <>
                      <Loader2 size={16} className="animate-spin" /> Saving...
                    </>
                  ) : taskError ? (
                    'Retry'
                  ) : (
                    'Confirm'
                  )}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </MemberLayout>
  );
}
