import React, { useState, useEffect } from 'react';
import { useNavigate } from '@/lib/router-compat';
import { 
  User, Dumbbell, Calendar, LogOut, Headset, ShieldCheck, 
  Key, Moon, Sun, Globe, Bell, Check, Edit2, Save, X, Phone, MapPin, Award, Sparkles, Lock, Eye, EyeOff, Shield
} from 'lucide-react';
import MemberLayout from '../../components/MemberLayout';
import PWAInstallBanner from '../../components/PWAInstallBanner';
import DigitalIdCard from '../../components/DigitalIdCard';
import { signOutEverything } from '@/lib/app-auth';
import { setStoredLanguage, getStoredLanguage, LANGUAGES, type Language } from '@/lib/i18n';

export default function MemberProfile() {
  const navigate = useNavigate();
  const [member, setMember] = useState<any>(null);
  const [appInfo, setAppInfo] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState<'profile' | 'achievements' | 'privacy' | 'preferences'>('profile');
  const [idCardOpen, setIdCardOpen] = useState(false);
  const [toast, setToast] = useState<string | null>(null);

  // Editable Profile Form State
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [age, setAge] = useState('');
  const [dob, setDob] = useState('');
  const [gender, setGender] = useState('Male');
  const [location, setLocation] = useState('');
  const [profileImage, setProfileImage] = useState('');

  // Public Profile & Privacy Toggles
  const [showPublicProfile, setShowPublicProfile] = useState(false);
  const [showPhotoPublicly, setShowPhotoPublicly] = useState(true);
  const [showNamePublicly, setShowNamePublicly] = useState(true);
  const [showLevelPublicly, setShowLevelPublicly] = useState(true);
  const [showBadgesPublicly, setShowBadgesPublicly] = useState(true);
  const [showRankPublicly, setShowRankPublicly] = useState(true);

  // Fitness Preferences
  const [primaryGoal, setPrimaryGoal] = useState('Muscle Building');
  const [dietPref, setDietPref] = useState('Non-Veg');
  const [workoutTime, setWorkoutTime] = useState('Morning');

  // App & Notification Preferences
  const [appLanguage, setAppLanguage] = useState<Language>(getStoredLanguage());
  const [appTheme, setAppTheme] = useState(localStorage.getItem('theme') || 'dark');
  const [notifyWorkout, setNotifyWorkout] = useState(true);
  const [notifyAttendance, setNotifyAttendance] = useState(true);
  const [notifyRenewal, setNotifyRenewal] = useState(true);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  };

  const fetchProfile = async () => {
    const sessionStr = localStorage.getItem('member_session');
    if (!sessionStr) { navigate('/'); return; }
    const session = JSON.parse(sessionStr);

    try {
      const [mRes, aRes] = await Promise.all([
        fetch(`/api/members/${session.gymId}/${session.memberId}`),
        fetch(`/api/member-app/${session.gymId}/${session.memberId}`)
      ]);

      const m = await mRes.json();
      const a = await aRes.json();

      if (m && m.id) {
        setMember(m);
        setFullName(m.fullName || '');
        setPhone(m.phone || '');
        setEmail(m.email || '');
        setAge(m.age ? m.age.toString() : '');
        setDob(m.dob || '');
        setGender(m.gender || 'Male');
        setLocation(m.location || '');
        setProfileImage(m.profileImage || '');

        setShowPublicProfile(m.showPublicProfile === true);
        setShowPhotoPublicly(m.showPhotoPublicly !== false);
        setShowNamePublicly(m.showNamePublicly !== false);
        setShowLevelPublicly(m.showLevelPublicly !== false);
        setShowBadgesPublicly(m.showBadgesPublicly !== false);
        setShowRankPublicly(m.showRankPublicly !== false);

        if (m.fitnessPreferences) {
          setPrimaryGoal(m.fitnessPreferences.primaryGoal || 'Muscle Building');
          setDietPref(m.fitnessPreferences.dietPref || 'Non-Veg');
          setWorkoutTime(m.fitnessPreferences.workoutTime || 'Morning');
        }

        if (m.notificationPreferences) {
          setNotifyWorkout(m.notificationPreferences.notifyWorkout ?? true);
          setNotifyAttendance(m.notificationPreferences.notifyAttendance ?? true);
          setNotifyRenewal(m.notificationPreferences.notifyRenewal ?? true);
        }
      }

      if (a && a.success) {
        setAppInfo(a);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProfile();
  }, []);

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);

    const sessionStr = localStorage.getItem('member_session');
    if (!sessionStr) return;
    const session = JSON.parse(sessionStr);

    try {
      const res = await fetch('/api/member/profile', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          memberId: session.memberId,
          gymId: session.gymId,
          fullName,
          phone,
          email,
          age: age ? Number(age) : null,
          dob,
          gender,
          location,
          profileImage,
          showPublicProfile,
          showPhotoPublicly,
          showNamePublicly,
          showLevelPublicly,
          showBadgesPublicly,
          showRankPublicly,
          fitnessPreferences: { primaryGoal, dietPref, workoutTime },
          notificationPreferences: { notifyWorkout, notifyAttendance, notifyRenewal },
          appLanguage,
          appTheme
        })
      });

      const data = await res.json();
      if (data.success && data.member) {
        setMember(data.member);
        showToast('Profile and settings updated successfully!');
      }
    } catch (err) {
      console.error(err);
      showToast('Failed to update profile.');
    } finally {
      setSaving(false);
    }
  };

  const handleLanguageChange = (newLang: Language) => {
    setAppLanguage(newLang);
    setStoredLanguage(newLang);
  };

  const handleThemeToggle = () => {
    const nextTheme = appTheme === 'dark' ? 'light' : 'dark';
    setAppTheme(nextTheme);
    localStorage.setItem('theme', nextTheme);
    if (nextTheme === 'light') {
      document.documentElement.classList.add('light');
      document.documentElement.classList.remove('dark');
    } else {
      document.documentElement.classList.add('dark');
      document.documentElement.classList.remove('light');
    }
  };

  const displayId = member?.memberDisplayId || `MEM-${member?.id?.replace(/\D/g, '').slice(-4) || '0042'}`;
  const daysRemaining = member?.daysRemaining || 30;
  const levelInfo = appInfo?.member?.levelInfo || { level: 1, title: 'Starter' };
  const badges = appInfo?.badges || [];

  return (
    <MemberLayout>
      <div className="px-4 mt-6 space-y-6 max-w-lg mx-auto pb-12">
        {toast && (
          <div className="fixed top-5 right-5 z-50 bg-[#34A853] text-white px-4 py-3 rounded-2xl font-bold text-xs shadow-lg animate-bounce">
            ✓ {toast}
          </div>
        )}

        <div className="flex justify-between items-center">
          <div>
            <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)]">My Account</span>
            <h1 className="text-2xl font-black uppercase tracking-wider text-[var(--text)]">Member Profile</h1>
          </div>

          <button
            onClick={() => setIdCardOpen(true)}
            className="px-3.5 py-2 rounded-xl bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-wider flex items-center gap-1.5 active:scale-95 transition-transform cursor-pointer shadow-sm"
          >
            <ShieldCheck size={16} /> Digital ID Card
          </button>
        </div>

        <PWAInstallBanner />

        {loading ? (
          <div className="py-20 text-center text-sm font-bold uppercase tracking-wider animate-pulse flex items-center justify-center gap-2">
            <Dumbbell className="animate-spin" size={20} /> Loading Profile...
          </div>
        ) : (
          <div className="space-y-6">
            {/* Member Profile Avatar Header Card */}
            <div className="clay-raised p-6 rounded-[28px] space-y-4">
              <div className="flex items-center gap-4">
                {profileImage ? (
                  <img src={profileImage} alt={fullName} className="w-16 h-16 rounded-full object-cover neo-pressed" />
                ) : (
                  <div className="w-16 h-16 rounded-full neo-pressed flex items-center justify-center font-black text-2xl uppercase text-[var(--text)]">
                    {fullName?.charAt(0) || 'M'}
                  </div>
                )}
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-lg font-black uppercase tracking-wider">{fullName}</h2>
                    <span className="text-[9px] font-mono px-2 py-0.5 rounded bg-[var(--btn-bg)] text-[var(--btn-text)] font-bold">
                      {displayId}
                    </span>
                  </div>
                  <p className="text-xs text-[var(--text-sec)] font-mono mt-0.5">{phone}</p>
                  <p className="text-[10px] text-amber-500 font-bold uppercase tracking-wider mt-0.5">
                    Level {levelInfo.level} • {levelInfo.title}
                  </p>
                </div>
              </div>

              {/* READ-ONLY Membership Plan Display */}
              <div className="space-y-2 pt-2 border-t border-[var(--border)]">
                <div className="flex justify-between items-center text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] px-1">
                  <span>Membership Details (Owner Managed)</span>
                  <span className="text-[#34A853]">Active</span>
                </div>
                
                <div className="grid grid-cols-2 gap-2">
                  <div className="p-3 neo-pressed rounded-[14px]">
                    <span className="text-[8px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Gym</span>
                    <span className="text-xs font-bold text-[var(--text)] mt-0.5 block truncate">{member?.gymName || 'Apex Fitness Club'}</span>
                  </div>
                  <div className="p-3 neo-pressed rounded-[14px]">
                    <span className="text-[8px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Current Plan</span>
                    <span className="text-xs font-bold text-[var(--text)] mt-0.5 block truncate">{member?.planName || 'Standard Plan'}</span>
                  </div>
                  <div className="p-3 neo-pressed rounded-[14px]">
                    <span className="text-[8px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Plan Expiry</span>
                    <span className="text-xs font-bold font-mono text-[var(--text)] mt-0.5 block">{member?.membershipExpiry || member?.endDate || 'Active'}</span>
                  </div>
                  <div className="p-3 neo-pressed rounded-[14px]">
                    <span className="text-[8px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Days Left</span>
                    <span className="text-xs font-black font-mono text-[#34A853] mt-0.5 block">{daysRemaining} Days</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Profile Navigation Tabs */}
            <div className="flex gap-2 border-b border-[var(--border)] pb-2 overflow-x-auto hide-scrollbar">
              {[
                { id: 'profile', label: 'Personal' },
                { id: 'achievements', label: 'Badges & Level' },
                { id: 'privacy', label: 'Privacy' },
                { id: 'preferences', label: 'App Settings' }
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`px-3.5 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider transition-all cursor-pointer whitespace-nowrap ${
                    activeTab === tab.id
                      ? 'bg-[var(--btn-bg)] text-[var(--btn-text)] shadow-sm'
                      : 'neo-pressed text-[var(--text-sec)] hover:text-[var(--text)]'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* TAB 1: PERSONAL DETAILS */}
            {activeTab === 'profile' && (
              <form onSubmit={handleSaveProfile} className="clay-raised p-6 rounded-[24px] space-y-4 animate-fade-in">
                <h3 className="text-xs font-black uppercase tracking-wider text-[var(--text)] border-b border-[var(--border)] pb-2">
                  Edit Personal Information
                </h3>

                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] mb-1">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full h-11 px-4 neo-pressed rounded-[14px] text-xs font-bold text-[var(--text)] outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] mb-1">
                    Phone Number *
                  </label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full h-11 px-4 neo-pressed rounded-[14px] text-xs font-bold font-mono text-[var(--text)] outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    placeholder="you@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full h-11 px-4 neo-pressed rounded-[14px] text-xs font-bold text-[var(--text)] outline-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] mb-1">
                      Age
                    </label>
                    <input
                      type="number"
                      value={age}
                      onChange={(e) => setAge(e.target.value)}
                      className="w-full h-11 px-4 neo-pressed rounded-[14px] text-xs font-bold text-[var(--text)] outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] mb-1">
                      Gender
                    </label>
                    <select
                      value={gender}
                      onChange={(e) => setGender(e.target.value)}
                      className="w-full h-11 px-4 neo-pressed rounded-[14px] text-xs font-bold text-[var(--text)] bg-[var(--surface)] cursor-pointer outline-none"
                    >
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Other">Other</option>
                      <option value="Prefer not to say">Prefer not to say</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] mb-1">
                    Locality / City
                  </label>
                  <input
                    type="text"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="w-full h-11 px-4 neo-pressed rounded-[14px] text-xs font-bold text-[var(--text)] outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] mb-1">
                    Profile Photo
                  </label>
                  <div className="space-y-2">
                    <label className="w-full h-11 px-4 neo-raised rounded-[14px] text-xs font-bold text-[var(--text)] flex items-center justify-center gap-2 cursor-pointer hover:bg-[var(--surface-sec)] transition-colors">
                      Upload Photo File
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            const reader = new FileReader();
                            reader.onload = (ev) => {
                              setProfileImage(ev.target?.result as string || '');
                            };
                            reader.readAsDataURL(file);
                          }
                        }}
                      />
                    </label>

                    <input
                      type="url"
                      placeholder="Or paste image URL (https://...)"
                      value={profileImage}
                      onChange={(e) => setProfileImage(e.target.value)}
                      className="w-full h-11 px-4 neo-pressed rounded-[14px] text-xs font-bold text-[var(--text)] outline-none"
                    />

                    {profileImage && (
                      <div className="flex items-center gap-3 p-2 neo-pressed rounded-xl">
                        <img src={profileImage} alt="Preview" className="w-10 h-10 rounded-full object-cover neo-pressed" />
                        <span className="text-xs font-bold text-[var(--text)] flex-1 truncate">Photo Selected</span>
                        <button
                          type="button"
                          onClick={() => setProfileImage('')}
                          className="px-2 py-1 neo-raised rounded-lg text-[10px] text-[#D64545] font-bold uppercase cursor-pointer"
                        >
                          Remove
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={saving}
                  className="w-full h-12 rounded-[16px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 cursor-pointer active:scale-95 transition-transform"
                >
                  {saving ? 'Saving...' : 'Save Personal Details'}
                </button>
              </form>
            )}

            {/* TAB 2: ACHIEVEMENTS & BADGES */}
            {activeTab === 'achievements' && (
              <div className="clay-raised p-6 rounded-[24px] space-y-6 animate-fade-in">
                <div className="flex justify-between items-center border-b border-[var(--border)] pb-2">
                  <h3 className="text-xs font-black uppercase tracking-wider text-[var(--text)]">
                    Level & Achievement Badges
                  </h3>
                  <span className="text-[10px] font-black uppercase text-amber-500 font-mono">
                    Level {levelInfo.level} • {levelInfo.title}
                  </span>
                </div>

                {/* Badge Grid */}
                <div className="grid grid-cols-2 gap-3">
                  {badges.map((b: any) => (
                    <div 
                      key={b.id} 
                      className={`p-4 rounded-[20px] space-y-2 relative border transition-all ${
                        b.unlocked 
                          ? 'neo-raised border-amber-500/30' 
                          : 'neo-pressed border-transparent opacity-60'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center text-lg ${
                          b.unlocked ? 'bg-amber-500/20 text-amber-500' : 'bg-gray-500/10 text-gray-400'
                        }`}>
                          <Award size={20} />
                        </div>
                        {b.unlocked ? (
                          <span className="text-[8px] font-black uppercase tracking-widest text-[#34A853] bg-[#34A853]/10 px-2 py-0.5 rounded-full">
                            UNLOCKED
                          </span>
                        ) : (
                          <Lock size={14} className="text-[var(--text-sec)]" />
                        )}
                      </div>

                      <div>
                        <h4 className="text-xs font-black uppercase tracking-wider text-[var(--text)]">{b.name}</h4>
                        <p className="text-[10px] text-[var(--text-sec)] leading-tight mt-0.5">{b.description}</p>
                      </div>

                      {!b.unlocked && (
                        <div className="w-full bg-[var(--surface)] h-1.5 rounded-full overflow-hidden mt-1">
                          <div 
                            className="bg-amber-500 h-full rounded-full" 
                            style={{ width: `${b.progressPercent || 0}%` }}
                          />
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 3: PRIVACY & PUBLIC PROFILE */}
            {activeTab === 'privacy' && (
              <form onSubmit={handleSaveProfile} className="clay-raised p-6 rounded-[24px] space-y-5 animate-fade-in">
                <div className="space-y-1 border-b border-[var(--border)] pb-3">
                  <h3 className="text-xs font-black uppercase tracking-wider text-[var(--text)] flex items-center gap-1.5">
                    <Shield size={16} className="text-[#34A853]" /> Public Profile Settings
                  </h3>
                  <p className="text-[10px] text-[var(--text-sec)] leading-relaxed">
                    When enabled, other gym members can view only the public details you explicitly choose to share.
                  </p>
                </div>

                {/* Main Public Toggle */}
                <label className="flex items-center justify-between p-4 neo-raised rounded-[20px] cursor-pointer">
                  <div>
                    <span className="text-xs font-black uppercase text-[var(--text)] block">Show my profile publicly</span>
                    <span className="text-[9px] text-[var(--text-sec)]">Allow your profile to appear on gym leaderboards</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={showPublicProfile}
                    onChange={(e) => setShowPublicProfile(e.target.checked)}
                    className="w-5 h-5 accent-[#34A853] cursor-pointer"
                  />
                </label>

                {/* Granular Privacy Toggles */}
                {showPublicProfile && (
                  <div className="space-y-3 pt-2">
                    <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">
                      Public Visibility Options
                    </span>

                    <label className="flex items-center justify-between p-3 neo-pressed rounded-[14px] cursor-pointer">
                      <span className="text-xs font-bold text-[var(--text)]">Display Full Name</span>
                      <input
                        type="checkbox"
                        checked={showNamePublicly}
                        onChange={(e) => setShowNamePublicly(e.target.checked)}
                        className="w-4 h-4 accent-[#34A853]"
                      />
                    </label>

                    <label className="flex items-center justify-between p-3 neo-pressed rounded-[14px] cursor-pointer">
                      <span className="text-xs font-bold text-[var(--text)]">Display Profile Photo</span>
                      <input
                        type="checkbox"
                        checked={showPhotoPublicly}
                        onChange={(e) => setShowPhotoPublicly(e.target.checked)}
                        className="w-4 h-4 accent-[#34A853]"
                      />
                    </label>

                    <label className="flex items-center justify-between p-3 neo-pressed rounded-[14px] cursor-pointer">
                      <span className="text-xs font-bold text-[var(--text)]">Show Level Title</span>
                      <input
                        type="checkbox"
                        checked={showLevelPublicly}
                        onChange={(e) => setShowLevelPublicly(e.target.checked)}
                        className="w-4 h-4 accent-[#34A853]"
                      />
                    </label>

                    <label className="flex items-center justify-between p-3 neo-pressed rounded-[14px] cursor-pointer">
                      <span className="text-xs font-bold text-[var(--text)]">Show Badges</span>
                      <input
                        type="checkbox"
                        checked={showBadgesPublicly}
                        onChange={(e) => setShowBadgesPublicly(e.target.checked)}
                        className="w-4 h-4 accent-[#34A853]"
                      />
                    </label>

                    <label className="flex items-center justify-between p-3 neo-pressed rounded-[14px] cursor-pointer">
                      <span className="text-xs font-bold text-[var(--text)]">Show Monthly Gym Ranking</span>
                      <input
                        type="checkbox"
                        checked={showRankPublicly}
                        onChange={(e) => setShowRankPublicly(e.target.checked)}
                        className="w-4 h-4 accent-[#34A853]"
                      />
                    </label>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={saving}
                  className="w-full h-12 rounded-[16px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 cursor-pointer active:scale-95 transition-transform"
                >
                  {saving ? 'Saving...' : 'Save Privacy Preferences'}
                </button>
              </form>
            )}

            {/* TAB 4: APP SETTINGS & NOTIFICATIONS */}
            {activeTab === 'preferences' && (
              <div className="clay-raised p-6 rounded-[24px] space-y-6 animate-fade-in">
                <h3 className="text-xs font-black uppercase tracking-wider text-[var(--text)] border-b border-[var(--border)] pb-2">
                  App Language & Settings
                </h3>

                {/* Language Selector */}
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] mb-2 flex items-center gap-1.5">
                    <Globe size={14} /> App Language (10 Indian Languages)
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    {LANGUAGES.map(lang => (
                      <button
                        type="button"
                        key={lang.code}
                        onClick={() => handleLanguageChange(lang.code)}
                        className={`p-3 rounded-xl text-left text-xs font-bold transition-all cursor-pointer border ${
                          appLanguage === lang.code
                            ? 'bg-[var(--btn-bg)] text-[var(--btn-text)] border-[var(--text)] shadow-sm'
                            : 'neo-pressed border-transparent text-[var(--text)] hover:border-[var(--border)]'
                        }`}
                      >
                        <div>{lang.name}</div>
                        <div className="text-[9px] opacity-75 font-normal">{lang.englishName}</div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Theme Selector */}
                <div className="pt-2 border-t border-[var(--border)]">
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] mb-2">
                    Theme Appearance
                  </label>
                  <button
                    type="button"
                    onClick={handleThemeToggle}
                    className="w-full h-12 rounded-xl neo-raised flex items-center justify-between px-4 text-xs font-bold cursor-pointer"
                  >
                    <span className="flex items-center gap-2">
                      {appTheme === 'dark' ? <Moon size={16} /> : <Sun size={16} />}
                      Current Theme: <strong className="uppercase">{appTheme}</strong>
                    </span>
                    <span className="text-[10px] font-black uppercase text-[var(--btn-bg)]">Switch</span>
                  </button>
                </div>

                {/* Notifications Toggles */}
                <div className="pt-2 border-t border-[var(--border)] space-y-3">
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)]">
                    Notification Preferences
                  </label>
                  
                  <label className="flex items-center justify-between p-3 neo-pressed rounded-[14px] cursor-pointer">
                    <span className="text-xs font-bold text-[var(--text)]">Daily Workout Reminders</span>
                    <input
                      type="checkbox"
                      checked={notifyWorkout}
                      onChange={(e) => setNotifyWorkout(e.target.checked)}
                      className="w-4 h-4 accent-[var(--btn-bg)]"
                    />
                  </label>

                  <label className="flex items-center justify-between p-3 neo-pressed rounded-[14px] cursor-pointer">
                    <span className="text-xs font-bold text-[var(--text)]">Gym Attendance Alerts</span>
                    <input
                      type="checkbox"
                      checked={notifyAttendance}
                      onChange={(e) => setNotifyAttendance(e.target.checked)}
                      className="w-4 h-4 accent-[var(--btn-bg)]"
                    />
                  </label>

                  <label className="flex items-center justify-between p-3 neo-pressed rounded-[14px] cursor-pointer">
                    <span className="text-xs font-bold text-[var(--text)]">Membership Expiry Warnings</span>
                    <input
                      type="checkbox"
                      checked={notifyRenewal}
                      onChange={(e) => setNotifyRenewal(e.target.checked)}
                      className="w-4 h-4 accent-[var(--btn-bg)]"
                    />
                  </label>
                </div>
              </div>
            )}

            {/* Support & Logout */}
            <div className="neo-raised p-4 rounded-[20px] space-y-3">
              <h3 className="text-xs font-black uppercase tracking-wider text-[var(--text)]">Need Assistance?</h3>
              <p className="text-[11px] text-[var(--text-sec)] font-medium">
                Have questions regarding your membership, attendance, or gym plans?
              </p>
              <a
                href="https://wa.me/919263604732?text=Hello%20Support%2C%20I%20am%20a%20Gym%20Member%20needing%20assistance."
                target="_blank"
                rel="noopener noreferrer"
                className="w-full h-11 rounded-[14px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 cursor-pointer"
              >
                WHATSAPP SUPPORT (+91 9263604732)
              </a>
            </div>

            <button
              onClick={() => void signOutEverything()}
              className="w-full h-12 rounded-[16px] neo-raised text-[#D64545] text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 active:scale-95 transition-transform cursor-pointer"
            >
              <LogOut size={16} /> LOGOUT OF MEMBER APP
            </button>
          </div>
        )}

        {/* Digital ID Card Modal */}
        <DigitalIdCard
          isOpen={idCardOpen}
          onClose={() => setIdCardOpen(false)}
          member={member}
        />
      </div>
    </MemberLayout>
  );
}
