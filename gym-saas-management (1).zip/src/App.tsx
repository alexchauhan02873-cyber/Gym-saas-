import React from 'react';
import { Router, Route, Routes } from '@/lib/router-compat';
import GymCodeEntry from './pages/GymCodeEntry';
import MemberLogin from './pages/MemberLogin';
import MemberDirectLinkHandler from './pages/MemberDirectLinkHandler';
import AccountRestrictionPage from './pages/AccountRestrictionPage';

// Owner pages
import OwnerDashboard from './pages/owner/OwnerDashboard';
import OwnerOnboarding from './pages/owner/OwnerOnboarding';
import MembersList from './pages/owner/MembersList';
import AddMember from './pages/owner/AddMember';
import MemberDetails from './pages/owner/MemberDetails';
import AttendanceDashboard from './pages/owner/AttendanceDashboard';
import DailyQR from './pages/owner/DailyQR';
import ManualAttendance from './pages/owner/ManualAttendance';
import PaymentsDashboard from './pages/owner/PaymentsDashboard';
import MembershipPlans from './pages/owner/MembershipPlans';
import OwnerBroadcast from './pages/owner/OwnerBroadcast';
import ProfileSettings from './pages/owner/ProfileSettings';
import OwnerWorkout from './pages/owner/OwnerWorkout';
import OwnerDiet from './pages/owner/OwnerDiet';
import OwnerWorkload from './pages/owner/OwnerWorkload';
import OwnerPerformance from './pages/owner/OwnerPerformance';
import CentralRecords from './pages/owner/CentralRecords';

// Member pages
import MemberOnboarding from './pages/member/MemberOnboarding';
import MemberDashboard from './pages/member/MemberDashboard';
import MemberAttendance from './pages/member/MemberAttendance';
import MemberWorkout from './pages/member/MemberWorkout';
import MemberDiet from './pages/member/MemberDiet';
import MemberPlans from './pages/member/MemberPlans';
import MemberProfile from './pages/member/MemberProfile';
import MemberAnalytics from './pages/member/MemberAnalytics';
import MemberWellbeingCheckin from './pages/member/MemberWellbeingCheckin';

// Admin pages
import AdminDashboard from './pages/admin/AdminDashboard';
import AdminGyms from './pages/admin/AdminGyms';
import AdminRevenue from './pages/admin/AdminRevenue';
import AdminBroadcast from './pages/admin/AdminBroadcast';
import AdminActivity from './pages/admin/AdminActivity';

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<GymCodeEntry />} />
        <Route path="/member/login" element={<MemberLogin />} />
        <Route path="/member" element={<MemberDirectLinkHandler />} />
        <Route path="/restriction" element={<AccountRestrictionPage />} />
        <Route path="/access-blocked" element={<AccountRestrictionPage />} />
        <Route path="/access-frozen" element={<AccountRestrictionPage />} />

        {/* Owner Routes */}
        <Route path="/owner/onboarding" element={<OwnerOnboarding />} />
        <Route path="/owner/dashboard" element={<OwnerDashboard />} />
        <Route path="/owner/members" element={<MembersList />} />
        <Route path="/owner/members/add" element={<AddMember />} />
        <Route path="/owner/members/new" element={<AddMember />} />
        <Route path="/owner/members/:id" element={<MemberDetails />} />
        <Route path="/owner/attendance" element={<AttendanceDashboard />} />
        <Route path="/owner/attendance/qr" element={<DailyQR />} />
        <Route path="/owner/attendance/manual" element={<ManualAttendance />} />
        <Route path="/owner/payments" element={<PaymentsDashboard />} />
        <Route path="/owner/plans" element={<MembershipPlans />} />
        <Route path="/owner/broadcast" element={<OwnerBroadcast />} />
        <Route path="/owner/profile" element={<ProfileSettings />} />
        <Route path="/owner/workout" element={<OwnerWorkout />} />
        <Route path="/owner/diet" element={<OwnerDiet />} />
        <Route path="/owner/tasks" element={<OwnerWorkload />} />
        <Route path="/owner/performance" element={<OwnerPerformance />} />
        <Route path="/owner/records" element={<CentralRecords />} />
        <Route path="/owner/history" element={<CentralRecords />} />

        {/* Member Routes */}
        <Route path="/member/onboarding" element={<MemberOnboarding />} />
        <Route path="/member/dashboard" element={<MemberDashboard />} />
        <Route path="/member/attendance" element={<MemberAttendance />} />
        <Route path="/member/workout" element={<MemberWorkout />} />
        <Route path="/member/analytics" element={<MemberAnalytics />} />
        <Route path="/member/diet" element={<MemberDiet />} />
        <Route path="/member/plans" element={<MemberPlans />} />
        <Route path="/member/profile" element={<MemberProfile />} />
        <Route path="/member/wellbeing-checkin" element={<MemberWellbeingCheckin />} />

        {/* Admin Routes */}
        <Route path="/admin/dashboard" element={<AdminDashboard />} />
        <Route path="/admin/gyms" element={<AdminGyms />} />
        <Route path="/admin/revenue" element={<AdminRevenue />} />
        <Route path="/admin/broadcast" element={<AdminBroadcast />} />
        <Route path="/admin/activity" element={<AdminActivity />} />

        {/* Fallback */}
        <Route path="*" element={<GymCodeEntry />} />
      </Routes>
    </Router>
  );
}
