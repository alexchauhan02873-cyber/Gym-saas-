import { createClient, SupabaseClient } from '@supabase/supabase-js';

const getEnvVar = (key: string): string => {
  try {
    const metaEnv = (import.meta as any)?.env;
    if (metaEnv && metaEnv[key]) {
      return metaEnv[key];
    }
  } catch {}
  try {
    if (typeof process !== 'undefined' && process.env && process.env[key]) {
      return process.env[key] || '';
    }
  } catch {}
  return '';
};

const SUPABASE_URL =
  getEnvVar('VITE_SUPABASE_URL') ||
  getEnvVar('SUPABASE_URL') ||
  'https://placeholder.supabase.co';

const SUPABASE_ANON_KEY =
  getEnvVar('VITE_SUPABASE_ANON_KEY') ||
  getEnvVar('SUPABASE_ANON_KEY') ||
  getEnvVar('VITE_SUPABASE_PUBLISHABLE_KEY') ||
  getEnvVar('SUPABASE_PUBLISHABLE_KEY') ||
  'placeholder_anon_key';

export const isSupabaseConfigured = (): boolean => {
  return (
    SUPABASE_URL !== 'https://placeholder.supabase.co' &&
    SUPABASE_ANON_KEY !== 'placeholder_anon_key' &&
    SUPABASE_URL.length > 0 &&
    SUPABASE_ANON_KEY.length > 0
  );
};

export const supabase: SupabaseClient = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
    storageKey: 'gym_supabase_auth_token',
    storage: window.localStorage,
  },
});

/**
 * Initiates Google OAuth login via Supabase Auth.
 * Uses window.location.origin to ensure production Vercel/Cloud Run compatibility
 * without hardcoded localhost URLs.
 */
export async function signInWithGoogle(customRedirectTo?: string) {
  if (!isSupabaseConfigured()) {
    throw new Error('Supabase environment variables (VITE_SUPABASE_URL & VITE_SUPABASE_ANON_KEY) are not configured.');
  }

  const redirectOrigin = customRedirectTo || `${window.location.origin}/`;

  const { data, error } = await supabase.auth.signInWithOAuth({
    provider: 'google',
    options: {
      redirectTo: redirectOrigin,
      queryParams: {
        access_type: 'offline',
        prompt: 'select_account',
      },
    },
  });

  if (error) {
    throw error;
  }
  return data;
}

/**
 * Cleans up OAuth hash/code parameters from the URL after successful authentication
 * to prevent redirect loops or invalid parameter states on page refresh.
 */
export function cleanAuthUrlHash() {
  if (typeof window === 'undefined') return;
  const hash = window.location.hash;
  const search = window.location.search;
  
  if (hash.includes('access_token=') || hash.includes('error=') || search.includes('code=')) {
    const cleanUrl = window.location.origin + window.location.pathname;
    window.history.replaceState(null, '', cleanUrl);
  }
}

