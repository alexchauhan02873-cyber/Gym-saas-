import { supabase } from '../supabase/client';

export const lovable = {
  auth: {
    signInWithOAuth: async (provider: string, opts?: { redirect_uri?: string }) => {
      try {
        const { data, error } = await supabase.auth.signInWithOAuth({
          provider: provider as any,
          options: {
            redirectTo: opts?.redirect_uri || window.location.origin,
          },
        });
        if (error) return { error };
        return { redirected: true, data };
      } catch (e: any) {
        return { error: e };
      }
    },
  },
};
