import React from 'react';
import { History, X, ShieldAlert, Snowflake, RefreshCw, Archive, UserCheck } from 'lucide-react';

export interface ReasonHistoryRecord {
  id: string;
  action: string;
  previousStatus?: string;
  newStatus?: string;
  reason?: string;
  internalNote?: string;
  actor?: string;
  actorRole?: string;
  timestamp: string;
  freezeUntil?: string;
}

interface Props {
  isOpen: boolean;
  onClose: () => void;
  targetName: string;
  targetId: string;
  history: ReasonHistoryRecord[];
}

export default function AdminReasonHistoryModal({
  isOpen,
  onClose,
  targetName,
  targetId,
  history = []
}: Props) {
  if (!isOpen) return null;

  const getActionIcon = (action: string) => {
    const act = (action || '').toUpperCase();
    if (act.includes('BLOCK')) return <ShieldAlert size={16} className="text-[#D64545]" />;
    if (act.includes('FREEZE')) return <Snowflake size={16} className="text-[#E8A33D]" />;
    if (act.includes('RESTORE')) return <RefreshCw size={16} className="text-[#34A853]" />;
    if (act.includes('ARCHIVE')) return <Archive size={16} className="text-[var(--text-sec)]" />;
    return <UserCheck size={16} className="text-[#4285F4]" />;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-xl clay-raised rounded-[28px] p-6 space-y-5 border border-[var(--border)] relative bg-[var(--bg)] text-[var(--text)] max-h-[90vh] flex flex-col">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 w-8 h-8 rounded-full neo-pressed flex items-center justify-center text-[var(--text-sec)] hover:text-[var(--text)]"
        >
          <X size={18} />
        </button>

        <div className="flex items-center gap-3 shrink-0">
          <div className="w-12 h-12 rounded-full neo-pressed text-[#4285F4] flex items-center justify-center shrink-0">
            <History size={24} />
          </div>
          <div>
            <span className="text-[9px] font-black uppercase tracking-widest text-[#4285F4] bg-[#4285F4]/10 px-2.5 py-0.5 rounded-full border border-[#4285F4]/20">
              AUDIT LOG TRAIL
            </span>
            <h2 className="text-lg font-black uppercase tracking-wider text-[var(--text)] mt-1">
              Moderation & Reason History
            </h2>
            <p className="text-xs text-[var(--text-sec)] font-mono">{targetName} ({targetId})</p>
          </div>
        </div>

        <div className="overflow-y-auto space-y-3 pr-1 flex-1">
          {history.length === 0 ? (
            <div className="neo-pressed p-8 rounded-[20px] text-center space-y-2">
              <History size={28} className="mx-auto text-[var(--text-sec)]" />
              <p className="text-xs font-bold uppercase tracking-wider text-[var(--text-sec)]">
                No moderation events recorded yet
              </p>
              <p className="text-[10px] text-[var(--text-sec)]">
                This account has standard operational status without moderation flags.
              </p>
            </div>
          ) : (
            history.map((record) => (
              <div key={record.id} className="neo-raised p-4 rounded-[20px] space-y-2 border border-[var(--border)]">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    {getActionIcon(record.action)}
                    <span className="text-xs font-black uppercase tracking-wider text-[var(--text)]">
                      {record.action}
                    </span>
                    {record.previousStatus && record.newStatus && (
                      <span className="text-[9px] font-mono px-2 py-0.5 rounded bg-[var(--surface-sec)] text-[var(--text-sec)] font-bold">
                        {record.previousStatus} &rarr; {record.newStatus}
                      </span>
                    )}
                  </div>
                  <span className="text-[10px] font-mono text-[var(--text-sec)]">
                    {new Date(record.timestamp).toLocaleString()}
                  </span>
                </div>

                {record.reason && (
                  <div className="neo-pressed p-2.5 rounded-[12px] text-xs">
                    <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">
                      Stated Reason
                    </span>
                    <p className="font-medium text-[var(--text)] mt-0.5">{record.reason}</p>
                  </div>
                )}

                {record.internalNote && (
                  <p className="text-[10px] text-[var(--text-sec)] italic">
                    Internal note: &quot;{record.internalNote}&quot;
                  </p>
                )}

                {record.freezeUntil && (
                  <p className="text-[10px] text-[#E8A33D] font-bold uppercase tracking-wider">
                    Freeze Expiry: {record.freezeUntil}
                  </p>
                )}

                <div className="text-[9px] text-[var(--text-sec)] font-mono flex items-center justify-between pt-1 border-t border-[var(--border)]">
                  <span>Actor: {record.actor || 'System Admin'} ({record.actorRole || 'ADMIN'})</span>
                  <span>ID: {record.id}</span>
                </div>
              </div>
            ))
          )}
        </div>

        <div className="pt-2 flex justify-end shrink-0">
          <button
            onClick={onClose}
            className="px-5 h-10 rounded-[14px] neo-raised text-xs font-bold uppercase tracking-wider"
          >
            Close History
          </button>
        </div>
      </div>
    </div>
  );
}
