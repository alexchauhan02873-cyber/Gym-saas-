import React, { useState } from 'react';
import { RefreshCw, X, CheckCircle } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  targetType: 'OWNER' | 'MEMBER' | 'GYM';
  targetId: string;
  targetName: string;
  currentStatus: string;
  currentReason?: string;
  onConfirm: (restorationNote: string) => Promise<void>;
}

export default function AdminRestoreModal({
  isOpen,
  onClose,
  targetType,
  targetId,
  targetName,
  currentStatus,
  currentReason,
  onConfirm
}: Props) {
  const [restorationNote, setRestorationNote] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      await onConfirm(restorationNote.trim());
      onClose();
    } catch (err: any) {
      setError(err?.message || 'Failed to restore account.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-lg clay-raised rounded-[28px] p-6 space-y-5 border border-[var(--border)] relative bg-[var(--bg)] text-[var(--text)]">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 w-8 h-8 rounded-full neo-pressed flex items-center justify-center text-[var(--text-sec)] hover:text-[var(--text)]"
        >
          <X size={18} />
        </button>

        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full neo-pressed text-[#34A853] flex items-center justify-center shrink-0">
            <RefreshCw size={24} />
          </div>
          <div>
            <span className="text-[9px] font-black uppercase tracking-widest text-[#34A853] bg-[#34A853]/10 px-2.5 py-0.5 rounded-full border border-[#34A853]/20">
              RESTORATION WORKFLOW
            </span>
            <h2 className="text-lg font-black uppercase tracking-wider text-[var(--text)] mt-1">
              Restore {targetType} Account
            </h2>
          </div>
        </div>

        <div className="neo-pressed p-4 rounded-[18px] space-y-2 text-xs">
          <div className="flex justify-between items-center text-[var(--text-sec)] font-bold uppercase tracking-wider text-[10px]">
            <span>Target Account</span>
            <span className="font-mono text-[var(--text)]">{targetId}</span>
          </div>
          <p className="font-black text-sm uppercase text-[var(--text)]">{targetName}</p>
          <div className="pt-2 border-t border-[var(--border)] flex justify-between items-center text-[11px]">
            <span className="text-[var(--text-sec)] font-bold uppercase">Current State:</span>
            <span className="font-mono font-bold text-[#D64545] uppercase">{currentStatus}</span>
          </div>
          {currentReason && (
            <p className="text-[10px] text-[var(--text-sec)] italic">
              Previous restriction reason: &quot;{currentReason}&quot;
            </p>
          )}
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {error && (
            <div className="p-3 rounded-[14px] bg-[#D64545]/10 border border-[#D64545]/20 text-[#D64545] text-xs font-semibold">
              {error}
            </div>
          )}

          <div className="space-y-1.5">
            <label className="text-[10px] font-black uppercase tracking-widest text-[var(--text-sec)] block">
              Restoration Note (Optional)
            </label>
            <input
              type="text"
              value={restorationNote}
              onChange={(e) => setRestorationNote(e.target.value)}
              placeholder="e.g. Issue resolved, payment confirmed..."
              className="w-full h-11 px-3.5 rounded-[14px] neo-pressed bg-transparent text-xs font-medium text-[var(--text)] focus:outline-none"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 h-11 rounded-[14px] neo-raised text-xs font-bold uppercase tracking-wider text-[var(--text-sec)] hover:text-[var(--text)]"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-6 h-11 rounded-[14px] bg-[#34A853] text-white text-xs font-bold uppercase tracking-wider flex items-center gap-2 hover:bg-[#34A853]/90 active:scale-95 transition-all disabled:opacity-50"
            >
              <CheckCircle size={15} /> {loading ? 'Restoring...' : 'Confirm Restore Access'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
