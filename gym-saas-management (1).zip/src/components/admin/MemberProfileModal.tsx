import React, { useState } from 'react';
import { 
  X, User, CreditCard, Calendar, Activity, 
  ShieldAlert, Snowflake, RefreshCw, Archive, Phone, MapPin, 
  CheckCircle, FileText, Dumbbell, Trophy, Lock, QrCode, IdCard
} from 'lucide-react';
import { STATE_BADGES } from '@/lib/access-status';
import DigitalIdCard from '@/components/DigitalIdCard';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  memberData: any;
  onBlock: (member: any) => void;
  onFreeze: (member: any) => void;
  onRestore: (member: any) => void;
  onArchive: (member: any) => void;
  onShowHistory: (member: any) => void;
}

export default function MemberProfileModal({
  isOpen,
  onClose,
  memberData,
  onBlock,
  onFreeze,
  onRestore,
  onArchive,
  onShowHistory
}: Props) {
  const [activeTab, setActiveTab] = useState<'overview' | 'personal' | 'membership' | 'payments' | 'attendance' | 'workout' | 'performance' | 'achievements' | 'activity' | 'security'>('overview');
  const [showIdCard, setShowIdCard] = useState(false);

  if (!isOpen || !memberData) return null;

  const status = memberData.status || 'ACTIVE';
  const badgeInfo = STATE_BADGES[status as keyof typeof STATE_BADGES] || STATE_BADGES.ACTIVE;

  const tabs = [
    { id: 'overview', label: 'Overview', icon: User },
    { id: 'personal', label: 'Personal', icon: FileText },
    { id: 'membership', label: 'Plan & Dates', icon: Dumbbell },
    { id: 'payments', label: 'Payments', icon: CreditCard },
    { id: 'attendance', label: 'Attendance', icon: Calendar },
    { id: 'workout', label: 'Workout', icon: Activity },
    { id: 'performance', label: 'Performance', icon: Activity },
    { id: 'achievements', label: 'Badges', icon: Trophy },
    { id: 'activity', label: 'Activity', icon: Activity },
    { id: 'security', label: 'Security', icon: Lock },
  ] as const;

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/75 backdrop-blur-md animate-in fade-in duration-200">
        <div className="w-full max-w-4xl max-h-[92vh] clay-raised rounded-[28px] border border-[var(--border)] bg-[var(--bg)] text-[var(--text)] flex flex-col overflow-hidden relative">
          {/* Header */}
          <div className="px-6 py-4 border-b border-[var(--border)] flex justify-between items-center bg-[var(--surface-sec)] shrink-0">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full neo-pressed overflow-hidden flex items-center justify-center text-[var(--text)] font-black text-lg border border-[var(--border)]">
                {memberData.profileImage ? (
                  <img src={memberData.profileImage} alt={memberData.fullName} className="w-full h-full object-cover" />
                ) : (
                  memberData.fullName?.charAt(0) || 'M'
                )}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-base font-black uppercase tracking-wider text-[var(--text)]">
                    {memberData.fullName}
                  </h2>
                  <span className={`text-[9px] font-black px-2.5 py-0.5 rounded-full border uppercase ${badgeInfo.className}`}>
                    {badgeInfo.label}
                  </span>
                </div>
                <p className="text-[10px] text-[var(--text-sec)] font-mono">
                  Display ID: {memberData.memberDisplayId || memberData.id} • Gym: {memberData.gymName || memberData.gymId}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowIdCard(true)}
                className="px-3 py-1.5 rounded-[12px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 cursor-pointer"
              >
                <IdCard size={14} /> Digital Pass
              </button>
              <button
                onClick={onClose}
                className="w-9 h-9 rounded-full neo-pressed flex items-center justify-center text-[var(--text-sec)] hover:text-[var(--text)] cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>
          </div>

          {/* Action Toolbar */}
          <div className="px-6 py-2.5 bg-[var(--surface)] border-b border-[var(--border)] flex flex-wrap items-center justify-between gap-2 shrink-0">
            <div className="flex items-center gap-2">
              {status === 'ACTIVE' && (
                <>
                  <button
                    onClick={() => onFreeze(memberData)}
                    className="px-3 py-1.5 rounded-[12px] bg-[#E8A33D]/10 text-[#E8A33D] border border-[#E8A33D]/25 font-bold text-xs uppercase flex items-center gap-1.5 hover:bg-[#E8A33D]/20 cursor-pointer"
                  >
                    <Snowflake size={14} /> Freeze Member
                  </button>
                  <button
                    onClick={() => onBlock(memberData)}
                    className="px-3 py-1.5 rounded-[12px] bg-[#D64545]/10 text-[#D64545] border border-[#D64545]/25 font-bold text-xs uppercase flex items-center gap-1.5 hover:bg-[#D64545]/20 cursor-pointer"
                  >
                    <ShieldAlert size={14} /> Block Member
                  </button>
                </>
              )}
              {(status === 'BLOCKED' || status === 'FROZEN') && (
                <button
                  onClick={() => onRestore(memberData)}
                  className="px-3 py-1.5 rounded-[12px] bg-[#34A853]/10 text-[#34A853] border border-[#34A853]/25 font-bold text-xs uppercase flex items-center gap-1.5 hover:bg-[#34A853]/20 cursor-pointer"
                >
                  <RefreshCw size={14} /> Restore Access
                </button>
              )}
              {status !== 'ARCHIVED' && (
                <button
                  onClick={() => onArchive(memberData)}
                  className="px-3 py-1.5 rounded-[12px] neo-raised text-[var(--text-sec)] hover:text-[var(--text)] font-bold text-xs uppercase flex items-center gap-1.5 cursor-pointer"
                >
                  <Archive size={14} /> Archive
                </button>
              )}
            </div>

            <button
              onClick={() => onShowHistory(memberData)}
              className="px-3 py-1.5 rounded-[12px] neo-pressed text-[var(--text-sec)] font-mono text-[11px] hover:text-[var(--text)] cursor-pointer"
            >
              View Reason History
            </button>
          </div>

          {/* Navigation Tabs */}
          <div className="bg-[var(--surface-sec)] px-6 py-2 border-b border-[var(--border)] flex gap-2 overflow-x-auto hide-scrollbar shrink-0">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`px-3 py-2 rounded-[12px] text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 shrink-0 transition-all cursor-pointer ${
                    isActive
                      ? 'clay-raised bg-[var(--btn-bg)] text-[var(--btn-text)]'
                      : 'text-[var(--text-sec)] hover:text-[var(--text)] hover:bg-[var(--surface)]'
                  }`}
                >
                  <Icon size={14} /> {tab.label}
                </button>
              );
            })}
          </div>

          {/* View Body */}
          <div className="p-6 overflow-y-auto space-y-5 flex-1">
            {activeTab === 'overview' && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="neo-pressed p-4 rounded-[18px]">
                    <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Current Plan</span>
                    <span className="text-xs font-black text-[var(--text)] mt-1 block truncate">{memberData.planName || 'Monthly Pass'}</span>
                  </div>
                  <div className="neo-pressed p-4 rounded-[18px]">
                    <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Lifetime XP</span>
                    <span className="text-xl font-black font-mono text-[#E3A008] mt-1 block">{memberData.lifetimeXp || 0} XP</span>
                  </div>
                  <div className="neo-pressed p-4 rounded-[18px]">
                    <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Valid Until</span>
                    <span className="text-xs font-black font-mono text-[#34A853] mt-1 block">{memberData.endDate || 'Active'}</span>
                  </div>
                  <div className="neo-pressed p-4 rounded-[18px]">
                    <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Status</span>
                    <span className="text-xs font-black uppercase text-[var(--text)] mt-1 block">{status}</span>
                  </div>
                </div>

                <div className="clay-raised p-5 rounded-[22px] space-y-3">
                  <h3 className="text-xs font-black uppercase tracking-wider text-[var(--text)]">Personal Overview</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                    <div className="flex items-center gap-2">
                      <Phone size={14} className="text-[var(--text-sec)] shrink-0" />
                      <span className="font-mono font-bold text-[var(--text)]">{memberData.phone || 'N/A'}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin size={14} className="text-[var(--text-sec)] shrink-0" />
                      <span className="text-[var(--text)]">{memberData.location || 'Patna'}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <User size={14} className="text-[var(--text-sec)] shrink-0" />
                      <span className="text-[var(--text)]">{memberData.gender || 'N/A'}, {memberData.age ? `${memberData.age} yrs` : ''}</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'personal' && (
              <div className="clay-raised p-5 rounded-[22px] space-y-3 text-xs">
                <h3 className="text-xs font-black uppercase tracking-wider text-[var(--text)]">Member Personal Info</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <span className="text-[9px] font-bold uppercase text-[var(--text-sec)] block">Full Name</span>
                    <p className="font-bold text-[var(--text)] mt-0.5">{memberData.fullName}</p>
                  </div>
                  <div>
                    <span className="text-[9px] font-bold uppercase text-[var(--text-sec)] block">Phone</span>
                    <p className="font-mono font-bold text-[var(--text)] mt-0.5">{memberData.phone || 'N/A'}</p>
                  </div>
                  <div>
                    <span className="text-[9px] font-bold uppercase text-[var(--text-sec)] block">Age & Gender</span>
                    <p className="text-[var(--text)] mt-0.5">{memberData.age ? `${memberData.age} yrs` : 'N/A'} • {memberData.gender || 'N/A'}</p>
                  </div>
                  <div>
                    <span className="text-[9px] font-bold uppercase text-[var(--text-sec)] block">Joined Date</span>
                    <p className="font-mono text-[var(--text)] mt-0.5">{memberData.createdAt ? new Date(memberData.createdAt).toLocaleDateString() : 'N/A'}</p>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'membership' && (
              <div className="clay-raised p-5 rounded-[22px] space-y-3 text-xs">
                <h3 className="text-xs font-black uppercase tracking-wider text-[var(--text)]">Membership Plan Details</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <span className="text-[9px] font-bold uppercase text-[var(--text-sec)] block">Plan</span>
                    <p className="font-bold text-[#34A853] mt-0.5">{memberData.planName || 'Monthly Pass'}</p>
                  </div>
                  <div>
                    <span className="text-[9px] font-bold uppercase text-[var(--text-sec)] block">Start Date</span>
                    <p className="font-mono text-[var(--text)] mt-0.5">{memberData.startDate || 'N/A'}</p>
                  </div>
                  <div>
                    <span className="text-[9px] font-bold uppercase text-[var(--text-sec)] block">Expiry Date</span>
                    <p className="font-mono font-bold text-[#34A853] mt-0.5">{memberData.endDate || 'N/A'}</p>
                  </div>
                  <div>
                    <span className="text-[9px] font-bold uppercase text-[var(--text-sec)] block">Gym</span>
                    <p className="text-[var(--text)] mt-0.5">{memberData.gymName || memberData.gymId}</p>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'payments' && (
              <div className="neo-pressed p-6 rounded-[22px] text-center space-y-2">
                <CreditCard size={28} className="mx-auto text-[var(--text-sec)]" />
                <p className="text-xs font-bold uppercase tracking-wider text-[var(--text)]">
                  Payment Records
                </p>
                <p className="text-[10px] text-[var(--text-sec)]">
                  View individual member payment transactions in the Payments module.
                </p>
              </div>
            )}

            {activeTab === 'attendance' && (
              <div className="neo-pressed p-6 rounded-[22px] text-center space-y-2">
                <Calendar size={28} className="mx-auto text-[var(--text-sec)]" />
                <p className="text-xs font-bold uppercase tracking-wider text-[var(--text)]">
                  Check-in History
                </p>
                <p className="text-[10px] text-[var(--text-sec)]">
                  Member check-in logs and monthly attendance statistics.
                </p>
              </div>
            )}

            {activeTab === 'workout' && (
              <div className="neo-pressed p-6 rounded-[22px] text-center space-y-2">
                <Activity size={28} className="mx-auto text-[var(--text-sec)]" />
                <p className="text-xs font-bold uppercase tracking-wider text-[var(--text)]">
                  Workout Routines
                </p>
                <p className="text-[10px] text-[var(--text-sec)]">
                  Active and historical workout assignments for this member.
                </p>
              </div>
            )}

            {activeTab === 'performance' && (
              <div className="neo-pressed p-6 rounded-[22px] text-center space-y-2">
                <Activity size={28} className="mx-auto text-[var(--text-sec)]" />
                <p className="text-xs font-bold uppercase tracking-wider text-[var(--text)]">
                  Performance & Consistency
                </p>
                <p className="text-[10px] text-[var(--text-sec)]">
                  Workout completions and streak statistics.
                </p>
              </div>
            )}

            {activeTab === 'achievements' && (
              <div className="neo-pressed p-6 rounded-[22px] text-center space-y-2">
                <Trophy size={28} className="mx-auto text-[var(--text-sec)]" />
                <p className="text-xs font-bold uppercase tracking-wider text-[var(--text)]">
                  Badges & XP Level
                </p>
                <p className="text-[10px] text-[var(--text-sec)]">
                  Current XP: {memberData.lifetimeXp || 0} XP
                </p>
              </div>
            )}

            {activeTab === 'activity' && (
              <div className="neo-pressed p-6 rounded-[22px] text-center space-y-2">
                <Activity size={28} className="mx-auto text-[var(--text-sec)]" />
                <p className="text-xs font-bold uppercase tracking-wider text-[var(--text)]">
                  Member Activity Log
                </p>
                <p className="text-[10px] text-[var(--text-sec)]">
                  Click &quot;View Reason History&quot; above for moderation history.
                </p>
              </div>
            )}

            {activeTab === 'security' && (
              <div className="clay-raised p-5 rounded-[22px] space-y-3 text-xs">
                <h3 className="text-xs font-black uppercase tracking-wider text-[var(--text)]">Security & Moderation Status</h3>
                <div className="space-y-2">
                  <div className="flex justify-between items-center py-2 border-b border-[var(--border)]">
                    <span className="text-[var(--text-sec)]">Operational Status:</span>
                    <span className="font-mono font-bold text-[var(--text)]">{status}</span>
                  </div>
                  {memberData.statusReason && (
                    <div className="flex justify-between items-center py-2 border-b border-[var(--border)]">
                      <span className="text-[var(--text-sec)]">Status Reason:</span>
                      <span className="font-semibold text-[#D64545]">{memberData.statusReason}</span>
                    </div>
                  )}
                  {memberData.freezeUntil && (
                    <div className="flex justify-between items-center py-2 border-b border-[var(--border)]">
                      <span className="text-[var(--text-sec)]">Freeze Expiry:</span>
                      <span className="font-mono font-bold text-[#E8A33D]">{memberData.freezeUntil}</span>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {showIdCard && (
        <DigitalIdCard
          isOpen={showIdCard}
          onClose={() => setShowIdCard(false)}
          member={memberData}
        />
      )}
    </>
  );
}
