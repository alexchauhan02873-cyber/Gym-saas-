import React, { useState } from 'react';
import { 
  X, User, Building2, Users, CreditCard, Calendar, Activity, 
  ShieldAlert, Snowflake, RefreshCw, Archive, Phone, Mail, MapPin, 
  CheckCircle, FileText, Dumbbell, Megaphone, Lock
} from 'lucide-react';
import { STATE_BADGES } from '@/lib/access-status';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  ownerData: any;
  onBlock: (owner: any) => void;
  onFreeze: (owner: any) => void;
  onRestore: (owner: any) => void;
  onArchive: (owner: any) => void;
  onShowHistory: (owner: any) => void;
}

export default function OwnerProfileModal({
  isOpen,
  onClose,
  ownerData,
  onBlock,
  onFreeze,
  onRestore,
  onArchive,
  onShowHistory
}: Props) {
  const [activeTab, setActiveTab] = useState<'overview' | 'personal' | 'gym' | 'members' | 'plans' | 'payments' | 'attendance' | 'workouts' | 'broadcasts' | 'subscriptions' | 'activity' | 'security'>('overview');

  if (!isOpen || !ownerData) return null;

  const status = ownerData.status || 'ACTIVE';
  const badgeInfo = STATE_BADGES[status as keyof typeof STATE_BADGES] || STATE_BADGES.ACTIVE;

  const tabs = [
    { id: 'overview', label: 'Overview', icon: User },
    { id: 'personal', label: 'Personal', icon: FileText },
    { id: 'gym', label: 'Gym Details', icon: Building2 },
    { id: 'members', label: 'Members', icon: Users },
    { id: 'plans', label: 'Plans', icon: Dumbbell },
    { id: 'payments', label: 'Payments', icon: CreditCard },
    { id: 'attendance', label: 'Attendance', icon: Calendar },
    { id: 'workouts', label: 'Workouts', icon: Activity },
    { id: 'broadcasts', label: 'Broadcasts', icon: Megaphone },
    { id: 'subscriptions', label: 'SaaS Sub', icon: CreditCard },
    { id: 'activity', label: 'Audit Trail', icon: Activity },
    { id: 'security', label: 'Security', icon: Lock },
  ] as const;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/75 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-4xl max-h-[92vh] clay-raised rounded-[28px] border border-[var(--border)] bg-[var(--bg)] text-[var(--text)] flex flex-col overflow-hidden relative">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-[var(--border)] flex justify-between items-center bg-[var(--surface-sec)] shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full neo-pressed overflow-hidden flex items-center justify-center text-[var(--text)] font-black text-lg border border-[var(--border)]">
              {ownerData.photoUrl ? (
                <img src={ownerData.photoUrl} alt={ownerData.fullName} className="w-full h-full object-cover" />
              ) : (
                ownerData.fullName?.charAt(0) || 'O'
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-black uppercase tracking-wider text-[var(--text)]">
                  {ownerData.fullName}
                </h2>
                <span className={`text-[9px] font-black px-2.5 py-0.5 rounded-full border uppercase ${badgeInfo.className}`}>
                  {badgeInfo.label}
                </span>
              </div>
              <p className="text-[10px] text-[var(--text-sec)] font-mono">
                Owner ID: {ownerData.id} • Gym: {ownerData.gymName || ownerData.gymId}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full neo-pressed flex items-center justify-center text-[var(--text-sec)] hover:text-[var(--text)] cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Action Controls Toolbar */}
        <div className="px-6 py-2.5 bg-[var(--surface)] border-b border-[var(--border)] flex flex-wrap items-center justify-between gap-2 shrink-0">
          <div className="flex items-center gap-2">
            {status === 'ACTIVE' && (
              <>
                <button
                  onClick={() => onFreeze(ownerData)}
                  className="px-3 py-1.5 rounded-[12px] bg-[#E8A33D]/10 text-[#E8A33D] border border-[#E8A33D]/25 font-bold text-xs uppercase flex items-center gap-1.5 hover:bg-[#E8A33D]/20 cursor-pointer"
                >
                  <Snowflake size={14} /> Freeze
                </button>
                <button
                  onClick={() => onBlock(ownerData)}
                  className="px-3 py-1.5 rounded-[12px] bg-[#D64545]/10 text-[#D64545] border border-[#D64545]/25 font-bold text-xs uppercase flex items-center gap-1.5 hover:bg-[#D64545]/20 cursor-pointer"
                >
                  <ShieldAlert size={14} /> Block
                </button>
              </>
            )}
            {(status === 'BLOCKED' || status === 'FROZEN') && (
              <button
                onClick={() => onRestore(ownerData)}
                className="px-3 py-1.5 rounded-[12px] bg-[#34A853]/10 text-[#34A853] border border-[#34A853]/25 font-bold text-xs uppercase flex items-center gap-1.5 hover:bg-[#34A853]/20 cursor-pointer"
              >
                <RefreshCw size={14} /> Restore Access
              </button>
            )}
            {status !== 'ARCHIVED' && (
              <button
                onClick={() => onArchive(ownerData)}
                className="px-3 py-1.5 rounded-[12px] neo-raised text-[var(--text-sec)] hover:text-[var(--text)] font-bold text-xs uppercase flex items-center gap-1.5 cursor-pointer"
              >
                <Archive size={14} /> Archive
              </button>
            )}
          </div>

          <button
            onClick={() => onShowHistory(ownerData)}
            className="px-3 py-1.5 rounded-[12px] neo-pressed text-[var(--text-sec)] font-mono text-[11px] hover:text-[var(--text)] cursor-pointer"
          >
            View Reason History
          </button>
        </div>

        {/* Sub-Navigation Tabs */}
        <div className="bg-[var(--surface-sec)] px-6 py-2 border-b border-[var(--border)] flex gap-2 overflow-x-auto hide-scrollbar shrink-0">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-3 py-2 rounded-[12px] text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 shrink-0 transition-all cursor-pointer ${
                  isActive
                    ? 'clay-raised bg-[var(--btn-bg)] text-[var(--btn-text)]'
                    : 'text-[var(--text-sec)] hover:text-[var(--text)] hover:bg-[var(--surface)]'
                }`}
              >
                <Icon size={14} /> {tab.label}
              </button>
            );
          })}
        </div>

        {/* Tab Content View */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1">
          {activeTab === 'overview' && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="neo-pressed p-4 rounded-[18px]">
                  <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Gym Name</span>
                  <span className="text-sm font-black text-[var(--text)] mt-1 block truncate">{ownerData.gymName || 'N/A'}</span>
                </div>
                <div className="neo-pressed p-4 rounded-[18px]">
                  <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Total Members</span>
                  <span className="text-xl font-black font-mono text-[#4285F4] mt-1 block">{ownerData.memberCount || 0}</span>
                </div>
                <div className="neo-pressed p-4 rounded-[18px]">
                  <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">SaaS Subscription</span>
                  <span className="text-xs font-black uppercase text-[#34A853] mt-1 block">{ownerData.saasPlan || 'PRO'}</span>
                </div>
                <div className="neo-pressed p-4 rounded-[18px]">
                  <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Account Status</span>
                  <span className="text-xs font-black uppercase text-[var(--text)] mt-1 block">{status}</span>
                </div>
              </div>

              <div className="clay-raised p-5 rounded-[22px] space-y-3">
                <h3 className="text-xs font-black uppercase tracking-wider text-[var(--text)]">Contact & Location</h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div className="flex items-center gap-2">
                    <Phone size={14} className="text-[var(--text-sec)] shrink-0" />
                    <span className="font-mono font-bold text-[var(--text)]">{ownerData.phone || 'N/A'}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Mail size={14} className="text-[var(--text-sec)] shrink-0" />
                    <span className="font-mono text-[var(--text)]">{ownerData.email || 'N/A'}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin size={14} className="text-[var(--text-sec)] shrink-0" />
                    <span className="text-[var(--text)]">{ownerData.city || 'Patna'}, {ownerData.state || 'Bihar'}</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'personal' && (
            <div className="clay-raised p-5 rounded-[22px] space-y-3 text-xs">
              <h3 className="text-xs font-black uppercase tracking-wider text-[var(--text)]">Owner Personal Details</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <span className="text-[9px] font-bold uppercase text-[var(--text-sec)] block">Full Name</span>
                  <p className="font-bold text-[var(--text)] mt-0.5">{ownerData.fullName}</p>
                </div>
                <div>
                  <span className="text-[9px] font-bold uppercase text-[var(--text-sec)] block">Phone Number</span>
                  <p className="font-mono font-bold text-[var(--text)] mt-0.5">{ownerData.phone || 'N/A'}</p>
                </div>
                <div>
                  <span className="text-[9px] font-bold uppercase text-[var(--text-sec)] block">Email Address</span>
                  <p className="font-mono text-[var(--text)] mt-0.5">{ownerData.email || 'N/A'}</p>
                </div>
                <div>
                  <span className="text-[9px] font-bold uppercase text-[var(--text-sec)] block">Joined Date</span>
                  <p className="font-mono text-[var(--text)] mt-0.5">{ownerData.createdAt ? new Date(ownerData.createdAt).toLocaleDateString() : 'N/A'}</p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'gym' && (
            <div className="clay-raised p-5 rounded-[22px] space-y-3 text-xs">
              <h3 className="text-xs font-black uppercase tracking-wider text-[var(--text)]">Gym Information</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <span className="text-[9px] font-bold uppercase text-[var(--text-sec)] block">Gym Name</span>
                  <p className="font-bold text-[var(--text)] mt-0.5">{ownerData.gymName}</p>
                </div>
                <div>
                  <span className="text-[9px] font-bold uppercase text-[var(--text-sec)] block">Gym Access Code</span>
                  <p className="font-mono font-bold text-[#34A853] mt-0.5">{ownerData.gymCode || ownerData.accessCode || 'N/A'}</p>
                </div>
                <div>
                  <span className="text-[9px] font-bold uppercase text-[var(--text-sec)] block">Location</span>
                  <p className="text-[var(--text)] mt-0.5">{ownerData.location || `${ownerData.city || 'Patna'}, Bihar`}</p>
                </div>
                <div>
                  <span className="text-[9px] font-bold uppercase text-[var(--text-sec)] block">Gym ID</span>
                  <p className="font-mono text-[var(--text-sec)] mt-0.5">{ownerData.gymId}</p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'members' && (
            <div className="neo-pressed p-6 rounded-[22px] text-center space-y-2">
              <Users size={28} className="mx-auto text-[var(--text-sec)]" />
              <p className="text-xs font-bold uppercase tracking-wider text-[var(--text)]">
                {ownerData.memberCount || 0} Registered Members
              </p>
              <p className="text-[10px] text-[var(--text-sec)]">
                View detailed member roster in the primary Members control panel.
              </p>
            </div>
          )}

          {activeTab === 'plans' && (
            <div className="neo-pressed p-6 rounded-[22px] text-center space-y-2">
              <Dumbbell size={28} className="mx-auto text-[var(--text-sec)]" />
              <p className="text-xs font-bold uppercase tracking-wider text-[var(--text)]">
                Gym Membership Plans
              </p>
              <p className="text-[10px] text-[var(--text-sec)]">
                Plans configured by owner are managed via the Plans module.
              </p>
            </div>
          )}

          {activeTab === 'payments' && (
            <div className="neo-pressed p-6 rounded-[22px] text-center space-y-2">
              <CreditCard size={28} className="mx-auto text-[var(--text-sec)]" />
              <p className="text-xs font-bold uppercase tracking-wider text-[var(--text)]">
                Payment History
              </p>
              <p className="text-[10px] text-[var(--text-sec)]">
                Revenue generated: ₹{(ownerData.revenue || 0).toLocaleString('en-IN')}
              </p>
            </div>
          )}

          {activeTab === 'attendance' && (
            <div className="neo-pressed p-6 rounded-[22px] text-center space-y-2">
              <Calendar size={28} className="mx-auto text-[var(--text-sec)]" />
              <p className="text-xs font-bold uppercase tracking-wider text-[var(--text)]">
                Gym Attendance Records
              </p>
              <p className="text-[10px] text-[var(--text-sec)]">
                Check-ins recorded today: {ownerData.todayAttendance || 0}
              </p>
            </div>
          )}

          {activeTab === 'workouts' && (
            <div className="neo-pressed p-6 rounded-[22px] text-center space-y-2">
              <Activity size={28} className="mx-auto text-[var(--text-sec)]" />
              <p className="text-xs font-bold uppercase tracking-wider text-[var(--text)]">
                Workout Assignments
              </p>
              <p className="text-[10px] text-[var(--text-sec)]">
                Workout routines assigned to gym members.
              </p>
            </div>
          )}

          {activeTab === 'broadcasts' && (
            <div className="neo-pressed p-6 rounded-[22px] text-center space-y-2">
              <Megaphone size={28} className="mx-auto text-[var(--text-sec)]" />
              <p className="text-xs font-bold uppercase tracking-wider text-[var(--text)]">
                Broadcast Campaigns
              </p>
              <p className="text-[10px] text-[var(--text-sec)]">
                In-app and notification broadcasts created by owner.
              </p>
            </div>
          )}

          {activeTab === 'subscriptions' && (
            <div className="clay-raised p-5 rounded-[22px] space-y-3 text-xs">
              <h3 className="text-xs font-black uppercase tracking-wider text-[var(--text)]">SaaS Platform Subscription</h3>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <span className="text-[9px] font-bold uppercase text-[var(--text-sec)] block">Plan</span>
                  <p className="font-bold text-[#34A853] mt-0.5">{ownerData.saasPlan || 'PRO PLATFORM'}</p>
                </div>
                <div>
                  <span className="text-[9px] font-bold uppercase text-[var(--text-sec)] block">Status</span>
                  <p className="font-bold text-[var(--text)] mt-0.5">{ownerData.subscriptionStatus || 'ACTIVE'}</p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'activity' && (
            <div className="neo-pressed p-6 rounded-[22px] text-center space-y-2">
              <Activity size={28} className="mx-auto text-[var(--text-sec)]" />
              <p className="text-xs font-bold uppercase tracking-wider text-[var(--text)]">
                System Audit Trail
              </p>
              <p className="text-[10px] text-[var(--text-sec)] font-mono">
                Click &quot;View Reason History&quot; above for complete moderation history.
              </p>
            </div>
          )}

          {activeTab === 'security' && (
            <div className="clay-raised p-5 rounded-[22px] space-y-3 text-xs">
              <h3 className="text-xs font-black uppercase tracking-wider text-[var(--text)]">Security & Session Status</h3>
              <div className="space-y-2">
                <div className="flex justify-between items-center py-2 border-b border-[var(--border)]">
                  <span className="text-[var(--text-sec)]">Operational Status:</span>
                  <span className="font-mono font-bold text-[var(--text)]">{status}</span>
                </div>
                {ownerData.statusReason && (
                  <div className="flex justify-between items-center py-2 border-b border-[var(--border)]">
                    <span className="text-[var(--text-sec)]">Status Reason:</span>
                    <span className="font-semibold text-[#D64545]">{ownerData.statusReason}</span>
                  </div>
                )}
                {ownerData.freezeUntil && (
                  <div className="flex justify-between items-center py-2 border-b border-[var(--border)]">
                    <span className="text-[var(--text-sec)]">Freeze Expiry:</span>
                    <span className="font-mono font-bold text-[#E8A33D]">{ownerData.freezeUntil}</span>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
