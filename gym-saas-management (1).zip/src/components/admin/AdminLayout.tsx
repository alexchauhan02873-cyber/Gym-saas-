import React, { useEffect, useState } from 'react';
import { useNavigate, useLocation, Link } from '@/lib/router-compat';
import { 
  ShieldCheck, Building2, User, Users, CreditCard, Receipt, DollarSign,
  Calendar, Activity, Megaphone, Bell, CheckSquare, TrendingUp, BarChart3,
  FileSpreadsheet, ShieldAlert, Snowflake, History, Settings, HelpCircle,
  LogOut, Sun, Moon, Menu, X, Search, ChevronRight, HardDrive, Cpu
} from 'lucide-react';
import { signOutEverything } from '@/lib/app-auth';

interface Props {
  children: React.ReactNode;
}

export default function AdminLayout({ children }: Props) {
  const navigate = useNavigate();
  const location = useLocation();
  const [session, setSession] = useState<any>(null);
  const [theme, setTheme] = useState(localStorage.getItem('theme') || 'light');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<{ owners: any[]; gyms: any[]; members: any[] } | null>(null);
  const [isSearching, setIsSearching] = useState(false);

  useEffect(() => {
    let active = true;
    const stored = localStorage.getItem('admin_session');
    if (!stored) {
      navigate('/');
      return;
    }
    try {
      const parsed = JSON.parse(stored);
      if (active) setSession(parsed);
    } catch (e) {
      navigate('/');
    }
    return () => { active = false; };
  }, [navigate]);

  useEffect(() => {
    if (theme === 'light') { 
      document.documentElement.classList.add('light'); 
      document.documentElement.classList.remove('dark');
    } else { 
      document.documentElement.classList.add('dark'); 
      document.documentElement.classList.remove('light');
    }
    localStorage.setItem('theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(theme === 'dark' ? 'light' : 'dark');
  };

  const handleLogout = () => {
    void signOutEverything();
  };

  const handleSearch = async (query: string) => {
    setSearchQuery(query);
    if (!query.trim()) {
      setSearchResults(null);
      return;
    }
    setIsSearching(true);
    try {
      const res = await fetch(`/api/admin/search?q=${encodeURIComponent(query)}`);
      const data = await res.json();
      if (data && data.success) {
        setSearchResults({
          owners: data.owners || [],
          gyms: data.gyms || [],
          members: data.members || []
        });
      }
    } catch (e) {
      console.error('Admin search failed:', e);
    } finally {
      setIsSearching(false);
    }
  };

  if (!session) return null;

  const menuGroups = [
    {
      title: 'OVERVIEW',
      items: [
        { label: 'Dashboard', path: '/admin/dashboard', icon: ShieldCheck },
        { label: 'Live Activity', path: '/admin/activity', icon: Activity },
        { label: 'System Health', path: '/admin/health', icon: Cpu },
      ]
    },
    {
      title: 'PLATFORM',
      items: [
        { label: 'Gyms', path: '/admin/gyms', icon: Building2 },
        { label: 'Owners', path: '/admin/owners', icon: User },
        { label: 'Members', path: '/admin/members', icon: Users },
        { label: 'Plans', path: '/admin/plans', icon: FileSpreadsheet },
        { label: 'Payments', path: '/admin/payments', icon: CreditCard },
        { label: 'Subscriptions', path: '/admin/subscriptions', icon: DollarSign },
        { label: 'Invoices', path: '/admin/invoices', icon: Receipt },
      ]
    },
    {
      title: 'OPERATIONS',
      items: [
        { label: 'Attendance', path: '/admin/attendance', icon: Calendar },
        { label: 'Workouts', path: '/admin/workouts', icon: Activity },
        { label: 'Broadcasts', path: '/admin/broadcast', icon: Megaphone },
        { label: 'Notifications', path: '/admin/notifications', icon: Bell },
        { label: 'Tasks', path: '/admin/tasks', icon: CheckSquare },
      ]
    },
    {
      title: 'ANALYTICS',
      items: [
        { label: 'Revenue', path: '/admin/revenue', icon: DollarSign },
        { label: 'Growth', path: '/admin/growth', icon: TrendingUp },
        { label: 'Performance', path: '/admin/performance', icon: BarChart3 },
        { label: 'Reports', path: '/admin/reports', icon: FileSpreadsheet },
      ]
    },
    {
      title: 'SECURITY',
      items: [
        { label: 'Blocked Accounts', path: '/admin/blocked', icon: ShieldAlert },
        { label: 'Frozen Accounts', path: '/admin/frozen', icon: Snowflake },
        { label: 'Audit Logs', path: '/admin/audit', icon: History },
      ]
    },
    {
      title: 'SETTINGS',
      items: [
        { label: 'Platform Settings', path: '/admin/settings', icon: Settings },
        { label: 'Admin Profile', path: '/admin/profile', icon: User },
        { label: 'Support Center', path: '/admin/support', icon: HelpCircle },
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-[var(--bg)] text-[var(--text)] flex flex-col md:flex-row">
      {/* Mobile Drawer Overlay */}
      {mobileMenuOpen && (
        <div 
          onClick={() => setMobileMenuOpen(false)}
          className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm md:hidden"
        />
      )}

      {/* Desktop & Mobile Navigation Sidebar */}
      <aside
        className={`fixed md:sticky top-0 left-0 z-50 w-64 h-screen bg-[var(--surface-sec)] border-r border-[var(--border)] flex flex-col transition-transform duration-300 ${
          mobileMenuOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        }`}
      >
        {/* Sidebar Header */}
        <div className="p-4 border-b border-[var(--border)] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full neo-pressed text-[#34A853] flex items-center justify-center shrink-0">
              <ShieldCheck size={22} />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h1 className="text-xs font-black tracking-widest uppercase">SUPER ADMIN</h1>
                <span className="text-[8px] font-bold px-1.5 py-0.5 rounded-full bg-[#34A853]/20 text-[#34A853] border border-[#34A853]/30 uppercase">
                  ONLINE
                </span>
              </div>
              <p className="text-[9px] uppercase tracking-widest text-[var(--text-sec)]">Platform Governance</p>
            </div>
          </div>
          <button
            onClick={() => setMobileMenuOpen(false)}
            className="md:hidden p-1.5 text-[var(--text-sec)] hover:text-[var(--text)]"
          >
            <X size={20} />
          </button>
        </div>

        {/* Navigation Items Scroll Container */}
        <div className="flex-1 overflow-y-auto p-3 space-y-4 hide-scrollbar">
          {menuGroups.map((group) => (
            <div key={group.title} className="space-y-1">
              <span className="text-[8px] font-black uppercase tracking-widest text-[var(--text-sec)] px-3 block">
                {group.title}
              </span>
              {group.items.map((item) => {
                const isActive = location.pathname === item.path;
                const Icon = item.icon;
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    onClick={() => setMobileMenuOpen(false)}
                    className={`h-9 px-3 rounded-[12px] text-xs font-bold uppercase tracking-wider flex items-center justify-between transition-all ${
                      isActive
                        ? 'clay-raised bg-[var(--btn-bg)] text-[var(--btn-text)]'
                        : 'text-[var(--text-sec)] hover:text-[var(--text)] hover:bg-[var(--surface)]'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <Icon size={15} />
                      <span>{item.label}</span>
                    </div>
                    {isActive && <ChevronRight size={14} />}
                  </Link>
                );
              })}
            </div>
          ))}
        </div>

        {/* Sidebar Footer Logout */}
        <div className="p-3 border-t border-[var(--border)] shrink-0">
          <button
            onClick={handleLogout}
            className="w-full h-10 rounded-[14px] neo-raised text-[#D64545] font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 active:scale-95 transition-transform cursor-pointer"
          >
            <LogOut size={16} /> Logout Platform
          </button>
        </div>
      </aside>

      {/* Main Content Workspace Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Main Admin Top Header */}
        <header className="sticky top-0 z-30 bg-[var(--bg)]/90 backdrop-blur-md px-4 py-3 border-b border-[var(--border)] flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileMenuOpen(true)}
              className="md:hidden p-2 rounded-full neo-pressed text-[var(--text)]"
            >
              <Menu size={20} />
            </button>

            {/* Global Search Bar */}
            <div className="relative w-full max-w-md hidden sm:block">
              <div className="relative">
                <Search size={15} className="absolute left-3.5 top-3 text-[var(--text-sec)]" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => handleSearch(e.target.value)}
                  placeholder="Global Search (Owner, Gym, Member)..."
                  className="w-full h-10 pl-9 pr-4 rounded-[14px] neo-pressed bg-transparent text-xs font-medium text-[var(--text)] focus:outline-none"
                />
              </div>

              {/* Search Overlay Results */}
              {searchResults && (
                <div className="absolute top-12 left-0 right-0 z-50 clay-raised rounded-[20px] p-4 space-y-3 bg-[var(--bg)] border border-[var(--border)] shadow-2xl max-h-80 overflow-y-auto">
                  {searchResults.owners.length === 0 && searchResults.gyms.length === 0 && searchResults.members.length === 0 ? (
                    <p className="text-xs text-[var(--text-sec)] text-center py-2">No matching records found.</p>
                  ) : (
                    <>
                      {searchResults.gyms.length > 0 && (
                        <div className="space-y-1">
                          <span className="text-[8px] font-black uppercase text-[var(--text-sec)] block">Gym Workspaces</span>
                          {searchResults.gyms.map((g: any) => (
                            <Link
                              key={g.id}
                              to="/admin/gyms"
                              onClick={() => setSearchResults(null)}
                              className="p-2 rounded-[10px] neo-pressed flex justify-between items-center text-xs text-[var(--text)] hover:bg-[var(--surface)]"
                            >
                              <span className="font-bold">{g.gymName}</span>
                              <span className="font-mono text-[10px] text-[var(--text-sec)]">Code: {g.accessCode}</span>
                            </Link>
                          ))}
                        </div>
                      )}

                      {searchResults.owners.length > 0 && (
                        <div className="space-y-1">
                          <span className="text-[8px] font-black uppercase text-[var(--text-sec)] block">Gym Owners</span>
                          {searchResults.owners.map((o: any) => (
                            <Link
                              key={o.id}
                              to="/admin/owners"
                              onClick={() => setSearchResults(null)}
                              className="p-2 rounded-[10px] neo-pressed flex justify-between items-center text-xs text-[var(--text)] hover:bg-[var(--surface)]"
                            >
                              <span className="font-bold">{o.fullName}</span>
                              <span className="font-mono text-[10px] text-[var(--text-sec)]">{o.phone}</span>
                            </Link>
                          ))}
                        </div>
                      )}

                      {searchResults.members.length > 0 && (
                        <div className="space-y-1">
                          <span className="text-[8px] font-black uppercase text-[var(--text-sec)] block">Gym Members</span>
                          {searchResults.members.map((m: any) => (
                            <Link
                              key={m.id}
                              to="/admin/members"
                              onClick={() => setSearchResults(null)}
                              className="p-2 rounded-[10px] neo-pressed flex justify-between items-center text-xs text-[var(--text)] hover:bg-[var(--surface)]"
                            >
                              <span className="font-bold">{m.fullName}</span>
                              <span className="font-mono text-[10px] text-[var(--text-sec)]">{m.memberDisplayId || m.id}</span>
                            </Link>
                          ))}
                        </div>
                      )}
                    </>
                  )}
                </div>
              )}
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button 
              onClick={toggleTheme} 
              className="p-2.5 rounded-full neo-raised text-[var(--text-sec)] hover:text-[var(--text)] transition-colors cursor-pointer"
              title="Toggle theme"
            >
              {theme === 'dark' ? <Moon size={18} /> : <Sun size={18} />}
            </button>
            <div className="hidden sm:flex items-center gap-2 pl-2 border-l border-[var(--border)]">
              <div className="w-8 h-8 rounded-full neo-pressed flex items-center justify-center font-black text-xs text-[var(--text)]">
                SA
              </div>
              <div className="text-left">
                <span className="text-xs font-black uppercase text-[var(--text)] block leading-none">Super Admin</span>
                <span className="text-[8px] font-mono text-[var(--text-sec)] block mt-0.5">Platform Controller</span>
              </div>
            </div>
          </div>
        </header>

        {/* Page Children Content */}
        <main className="flex-1 p-4 md:p-6 max-w-7xl w-full mx-auto">
          {children}
        </main>
      </div>
    </div>
  );
}
