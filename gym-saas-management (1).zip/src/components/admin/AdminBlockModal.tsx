import React, { useState } from 'react';
import { ShieldAlert, X, AlertTriangle, Lock } from 'lucide-react';
import { BLOCK_REASONS, GYM_BLOCK_REASONS } from '@/lib/access-status';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  targetType: 'OWNER' | 'MEMBER' | 'GYM';
  targetId: string;
  targetName: string;
  onConfirm: (reason: string, internalNote: string) => Promise<void>;
}

export default function AdminBlockModal({
  isOpen,
  onClose,
  targetType,
  targetId,
  targetName,
  onConfirm
}: Props) {
  const [selectedReason, setSelectedReason] = useState<string>('');
  const [customReason, setCustomReason] = useState<string>('');
  const [internalNote, setInternalNote] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const reasonList = targetType === 'GYM' || targetType === 'OWNER' ? GYM_BLOCK_REASONS : BLOCK_REASONS;
  const finalReason = selectedReason === 'Other' || selectedReason === '' ? customReason : selectedReason;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!finalReason.trim()) {
      setError('A block reason is required.');
      return;
    }

    setLoading(true);
    setError(null);
    try {
      await onConfirm(finalReason.trim(), internalNote.trim());
      onClose();
    } catch (err: any) {
      setError(err?.message || 'Failed to block account.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-lg clay-raised rounded-[28px] p-6 space-y-5 border border-[var(--border)] relative bg-[var(--bg)] text-[var(--text)]">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 w-8 h-8 rounded-full neo-pressed flex items-center justify-center text-[var(--text-sec)] hover:text-[var(--text)]"
        >
          <X size={18} />
        </button>

        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full neo-pressed text-[#D64545] flex items-center justify-center shrink-0">
            <ShieldAlert size={24} />
          </div>
          <div>
            <span className="text-[9px] font-black uppercase tracking-widest text-[#D64545] bg-[#D64545]/10 px-2.5 py-0.5 rounded-full border border-[#D64545]/20">
              CONFIRM MODERATION
            </span>
            <h2 className="text-lg font-black uppercase tracking-wider text-[var(--text)] mt-1">
              Block {targetType} Account
            </h2>
          </div>
        </div>

        <div className="neo-pressed p-4 rounded-[18px] space-y-2 text-xs">
          <div className="flex justify-between items-center text-[var(--text-sec)] font-bold uppercase tracking-wider text-[10px]">
            <span>Target Account</span>
            <span className="font-mono text-[var(--text)]">{targetId}</span>
          </div>
          <p className="font-black text-sm uppercase text-[var(--text)]">{targetName}</p>
          <p className="text-[11px] text-[#D64545] font-medium flex items-center gap-1.5 pt-1 border-t border-[var(--border)]">
            <AlertTriangle size={14} className="shrink-0" />
            Blocking prevents operational application access immediately. Active sessions will be revoked.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {error && (
            <div className="p-3 rounded-[14px] bg-[#D64545]/10 border border-[#D64545]/20 text-[#D64545] text-xs font-semibold">
              {error}
            </div>
          )}

          <div className="space-y-1.5">
            <label className="text-[10px] font-black uppercase tracking-widest text-[var(--text-sec)] block">
              Reason (Required)
            </label>
            <select
              value={selectedReason}
              onChange={(e) => setSelectedReason(e.target.value)}
              className="w-full h-11 px-3.5 rounded-[14px] neo-pressed bg-transparent text-xs font-semibold text-[var(--text)] focus:outline-none"
            >
              <option value="">-- Select Standard Reason --</option>
              {reasonList.map((r) => (
                <option key={r} value={r}>{r}</option>
              ))}
            </select>
          </div>

          {(selectedReason === 'Other' || !selectedReason) && (
            <div className="space-y-1.5">
              <label className="text-[10px] font-black uppercase tracking-widest text-[var(--text-sec)] block">
                Detailed Reason Statement
              </label>
              <textarea
                value={customReason}
                onChange={(e) => setCustomReason(e.target.value)}
                placeholder="Enter specific reason for blocking this account..."
                rows={3}
                className="w-full p-3 rounded-[14px] neo-pressed bg-transparent text-xs font-medium text-[var(--text)] focus:outline-none resize-none"
              />
            </div>
          )}

          <div className="space-y-1.5">
            <label className="text-[10px] font-black uppercase tracking-widest text-[var(--text-sec)] block">
              Internal Admin Note (Optional)
            </label>
            <input
              type="text"
              value={internalNote}
              onChange={(e) => setInternalNote(e.target.value)}
              placeholder="Internal compliance record reference..."
              className="w-full h-11 px-3.5 rounded-[14px] neo-pressed bg-transparent text-xs font-medium text-[var(--text)] focus:outline-none"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 h-11 rounded-[14px] neo-raised text-xs font-bold uppercase tracking-wider text-[var(--text-sec)] hover:text-[var(--text)]"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-6 h-11 rounded-[14px] bg-[#D64545] text-white text-xs font-bold uppercase tracking-wider flex items-center gap-2 hover:bg-[#D64545]/90 active:scale-95 transition-all disabled:opacity-50"
            >
              <Lock size={15} /> {loading ? 'Processing...' : 'Confirm Block Account'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
