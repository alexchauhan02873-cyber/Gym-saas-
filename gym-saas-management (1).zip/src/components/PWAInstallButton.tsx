import React, { useState } from 'react';
import { Download, Smartphone, Check, X, Share2, PlusSquare } from 'lucide-react';
import { usePWAInstall } from '@/hooks/usePWAInstall';

export default function PWAInstallButton({ className = '' }: { className?: string }) {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showGuide, setShowGuide] = useState(false);
  const [installSuccess, setInstallSuccess] = useState(false);

  if (isInstalled) {
    return (
      <div className={`p-3.5 rounded-[16px] neo-pressed flex items-center justify-between text-xs text-[var(--text-sec)] ${className}`}>
        <div className="flex items-center gap-2">
          <Smartphone size={16} className="text-[#34A853]" />
          <span className="font-bold uppercase tracking-wider text-[11px] text-[var(--text)]">App Installed</span>
        </div>
        <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#34A853]/10 text-[#34A853] font-bold border border-[#34A853]/20">
          STANDALONE
        </span>
      </div>
    );
  }

  const handleInstallClick = async () => {
    if (isInstallable) {
      const res = await install();
      if (res) {
        setInstallSuccess(true);
      }
    } else {
      setShowGuide(true);
    }
  };

  return (
    <>
      {installSuccess ? (
        <div className="p-3.5 rounded-[16px] bg-[#34A853]/10 border border-[#34A853]/30 text-[#34A853] flex items-center gap-2 text-xs font-bold">
          <Check size={16} />
          <span>App Successfully Installed!</span>
        </div>
      ) : (
        <button
          onClick={handleInstallClick}
          type="button"
          className={`w-full py-3 px-4 rounded-[16px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2.5 hover:scale-[1.01] active:scale-95 transition-all cursor-pointer ${className}`}
        >
          <Download size={16} />
          <span>{isIOS ? 'Install PWA on iPhone' : 'Install App'}</span>
        </button>
      )}

      {showGuide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-sm rounded-[28px] clay-raised p-6 bg-[var(--bg)] text-[var(--text)] border border-[var(--border)] relative space-y-4">
            <button
              onClick={() => setShowGuide(false)}
              className="absolute top-4 right-4 p-2 rounded-full neo-pressed text-[var(--text-sec)] hover:text-[var(--text)] cursor-pointer"
            >
              <X size={16} />
            </button>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-[var(--btn-bg)] text-[var(--btn-text)] flex items-center justify-center shrink-0">
                <Smartphone size={20} />
              </div>
              <div>
                <h3 className="text-sm font-black uppercase tracking-wider">Install App</h3>
                <p className="text-[10px] text-[var(--text-sec)] font-mono uppercase">Add to Home Screen</p>
              </div>
            </div>

            {isIOS ? (
              <div className="neo-pressed p-4 rounded-[18px] text-xs space-y-3">
                <p className="font-bold text-[var(--text)]">To install on iOS Safari:</p>
                <ol className="space-y-2 text-[11px] text-[var(--text-sec)] list-decimal pl-4">
                  <li className="flex items-center gap-1.5">
                    Tap the <Share2 size={14} className="text-[var(--text)] shrink-0 inline" /> <strong>Share</strong> icon in Safari toolbar.
                  </li>
                  <li className="flex items-center gap-1.5">
                    Scroll down and select <PlusSquare size={14} className="text-[var(--text)] shrink-0 inline" /> <strong>Add to Home Screen</strong>.
                  </li>
                  <li>Tap <strong>Add</strong> in the top right corner.</li>
                </ol>
              </div>
            ) : (
              <div className="neo-pressed p-4 rounded-[18px] text-xs space-y-3">
                <p className="font-bold text-[var(--text)]">To install on Chrome / Android / Desktop:</p>
                <ol className="space-y-2 text-[11px] text-[var(--text-sec)] list-decimal pl-4">
                  <li>Open browser menu (three dots icon in top right).</li>
                  <li>Select <strong>Install App</strong> or <strong>Add to Home Screen</strong>.</li>
                  <li>Confirm installation prompt.</li>
                </ol>
              </div>
            )}

            <button
              onClick={() => setShowGuide(false)}
              className="w-full py-2.5 rounded-[14px] neo-raised text-xs font-bold uppercase tracking-wider text-[var(--text-sec)] hover:text-[var(--text)] cursor-pointer"
            >
              Got It
            </button>
          </div>
        </div>
      )}
    </>
  );
}
