import React, { useState } from 'react';
import { Globe, ChevronDown, Check } from 'lucide-react';
import { LANGUAGES, getStoredLanguage, setStoredLanguage, type Language } from '@/lib/i18n';

interface LanguageSelectorProps {
  onLanguageChange?: (lang: Language) => void;
  variant?: 'button' | 'compact' | 'inline';
}

export default function LanguageSelector({ onLanguageChange, variant = 'button' }: LanguageSelectorProps) {
  const [currentLang, setCurrentLang] = useState<Language>(getStoredLanguage());
  const [isOpen, setIsOpen] = useState(false);

  const activeOption = LANGUAGES.find(l => l.code === currentLang) || LANGUAGES[0];

  const handleSelect = (langCode: Language) => {
    setCurrentLang(langCode);
    setStoredLanguage(langCode);
    setIsOpen(false);
    if (onLanguageChange) {
      onLanguageChange(langCode);
    }
  };

  return (
    <div className="relative inline-block text-left z-30">
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className={`flex items-center gap-2 rounded-full transition-all cursor-pointer ${
          variant === 'compact'
            ? 'px-3 py-1.5 text-xs neo-raised text-[var(--text)]'
            : 'px-4 py-2 text-xs font-bold neo-raised bg-[var(--surface)] text-[var(--text)] hover:scale-105 active:scale-95'
        }`}
        aria-label="Select Language"
      >
        <Globe size={16} className="text-[var(--text-sec)]" />
        <span className="font-bold tracking-wider">{activeOption.name}</span>
        <span className="text-[10px] text-[var(--text-sec)] font-mono">({activeOption.englishName})</span>
        <ChevronDown size={14} className={`transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && (
        <>
          <div 
            className="fixed inset-0 z-40 bg-black/30 backdrop-blur-xs" 
            onClick={() => setIsOpen(false)} 
          />
          <div className="absolute right-0 mt-2 w-56 rounded-2xl bg-[var(--surface)] neo-raised p-2 z-50 shadow-2xl max-h-72 overflow-y-auto animate-fade-in border border-[var(--border)]">
            <div className="px-3 py-2 border-b border-[var(--border)] text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)]">
              Select Language / भाषा चुनें
            </div>
            <div className="py-1 space-y-1">
              {LANGUAGES.map((lang) => {
                const isSelected = lang.code === currentLang;
                return (
                  <button
                    key={lang.code}
                    onClick={() => handleSelect(lang.code)}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                      isSelected
                        ? 'bg-[var(--text)] text-[var(--bg)]'
                        : 'text-[var(--text)] hover:bg-[var(--surface-sec)]'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold">{lang.name}</span>
                      <span className={`text-[10px] ${isSelected ? 'text-[var(--bg)]/80' : 'text-[var(--text-sec)]'}`}>
                        ({lang.englishName})
                      </span>
                    </div>
                    {isSelected && <Check size={14} />}
                  </button>
                );
              })}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
