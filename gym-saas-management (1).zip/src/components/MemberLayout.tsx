import React, { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from '@/lib/router-compat';
import { Home, Dumbbell, Calendar, TrendingUp, CreditCard, User, Sun, Moon, Headset } from 'lucide-react';
import NotificationCenter from './NotificationCenter';
import { readAppSession, checkAccessState } from '@/lib/app-auth';

interface MemberLayoutProps {
  children: React.ReactNode;
}

export default function MemberLayout({ children }: MemberLayoutProps) {
  const location = useLocation();
  const navigate = useNavigate();
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [memberInfo, setMemberInfo] = useState<any>(null);
  const [showSupportSheet, setShowSupportSheet] = useState(false);

  useEffect(() => {
    (async () => {
      const session = readAppSession('member_session');
      if (session) {
        setMemberInfo(session);
      } else {
        const storedMember = localStorage.getItem('member_session');
        if (storedMember) {
          try {
            setMemberInfo(JSON.parse(storedMember));
          } catch (e) {}
        }
      }

      const access = await checkAccessState();
      if (!access.allowed && access.code) {
        navigate(access.code === 'SESSION_EXPIRED' ? '/' : `/access-blocked?code=${access.code}`, { replace: true });
      }
    })();

    const savedTheme = (localStorage.getItem('member_theme') || localStorage.getItem('gym_theme')) as 'light' | 'dark';
    const initialTheme = savedTheme || 'light';
    setTheme(initialTheme);
    if (initialTheme === 'dark') {
      document.documentElement.classList.add('dark');
      document.documentElement.classList.remove('light');
      document.documentElement.setAttribute('data-theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      document.documentElement.classList.add('light');
      document.documentElement.setAttribute('data-theme', 'light');
    }
  }, [navigate]);

  const toggleTheme = () => {
    const nextTheme = theme === 'dark' ? 'light' : 'dark';
    setTheme(nextTheme);
    localStorage.setItem('member_theme', nextTheme);
    localStorage.setItem('gym_theme', nextTheme);
    
    if (nextTheme === 'dark') {
      document.documentElement.classList.add('dark');
      document.documentElement.classList.remove('light');
      document.documentElement.setAttribute('data-theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      document.documentElement.classList.add('light');
      document.documentElement.setAttribute('data-theme', 'light');
    }
  };

  const navItems = [
    { label: 'HOME', path: '/member/dashboard', icon: Home },
    { label: 'WORKOUT', path: '/member/workout', icon: Dumbbell },
    { label: 'ATTENDANCE', path: '/member/attendance', icon: Calendar },
    { label: 'ANALYTICS', path: '/member/analytics', icon: TrendingUp },
    { label: 'PROFILE', path: '/member/profile', icon: User },
  ];

  return (
    <div className="min-h-screen bg-[var(--bg)] text-[var(--text)] transition-colors duration-200 relative pb-28">
      {/* Top Bar */}
      <header className="sticky top-0 z-40 bg-[var(--bg)]/80 backdrop-blur-md px-4 py-3 border-b border-[var(--border-muted)] flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full neo-pressed flex items-center justify-center text-[var(--text)]">
            <Dumbbell size={18} />
          </div>
          <div>
            <h1 className="text-sm font-black tracking-widest uppercase">Gym Member</h1>
            <p className="text-[9px] uppercase tracking-widest text-[var(--text-sec)]">Fitness Portal</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {memberInfo && memberInfo.gymId && memberInfo.memberId && (
            <NotificationCenter
              gymId={memberInfo.gymId}
              targetId={memberInfo.memberId}
              targetRole="member"
            />
          )}

          <button
            onClick={toggleTheme}
            className="h-9 px-2.5 rounded-full neo-raised flex items-center gap-1.5 active:scale-95 transition-all text-[10px] font-bold uppercase tracking-wider cursor-pointer"
            aria-label="Toggle Theme"
          >
            <div className={`p-1 rounded-full transition-colors ${theme === 'light' ? 'bg-[var(--text)] text-[var(--bg)]' : 'text-[var(--text-sec)]'}`}>
              <Sun size={13} />
            </div>
            <div className={`p-1 rounded-full transition-colors ${theme === 'dark' ? 'bg-[var(--text)] text-[var(--bg)]' : 'text-[var(--text-sec)]'}`}>
              <Moon size={13} />
            </div>
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-md mx-auto">
        {children}
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[var(--bg)]/90 backdrop-blur-lg border-t border-[var(--border-muted)] px-3 py-2">
        <div className="max-w-md mx-auto flex items-center justify-around">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            const Icon = item.icon;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex flex-col items-center justify-center py-1 px-3 rounded-[16px] transition-all duration-200 ${
                  isActive
                    ? 'bg-[var(--text)] text-[var(--bg)] font-bold'
                    : 'text-[var(--text-sec)] hover:text-[var(--text)]'
                }`}
              >
                <Icon size={18} className="mb-0.5" />
                <span className="text-[9px] font-bold tracking-widest uppercase">{item.label}</span>
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
