import React, { useRef } from 'react';
import { X, Printer, Share2, Check, Shield, Award, Sparkles, Dumbbell } from 'lucide-react';

interface DigitalIdCardProps {
  isOpen: boolean;
  onClose: () => void;
  member: {
    id: string;
    fullName: string;
    memberDisplayId?: string;
    phone?: string;
    profileImage?: string;
    gymName?: string;
    planName?: string;
    endDate?: string;
    membershipExpiry?: string;
    status?: string;
    startDate?: string;
  };
}

export default function DigitalIdCard({ isOpen, onClose, member }: DigitalIdCardProps) {
  const cardRef = useRef<HTMLDivElement>(null);
  const [copied, setCopied] = React.useState(false);

  if (!isOpen || !member) return null;

  const displayId = member.memberDisplayId || `MEM-${member.id?.replace(/\D/g, '').slice(-4) || '0042'}`;
  const gymName = member.gymName || 'APEX FITNESS CLUB';
  const planName = member.planName || 'Pro Monthly Pass';
  const expiryDate = member.endDate || member.membershipExpiry || 'Active Membership';
  const status = (member.status || 'ACTIVE').toUpperCase();

  const getStatusColor = () => {
    switch (status) {
      case 'ACTIVE':
        return 'bg-[#34A853] text-white';
      case 'FROZEN':
        return 'bg-[#E3A008] text-black';
      case 'BLOCKED':
        return 'bg-[#D64545] text-white';
      case 'ARCHIVED':
        return 'bg-gray-500 text-white';
      default:
        return 'bg-[#34A853] text-white';
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleShare = () => {
    const text = `Gym Member ID Card\nName: ${member.fullName}\nID: ${displayId}\nGym: ${gymName}\nPlan: ${planName}\nValid Until: ${expiryDate}`;
    if (navigator.share) {
      navigator.share({ title: `${member.fullName} - Gym ID`, text }).catch(() => {});
    } else {
      navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in print:p-0 print:bg-white">
      <div className="w-full max-w-md bg-[var(--surface)] rounded-[32px] neo-raised overflow-hidden relative border border-[var(--border)] print:border-none print:shadow-none">
        {/* Header Bar */}
        <div className="px-6 py-4 flex justify-between items-center border-b border-[var(--border)] print:hidden">
          <div className="flex items-center gap-2">
            <Shield size={18} className="text-[#34A853]" />
            <span className="text-xs font-black uppercase tracking-widest text-[var(--text)]">Official Member Pass</span>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full neo-pressed flex items-center justify-center text-[var(--text-sec)] hover:text-[var(--text)] transition-colors cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Printable Pass Body */}
        <div ref={cardRef} className="p-6 sm:p-8 space-y-6 relative bg-gradient-to-b from-[var(--surface)] to-[var(--bg)]">
          {/* Gym Branding Header */}
          <div className="flex justify-between items-start pb-4 border-b border-[var(--border)]">
            <div>
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-xl bg-[var(--btn-bg)] text-[var(--btn-text)] flex items-center justify-center font-black">
                  <Dumbbell size={16} />
                </div>
                <h3 className="text-sm font-black uppercase tracking-widest text-[var(--text)]">{gymName}</h3>
              </div>
              <p className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] mt-1">Digital Gym Identity Pass</p>
            </div>
            <span className={`text-[9px] font-black uppercase px-3 py-1 rounded-full tracking-widest shadow-sm ${getStatusColor()}`}>
              {status}
            </span>
          </div>

          {/* Member Details Layout */}
          <div className="flex items-center gap-5">
            {/* Photo Avatar */}
            <div className="relative shrink-0">
              {member.profileImage ? (
                <img
                  src={member.profileImage}
                  alt={member.fullName}
                  className="w-20 h-20 rounded-[22px] object-cover neo-pressed border-2 border-[var(--border)]"
                />
              ) : (
                <div className="w-20 h-20 rounded-[22px] neo-pressed flex items-center justify-center font-black text-2xl uppercase text-[var(--text)] border-2 border-[var(--border)]">
                  {member.fullName?.charAt(0) || 'M'}
                </div>
              )}
              <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-[#34A853] text-white flex items-center justify-center text-[10px]">
                <Check size={12} />
              </div>
            </div>

            {/* Member Info */}
            <div className="space-y-1 min-w-0 flex-1">
              <span className="text-[9px] font-black font-mono px-2 py-0.5 rounded bg-[var(--btn-bg)] text-[var(--btn-text)] inline-block uppercase tracking-wider">
                ID: {displayId}
              </span>
              <h2 className="text-lg font-black uppercase tracking-wider text-[var(--text)] truncate">{member.fullName}</h2>
              {member.phone && (
                <p className="text-xs text-[var(--text-sec)] font-mono">{member.phone}</p>
              )}
            </div>
          </div>

          {/* Key Membership Metadata */}
          <div className="grid grid-cols-2 gap-3 pt-2">
            <div className="p-3 neo-pressed rounded-[16px]">
              <span className="text-[8px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Membership Plan</span>
              <span className="text-xs font-black text-[var(--text)] mt-0.5 block truncate">{planName}</span>
            </div>
            <div className="p-3 neo-pressed rounded-[16px]">
              <span className="text-[8px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Valid Until</span>
              <span className="text-xs font-black font-mono text-[#34A853] mt-0.5 block truncate">{expiryDate}</span>
            </div>
          </div>

          {/* Security Verification Footer */}
          <div className="neo-pressed p-3 rounded-[16px] flex items-center justify-between text-[9px] text-[var(--text-sec)] font-mono">
            <div className="flex items-center gap-1.5">
              <Sparkles size={12} className="text-[#E3A008]" />
              <span>VERIFIED MEMBER PASS</span>
            </div>
            <span className="font-bold text-[var(--text)]">GYM PRO AUTH</span>
          </div>
        </div>

        {/* Action Controls */}
        <div className="p-4 bg-[var(--surface-sec)] border-t border-[var(--border)] flex gap-3 print:hidden">
          <button
            onClick={handleShare}
            className="flex-1 h-11 rounded-[16px] neo-raised text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer active:scale-95 transition-transform"
          >
            {copied ? <Check size={16} className="text-[#34A853]" /> : <Share2 size={16} />}
            {copied ? 'Copied Details' : 'Share Card'}
          </button>
          <button
            onClick={handlePrint}
            className="flex-1 h-11 rounded-[16px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer active:scale-95 transition-transform"
          >
            <Printer size={16} /> Print / Download
          </button>
        </div>
      </div>
    </div>
  );
}
