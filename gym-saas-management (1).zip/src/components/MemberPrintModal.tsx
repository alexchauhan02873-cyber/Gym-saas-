import React, { useState } from 'react';
import { X, Printer, QrCode, FileText, ShieldCheck, Dumbbell, User, Check, Phone, Calendar, CreditCard } from 'lucide-react';

interface MemberPrintModalProps {
  isOpen: boolean;
  onClose: () => void;
  member: any;
  gymName?: string;
}

export default function MemberPrintModal({ isOpen, onClose, member, gymName = 'Apex Fitness Club' }: MemberPrintModalProps) {
  const [activeTab, setActiveTab] = useState<'SUMMARY' | 'QR_LABEL'>('QR_LABEL');

  if (!isOpen || !member) return null;

  const displayId = member.memberDisplayId || member.memberCode || `MEM-${member.id?.replace(/\D/g, '').slice(-4) || '0042'}`;
  const accessCode = member.memberAccessCode || member.memberCode || '483921';
  const planName = member.planName || 'Pro Monthly Pass';
  const expiryDate = member.endDate || member.membershipExpiry || 'Active Membership';
  const status = (member.status || 'ACTIVE').toUpperCase();
  const joinedDate = member.joinedDate || member.createdAt?.split('T')[0] || new Date().toISOString().split('T')[0];

  // High-density QR code URL using Google Chart API encoding access code / member ID
  const qrCodeData = encodeURIComponent(`GYM:${gymName}|ID:${displayId}|CODE:${accessCode}`);
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${qrCodeData}`;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in print:p-0 print:bg-white print:static print:inset-auto">
      {/* Hide surrounding UI during window.print() */}
      <style>{`
        @media print {
          body * {
            visibility: hidden;
          }
          #printable-member-area, #printable-member-area * {
            visibility: visible;
          }
          #printable-member-area {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            padding: 20px;
            background: #ffffff !important;
            color: #000000 !important;
          }
          .print-hidden {
            display: none !important;
          }
        }
      `}</style>

      <div className="w-full max-w-lg bg-[var(--surface)] rounded-[32px] neo-raised overflow-hidden relative border border-[var(--border)] print:border-none print:shadow-none print:w-full print:max-w-none">
        {/* Modal Header & Navigation */}
        <div className="px-6 py-4 flex justify-between items-center border-b border-[var(--border)] print:hidden">
          <div className="flex items-center gap-2">
            <ShieldCheck size={20} className="text-[#34A853]" />
            <h3 className="text-sm font-black uppercase tracking-wider text-[var(--text)]">Print Member Label & Summary</h3>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full neo-pressed flex items-center justify-center text-[var(--text-sec)] hover:text-[var(--text)] transition-colors cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="px-6 pt-4 flex gap-2 print:hidden">
          <button
            onClick={() => setActiveTab('QR_LABEL')}
            className={`flex-1 py-2.5 rounded-[14px] text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer ${
              activeTab === 'QR_LABEL'
                ? 'bg-[var(--btn-bg)] text-[var(--btn-text)] shadow-sm'
                : 'neo-pressed text-[var(--text-sec)]'
            }`}
          >
            <QrCode size={16} /> QR ID Label Sticker
          </button>
          <button
            onClick={() => setActiveTab('SUMMARY')}
            className={`flex-1 py-2.5 rounded-[14px] text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer ${
              activeTab === 'SUMMARY'
                ? 'bg-[var(--btn-bg)] text-[var(--btn-text)] shadow-sm'
                : 'neo-pressed text-[var(--text-sec)]'
            }`}
          >
            <FileText size={16} /> Member Full Summary
          </button>
        </div>

        {/* PRINTABLE AREA */}
        <div id="printable-member-area" className="p-6 space-y-6">
          {activeTab === 'QR_LABEL' ? (
            /* COMPACT QR CODE ID LABEL (Thermal / Badge Print format) */
            <div className="max-w-xs mx-auto p-5 rounded-[24px] neo-pressed border-2 border-[var(--border)] bg-[var(--surface)] text-center space-y-4 print:border-2 print:border-black print:rounded-xl">
              <div className="flex items-center justify-center gap-2 border-b border-[var(--border)] pb-3">
                <Dumbbell size={18} className="text-[var(--text)]" />
                <span className="text-xs font-black uppercase tracking-widest text-[var(--text)]">{gymName}</span>
              </div>

              {/* QR Code */}
              <div className="w-44 h-44 mx-auto bg-white p-2.5 rounded-2xl shadow-inner border border-gray-200 flex items-center justify-center">
                <img src={qrCodeUrl} alt="Member QR Code" className="w-full h-full object-contain" />
              </div>

              {/* Member Details */}
              <div className="space-y-1">
                <span className="text-[10px] font-black font-mono tracking-widest bg-[var(--btn-bg)] text-[var(--btn-text)] px-3 py-0.5 rounded-full inline-block uppercase">
                  ID: {displayId}
                </span>
                <h2 className="text-base font-black uppercase tracking-wider text-[var(--text)]">{member.fullName}</h2>
                <p className="text-[10px] font-mono text-[var(--text-sec)]">{member.phone || 'Phone N/A'}</p>
              </div>

              <div className="grid grid-cols-2 gap-2 text-left pt-2 border-t border-[var(--border)] text-[9px] font-mono">
                <div>
                  <span className="text-[var(--text-sec)] block font-bold uppercase">STATUS</span>
                  <span className="font-black text-[#34A853]">{status}</span>
                </div>
                <div>
                  <span className="text-[var(--text-sec)] block font-bold uppercase">EXPIRES</span>
                  <span className="font-black text-[var(--text)]">{expiryDate}</span>
                </div>
              </div>

              <div className="text-[8px] font-mono text-[var(--text-sec)] tracking-widest uppercase pt-1">
                Official Gym Pass • Code: {accessCode}
              </div>
            </div>
          ) : (
            /* FULL MEMBER SUMMARY SHEET */
            <div className="p-6 rounded-[24px] neo-pressed space-y-6 bg-[var(--surface)] border border-[var(--border)] print:border-none">
              {/* Gym Header */}
              <div className="flex justify-between items-start border-b border-[var(--border)] pb-4">
                <div>
                  <div className="flex items-center gap-2">
                    <Dumbbell size={20} className="text-[#34A853]" />
                    <h2 className="text-base font-black uppercase tracking-wider text-[var(--text)]">{gymName}</h2>
                  </div>
                  <p className="text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] mt-0.5">Member Identity & Subscription Record</p>
                </div>
                <span className="text-[10px] font-black font-mono px-3 py-1 bg-[#34A853]/20 text-[#34A853] rounded-full uppercase">
                  {status} MEMBER
                </span>
              </div>

              {/* Member Profile Main Header */}
              <div className="flex items-center gap-4">
                {member.profileImage ? (
                  <img src={member.profileImage} alt={member.fullName} className="w-16 h-16 rounded-[20px] object-cover neo-pressed" />
                ) : (
                  <div className="w-16 h-16 rounded-[20px] neo-pressed flex items-center justify-center text-xl font-black uppercase text-[var(--text)]">
                    {member.fullName?.charAt(0) || 'M'}
                  </div>
                )}
                <div>
                  <span className="text-[9px] font-mono px-2 py-0.5 rounded bg-[var(--btn-bg)] text-[var(--btn-text)] font-bold">
                    {displayId}
                  </span>
                  <h3 className="text-lg font-black uppercase tracking-wider text-[var(--text)] mt-0.5">{member.fullName}</h3>
                  <p className="text-xs text-[var(--text-sec)] font-mono">{member.phone} {member.email ? `• ${member.email}` : ''}</p>
                </div>
              </div>

              {/* Grid Summary Details */}
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-3 neo-raised rounded-[16px] space-y-1">
                  <span className="text-[9px] font-bold uppercase text-[var(--text-sec)] block">Gender & Age</span>
                  <span className="font-bold text-[var(--text)]">{member.gender || 'Male'}, {member.age ? `${member.age} Yrs` : 'N/A'}</span>
                </div>
                <div className="p-3 neo-raised rounded-[16px] space-y-1">
                  <span className="text-[9px] font-bold uppercase text-[var(--text-sec)] block">Locality</span>
                  <span className="font-bold text-[var(--text)]">{member.location || member.locality || 'Main Branch'}</span>
                </div>
                <div className="p-3 neo-raised rounded-[16px] space-y-1">
                  <span className="text-[9px] font-bold uppercase text-[var(--text-sec)] block">Membership Plan</span>
                  <span className="font-bold text-[var(--text)]">{planName}</span>
                </div>
                <div className="p-3 neo-raised rounded-[16px] space-y-1">
                  <span className="text-[9px] font-bold uppercase text-[var(--text-sec)] block">Payment Status</span>
                  <span className={`font-bold ${member.due || member.paymentStatus === 'DUE' ? 'text-[#E3A008]' : 'text-[#34A853]'}`}>
                    {member.due ? 'DUE PENDING' : (member.paymentStatus || 'PAID')}
                  </span>
                </div>
                <div className="p-3 neo-raised rounded-[16px] space-y-1">
                  <span className="text-[9px] font-bold uppercase text-[var(--text-sec)] block">Date Joined</span>
                  <span className="font-bold font-mono text-[var(--text)]">{joinedDate}</span>
                </div>
                <div className="p-3 neo-raised rounded-[16px] space-y-1">
                  <span className="text-[9px] font-bold uppercase text-[var(--text-sec)] block">Plan Expiry Date</span>
                  <span className="font-bold font-mono text-[#34A853]">{expiryDate}</span>
                </div>
              </div>

              {/* Member Access QR & Code */}
              <div className="p-4 neo-raised rounded-[20px] flex items-center justify-between gap-4">
                <div className="space-y-1">
                  <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Reception Check-in Access Code</span>
                  <div className="text-xl font-black font-mono tracking-widest text-[var(--text)]">{accessCode}</div>
                  <p className="text-[9px] text-[var(--text-sec)]">Scan QR code or enter access code at reception scanner.</p>
                </div>
                <div className="w-20 h-20 bg-white p-1.5 rounded-xl shrink-0 border border-gray-200">
                  <img src={qrCodeUrl} alt="QR Code" className="w-full h-full object-contain" />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Action Controls */}
        <div className="p-4 bg-[var(--surface-sec)] border-t border-[var(--border)] flex gap-3 print:hidden">
          <button
            onClick={onClose}
            className="w-1/3 h-11 rounded-[16px] neo-raised text-xs font-bold uppercase tracking-wider cursor-pointer"
          >
            Close
          </button>
          <button
            onClick={handlePrint}
            className="w-2/3 h-11 rounded-[16px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer active:scale-95 transition-transform shadow-md"
          >
            <Printer size={16} /> PRINT {activeTab === 'QR_LABEL' ? 'QR ID LABEL' : 'SUMMARY'}
          </button>
        </div>
      </div>
    </div>
  );
}
