import React from 'react';
import { Trophy, Zap, ChevronRight } from 'lucide-react';

interface LevelUpModalProps {
  isOpen: boolean;
  onClose: () => void;
  levelInfo: {
    level: number;
    title: string;
    levelName?: string;
  } | null;
}

export default function LevelUpModal({ isOpen, onClose, levelInfo }: LevelUpModalProps) {
  if (!isOpen || !levelInfo) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
      <div className="w-full max-w-sm bg-[var(--surface)] rounded-[32px] neo-raised p-6 text-center space-y-5 border border-[var(--border)] relative overflow-hidden">
        <div className="absolute -top-12 -right-12 w-36 h-36 bg-blue-500/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute -bottom-12 -left-12 w-36 h-36 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="flex justify-center">
          <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-emerald-500 to-teal-300 text-black flex items-center justify-center shadow-lg transform hover:scale-110 transition-transform">
            <Trophy size={40} className="stroke-[2.5]" />
          </div>
        </div>

        <div className="space-y-1">
          <span className="text-[10px] font-black uppercase tracking-widest text-emerald-500 bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20 inline-block">
            LEVEL UP!
          </span>
          <h2 className="text-2xl font-black uppercase tracking-wider text-[var(--text)] pt-2">
            LEVEL {levelInfo.level}
          </h2>
          <p className="text-sm font-bold uppercase text-[var(--text-sec)] tracking-widest">
            {levelInfo.title}
          </p>
        </div>

        <div className="p-3.5 neo-pressed rounded-[20px] text-[11px] text-[var(--text)] font-semibold flex items-center justify-center gap-2">
          <Zap size={15} className="text-emerald-500" />
          <span>Consistency pays off! Keep going!</span>
        </div>

        <button
          onClick={onClose}
          className="w-full h-12 rounded-[20px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer active:scale-95 transition-transform"
        >
          Keep Pushing! <ChevronRight size={16} />
        </button>
      </div>
    </div>
  );
}
