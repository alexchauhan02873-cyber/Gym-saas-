import React, { useState } from 'react';
import { Smartphone, CheckCircle2, X, Share, PlusSquare, Download } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

export default function PWAInstallBanner() {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [dismissed, setDismissed] = useState(false);

  if (isInstalled) {
    return (
      <div className="neo-pressed p-3.5 rounded-[18px] flex items-center justify-between text-[var(--text-sec)]">
        <div className="flex items-center gap-2.5">
          <CheckCircle2 size={18} className="text-[#34A853]" />
          <span className="text-xs font-bold uppercase tracking-wider">App Installed on Device</span>
        </div>
        <span className="text-[10px] font-black uppercase tracking-widest px-2 py-0.5 neo-raised rounded-md text-[var(--text)]">PWA Active</span>
      </div>
    );
  }

  if (dismissed) return null;
  if (!isInstallable && !isIOS) return null;

  return (
    <div className="neo-raised p-4 rounded-[22px] bg-gradient-to-br from-[var(--surface)] to-[var(--bg)] space-y-3 relative border border-[var(--border)]">
      <button
        onClick={() => setDismissed(true)}
        className="absolute top-3 right-3 p-1.5 neo-pressed rounded-full text-[var(--text-sec)] hover:text-[var(--text)] transition-colors cursor-pointer"
        aria-label="Dismiss"
      >
        <X size={14} />
      </button>

      <div className="flex items-start gap-3">
        <div className="p-3 neo-pressed rounded-[16px] text-[var(--text)] shrink-0">
          <Smartphone size={24} />
        </div>
        <div className="pr-6">
          <h4 className="text-xs font-black uppercase tracking-wider">Install Gym App</h4>
          <p className="text-[11px] text-[var(--text-sec)] font-medium mt-0.5 leading-relaxed">
            Add the dashboard to your home screen and open it full screen, without a browser tab.
          </p>
        </div>
      </div>

      {isInstallable ? (
        <button
          onClick={install}
          className="w-full h-11 rounded-[14px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 active:scale-95 transition-transform cursor-pointer"
        >
          <Download size={16} /> INSTALL APP TO HOME SCREEN
        </button>
      ) : (
        <div className="neo-pressed rounded-[14px] p-3 space-y-2">
          <p className="text-[10px] font-black uppercase tracking-widest text-[var(--text)]">
            iPhone / iPad • Safari
          </p>
          <div className="flex items-center gap-2 text-[11px] text-[var(--text-sec)] font-medium">
            <Share size={14} className="shrink-0" />
            <span>1. Tap the Share button in Safari</span>
          </div>
          <div className="flex items-center gap-2 text-[11px] text-[var(--text-sec)] font-medium">
            <PlusSquare size={14} className="shrink-0" />
            <span>2. Choose "Add to Home Screen", then Add</span>
          </div>
        </div>
      )}
    </div>
  );
}
