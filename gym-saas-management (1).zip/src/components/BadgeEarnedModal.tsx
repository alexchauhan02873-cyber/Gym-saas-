import React from 'react';
import { Award, Sparkles, Check } from 'lucide-react';

interface BadgeEarnedModalProps {
  isOpen: boolean;
  onClose: () => void;
  badge: {
    id: string;
    name: string;
    description: string;
    icon?: string;
    unlockedAt?: string;
  } | null;
}

export default function BadgeEarnedModal({ isOpen, onClose, badge }: BadgeEarnedModalProps) {
  if (!isOpen || !badge) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
      <div className="w-full max-w-sm bg-[var(--surface)] rounded-[32px] neo-raised p-6 text-center space-y-5 border border-[var(--border)] relative overflow-hidden">
        <div className="absolute -top-12 -left-12 w-32 h-32 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute -bottom-12 -right-12 w-32 h-32 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="flex justify-center">
          <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-amber-500 to-yellow-300 text-black flex items-center justify-center shadow-lg transform hover:scale-110 transition-transform">
            <Award size={40} className="stroke-[2.5]" />
          </div>
        </div>

        <div className="space-y-1">
          <span className="text-[10px] font-black uppercase tracking-widest text-amber-500 bg-amber-500/10 px-3 py-1 rounded-full border border-amber-500/20 inline-block">
            ACHIEVEMENT UNLOCKED
          </span>
          <h2 className="text-xl font-black uppercase tracking-wider text-[var(--text)] pt-2">{badge.name}</h2>
          <p className="text-xs text-[var(--text-sec)] font-medium leading-relaxed">{badge.description}</p>
        </div>

        <div className="p-3 neo-pressed rounded-[20px] text-[10px] text-[var(--text-sec)] font-mono flex items-center justify-center gap-1.5">
          <Sparkles size={14} className="text-amber-500" />
          <span>Permanently Earned & Saved in Profile</span>
        </div>

        <button
          onClick={onClose}
          className="w-full h-12 rounded-[20px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer active:scale-95 transition-transform"
        >
          <Check size={16} /> Awesome!
        </button>
      </div>
    </div>
  );
}
