import React, { useState, useEffect } from 'react';
import { X, IndianRupee, Search, Check, AlertCircle, FileText, Calendar, CreditCard } from 'lucide-react';

interface RecordPaymentModalProps {
  gymId: string;
  isOpen: boolean;
  onClose: () => void;
  preselectedMemberId?: string;
  onSuccess?: (paymentRecord: any) => void;
  onGenerateInvoice?: (memberId: string, paymentId?: string) => void;
}

export default function RecordPaymentModal({
  gymId,
  isOpen,
  onClose,
  preselectedMemberId,
  onSuccess,
  onGenerateInvoice
}: RecordPaymentModalProps) {
  const [members, setMembers] = useState<any[]>([]);
  const [plans, setPlans] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedMember, setSelectedMember] = useState<any | null>(null);

  const [amount, setAmount] = useState<string>('');
  const [paymentMode, setPaymentMode] = useState<string>('UPI');
  const [reference, setReference] = useState<string>('');
  const [note, setNote] = useState<string>('');
  const [paymentDate, setPaymentDate] = useState<string>(new Date().toISOString().split('T')[0]);
  
  const [loading, setLoading] = useState(false);
  const [fetchingMembers, setFetchingMembers] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [recordedPayment, setRecordedPayment] = useState<any | null>(null);

  useEffect(() => {
    if (!isOpen || !gymId) return;
    setFetchingMembers(true);
    setError(null);
    setRecordedPayment(null);

    Promise.all([
      fetch(`/api/members/${gymId}`).then(res => res.json()),
      fetch(`/api/plans/public/${gymId}`).then(res => res.json())
    ])
      .then(([membersRes, plansRes]) => {
        if (membersRes.success && membersRes.members) {
          setMembers(membersRes.members);
          if (preselectedMemberId) {
            const found = membersRes.members.find((m: any) => m.id === preselectedMemberId);
            if (found) {
              selectMemberHandler(found);
            }
          }
        }
        if (plansRes.success && plansRes.plans) {
          setPlans(plansRes.plans);
        }
      })
      .catch(err => {
        console.error(err);
        setError('Failed to load members list.');
      })
      .finally(() => setFetchingMembers(false));
  }, [isOpen, gymId, preselectedMemberId]);

  const selectMemberHandler = (m: any) => {
    setSelectedMember(m);
    const plan = plans.find(p => p.id === m.planId) || { price: 1500 };
    const planPrice = Number(m.customPrice || plan.price || 1500);
    const paid = Number(m.totalPaid || 0);
    const remaining = Math.max(0, planPrice - paid);
    setAmount(remaining > 0 ? remaining.toString() : planPrice.toString());
  };

  const filteredMembers = members.filter(m => 
    m.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    m.phone?.includes(searchQuery) ||
    m.memberDisplayId?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMember) {
      setError('Please select a member.');
      return;
    }
    const numAmount = Number(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      setError('Please enter a valid payment amount (> 0).');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const res = await fetch('/api/payments/record', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          gymId,
          memberId: selectedMember.id,
          amount: numAmount,
          paymentMode,
          reference: reference.trim(),
          note: note.trim(),
          date: paymentDate
        })
      });
      const data = await res.json();
      if (data.success) {
        setRecordedPayment(data.payment);
        if (onSuccess) onSuccess(data.payment);
      } else {
        setError(data.message || 'Failed to record payment.');
      }
    } catch (err: any) {
      console.error(err);
      setError('Network error occurred while recording payment.');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in">
      <div className="bg-[var(--surface)] text-[var(--text)] w-full max-w-lg rounded-[24px] border border-[var(--border)] shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-[var(--border)] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-[var(--text)] text-[var(--bg)] flex items-center justify-center font-black">
              <IndianRupee size={18} />
            </div>
            <div>
              <h2 className="text-base font-black uppercase tracking-wider">Record Manual Payment</h2>
              <p className="text-[10px] text-[var(--text-sec)] uppercase tracking-wider">Owner Direct Payment Entry</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl neo-pressed text-[var(--text-sec)] hover:text-[var(--text)] cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1">
          {error && (
            <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-600 dark:text-red-400 text-xs font-bold flex items-center gap-2">
              <AlertCircle size={16} className="shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {recordedPayment ? (
            <div className="p-6 rounded-[20px] bg-emerald-500/10 border border-emerald-500/30 text-center space-y-4">
              <div className="w-12 h-12 rounded-full bg-emerald-500 text-white mx-auto flex items-center justify-center shadow-md">
                <Check size={28} />
              </div>
              <div>
                <h3 className="text-base font-black uppercase tracking-wider text-emerald-600 dark:text-emerald-400">Payment Recorded!</h3>
                <p className="text-xs text-[var(--text-sec)] mt-1">₹{recordedPayment.amount} received via {recordedPayment.paymentMode} for {recordedPayment.memberName}</p>
              </div>

              <div className="pt-2 flex flex-col sm:flex-row gap-2 justify-center">
                {onGenerateInvoice && (
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onGenerateInvoice(recordedPayment.memberId, recordedPayment.id);
                    }}
                    className="px-4 py-2.5 rounded-xl bg-[var(--text)] text-[var(--bg)] text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <FileText size={16} /> Generate Invoice
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => {
                    setRecordedPayment(null);
                    setSelectedMember(null);
                  }}
                  className="px-4 py-2.5 rounded-xl neo-raised text-xs font-bold uppercase tracking-wider cursor-pointer"
                >
                  Record Another
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Member Selector */}
              <div>
                <label className="text-[10px] font-black uppercase tracking-widest text-[var(--text-sec)] block mb-1.5">
                  1. Select Member
                </label>
                {selectedMember ? (
                  <div className="p-3 rounded-xl bg-[var(--surface-sec)] border border-[var(--border)] flex items-center justify-between">
                    <div>
                      <h4 className="text-xs font-black uppercase text-[var(--text)]">{selectedMember.fullName}</h4>
                      <p className="text-[10px] text-[var(--text-sec)] uppercase">{selectedMember.memberDisplayId || selectedMember.id} • {selectedMember.phone}</p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setSelectedMember(null)}
                      className="text-[10px] font-bold text-red-500 uppercase hover:underline"
                    >
                      Change
                    </button>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <div className="relative">
                      <Search size={16} className="absolute left-3 top-2.5 text-[var(--text-sec)]" />
                      <input
                        type="text"
                        placeholder="Search member by Name, ID or Phone..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="w-full pl-9 pr-3 py-2 rounded-xl bg-[var(--surface-sec)] border border-[var(--border)] text-xs focus:outline-none focus:border-[var(--text)]"
                      />
                    </div>
                    {fetchingMembers ? (
                      <div className="p-3 text-center text-xs text-[var(--text-sec)]">Loading members...</div>
                    ) : (
                      <div className="max-h-36 overflow-y-auto space-y-1 border border-[var(--border)] rounded-xl p-1 bg-[var(--bg)]">
                        {filteredMembers.length === 0 ? (
                          <div className="p-3 text-center text-xs text-[var(--text-sec)]">No matching members found</div>
                        ) : (
                          filteredMembers.slice(0, 10).map(m => (
                            <button
                              key={m.id}
                              type="button"
                              onClick={() => selectMemberHandler(m)}
                              className="w-full text-left p-2 rounded-lg hover:bg-[var(--surface-sec)] flex items-center justify-between cursor-pointer"
                            >
                              <div>
                                <span className="text-xs font-bold uppercase text-[var(--text)] block">{m.fullName}</span>
                                <span className="text-[9px] text-[var(--text-sec)] uppercase">{m.memberDisplayId || m.id} • {m.phone}</span>
                              </div>
                              <span className="text-[9px] font-bold px-2 py-0.5 rounded-full bg-[var(--surface-sec)] uppercase">
                                {m.paymentStatus || 'ACTIVE'}
                              </span>
                            </button>
                          ))
                        )}
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Payment Details Form */}
              {selectedMember && (
                <>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] font-black uppercase tracking-widest text-[var(--text-sec)] block mb-1">
                        Amount Paid (₹) *
                      </label>
                      <input
                        type="number"
                        min="1"
                        required
                        value={amount}
                        onChange={(e) => setAmount(e.target.value)}
                        placeholder="e.g. 1500"
                        className="w-full px-3 py-2 rounded-xl bg-[var(--surface-sec)] border border-[var(--border)] text-xs font-bold text-[var(--text)] focus:outline-none focus:border-[var(--text)]"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] font-black uppercase tracking-widest text-[var(--text-sec)] block mb-1">
                        Payment Mode *
                      </label>
                      <select
                        value={paymentMode}
                        onChange={(e) => setPaymentMode(e.target.value)}
                        className="w-full px-3 py-2 rounded-xl bg-[var(--surface-sec)] border border-[var(--border)] text-xs font-bold text-[var(--text)] focus:outline-none focus:border-[var(--text)]"
                      >
                        <option value="UPI">UPI / GPay / PhonePe</option>
                        <option value="CASH">Cash</option>
                        <option value="CARD">Credit / Debit Card</option>
                        <option value="BANK_TRANSFER">Bank Transfer / NEFT</option>
                        <option value="OTHER">Other Mode</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] font-black uppercase tracking-widest text-[var(--text-sec)] block mb-1">
                        Transaction Ref / UPI ID (Optional)
                      </label>
                      <input
                        type="text"
                        value={reference}
                        onChange={(e) => setReference(e.target.value)}
                        placeholder="e.g. UPI-94827103"
                        className="w-full px-3 py-2 rounded-xl bg-[var(--surface-sec)] border border-[var(--border)] text-xs text-[var(--text)] focus:outline-none focus:border-[var(--text)]"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] font-black uppercase tracking-widest text-[var(--text-sec)] block mb-1">
                        Payment Date
                      </label>
                      <input
                        type="date"
                        value={paymentDate}
                        onChange={(e) => setPaymentDate(e.target.value)}
                        className="w-full px-3 py-2 rounded-xl bg-[var(--surface-sec)] border border-[var(--border)] text-xs text-[var(--text)] focus:outline-none focus:border-[var(--text)]"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-[10px] font-black uppercase tracking-widest text-[var(--text-sec)] block mb-1">
                      Notes / Remarks (Optional)
                    </label>
                    <input
                      type="text"
                      value={note}
                      onChange={(e) => setNote(e.target.value)}
                      placeholder="e.g. Paid partial installment"
                      className="w-full px-3 py-2 rounded-xl bg-[var(--surface-sec)] border border-[var(--border)] text-xs text-[var(--text)] focus:outline-none focus:border-[var(--text)]"
                    />
                  </div>

                  <div className="pt-2 flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={onClose}
                      className="px-4 py-2.5 rounded-xl neo-raised text-xs font-bold uppercase tracking-wider cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={loading}
                      className="px-5 py-2.5 rounded-xl bg-[var(--text)] text-[var(--bg)] text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer shadow-md hover:scale-105 active:scale-95 transition-transform disabled:opacity-50"
                    >
                      {loading ? 'Recording...' : 'Confirm & Save Payment'}
                    </button>
                  </div>
                </>
              )}
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
