import React, { useState, useEffect, useRef } from 'react';
import { X, Camera, Upload, AlertCircle, Check, RefreshCw, ShieldAlert, Image } from 'lucide-react';
import jsQR from 'jsqr';
import { SCAN_MESSAGES, parseAttendanceQrPayload } from '@/lib/attendance-qr';

interface MemberQRScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  gymId: string;
  memberId: string;
  onSuccess: (data: any) => void;
}

export default function MemberQRScannerModal({
  isOpen,
  onClose,
  gymId,
  memberId,
  onSuccess,
}: MemberQRScannerModalProps) {
  const [activeTab, setActiveTab] = useState<'camera' | 'gallery'>('camera');
  const [cameraState, setCameraState] = useState<'idle' | 'requesting' | 'active' | 'denied' | 'error'>('idle');
  const [cameraError, setCameraError] = useState<string | null>(null);
  
  const [verifying, setVerifying] = useState(false);
  const [scanResult, setScanResult] = useState<{ success: boolean; code?: string; message: string; details?: any } | null>(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const animFrameRef = useRef<number | null>(null);

  const stopCamera = () => {
    if (animFrameRef.current) {
      cancelAnimationFrame(animFrameRef.current);
      animFrameRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => {
        track.stop();
      });
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setCameraState('idle');
  };

  const verifyQrPayload = async (rawPayload: string) => {
    if (verifying) return;
    setVerifying(true);
    setScanResult(null);

    // Parse format first
    const parsed = parseAttendanceQrPayload(rawPayload);
    if (!parsed.validFormat) {
      setVerifying(false);
      setScanResult({
        success: false,
        code: 'INVALID_QR_FORMAT',
        message: SCAN_MESSAGES.INVALID_QR_FORMAT.message
      });
      return;
    }

    try {
      const res = await fetch('/api/attendance/checkin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          gymId,
          memberId,
          qrPayload: rawPayload,
          method: 'QR'
        })
      });
      const data = await res.json();
      if (data.success) {
        stopCamera();
        setScanResult({
          success: true,
          code: data.code || 'SCAN_SUCCESS',
          message: data.message || 'Attendance marked successfully!',
          details: data
        });
        onSuccess(data);
      } else {
        const errCode = data.code || 'ATTENDANCE_VERIFICATION_ERROR';
        const msgConfig = SCAN_MESSAGES[errCode] || { title: 'Error', message: data.message || 'Verification failed.' };
        setScanResult({
          success: false,
          code: errCode,
          message: msgConfig.message
        });
      }
    } catch (err) {
      console.error(err);
      setScanResult({
        success: false,
        code: 'NETWORK_ERROR',
        message: SCAN_MESSAGES.NETWORK_ERROR.message
      });
    } finally {
      setVerifying(false);
    }
  };

  const scanVideoFrame = () => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas || video.readyState !== video.HAVE_ENOUGH_DATA) {
      animFrameRef.current = requestAnimationFrame(scanVideoFrame);
      return;
    }

    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) {
      animFrameRef.current = requestAnimationFrame(scanVideoFrame);
      return;
    }

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const code = jsQR(imageData.data, imageData.width, imageData.height, {
      inversionAttempts: 'dontInvert'
    });

    if (code && code.data) {
      // Detected QR!
      verifyQrPayload(code.data);
      return; // Pause scanning while verifying
    }

    animFrameRef.current = requestAnimationFrame(scanVideoFrame);
  };

  const startCamera = async () => {
    stopCamera();
    setScanResult(null);
    setCameraState('requesting');
    setCameraError(null);

    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setCameraState('error');
      setCameraError('Camera API is not supported in this browser environment. Use Upload from Gallery instead.');
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } }
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
        setCameraState('active');
        animFrameRef.current = requestAnimationFrame(scanVideoFrame);
      }
    } catch (err: any) {
      console.error('Camera access error:', err);
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        setCameraState('denied');
        setCameraError('Camera access was blocked by your browser. Please grant camera permissions in your browser site settings, or use "Upload from Gallery".');
      } else {
        setCameraState('error');
        setCameraError(`Unable to open camera (${err.message || 'Device error'}). You can upload a QR image from your gallery instead.`);
      }
    }
  };

  useEffect(() => {
    if (isOpen && activeTab === 'camera') {
      startCamera();
    } else {
      stopCamera();
    }
    return () => {
      stopCamera();
    };
  }, [isOpen, activeTab]);

  const handleGalleryUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setScanResult(null);
    setVerifying(true);

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new window.Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          setVerifying(false);
          setScanResult({
            success: false,
            message: 'Unable to process image file.'
          });
          return;
        }
        ctx.drawImage(img, 0, 0);
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const code = jsQR(imageData.data, imageData.width, imageData.height);

        if (code && code.data) {
          setVerifying(false);
          verifyQrPayload(code.data);
        } else {
          setVerifying(false);
          setScanResult({
            success: false,
            code: 'NO_QR_FOUND',
            message: 'No QR code found in this image. Please upload a clear photo of the gym reception QR.'
          });
        }
      };
      img.onerror = () => {
        setVerifying(false);
        setScanResult({
          success: false,
          message: 'Failed to load selected image.'
        });
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleCloseModal = () => {
    stopCamera();
    setScanResult(null);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div className="bg-[var(--surface)] text-[var(--text)] w-full max-w-md rounded-[28px] border border-[var(--border)] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="px-5 py-4 border-b border-[var(--border)] flex items-center justify-between bg-[var(--surface-sec)]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[var(--text)] text-[var(--bg)] flex items-center justify-center font-black">
              <Camera size={18} />
            </div>
            <div>
              <h2 className="text-sm font-black uppercase tracking-wider">Gym QR Scanner</h2>
              <p className="text-[10px] text-[var(--text-sec)] font-mono uppercase">Instant Reception Check-In</p>
            </div>
          </div>
          <button
            onClick={handleCloseModal}
            className="p-2 rounded-xl neo-pressed text-[var(--text-sec)] hover:text-[var(--text)] cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Tab Selector */}
        <div className="p-3 bg-[var(--bg)] border-b border-[var(--border)] flex gap-2">
          <button
            onClick={() => { setActiveTab('camera'); setScanResult(null); }}
            className={`flex-1 py-2.5 px-3 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer transition-all ${
              activeTab === 'camera'
                ? 'bg-[var(--btn-bg)] text-[var(--btn-text)] shadow-sm'
                : 'neo-raised text-[var(--text-sec)]'
            }`}
          >
            <Camera size={15} /> Live Camera
          </button>
          <button
            onClick={() => { setActiveTab('gallery'); stopCamera(); setScanResult(null); }}
            className={`flex-1 py-2.5 px-3 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer transition-all ${
              activeTab === 'gallery'
                ? 'bg-[var(--btn-bg)] text-[var(--btn-text)] shadow-sm'
                : 'neo-raised text-[var(--text-sec)]'
            }`}
          >
            <Upload size={15} /> Gallery Upload
          </button>
        </div>

        {/* Content Area */}
        <div className="p-5 overflow-y-auto space-y-4 flex-1 flex flex-col justify-center">
          {/* Result Alert Box */}
          {scanResult && (
            <div className={`p-4 rounded-[20px] text-center space-y-2 border ${
              scanResult.success
                ? 'bg-[#34A853]/10 border-[#34A853]/40 text-[#34A853]'
                : 'bg-[#D64545]/10 border-[#D64545]/40 text-[#D64545]'
            }`}>
              <div className={`w-12 h-12 rounded-full mx-auto flex items-center justify-center ${
                scanResult.success ? 'bg-[#34A853] text-white' : 'bg-[#D64545] text-white'
              }`}>
                {scanResult.success ? <Check size={24} /> : <AlertCircle size={24} />}
              </div>
              <h3 className="text-sm font-black uppercase tracking-wider">
                {scanResult.success ? 'Attendance Marked!' : 'Scan Verification Error'}
              </h3>
              <p className="text-xs font-bold">{scanResult.message}</p>
              {scanResult.details?.time && (
                <div className="pt-2 border-t border-current/20 text-[10px] font-mono font-bold uppercase flex justify-center gap-3 text-current">
                  <span>Time: {scanResult.details.time}</span>
                  <span>Date: {scanResult.details.date}</span>
                </div>
              )}
              {!scanResult.success && activeTab === 'camera' && (
                <button
                  onClick={startCamera}
                  className="mt-2 px-4 py-1.5 rounded-xl bg-current text-white text-[10px] font-bold uppercase cursor-pointer"
                >
                  Try Scanning Again
                </button>
              )}
            </div>
          )}

          {activeTab === 'camera' && !scanResult?.success && (
            <div className="space-y-3">
              <div className="relative w-full aspect-square rounded-[24px] overflow-hidden bg-black flex items-center justify-center border-2 border-[var(--border)]">
                <video
                  ref={videoRef}
                  playsInline
                  muted
                  autoPlay
                  className="w-full h-full object-cover"
                />
                <canvas ref={canvasRef} className="hidden" />

                {cameraState === 'active' && (
                  <div className="absolute inset-0 pointer-events-none flex flex-col items-center justify-center">
                    <div className="w-56 h-56 border-2 border-dashed border-[#34A853] rounded-3xl animate-pulse flex items-center justify-center">
                      <div className="w-full h-0.5 bg-[#34A853]/80 animate-ping" />
                    </div>
                    <span className="mt-3 text-[10px] font-mono font-bold uppercase bg-black/70 text-white px-3 py-1 rounded-full backdrop-blur-sm">
                      Align QR inside frame
                    </span>
                  </div>
                )}

                {cameraState === 'requesting' && (
                  <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center text-white space-y-2 p-4 text-center">
                    <RefreshCw size={28} className="animate-spin text-emerald-400" />
                    <p className="text-xs font-bold uppercase tracking-wider">Starting Camera...</p>
                    <p className="text-[10px] text-neutral-400">Please grant camera permission if prompted</p>
                  </div>
                )}

                {(cameraState === 'denied' || cameraState === 'error') && (
                  <div className="absolute inset-0 bg-neutral-900/95 flex flex-col items-center justify-center text-white p-6 text-center space-y-3">
                    <ShieldAlert size={36} className="text-rose-500" />
                    <h4 className="text-xs font-black uppercase tracking-wider text-rose-400">Camera Access Denied</h4>
                    <p className="text-[11px] text-neutral-300 leading-relaxed font-medium">
                      {cameraError}
                    </p>
                    <button
                      onClick={startCamera}
                      className="px-4 py-2 bg-white text-black rounded-xl text-xs font-black uppercase tracking-wider cursor-pointer active:scale-95 transition-transform"
                    >
                      Retry Permission
                    </button>
                  </div>
                )}
              </div>

              {verifying && (
                <div className="p-3 bg-[var(--surface-sec)] rounded-xl text-center text-xs font-bold font-mono text-[var(--text)] animate-pulse uppercase tracking-wider">
                  ⏳ Verifying QR with server...
                </div>
              )}
            </div>
          )}

          {activeTab === 'gallery' && !scanResult?.success && (
            <div className="space-y-4 text-center py-4">
              <div className="p-8 rounded-[24px] neo-pressed border-2 border-dashed border-[var(--border)] space-y-3">
                <div className="w-16 h-16 rounded-2xl bg-[var(--surface)] text-[var(--text)] mx-auto flex items-center justify-center shadow-md">
                  <Image size={28} />
                </div>
                <div>
                  <h3 className="text-sm font-black uppercase tracking-wider">Upload QR Photo</h3>
                  <p className="text-[11px] text-[var(--text-sec)] font-medium mt-1">
                    Select a reception QR image from your device photo library
                  </p>
                </div>

                <label className="inline-flex h-12 px-6 rounded-[16px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-widest items-center justify-center gap-2 cursor-pointer shadow-md active:scale-95 transition-transform">
                  <Upload size={16} /> Select Photo From Gallery
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleGalleryUpload}
                  />
                </label>
              </div>

              {verifying && (
                <div className="p-3 bg-[var(--surface-sec)] rounded-xl text-center text-xs font-bold font-mono text-[var(--text)] animate-pulse uppercase tracking-wider">
                  🔍 Scanning image & verifying QR payload...
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
