import React, { useEffect, useState } from 'react';
import { useNavigate, useLocation, Link } from '@/lib/router-compat';
import { 
  Menu, User, QrCode, Users, IndianRupee, 
  LogOut, Home, Settings, Activity, Sun, Moon, Send, X, Dumbbell, Utensils, TrendingUp, HelpCircle, ShieldAlert, Bell, History
} from 'lucide-react';
import { signOutEverything, checkAccessState } from '@/lib/app-auth';
import NotificationCenter from './NotificationCenter';

export default function OwnerLayout({ children }: { children: React.ReactNode }) {
  const navigate = useNavigate();
  const location = useLocation();
  const [showDrawer, setShowDrawer] = useState(false);
  const [session, setSession] = useState<any>(null);
  const [gymDetails, setGymDetails] = useState<any>(null);
  const [theme, setTheme] = useState(localStorage.getItem('theme') || 'light');

  useEffect(() => {
    let active = true;
    (async () => {
      const stored = localStorage.getItem('gym_session');
      if (!stored) {
        if (active) navigate('/');
        return;
      }
      try {
        const parsed = JSON.parse(stored);
        if (active) setSession(parsed);

        // Fetch gym details if available
        if (parsed.gymId) {
          const res = await fetch(`/api/dashboard/${parsed.gymId}`);
          const data = await res.json();
          if (data && data.gym && active) {
            setGymDetails(data.gym);
          }
        }
      } catch (e) {
        if (active) navigate('/');
        return;
      }

      const access = await checkAccessState();
      if (!active) return;
      if (!access.allowed && access.code) {
        navigate(access.code === 'SESSION_EXPIRED' ? '/' : `/access-blocked?code=${access.code}`, { replace: true });
      }
    })();
    return () => { active = false; };
  }, [navigate]);

  useEffect(() => {
    if (theme === 'light') { 
       document.documentElement.classList.add('light'); 
       document.documentElement.classList.remove('dark');
    } else { 
       document.documentElement.classList.add('dark'); 
       document.documentElement.classList.remove('light');
    }
    localStorage.setItem('theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(theme === 'dark' ? 'light' : 'dark');
  };

  const handleLogout = () => {
    void signOutEverything();
  };

  if (!session) return null;

  const gymName = gymDetails?.gymName || session.gymName || "Apex Gym";
  const ownerName = gymDetails?.ownerName || session.memberName || "Gym Owner";

  const getPageTitle = () => {
    const p = location.pathname;
    if (p.includes('/members/add')) return 'Add Member';
    if (p.includes('/members/')) return 'Member Profile';
    if (p.includes('/members')) return 'Members Directory';
    if (p.includes('/attendance/qr')) return 'Daily QR Check-In';
    if (p.includes('/attendance')) return 'Attendance';
    if (p.includes('/workout')) return 'Workout Management';
    if (p.includes('/diet')) return 'Diet & Nutrition';
    if (p.includes('/tasks')) return 'Daily Workload Tasks';
    if (p.includes('/performance')) return 'Performance Analytics';
    if (p.includes('/payments')) return 'Payments & Revenue';
    if (p.includes('/broadcast')) return 'Broadcast Center';
    if (p.includes('/plans')) return 'Membership Plans';
    if (p.includes('/profile')) return 'Owner Profile & Settings';
    return 'Owner Dashboard';
  };

  return (
    <div className="min-h-screen bg-[var(--bg)] text-[var(--text)] relative overflow-x-hidden flex flex-col md:flex-row">
      {/* Top Header - Mobile & Desktop */}
      <header className="sticky top-0 z-30 bg-[var(--bg)]/90 backdrop-blur-md px-4 py-3 flex items-center justify-between border-b border-[var(--border)] w-full">
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setShowDrawer(true)} 
            className="p-2 -ml-1 rounded-xl neo-raised text-[var(--text)] hover:scale-105 active:scale-95 transition-transform cursor-pointer" 
            aria-label="Open navigation menu"
          >
            <Menu size={22} />
          </button>
          
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-[var(--text)] text-[var(--bg)] flex items-center justify-center font-black text-xs uppercase shadow-sm">
              {gymName.charAt(0)}
            </div>
            <div>
              <h1 className="text-xs font-black uppercase tracking-wider text-[var(--text)] line-clamp-1">{gymName}</h1>
              <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">{getPageTitle()}</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button 
            onClick={toggleTheme} 
            className="p-2 rounded-full neo-raised text-[var(--text-sec)] hover:text-[var(--text)] transition-colors cursor-pointer" 
            aria-label="Toggle theme"
          >
            {theme === 'dark' ? <Moon size={18} /> : <Sun size={18} />}
          </button>

          {session && session.gymId && (
            <NotificationCenter
              gymId={session.gymId}
              targetId={session.gymId}
              targetRole="owner"
            />
          )}

          <Link to="/owner/profile" className="flex items-center gap-2 p-1.5 pl-2 rounded-full neo-raised text-[var(--text)] hover:scale-105 transition-all">
            <div className="w-7 h-7 rounded-full bg-[#34A853]/10 text-[#34A853] font-bold flex items-center justify-center text-xs uppercase">
              {ownerName.charAt(0)}
            </div>
            <span className="hidden sm:inline text-[10px] font-black uppercase pr-2">{ownerName.split(' ')[0]}</span>
          </Link>
        </div>
      </header>

      {/* Side Drawer Menu - Mobile & Desktop */}
      {showDrawer && (
        <div className="fixed inset-0 z-50 flex animate-fade-in">
          <div 
            className="absolute inset-0 bg-black/60 backdrop-blur-sm" 
            onClick={() => setShowDrawer(false)}
          />

          <div className="relative w-80 max-w-[85vw] bg-[var(--bg)] border-r border-[var(--border)] h-full p-6 flex flex-col justify-between shadow-2xl overflow-y-auto">
            <div className="space-y-6">
              {/* Drawer Header */}
              <div className="flex justify-between items-center border-b border-[var(--border)] pb-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl clay-raised flex items-center justify-center bg-[var(--text)] text-[var(--bg)] font-black text-sm uppercase">
                    {gymName.charAt(0)}
                  </div>
                  <div>
                    <h2 className="text-sm font-black uppercase tracking-wider text-[var(--text)]">{gymName}</h2>
                    <span className="text-[9px] font-bold uppercase text-[var(--text-sec)] block">Owner Management</span>
                  </div>
                </div>

                <button 
                  onClick={() => setShowDrawer(false)}
                  className="p-2 rounded-xl neo-pressed text-[var(--text-sec)] hover:text-[var(--text)] cursor-pointer"
                >
                  <X size={20} />
                </button>
              </div>

              {/* Drawer Sections */}
              <nav className="space-y-6">
                {/* SECTION: MAIN */}
                <div className="space-y-1">
                  <span className="text-[9px] font-black uppercase tracking-widest text-[var(--text-sec)] px-3 block mb-1">MAIN</span>
                  <DrawerLink to="/owner/dashboard" icon={<Home size={18} />} label="Dashboard" onClick={() => setShowDrawer(false)} />
                  <DrawerLink to="/owner/members" icon={<Users size={18} />} label="Members Directory" onClick={() => setShowDrawer(false)} />
                  <DrawerLink to="/owner/attendance" icon={<Activity size={18} />} label="Attendance & QR" onClick={() => setShowDrawer(false)} />
                  <DrawerLink to="/owner/payments" icon={<IndianRupee size={18} />} label="Payments & Revenue" onClick={() => setShowDrawer(false)} />
                  <DrawerLink to="/owner/plans" icon={<Settings size={18} />} label="Membership Plans" onClick={() => setShowDrawer(false)} />
                </div>

                {/* SECTION: MANAGEMENT */}
                <div className="space-y-1">
                  <span className="text-[9px] font-black uppercase tracking-widest text-[var(--text-sec)] px-3 block mb-1">MANAGEMENT</span>
                  <DrawerLink to="/owner/records" icon={<History size={18} />} label="Records & History" onClick={() => setShowDrawer(false)} />
                  <DrawerLink to="/owner/workout" icon={<Dumbbell size={18} />} label="Workout Plans" onClick={() => setShowDrawer(false)} />
                  <DrawerLink to="/owner/broadcast" icon={<Send size={18} />} label="Broadcast Center" onClick={() => setShowDrawer(false)} />
                  <DrawerLink to="/owner/performance" icon={<TrendingUp size={18} />} label="Performance Analytics" onClick={() => setShowDrawer(false)} />
                  <DrawerLink to="/owner/tasks" icon={<ShieldAlert size={18} />} label="Daily Workload Tasks" onClick={() => setShowDrawer(false)} />
                </div>

                {/* SECTION: ACCOUNT */}
                <div className="space-y-1">
                  <span className="text-[9px] font-black uppercase tracking-widest text-[var(--text-sec)] px-3 block mb-1">ACCOUNT</span>
                  <DrawerLink to="/owner/profile" icon={<User size={18} />} label="Profile & Settings" onClick={() => setShowDrawer(false)} />
                  <DrawerLink to="/owner/profile?action=support" icon={<HelpCircle size={18} />} label="Support & Help" onClick={() => setShowDrawer(false)} />
                </div>
              </nav>
            </div>

            {/* Logout Button */}
            <div className="pt-6 border-t border-[var(--border)] mt-6">
              <button 
                onClick={handleLogout} 
                className="w-full h-11 rounded-[14px] bg-[#D64545]/10 text-[#D64545] font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer active:scale-95 transition-transform"
              >
                <LogOut size={16} /> Logout Owner
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Content Area - Full width, NO BOTTOM NAVIGATION */}
      <main className="flex-1 w-full max-w-5xl mx-auto p-4 md:p-8">
        {children}
      </main>
    </div>
  );
}

function DrawerLink({ to, icon, label, onClick }: { to: string; icon: React.ReactNode; label: string; onClick: () => void }) {
  const location = useLocation();
  const active = location.pathname === to || (to !== '/owner/dashboard' && location.pathname.startsWith(to));
  return (
    <Link 
      to={to} 
      onClick={onClick}
      className={`flex items-center gap-3 px-3.5 py-2.5 rounded-[14px] text-xs font-bold uppercase tracking-wider transition-all ${
        active 
          ? 'bg-[var(--text)] text-[var(--bg)] shadow-md font-black' 
          : 'text-[var(--text)] hover:bg-[var(--surface-sec)]'
      }`}
    >
      {icon}
      <span>{label}</span>
    </Link>
  );
}

