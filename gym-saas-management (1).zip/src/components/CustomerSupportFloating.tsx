import React from 'react';

export default function CustomerSupportFloating() {
  return null;
}
