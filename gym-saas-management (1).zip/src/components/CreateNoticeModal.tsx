import React, { useState, useEffect } from 'react';
import { X, Send, AlertTriangle, Users, Bell, Calendar, Check } from 'lucide-react';

interface CreateNoticeModalProps {
  gymId: string;
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: (notice: any) => void;
}

export default function CreateNoticeModal({
  gymId,
  isOpen,
  onClose,
  onSuccess
}: CreateNoticeModalProps) {
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [audience, setAudience] = useState<'ALL_ACTIVE' | 'SPECIFIC_MEMBERS' | 'PLAN_BASED'>('ALL_ACTIVE');
  const [priority, setPriority] = useState<'NORMAL' | 'HIGH' | 'URGENT'>('NORMAL');
  const [startDate, setStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [endDate, setEndDate] = useState('');

  const [members, setMembers] = useState<any[]>([]);
  const [plans, setPlans] = useState<any[]>([]);
  const [selectedMemberIds, setSelectedMemberIds] = useState<string[]>([]);
  const [selectedPlanIds, setSelectedPlanIds] = useState<string[]>([]);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen || !gymId) return;
    setError(null);
    setTitle('');
    setMessage('');
    setAudience('ALL_ACTIVE');
    setPriority('NORMAL');

    Promise.all([
      fetch(`/api/members/${gymId}`).then(r => r.json()),
      fetch(`/api/plans/public/${gymId}`).then(r => r.json())
    ]).then(([mRes, pRes]) => {
      if (mRes.success && mRes.members) setMembers(mRes.members.filter((m: any) => m.status === 'ACTIVE'));
      if (pRes.success && pRes.plans) setPlans(pRes.plans);
    }).catch(console.error);
  }, [isOpen, gymId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !message.trim()) {
      setError('Title and notice message are required.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const res = await fetch('/api/owner/notices/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          gymId,
          title: title.trim(),
          message: message.trim(),
          audience,
          targetIds: selectedMemberIds,
          targetPlanIds: selectedPlanIds,
          priority,
          startDate,
          endDate
        })
      });

      const data = await res.json();
      if (data.success) {
        if (onSuccess) onSuccess(data.notice);
        onClose();
      } else {
        setError(data.message || 'Failed to create notice.');
      }
    } catch (err) {
      console.error(err);
      setError('Network error creating notice.');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in">
      <div className="bg-[var(--surface)] text-[var(--text)] w-full max-w-lg rounded-[24px] border border-[var(--border)] shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-[var(--border)] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-[var(--text)] text-[var(--bg)] flex items-center justify-center font-black">
              <Bell size={18} />
            </div>
            <div>
              <h2 className="text-base font-black uppercase tracking-wider">Create Gym Notice</h2>
              <p className="text-[10px] text-[var(--text-sec)] uppercase tracking-wider">Gym Announcement Broadcast</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl neo-pressed text-[var(--text-sec)] hover:text-[var(--text)] cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Form Content */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-4 flex-1">
          {error && (
            <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-600 dark:text-red-400 text-xs font-bold">
              {error}
            </div>
          )}

          <div>
            <label className="text-[10px] font-black uppercase tracking-widest text-[var(--text-sec)] block mb-1">
              Notice Title *
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Gym Holiday Announcement / New Equipment Arrival"
              className="w-full px-3 py-2 rounded-xl bg-[var(--surface-sec)] border border-[var(--border)] text-xs font-bold text-[var(--text)] focus:outline-none focus:border-[var(--text)]"
            />
          </div>

          <div>
            <label className="text-[10px] font-black uppercase tracking-widest text-[var(--text-sec)] block mb-1">
              Notice Message *
            </label>
            <textarea
              required
              rows={3}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Write clear, official notice details for members..."
              className="w-full px-3 py-2 rounded-xl bg-[var(--surface-sec)] border border-[var(--border)] text-xs text-[var(--text)] focus:outline-none focus:border-[var(--text)] resize-none"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] font-black uppercase tracking-widest text-[var(--text-sec)] block mb-1">
                Target Audience
              </label>
              <select
                value={audience}
                onChange={(e: any) => setAudience(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-[var(--surface-sec)] border border-[var(--border)] text-xs font-bold text-[var(--text)] focus:outline-none focus:border-[var(--text)]"
              >
                <option value="ALL_ACTIVE">All Active Members</option>
                <option value="PLAN_BASED">Plan Specific Members</option>
                <option value="SPECIFIC_MEMBERS">Specific Members Only</option>
              </select>
            </div>

            <div>
              <label className="text-[10px] font-black uppercase tracking-widest text-[var(--text-sec)] block mb-1">
                Notice Priority
              </label>
              <select
                value={priority}
                onChange={(e: any) => setPriority(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-[var(--surface-sec)] border border-[var(--border)] text-xs font-bold text-[var(--text)] focus:outline-none focus:border-[var(--text)]"
              >
                <option value="NORMAL">Normal</option>
                <option value="HIGH">High Priority</option>
                <option value="URGENT">Urgent Announcement</option>
              </select>
            </div>
          </div>

          {audience === 'SPECIFIC_MEMBERS' && (
            <div>
              <label className="text-[10px] font-black uppercase tracking-widest text-[var(--text-sec)] block mb-1">
                Select Members ({selectedMemberIds.length} selected)
              </label>
              <div className="max-h-32 overflow-y-auto space-y-1 border border-[var(--border)] rounded-xl p-2 bg-[var(--bg)]">
                {members.map(m => (
                  <label key={m.id} className="flex items-center gap-2 p-1 text-xs cursor-pointer">
                    <input
                      type="checkbox"
                      checked={selectedMemberIds.includes(m.id)}
                      onChange={(e) => {
                        if (e.target.checked) setSelectedMemberIds([...selectedMemberIds, m.id]);
                        else setSelectedMemberIds(selectedMemberIds.filter(id => id !== m.id));
                      }}
                      className="rounded"
                    />
                    <span>{m.fullName} ({m.memberDisplayId || m.id})</span>
                  </label>
                ))}
              </div>
            </div>
          )}

          {audience === 'PLAN_BASED' && (
            <div>
              <label className="text-[10px] font-black uppercase tracking-widest text-[var(--text-sec)] block mb-1">
                Select Membership Plans ({selectedPlanIds.length} selected)
              </label>
              <div className="max-h-32 overflow-y-auto space-y-1 border border-[var(--border)] rounded-xl p-2 bg-[var(--bg)]">
                {plans.map(p => (
                  <label key={p.id} className="flex items-center gap-2 p-1 text-xs cursor-pointer">
                    <input
                      type="checkbox"
                      checked={selectedPlanIds.includes(p.id)}
                      onChange={(e) => {
                        if (e.target.checked) setSelectedPlanIds([...selectedPlanIds, p.id]);
                        else setSelectedPlanIds(selectedPlanIds.filter(id => id !== p.id));
                      }}
                      className="rounded"
                    />
                    <span>{p.planName} (₹{p.price})</span>
                  </label>
                ))}
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] font-black uppercase tracking-widest text-[var(--text-sec)] block mb-1">
                Start Date
              </label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-[var(--surface-sec)] border border-[var(--border)] text-xs text-[var(--text)] focus:outline-none"
              />
            </div>
            <div>
              <label className="text-[10px] font-black uppercase tracking-widest text-[var(--text-sec)] block mb-1">
                End Date (Optional)
              </label>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-[var(--surface-sec)] border border-[var(--border)] text-xs text-[var(--text)] focus:outline-none"
              />
            </div>
          </div>

          <div className="pt-2 flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl neo-raised text-xs font-bold uppercase cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-5 py-2.5 rounded-xl bg-[var(--text)] text-[var(--bg)] text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer shadow-md hover:scale-105 active:scale-95 transition-transform disabled:opacity-50"
            >
              <Send size={14} /> {loading ? 'Publishing...' : 'Publish Notice'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
