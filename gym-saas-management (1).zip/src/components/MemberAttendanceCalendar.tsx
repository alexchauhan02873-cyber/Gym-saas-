import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Flame, Clock } from 'lucide-react';

interface AttendanceRecord {
  id?: string;
  date: string;
  status: 'Present' | 'Absent' | string;
  checkIn?: string;
  checkOut?: string;
  method?: string;
}

interface MemberAttendanceCalendarProps {
  attendanceRecords: AttendanceRecord[];
  currentStreak?: number;
  bestStreak?: number;
  lastVisit?: string;
  memberName?: string;
}

export default function MemberAttendanceCalendar({
  attendanceRecords = [],
  currentStreak = 0,
  bestStreak = 0,
  lastVisit = 'Never',
  memberName = 'Member'
}: MemberAttendanceCalendarProps) {
  const [currentDate, setCurrentDate] = useState<Date>(new Date());
  const [selectedDayRecord, setSelectedDayRecord] = useState<{ dateStr: string; record?: AttendanceRecord } | null>(null);

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const firstDayIndex = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  const handlePrevMonth = () => {
    setCurrentDate(new Date(year, month - 1, 1));
    setSelectedDayRecord(null);
  };

  const handleNextMonth = () => {
    setCurrentDate(new Date(year, month + 1, 1));
    setSelectedDayRecord(null);
  };

  const monthKey = `${year}-${String(month + 1).padStart(2, '0')}`;
  const todayStr = new Date().toISOString().split('T')[0];

  const monthRecords = attendanceRecords.filter(r => r.date && r.date.startsWith(monthKey));
  const presentCount = monthRecords.filter(r => r.status === 'Present').length;
  const absentCount = monthRecords.filter(r => r.status === 'Absent').length;

  const isCurrentMonth = todayStr.startsWith(monthKey);
  const currentDayNumber = isCurrentMonth ? new Date().getDate() : daysInMonth;
  const eligibleDays = isCurrentMonth ? currentDayNumber : daysInMonth;
  const attendancePercentage = eligibleDays > 0 ? Math.round((presentCount / eligibleDays) * 100) : 0;

  const recordMap: Record<string, AttendanceRecord> = {};
  attendanceRecords.forEach(r => {
    if (r.date) {
      recordMap[r.date] = r;
    }
  });

  const calendarCells = [];
  for (let i = 0; i < firstDayIndex; i++) {
    calendarCells.push(null);
  }
  for (let day = 1; day <= daysInMonth; day++) {
    const dayStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    calendarCells.push(dayStr);
  }

  return (
    <div className="neo-raised p-6 rounded-[24px] space-y-6">
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3 neo-pressed rounded-[16px]">
          <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Attendance</span>
          <span className="text-xl font-black font-mono text-[#34A853]">{attendancePercentage}%</span>
          <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block mt-0.5">
            {presentCount} / {eligibleDays} Days
          </span>
        </div>
        <div className="p-3 neo-pressed rounded-[16px]">
          <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Streak</span>
          <div className="flex items-center gap-1.5 mt-0.5">
            <Flame size={16} className="text-[#EA4335]" />
            <span className="text-xl font-black font-mono text-[var(--text)]">{currentStreak} Days</span>
          </div>
          <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block mt-0.5">
            Best: {bestStreak} Days
          </span>
        </div>
        <div className="p-3 neo-pressed rounded-[16px]">
          <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Present / Absent</span>
          <div className="flex items-center gap-2 mt-1 font-mono font-bold text-xs">
            <span className="text-[#34A853]">{presentCount} Present</span>
            <span className="text-[var(--text-sec)]">•</span>
            <span className="text-[#D64545]">{absentCount} Absent</span>
          </div>
        </div>
        <div className="p-3 neo-pressed rounded-[16px]">
          <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">Last Visit</span>
          <div className="flex items-center gap-1 mt-1 font-mono text-xs font-bold text-[var(--text)]">
            <Clock size={14} className="text-[var(--text-sec)]" />
            <span>{lastVisit}</span>
          </div>
        </div>
      </div>

      <div className="flex justify-between items-center border-t border-[var(--border)] pt-4">
        <button
          onClick={handlePrevMonth}
          className="w-9 h-9 rounded-full neo-raised flex items-center justify-center text-[var(--text)] active:scale-95 transition-transform cursor-pointer"
        >
          <ChevronLeft size={18} />
        </button>
        <div className="text-center">
          <h3 className="text-sm font-black uppercase tracking-wider text-[var(--text)]">
            {monthNames[month]} {year}
          </h3>
          <p className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)]">
            {memberName}'s Attendance Log
          </p>
        </div>
        <button
          onClick={handleNextMonth}
          className="w-9 h-9 rounded-full neo-raised flex items-center justify-center text-[var(--text)] active:scale-95 transition-transform cursor-pointer"
        >
          <ChevronRight size={18} />
        </button>
      </div>

      <div className="grid grid-cols-7 text-center font-black text-[9px] uppercase tracking-widest text-[var(--text-sec)]">
        <span>Sun</span>
        <span>Mon</span>
        <span>Tue</span>
        <span>Wed</span>
        <span>Thu</span>
        <span>Fri</span>
        <span>Sat</span>
      </div>

      <div className="grid grid-cols-7 gap-1.5">
        {calendarCells.map((dayStr, idx) => {
          if (!dayStr) {
            return <div key={`empty-${idx}`} className="h-10 sm:h-12 rounded-[12px]" />;
          }
          const dayNumber = parseInt(dayStr.split('-')[2], 10);
          const record = recordMap[dayStr];
          const isToday = dayStr === todayStr;
          const isFuture = dayStr > todayStr;
          const isPresent = record && record.status === 'Present';
          const isAbsent = record && record.status === 'Absent';

          return (
            <button
              key={dayStr}
              onClick={() => setSelectedDayRecord({ dateStr: dayStr, record })}
              disabled={isFuture}
              className={`h-10 sm:h-12 rounded-[12px] flex flex-col items-center justify-center transition-all relative font-mono text-xs font-bold cursor-pointer ${
                isFuture
                  ? 'opacity-30 cursor-not-allowed bg-[var(--surface-sec)] text-[var(--text-sec)]'
                  : isPresent
                  ? 'bg-[#34A853]/20 border border-[#34A853] text-[#34A853] shadow-sm active:scale-95'
                  : isAbsent
                  ? 'bg-[#D64545]/20 border border-[#D64545] text-[#D64545] active:scale-95'
                  : 'neo-pressed text-[var(--text-sec)] hover:border hover:border-[var(--border)]'
              } ${isToday ? 'ring-2 ring-[#4285F4]' : ''}`}
            >
              <span>{dayNumber}</span>
              {isPresent && <span className="text-[9px] leading-none font-black">✓</span>}
              {isAbsent && <span className="text-[9px] leading-none font-black">✕</span>}
            </button>
          );
        })}
      </div>

      {selectedDayRecord && (
        <div className="p-4 rounded-[18px] neo-pressed border border-[var(--border)] flex justify-between items-center animate-fade-in">
          <div>
            <span className="text-[9px] font-bold uppercase tracking-widest text-[var(--text-sec)] block">
              {new Date(selectedDayRecord.dateStr).toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
            </span>
            <div className="flex items-center gap-2 mt-1">
              <span className={`text-xs font-black uppercase px-2 py-0.5 rounded-md ${
                selectedDayRecord.record?.status === 'Present'
                  ? 'bg-[#34A853] text-white'
                  : selectedDayRecord.record?.status === 'Absent'
                  ? 'bg-[#D64545] text-white'
                  : 'bg-[var(--surface-sec)] text-[var(--text-sec)]'
              }`}>
                {selectedDayRecord.record?.status || 'No Attendance Record'}
              </span>
              {selectedDayRecord.record?.checkIn && (
                <span className="text-xs font-mono text-[var(--text)]">
                  In: {selectedDayRecord.record.checkIn} {selectedDayRecord.record.checkOut ? `• Out: ${selectedDayRecord.record.checkOut}` : ''}
                </span>
              )}
            </div>
          </div>
          <button
            onClick={() => setSelectedDayRecord(null)}
            className="text-xs font-bold text-[var(--text-sec)] hover:text-[var(--text)] px-2 py-1 cursor-pointer"
          >
            Close
          </button>
        </div>
      )}
    </div>
  );
}
