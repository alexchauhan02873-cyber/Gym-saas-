import React, { useState, useEffect } from 'react';
import { Bell, Check, X, Sparkles, Trophy, Calendar, CreditCard, Dumbbell, Utensils } from 'lucide-react';

interface NotificationItem {
  id: string;
  gymId: string;
  title: string;
  body: string;
  url?: string;
  type?: string;
  read: boolean;
  createdAt: string;
}

interface NotificationCenterProps {
  gymId: string;
  targetId: string;
  targetRole: 'member' | 'owner';
}

export default function NotificationCenter({ gymId, targetId, targetRole }: NotificationCenterProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [activeTab, setActiveTab] = useState<string>('ALL');
  const [pushStatus, setPushStatus] = useState<'default' | 'granted' | 'denied' | 'unsupported'>('default');
  const [promptBannerVisible, setPromptBannerVisible] = useState(false);

  useEffect(() => {
    if (!('Notification' in window) || !('serviceWorker' in navigator)) {
      setPushStatus('unsupported');
    } else {
      setPushStatus(Notification.permission as any);
      if (Notification.permission === 'default') {
        setPromptBannerVisible(true);
      }
    }
  }, []);

  const fetchNotifications = async () => {
    if (!gymId || gymId === 'undefined' || gymId === 'null') return;
    if (targetRole !== 'owner' && (!targetId || targetId === 'undefined' || targetId === 'null')) return;

    const endpoint = targetRole === 'owner'
      ? `/api/notifications/owner/${gymId}`
      : `/api/notifications/${gymId}/${targetId}`;

    try {
      const res = await fetch(endpoint);
      if (!res.ok) return;
      const data = await res.json();
      if (data && data.success && Array.isArray(data.notifications)) {
        setNotifications(data.notifications);
      }
    } catch (err) {
      // Quietly handle network or dev server restart blips without throwing unhandled exceptions
      console.warn('Notification update currently unavailable');
    }
  };

  useEffect(() => {
    fetchNotifications();
    const interval = setInterval(fetchNotifications, 15000);
    return () => clearInterval(interval);
  }, [gymId, targetId, targetRole]);

  const handleEnablePush = async () => {
    if (!('Notification' in window) || !('serviceWorker' in navigator)) return;
    try {
      const permission = await Notification.requestPermission();
      setPushStatus(permission as any);
      if (permission === 'granted') {
        setPromptBannerVisible(false);
        const keyRes = await fetch('/api/notifications/vapid-public-key');
        const keyData = await keyRes.json();
        if (!keyData.publicKey) return;
        const registration = await navigator.serviceWorker.ready;
        let sub = await registration.pushManager.getSubscription();
        if (!sub) {
          sub = await registration.pushManager.subscribe({
            userVisibleOnly: true,
            applicationServerKey: urlBase64ToUint8Array(keyData.publicKey)
          });
        }
        await fetch('/api/notifications/subscribe', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            subscription: sub,
            targetRole,
            targetId,
            gymId
          })
        });
      }
    } catch (e) {
      console.error('Push Subscription error:', e);
    }
  };

  const handleMarkAllRead = async () => {
    try {
      await fetch('/api/notifications/mark-all-read', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ targetRole, targetId })
      });
      setNotifications(prev => prev.map(n => ({ ...n, read: true })));
    } catch (e) {
      console.error(e);
    }
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  const filteredNotifs = notifications.filter(n => {
    if (activeTab === 'ALL') return true;
    if (activeTab === 'UNREAD') return !n.read;
    return (n.type || '').toUpperCase() === activeTab;
  });

  const getNotifIcon = (type?: string) => {
    switch ((type || '').toUpperCase()) {
      case 'WORKOUT': return <Dumbbell size={16} className="text-[var(--text)]" />;
      case 'DIET': return <Utensils size={16} className="text-[var(--text)]" />;
      case 'ATTENDANCE': return <Calendar size={16} className="text-[#34A853]" />;
      case 'PAYMENT': return <CreditCard size={16} className="text-[var(--text)]" />;
      case 'GAMIFICATION': return <Trophy size={16} className="text-[#FBBC05]" />;
      default: return <Sparkles size={16} className="text-[var(--text-sec)]" />;
    }
  };

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className="relative p-2.5 rounded-[14px] neo-raised text-[var(--text)] hover:scale-105 active:scale-95 transition-transform cursor-pointer"
        aria-label="Notifications"
      >
        <Bell size={20} />
        {unreadCount > 0 && (
          <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-[#D64545] text-white font-black text-[10px] flex items-center justify-center animate-pulse border-2 border-[var(--bg)]">
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </button>

      {isOpen && (
        <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-sm animate-fade-in">
          <div className="bg-[var(--surface)] w-full max-w-md h-full p-6 neo-raised flex flex-col justify-between overflow-y-auto">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <div className="p-2 neo-pressed rounded-xl">
                    <Bell size={18} />
                  </div>
                  <div>
                    <h2 className="text-base font-black uppercase tracking-wider">Notifications</h2>
                    <p className="text-[10px] font-bold text-[var(--text-sec)] uppercase tracking-widest">
                      {unreadCount} unread update{unreadCount === 1 ? '' : 's'}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {unreadCount > 0 && (
                    <button
                      onClick={handleMarkAllRead}
                      className="px-2.5 py-1 rounded-[10px] neo-pressed text-[10px] font-bold uppercase tracking-wider text-[var(--text-sec)] hover:text-[var(--text)] transition-colors cursor-pointer"
                    >
                      Read All
                    </button>
                  )}
                  <button
                    onClick={() => setIsOpen(false)}
                    className="p-2 neo-pressed rounded-xl text-[var(--text-sec)] hover:text-[var(--text)] transition-colors cursor-pointer"
                  >
                    <X size={18} />
                  </button>
                </div>
              </div>

              {pushStatus === 'default' && promptBannerVisible && (
                <div className="neo-pressed p-4 rounded-[18px] bg-gradient-to-r from-neutral-900 to-neutral-950 text-white space-y-3">
                  <div className="flex items-start gap-3">
                    <div className="p-2 rounded-xl bg-white/10 shrink-0">
                      <Sparkles size={18} />
                    </div>
                    <div>
                      <h4 className="text-xs font-black uppercase tracking-wider">Enable Push Notifications</h4>
                      <p className="text-[11px] text-neutral-300 font-medium mt-0.5">
                        Get instant reminders for workouts, attendance streaks, payments, and gym announcements.
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-2 pt-1">
                    <button
                      onClick={() => setPromptBannerVisible(false)}
                      className="w-1/2 py-2 rounded-[10px] bg-white/10 text-xs font-bold uppercase tracking-wider hover:bg-white/20 transition-colors cursor-pointer"
                    >
                      Later
                    </button>
                    <button
                      onClick={handleEnablePush}
                      className="w-1/2 py-2 rounded-[10px] bg-white text-black text-xs font-black uppercase tracking-wider hover:bg-neutral-200 transition-colors flex items-center justify-center gap-1 cursor-pointer"
                    >
                      Enable <Check size={14} />
                    </button>
                  </div>
                </div>
              )}

              <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none">
                {['ALL', 'UNREAD', 'WORKOUT', 'ATTENDANCE', 'PAYMENT'].map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`px-3 py-1.5 rounded-[12px] text-[10px] font-black uppercase tracking-wider shrink-0 transition-all cursor-pointer ${
                      activeTab === tab
                        ? 'bg-[var(--btn-bg)] text-[var(--btn-text)] shadow-sm'
                        : 'neo-pressed text-[var(--text-sec)] hover:text-[var(--text)]'
                    }`}
                  >
                    {tab}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex-1 overflow-y-auto my-4 space-y-3 pr-1">
              {filteredNotifs.length > 0 ? (
                filteredNotifs.map((n) => (
                  <div
                    key={n.id}
                    className={`p-4 rounded-[18px] neo-raised transition-all relative flex items-start gap-3 ${
                      !n.read ? 'border-l-4 border-l-[var(--text)]' : 'opacity-70'
                    }`}
                  >
                    <div className="p-2.5 neo-pressed rounded-xl shrink-0 mt-0.5">
                      {getNotifIcon(n.type)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <h4 className="text-xs font-bold text-[var(--text)] truncate">{n.title}</h4>
                        <span className="text-[9px] font-bold text-[var(--text-sec)] shrink-0">
                          {formatTime(n.createdAt)}
                        </span>
                      </div>
                      <p className="text-[11px] text-[var(--text-sec)] font-medium mt-1 leading-relaxed">
                        {n.body}
                      </p>
                    </div>
                  </div>
                ))
              ) : (
                <div className="h-48 neo-pressed rounded-[20px] flex flex-col items-center justify-center p-6 text-center space-y-2">
                  <Bell size={28} className="text-[var(--text-sec)] opacity-40" />
                  <p className="text-xs font-bold uppercase tracking-wider text-[var(--text-sec)]">
                    No notifications yet
                  </p>
                </div>
              )}
            </div>

            <div className="pt-3 border-t border-[var(--border)]">
              <button
                onClick={() => setIsOpen(false)}
                className="w-full h-11 rounded-[14px] neo-pressed text-xs font-bold uppercase tracking-widest text-[var(--text)] cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

function urlBase64ToUint8Array(base64String: string) {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

function formatTime(isoStr: string) {
  if (!isoStr) return '';
  const date = new Date(isoStr);
  const diffMins = Math.round((Date.now() - date.getTime()) / (1000 * 60));
  if (diffMins < 1) return 'Just now';
  if (diffMins < 60) return `${diffMins}m ago`;
  const diffHours = Math.round(diffMins / 60);
  if (diffHours < 24) return `${diffHours}h ago`;
  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}
