import React, { useEffect, useState } from 'react';
import { 
  CheckCircle, AlertCircle, Sparkles, X, ArrowRight, Clock,
  RefreshCw
} from 'lucide-react';

export const motionTokens = {
  duration: {
    fast: '150ms',
    normal: '250ms',
    success: '500ms',
    page: '300ms',
  },
  easing: 'cubic-bezier(0.16, 1, 0.3, 1)',
};

export interface AnimatedButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  loading?: boolean;
  success?: boolean;
  successText?: string;
  variant?: 'primary' | 'secondary' | 'outline' | 'danger' | 'success';
  children: React.ReactNode;
  className?: string;
  disabled?: boolean;
  onClick?: (e: React.MouseEvent<HTMLButtonElement>) => void;
}

export function AnimatedButton({
  loading = false,
  success = false,
  successText = 'Done!',
  variant = 'primary',
  children,
  className = '',
  disabled,
  ...props
}: AnimatedButtonProps) {
  const baseClasses = "relative px-5 py-3 rounded-[16px] text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 transition-all duration-200 active:scale-95 disabled:opacity-50 disabled:pointer-events-none select-none";
  
  const variantClasses = {
    primary: "bg-[var(--btn-bg)] text-[var(--btn-text)] shadow-md hover:opacity-95",
    secondary: "neo-raised text-[var(--text)] hover:bg-[var(--surface-sec)]",
    outline: "border-2 border-[var(--border)] text-[var(--text)] hover:bg-[var(--surface-sec)]",
    danger: "bg-[#D64545] text-white shadow-md hover:bg-[#c33d3d]",
    success: "bg-[#34A853] text-white shadow-md hover:bg-[#2d9648]",
  };

  return (
    <button
      className={`${baseClasses} ${variantClasses[variant]} ${className}`}
      disabled={loading || success || disabled}
      {...props}
    >
      {loading ? (
        <span className="flex items-center gap-2">
          <RefreshCw size={16} className="animate-spin" />
          Processing...
        </span>
      ) : success ? (
        <span className="flex items-center gap-2 text-white animate-fade-in">
          <CheckCircle size={16} className="animate-bounce" />
          {successText}
        </span>
      ) : (
        children
      )}
    </button>
  );
}

export function SuccessCheck({ className = '' }: { size?: number; className?: string }) {
  return (
    <div className={`relative inline-flex items-center justify-center ${className}`}>
      <div className="absolute inset-0 rounded-full bg-[#34A853]/20 animate-ping opacity-75" />
      <div className="w-12 h-12 rounded-full bg-[#34A853] text-white flex items-center justify-center shadow-lg transform transition-all duration-300 scale-100">
        <svg className="w-6 h-6 stroke-current stroke-[3]" viewBox="0 0 24 24" fill="none">
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="M5 13l4 4L19 7"
            className="animate-draw-check"
          />
        </svg>
      </div>
    </div>
  );
}

interface AnimatedModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  children: React.ReactNode;
}

export function AnimatedModal({ isOpen, onClose, title, subtitle, children }: AnimatedModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md animate-fade-in">
      <div 
        className="w-full max-w-lg bg-[var(--bg)] p-6 sm:p-8 rounded-[28px] neo-raised border border-[var(--border)] shadow-2xl space-y-6 max-h-[90vh] overflow-y-auto animate-scale-up"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex justify-between items-start border-b border-[var(--border)] pb-4">
          <div>
            <h2 className="text-lg font-black uppercase tracking-wider text-[var(--text)]">{title}</h2>
            {subtitle && (
              <p className="text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] mt-1">{subtitle}</p>
            )}
          </div>
          <button 
            onClick={onClose}
            className="w-8 h-8 rounded-full neo-pressed flex items-center justify-center text-[var(--text-sec)] hover:text-[var(--text)] transition-colors active:scale-90"
          >
            <X size={18} />
          </button>
        </div>
        <div>{children}</div>
      </div>
    </div>
  );
}

export function AnimatedToast({ message, type = 'success', onClose }: { message: string; type?: 'success' | 'error' | 'info'; onClose: () => void }) {
  useEffect(() => {
    const timer = setTimeout(onClose, 4000);
    return () => clearTimeout(timer);
  }, [onClose]);

  const bgColors = {
    success: 'bg-[var(--text)] text-[var(--bg)] border-[#34A853]/40',
    error: 'bg-[#D64545] text-white border-red-700',
    info: 'bg-[#4285F4] text-white border-blue-700'
  };

  return (
    <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50 px-6 py-3.5 rounded-full text-xs font-bold uppercase tracking-widest shadow-2xl border flex items-center gap-3 animate-slide-down">
      <span className={`p-1 rounded-full ${bgColors[type]}`}>
        {type === 'success' && <Sparkles size={16} />}
        {type === 'error' && <AlertCircle size={16} />}
        {type === 'info' && <Clock size={16} />}
      </span>
      <span>{message}</span>
      <button onClick={onClose} className="ml-2 opacity-80 hover:opacity-100">
        <X size={14} />
      </button>
    </div>
  );
}

export function SkeletonLoader({ className = 'h-16 w-full' }: { className?: string }) {
  return (
    <div className={`neo-pressed rounded-[18px] animate-pulse bg-gradient-to-r from-[var(--surface)] via-[var(--surface-sec)] to-[var(--surface)] ${className}`} />
  );
}

interface TaskDetailModalProps {
  task: any;
  isOpen: boolean;
  onClose: () => void;
  onAction: (task: any) => void;
  onDismiss: (taskId: string) => void;
}

export function TaskDetailModal({ task, isOpen, onClose, onAction, onDismiss }: TaskDetailModalProps) {
  const [confirmDismiss, setConfirmDismiss] = useState(false);

  if (!isOpen || !task) return null;

  return (
    <AnimatedModal
      isOpen={isOpen}
      onClose={onClose}
      title={task.title}
      subtitle={`Priority: ${task.priority} • Type: ${task.taskType || 'SYSTEM_ACTION'}`}
    >
      <div className="space-y-6">
        <div className="p-4 rounded-[20px] neo-pressed space-y-2">
          <div className="flex justify-between items-center">
            <span className={`text-[9px] font-black uppercase px-2.5 py-1 rounded-full ${
              task.priority === 'URGENT' ? 'bg-[#D64545] text-white' :
              task.priority === 'HIGH' ? 'bg-[#EA4335] text-white' :
              'bg-[var(--surface-sec)] text-[var(--text-sec)]'
            }`}>
              {task.priority} PRIORITY
            </span>
            <span className="text-[10px] font-mono text-[var(--text-sec)]">
              {task.taskDate ? `Date: ${task.taskDate}` : 'Today'}
            </span>
          </div>
          <p className="text-xs font-semibold text-[var(--text)] leading-relaxed">
            {task.description}
          </p>
        </div>

        <div className="p-4 rounded-[18px] bg-[#34A853]/10 border border-[#34A853]/20 text-[11px] font-bold text-[var(--text)] flex items-start gap-3">
          <Sparkles size={18} className="text-[#34A853] shrink-0 mt-0.5" />
          <div>
            <p className="text-[10px] uppercase tracking-widest text-[#34A853] font-black">Workflow Action</p>
            <p className="mt-0.5 text-[var(--text-sec)]">
              Executing below will take you directly to the action page. The task marks DONE upon completion.
            </p>
          </div>
        </div>

        <div className="space-y-3 pt-2">
          <button
            onClick={() => {
              onClose();
              onAction(task);
            }}
            className="w-full py-4 rounded-[18px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 active:scale-98 transition-transform shadow-lg cursor-pointer"
          >
            <span>{task.actionText || 'Execute Workflow'}</span>
            <ArrowRight size={16} />
          </button>

          {!confirmDismiss ? (
            <button
              onClick={() => setConfirmDismiss(true)}
              className="w-full py-2.5 neo-raised rounded-[14px] text-[10px] font-bold uppercase tracking-widest text-[var(--text-sec)] hover:text-[#D64545] transition-colors cursor-pointer"
            >
              Dismiss Task
            </button>
          ) : (
            <div className="p-3 neo-pressed rounded-[16px] text-center space-y-2 animate-fade-in">
              <p className="text-[10px] uppercase tracking-widest text-[#D64545] font-bold">
                Dismiss this task?
              </p>
              <div className="flex gap-2">
                <button
                  onClick={() => {
                    onDismiss(task.id);
                    onClose();
                  }}
                  className="flex-1 py-2 bg-[#D64545] text-white rounded-[12px] text-[10px] font-bold uppercase tracking-wider cursor-pointer"
                >
                  Confirm Dismiss
                </button>
                <button
                  onClick={() => setConfirmDismiss(false)}
                  className="flex-1 py-2 neo-raised rounded-[12px] text-[10px] font-bold uppercase tracking-wider text-[var(--text)] cursor-pointer"
                >
                  Keep Task
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </AnimatedModal>
  );
}
