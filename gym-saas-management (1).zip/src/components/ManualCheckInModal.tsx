import React, { useState, useEffect } from 'react';
import { X, Calendar, Search, Check, AlertCircle, Clock, UserCheck, ShieldAlert, Dumbbell } from 'lucide-react';

interface ManualCheckInModalProps {
  gymId: string;
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: (attendanceRecord: any) => void;
  preselectedMemberId?: string;
}

export default function ManualCheckInModal({
  gymId,
  isOpen,
  onClose,
  onSuccess,
  preselectedMemberId
}: ManualCheckInModalProps) {
  const [members, setMembers] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedMember, setSelectedMember] = useState<any | null>(null);

  const [loading, setLoading] = useState(false);
  const [fetchingMembers, setFetchingMembers] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [checkInResult, setCheckInResult] = useState<any | null>(null);

  useEffect(() => {
    if (!isOpen || !gymId) return;
    setFetchingMembers(true);
    setError(null);
    setCheckInResult(null);
    setSelectedMember(null);

    fetch(`/api/members/${gymId}`)
      .then(res => res.json())
      .then(data => {
        if (data.success && data.members) {
          const validMembers = data.members.filter((m: any) => m.status !== 'ARCHIVED');
          setMembers(validMembers);
          if (preselectedMemberId) {
            const match = validMembers.find((m: any) => m.id === preselectedMemberId);
            if (match) setSelectedMember(match);
          }
        }
      })
      .catch(err => {
        console.error(err);
        setError('Failed to load gym members list.');
      })
      .finally(() => setFetchingMembers(false));
  }, [isOpen, gymId, preselectedMemberId]);

  const filteredMembers = members.filter(m =>
    m.fullName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    m.phone?.includes(searchQuery) ||
    m.memberDisplayId?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    m.id?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const nowKolkata = new Date().toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
    timeZone: 'Asia/Kolkata'
  });
  const todayKolkata = new Date().toISOString().split('T')[0];

  const executeCheckIn = async (member: any) => {
    setLoading(true);
    setError(null);
    setCheckInResult(null);

    try {
      const res = await fetch(`/api/attendance/${gymId}/manual`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          memberId: member.id,
          method: 'MANUAL'
        })
      });
      const data = await res.json();
      if (data.success) {
        setCheckInResult(data);
        if (onSuccess) onSuccess(data.attendance || data);
      } else if (data.alreadyCheckedIn || data.code === 'ALREADY_CHECKED_IN') {
        setCheckInResult({
          alreadyCheckedIn: true,
          checkInTime: data.checkInTime || 'Recorded',
          memberName: member.fullName,
          date: todayKolkata
        });
      } else {
        setError(data.message || 'Check-in failed due to verification restrictions.');
      }
    } catch (err) {
      console.error(err);
      setError('Network error during manual check-in.');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fade-in">
      <div className="bg-[var(--surface)] text-[var(--text)] w-full max-w-lg rounded-[28px] border border-[var(--border)] shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-[var(--border)] flex items-center justify-between bg-[var(--surface-sec)]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[var(--btn-bg)] text-[var(--btn-text)] flex items-center justify-center font-black">
              <UserCheck size={20} />
            </div>
            <div>
              <h2 className="text-base font-black uppercase tracking-wider">Manual Attendance Check-In</h2>
              <p className="text-[10px] text-[var(--text-sec)] font-mono uppercase tracking-wider">Reception Check-in Override</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl neo-pressed text-[var(--text-sec)] hover:text-[var(--text)] cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1">
          {error && (
            <div className="p-4 rounded-[16px] bg-[#D64545]/10 border border-[#D64545]/30 text-[#D64545] text-xs font-bold flex items-start gap-2.5">
              <AlertCircle size={18} className="shrink-0 mt-0.5" />
              <div>
                <span className="block uppercase text-[10px] tracking-wider font-black">Check-In Denied</span>
                <span>{error}</span>
              </div>
            </div>
          )}

          {checkInResult ? (
            <div className={`p-6 rounded-[22px] text-center space-y-4 ${
              checkInResult.alreadyCheckedIn 
                ? 'bg-amber-500/10 border border-amber-500/30 text-amber-600 dark:text-amber-400' 
                : 'bg-[#34A853]/10 border border-[#34A853]/30 text-[#34A853]'
            }`}>
              <div className={`w-14 h-14 rounded-full mx-auto flex items-center justify-center shadow-lg ${
                checkInResult.alreadyCheckedIn ? 'bg-amber-500 text-white' : 'bg-[#34A853] text-white'
              }`}>
                {checkInResult.alreadyCheckedIn ? <Clock size={32} /> : <Check size={32} />}
              </div>
              <div>
                <span className="text-[9px] font-black uppercase tracking-widest block opacity-80">
                  {checkInResult.alreadyCheckedIn ? 'ALREADY RECORDED' : 'ATTENDANCE MARKED'}
                </span>
                <h3 className="text-lg font-black uppercase tracking-wider mt-0.5">
                  {checkInResult.alreadyCheckedIn ? 'Already Checked In Today' : 'Attendance Marked'}
                </h3>
                <p className="text-xs text-[var(--text-sec)] font-medium mt-1">
                  Member: <strong className="text-[var(--text)]">{selectedMember?.fullName || checkInResult.memberName}</strong>
                </p>
                <div className="mt-3 inline-flex items-center gap-3 px-4 py-2 rounded-xl bg-[var(--surface)] border border-[var(--border)] text-xs font-mono font-bold text-[var(--text)]">
                  <span>Date: {checkInResult.date || todayKolkata}</span>
                  <span>•</span>
                  <span>Time: {checkInResult.checkInTime || nowKolkata}</span>
                </div>
              </div>

              <div className="pt-2 flex justify-center gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setCheckInResult(null);
                    setSelectedMember(null);
                    setError(null);
                  }}
                  className="px-5 h-11 rounded-[14px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-wider cursor-pointer active:scale-95 transition-transform"
                >
                  Check In Another Member
                </button>
                <button
                  type="button"
                  onClick={onClose}
                  className="px-5 h-11 rounded-[14px] neo-raised text-xs font-bold uppercase tracking-wider cursor-pointer"
                >
                  Done
                </button>
              </div>
            </div>
          ) : selectedMember ? (
            /* Member Selected Confirmation Sheet */
            <div className="space-y-4">
              <div className="neo-pressed p-5 rounded-[22px] space-y-3">
                <div className="flex items-center justify-between border-b border-[var(--border)] pb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-[16px] bg-[var(--surface)] neo-raised flex items-center justify-center font-black text-lg text-[var(--text)] border border-[var(--border)] overflow-hidden">
                      {selectedMember.profileImage ? (
                        <img src={selectedMember.profileImage} alt={selectedMember.fullName} className="w-full h-full object-cover" />
                      ) : (
                        selectedMember.fullName?.charAt(0) || 'M'
                      )}
                    </div>
                    <div>
                      <h3 className="text-sm font-black uppercase tracking-wider text-[var(--text)]">{selectedMember.fullName}</h3>
                      <p className="text-[10px] text-[var(--text-sec)] font-mono uppercase">
                        ID: {selectedMember.memberDisplayId || selectedMember.id} • {selectedMember.phone}
                      </p>
                    </div>
                  </div>
                  <span className={`text-[9px] font-black uppercase px-2.5 py-1 rounded-full border ${
                    selectedMember.status === 'ACTIVE' 
                      ? 'bg-[#34A853]/10 text-[#34A853] border-[#34A853]/30'
                      : 'bg-amber-500/10 text-amber-500 border-amber-500/30'
                  }`}>
                    {selectedMember.status || 'ACTIVE'}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="p-3 bg-[var(--surface)] rounded-[14px] border border-[var(--border)]">
                    <span className="text-[8px] font-bold uppercase text-[var(--text-sec)] block">Current Plan</span>
                    <span className="font-black text-[var(--text)] mt-0.5 block truncate">{selectedMember.planName || 'Standard Membership'}</span>
                  </div>
                  <div className="p-3 bg-[var(--surface)] rounded-[14px] border border-[var(--border)]">
                    <span className="text-[8px] font-bold uppercase text-[var(--text-sec)] block">Valid Until</span>
                    <span className="font-mono font-bold text-[#34A853] mt-0.5 block truncate">{selectedMember.endDate || 'Active'}</span>
                  </div>
                </div>

                <div className="p-3 bg-[var(--surface)] rounded-[14px] border border-[var(--border)] space-y-1.5 font-mono text-xs">
                  <div className="flex justify-between items-center text-[var(--text-sec)]">
                    <span className="uppercase text-[9px]">Check-In Method:</span>
                    <span className="font-bold text-[var(--text)]">MANUAL (RECEPTION)</span>
                  </div>
                  <div className="flex justify-between items-center text-[var(--text-sec)]">
                    <span className="uppercase text-[9px]">Check-In Date:</span>
                    <span className="font-bold text-[var(--text)]">{todayKolkata}</span>
                  </div>
                  <div className="flex justify-between items-center text-[var(--text-sec)]">
                    <span className="uppercase text-[9px]">Current Time:</span>
                    <span className="font-bold text-[#34A853]">{nowKolkata}</span>
                  </div>
                </div>
              </div>

              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => setSelectedMember(null)}
                  className="flex-1 h-12 rounded-[16px] neo-raised text-xs font-bold uppercase tracking-wider text-[var(--text-sec)] hover:text-[var(--text)] cursor-pointer"
                >
                  Back to Search
                </button>
                <button
                  type="button"
                  disabled={loading}
                  onClick={() => executeCheckIn(selectedMember)}
                  className="flex-1 h-12 rounded-[16px] bg-[var(--btn-bg)] text-[var(--btn-text)] text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 active:scale-95 transition-transform cursor-pointer disabled:opacity-50"
                >
                  <UserCheck size={18} /> Confirm Check-In
                </button>
              </div>
            </div>
          ) : (
            /* Search Member List */
            <div className="space-y-4">
              <div className="relative">
                <Search size={18} className="absolute left-3.5 top-3 text-[var(--text-sec)]" />
                <input
                  type="text"
                  placeholder="Search member by Name, Member ID, or Phone..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full h-11 pl-10 pr-3 rounded-[16px] bg-[var(--surface-sec)] border border-[var(--border)] text-xs font-medium focus:outline-none focus:border-[var(--text)]"
                />
              </div>

              {fetchingMembers ? (
                <div className="p-8 text-center text-xs text-[var(--text-sec)] font-mono">Loading gym members...</div>
              ) : (
                <div className="max-h-72 overflow-y-auto space-y-2 border border-[var(--border)] rounded-[20px] p-2 bg-[var(--bg)]">
                  {filteredMembers.length === 0 ? (
                    <div className="p-6 text-center text-xs text-[var(--text-sec)]">No matching gym members found</div>
                  ) : (
                    filteredMembers.map(m => (
                      <div
                        key={m.id}
                        onClick={() => setSelectedMember(m)}
                        className="p-3.5 rounded-[16px] bg-[var(--surface)] border border-[var(--border)] flex items-center justify-between hover:border-[var(--text)] transition-all cursor-pointer group"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-xl bg-[var(--surface-sec)] neo-pressed flex items-center justify-center font-black text-xs text-[var(--text)] border border-[var(--border)] overflow-hidden shrink-0">
                            {m.profileImage ? (
                              <img src={m.profileImage} alt={m.fullName} className="w-full h-full object-cover" />
                            ) : (
                              m.fullName?.charAt(0) || 'M'
                            )}
                          </div>
                          <div>
                            <h4 className="text-xs font-black uppercase text-[var(--text)] group-hover:text-[#34A853] transition-colors">{m.fullName}</h4>
                            <p className="text-[10px] text-[var(--text-sec)] font-mono uppercase">
                              ID: {m.memberDisplayId || m.id} • {m.phone || 'No phone'}
                            </p>
                          </div>
                        </div>

                        <span className="px-3 h-8 rounded-xl bg-[var(--btn-bg)] text-[var(--btn-text)] text-[10px] font-black uppercase tracking-wider flex items-center gap-1 group-hover:scale-105 transition-transform">
                          Select
                        </span>
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

