import React, { useState, useEffect, useRef } from 'react';
import { X, Printer, Download, Share2, FileText, Check, ShieldCheck, IndianRupee } from 'lucide-react';

interface GenerateInvoiceModalProps {
  gymId: string;
  memberId: string;
  paymentId?: string;
  isOpen: boolean;
  onClose: () => void;
}

export default function GenerateInvoiceModal({
  gymId,
  memberId,
  paymentId,
  isOpen,
  onClose
}: GenerateInvoiceModalProps) {
  const [invoice, setInvoice] = useState<any | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const printRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!isOpen || !memberId) return;
    setLoading(true);
    setError(null);

    fetch('/api/invoices/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ gymId, memberId, paymentId })
    })
      .then(res => res.json())
      .then(data => {
        if (data.success && data.invoice) {
          setInvoice(data.invoice);
        } else {
          setError(data.message || 'Failed to generate invoice.');
        }
      })
      .catch(err => {
        console.error(err);
        setError('Error generating invoice.');
      })
      .finally(() => setLoading(false));
  }, [isOpen, gymId, memberId, paymentId]);

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadText = () => {
    if (!invoice) return;
    const content = `
==================================================
TAX INVOICE / PAYMENT RECEIPT
${invoice.gymName}
Phone: ${invoice.gymPhone} | Location: ${invoice.gymLocation}
Owner: ${invoice.ownerName}
==================================================
Invoice No: ${invoice.invoiceNumber}
Date: ${invoice.invoiceDate}
Status: ${invoice.status}

MEMBER DETAILS:
Name: ${invoice.memberName}
Member ID: ${invoice.memberDisplayId}
Phone: ${invoice.memberPhone}

PLAN DETAILS:
Plan Name: ${invoice.planName}
Duration: ${invoice.startDate} to ${invoice.endDate || 'N/A'}

FINANCIAL BREAKDOWN:
Plan Price: ₹${invoice.planAmount}
Amount Paid: ₹${invoice.amountPaid}
Previous Paid: ₹${invoice.previousPaid}
Remaining Due: ₹${invoice.remainingDue}
Payment Mode: ${invoice.paymentMode}
Reference: ${invoice.reference || 'N/A'}

Thank you for training at ${invoice.gymName}!
==================================================
    `.trim();

    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${invoice.invoiceNumber}_${invoice.memberName.replace(/\s+/g, '_')}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleShare = () => {
    if (!invoice) return;
    const shareText = `Invoice ${invoice.invoiceNumber} for ${invoice.memberName} - Amount: ₹${invoice.amountPaid} at ${invoice.gymName}`;
    if (navigator.share) {
      navigator.share({
        title: `Invoice ${invoice.invoiceNumber}`,
        text: shareText,
        url: window.location.href
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(shareText);
      alert('Invoice details copied to clipboard!');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs animate-fade-in print:p-0 print:bg-white">
      <div className="bg-[var(--surface)] text-[var(--text)] w-full max-w-xl rounded-[24px] border border-[var(--border)] shadow-2xl overflow-hidden max-h-[95vh] flex flex-col print:border-none print:shadow-none print:max-h-none print:w-full">
        {/* Modal Top Bar (hidden on print) */}
        <div className="px-6 py-4 border-b border-[var(--border)] flex items-center justify-between print:hidden">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-[var(--text)] text-[var(--bg)] flex items-center justify-center font-black">
              <FileText size={18} />
            </div>
            <div>
              <h2 className="text-base font-black uppercase tracking-wider">Official Invoice / Receipt</h2>
              <p className="text-[10px] text-[var(--text-sec)] uppercase tracking-wider">{invoice?.invoiceNumber || 'Generating...'}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl neo-pressed text-[var(--text-sec)] hover:text-[var(--text)] cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Invoice Paper View */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 bg-[var(--bg)] print:p-8 print:bg-white" ref={printRef}>
          {loading ? (
            <div className="p-12 text-center text-xs font-bold text-[var(--text-sec)] uppercase tracking-widest">
              Generating Tax Invoice...
            </div>
          ) : error ? (
            <div className="p-6 text-center text-xs text-red-500 font-bold">{error}</div>
          ) : invoice ? (
            <div className="bg-[var(--surface)] p-6 rounded-[20px] border border-[var(--border)] shadow-sm space-y-6 print:border-none print:p-0">
              {/* Header */}
              <div className="flex justify-between items-start border-b border-[var(--border)] pb-4">
                <div>
                  <h1 className="text-xl font-black uppercase tracking-wider text-[var(--text)]">{invoice.gymName}</h1>
                  <p className="text-[11px] text-[var(--text-sec)]">{invoice.gymLocation}</p>
                  <p className="text-[11px] text-[var(--text-sec)]">Phone: {invoice.gymPhone}</p>
                  <p className="text-[10px] font-bold text-[var(--text-sec)] uppercase mt-1">Proprietor: {invoice.ownerName}</p>
                </div>
                <div className="text-right">
                  <span className={`inline-block px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${
                    invoice.status === 'PAID' ? 'bg-emerald-500/10 text-emerald-600 border border-emerald-500/30' : 'bg-amber-500/10 text-amber-600 border border-amber-500/30'
                  }`}>
                    {invoice.status}
                  </span>
                  <p className="text-xs font-black uppercase tracking-wider mt-2">{invoice.invoiceNumber}</p>
                  <p className="text-[10px] text-[var(--text-sec)] uppercase">Date: {invoice.invoiceDate}</p>
                </div>
              </div>

              {/* Member Info */}
              <div className="grid grid-cols-2 gap-4 bg-[var(--surface-sec)] p-4 rounded-xl text-xs">
                <div>
                  <span className="text-[9px] font-black uppercase text-[var(--text-sec)] block">BILLED TO MEMBER</span>
                  <p className="font-black text-[var(--text)] text-sm uppercase mt-0.5">{invoice.memberName}</p>
                  <p className="text-[10px] text-[var(--text-sec)] font-bold">{invoice.memberDisplayId} • {invoice.memberPhone}</p>
                </div>
                <div>
                  <span className="text-[9px] font-black uppercase text-[var(--text-sec)] block">MEMBERSHIP DETAILS</span>
                  <p className="font-black text-[var(--text)] uppercase mt-0.5">{invoice.planName}</p>
                  <p className="text-[10px] text-[var(--text-sec)]">{invoice.startDate} to {invoice.endDate || 'Ongoing'}</p>
                </div>
              </div>

              {/* Breakdown Table */}
              <div className="space-y-2">
                <span className="text-[10px] font-black uppercase tracking-widest text-[var(--text-sec)] block">FINANCIAL SUMMARY</span>
                <div className="border border-[var(--border)] rounded-xl overflow-hidden text-xs">
                  <div className="bg-[var(--surface-sec)] px-4 py-2 font-black uppercase tracking-wider grid grid-cols-2">
                    <span>Description</span>
                    <span className="text-right">Amount</span>
                  </div>
                  <div className="p-4 space-y-2 divide-y divide-[var(--border)]">
                    <div className="flex justify-between py-1">
                      <span>Plan Total Price</span>
                      <span className="font-bold">₹{invoice.planAmount}</span>
                    </div>
                    {invoice.previousPaid > 0 && (
                      <div className="flex justify-between py-1 text-[var(--text-sec)]">
                        <span>Previously Paid</span>
                        <span>- ₹{invoice.previousPaid}</span>
                      </div>
                    )}
                    <div className="flex justify-between py-1 font-black text-emerald-600 dark:text-emerald-400">
                      <span>Current Amount Paid ({invoice.paymentMode})</span>
                      <span>₹{invoice.amountPaid}</span>
                    </div>
                    {invoice.reference && (
                      <div className="flex justify-between py-1 text-[10px] text-[var(--text-sec)]">
                        <span>Reference No.</span>
                        <span>{invoice.reference}</span>
                      </div>
                    )}
                    <div className="flex justify-between py-2 text-sm font-black text-[var(--text)] border-t-2 border-[var(--border)] pt-2">
                      <span>Remaining Balance Due</span>
                      <span className={invoice.remainingDue > 0 ? 'text-red-500' : 'text-emerald-600'}>
                        ₹{invoice.remainingDue}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Footer */}
              <div className="text-center border-t border-[var(--border)] pt-4 space-y-1">
                <p className="text-[10px] font-bold uppercase text-[var(--text-sec)]">System Generated Receipt • Computerized Record</p>
                <p className="text-[9px] text-[var(--text-sec)]">Thank you for being a valued member of {invoice.gymName}!</p>
              </div>
            </div>
          ) : null}
        </div>

        {/* Action Controls (hidden on print) */}
        {invoice && (
          <div className="px-6 py-4 border-t border-[var(--border)] bg-[var(--surface)] flex flex-wrap justify-between gap-2 print:hidden">
            <button
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl neo-raised text-xs font-bold uppercase cursor-pointer"
            >
              Close
            </button>

            <div className="flex items-center gap-2">
              <button
                onClick={handleShare}
                className="px-3 py-2.5 rounded-xl neo-raised text-xs font-bold uppercase flex items-center gap-1.5 cursor-pointer"
              >
                <Share2 size={16} /> Share
              </button>
              <button
                onClick={handleDownloadText}
                className="px-3 py-2.5 rounded-xl neo-raised text-xs font-bold uppercase flex items-center gap-1.5 cursor-pointer"
              >
                <Download size={16} /> Download
              </button>
              <button
                onClick={handlePrint}
                className="px-4 py-2.5 rounded-xl bg-[var(--text)] text-[var(--bg)] text-xs font-black uppercase tracking-wider flex items-center gap-1.5 shadow-md cursor-pointer hover:scale-105 transition-transform"
              >
                <Printer size={16} /> Print Receipt
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
