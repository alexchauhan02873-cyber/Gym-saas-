/* Service Worker for GYM SaaS PWA */

const CACHE_NAME = 'gym-saas-v3';
const ASSETS_TO_CACHE = [
  '/',
  '/manifest.json',
  '/index.html',
  '/pwa-icon.svg'
];

self.addEventListener('install', (event) => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(ASSETS_TO_CACHE).catch(() => {});
    })
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    clients.claim().then(() => {
      return caches.keys().then((keys) => {
        return Promise.all(
          keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k))
        );
      });
    })
  );
});

/* Fetch Event Interception: Exclude Sensitive API Responses from CacheStorage */
self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);

  // STRICT RULE: Never cache any /api/* request (sensitive payments, members, auth tokens, attendance)
  if (url.pathname.startsWith('/api/') || event.request.method !== 'GET') {
    event.respondWith(
      fetch(event.request).catch((err) => {
        return new Response(
          JSON.stringify({ success: false, message: 'Offline: Network request failed' }),
          { status: 503, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store, no-cache, must-revalidate, private' } }
        );
      })
    );
    return;
  }

  // Cache-First strategy for static assets only
  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      if (cachedResponse) {
        return cachedResponse;
      }
      return fetch(event.request);
    })
  );
});

/* Handle Web Push Notifications */
self.addEventListener('push', (event) => {
  let data = {
    title: 'Gym SaaS Update',
    body: 'You have a new update from your gym.',
    data: { url: '/member/dashboard' }
  };

  if (event.data) {
    try {
      data = event.data.json();
    } catch (e) {
      data.body = event.data.text();
    }
  }

  const options = {
    body: data.body || 'Gym update',
    icon: data.icon || '/pwa-icon.svg',
    badge: data.badge || '/pwa-icon.svg',
    tag: data.tag || 'gym-notification',
    renotify: true,
    data: data.data || { url: data.url || '/member/dashboard' },
    actions: data.actions || []
  };

  event.waitUntil(
    self.registration.showNotification(data.title || 'Gym SaaS', options)
  );
});

/* Handle Notification Click & Action Buttons */
self.addEventListener('notificationclick', (event) => {
  event.notification.close();

  const action = event.action; // Action selected from notification button
  const notificationData = event.notification.data || {};
  let targetUrl = notificationData.url || '/member/dashboard';

  if (action) {
    if (action.startsWith('feeling_') || ['GREAT', 'GOOD', 'OKAY', 'LOW', 'NOT_GREAT'].includes(action)) {
      const feelingVal = action.replace('feeling_', '');
      targetUrl = `/member/wellbeing-checkin?feeling=${encodeURIComponent(feelingVal)}`;
    }
  }

  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((windowClients) => {
      for (const client of windowClients) {
        if (client.url.includes(self.location.origin) && 'focus' in client) {
          client.navigate(targetUrl);
          return client.focus();
        }
      }
      if (clients.openWindow) {
        return clients.openWindow(targetUrl);
      }
    })
  );
});
