import fs from 'fs';
import path from 'path';

// Helper to generate a minimal valid PNG with solid background and dumbbell icon
function createSimplePng(width, height, bgColor = [18, 18, 18, 255]) {
  // We can write an uncompressed PNG or raw SVG rendered to canvas using simple buffer construction or SVG fallback
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">
    <rect width="${width}" height="${height}" rx="${Math.floor(width * 0.2)}" fill="#121212"/>
    <circle cx="${width/2}" cy="${height/2}" r="${width * 0.35}" fill="#222222" stroke="#34A853" stroke-width="${width * 0.03}"/>
    <path d="M${width*0.35} ${height*0.5} h${width*0.3} M${width*0.32} ${height*0.4} v${height*0.2} M${width*0.68} ${height*0.4} v${height*0.2}" stroke="#ffffff" stroke-width="${width * 0.06}" stroke-linecap="round"/>
  </svg>`;
  return svg;
}

// Generate SVG icons first
const publicDir = path.join(process.cwd(), 'public');
fs.writeFileSync(path.join(publicDir, 'pwa-icon.svg'), createSimplePng(512, 512));

console.log('PWA SVG Icon generated.');
