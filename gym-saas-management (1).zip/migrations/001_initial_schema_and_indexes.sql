-- PostgreSQL Database Schema & Production Index Migrations
-- Gym Management SaaS (Target: 2,000+ Active Gyms, 300,000+ Members)

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. GYMS TABLE
CREATE TABLE IF NOT EXISTS gyms (
    id VARCHAR(64) PRIMARY KEY DEFAULT uuid_generate_v4()::text,
    gym_code VARCHAR(32) UNIQUE NOT NULL,
    gym_name VARCHAR(255) NOT NULL,
    owner_id VARCHAR(64),
    status VARCHAR(32) NOT NULL DEFAULT 'ACTIVE',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Gym Indexes
CREATE INDEX IF NOT EXISTS idx_gyms_gym_code ON gyms(gym_code);
CREATE INDEX IF NOT EXISTS idx_gyms_status ON gyms(status);

-- 2. MEMBERS TABLE
CREATE TABLE IF NOT EXISTS members (
    id VARCHAR(64) PRIMARY KEY DEFAULT uuid_generate_v4()::text,
    gym_id VARCHAR(64) NOT NULL REFERENCES gyms(id) ON DELETE CASCADE,
    member_display_id VARCHAR(64) NOT NULL,
    member_access_code VARCHAR(6) NOT NULL,
    full_name VARCHAR(255) NOT NULL,
    phone VARCHAR(32) NOT NULL,
    email VARCHAR(255),
    status VARCHAR(32) NOT NULL DEFAULT 'ACTIVE',
    plan_id VARCHAR(64),
    start_date DATE,
    end_date DATE,
    preferred_training_time VARCHAR(16),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT unique_gym_access_code UNIQUE (gym_id, member_access_code)
);

-- High-Frequency Composite & Single Column Lookup Indexes for Members
CREATE INDEX IF NOT EXISTS idx_members_gym_id ON members(gym_id);
CREATE INDEX IF NOT EXISTS idx_members_gym_status ON members(gym_id, status);
CREATE INDEX IF NOT EXISTS idx_members_gym_access_code ON members(gym_id, member_access_code);
CREATE INDEX IF NOT EXISTS idx_members_gym_display_id ON members(gym_id, member_display_id);
CREATE INDEX IF NOT EXISTS idx_members_gym_phone ON members(gym_id, phone);
CREATE INDEX IF NOT EXISTS idx_members_gym_end_date ON members(gym_id, end_date);
CREATE INDEX IF NOT EXISTS idx_members_search_name ON members(gym_id, lower(full_name));

-- 3. PAYMENTS TABLE
CREATE TABLE IF NOT EXISTS payments (
    id VARCHAR(64) PRIMARY KEY DEFAULT uuid_generate_v4()::text,
    gym_id VARCHAR(64) NOT NULL REFERENCES gyms(id) ON DELETE CASCADE,
    member_id VARCHAR(64) NOT NULL REFERENCES members(id) ON DELETE CASCADE,
    amount NUMERIC(12, 2) NOT NULL,
    payment_mode VARCHAR(32) NOT NULL,
    status VARCHAR(32) NOT NULL DEFAULT 'PAID',
    idempotency_key VARCHAR(128) UNIQUE,
    transaction_date DATE NOT NULL DEFAULT CURRENT_DATE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- High-Frequency Lookup Indexes for Payments
CREATE INDEX IF NOT EXISTS idx_payments_gym_id ON payments(gym_id);
CREATE INDEX IF NOT EXISTS idx_payments_member_id ON payments(member_id);
CREATE INDEX IF NOT EXISTS idx_payments_gym_date ON payments(gym_id, transaction_date);
CREATE INDEX IF NOT EXISTS idx_payments_gym_status_date ON payments(gym_id, status, transaction_date);
CREATE INDEX IF NOT EXISTS idx_payments_idempotency ON payments(idempotency_key) WHERE idempotency_key IS NOT NULL;

-- 4. ATTENDANCE TABLE
CREATE TABLE IF NOT EXISTS attendance (
    id VARCHAR(64) PRIMARY KEY DEFAULT uuid_generate_v4()::text,
    gym_id VARCHAR(64) NOT NULL REFERENCES gyms(id) ON DELETE CASCADE,
    member_id VARCHAR(64) NOT NULL REFERENCES members(id) ON DELETE CASCADE,
    attendance_date DATE NOT NULL DEFAULT CURRENT_DATE,
    check_in_time TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(32) NOT NULL DEFAULT 'PRESENT',
    source VARCHAR(32) NOT NULL DEFAULT 'QR_CODE',
    CONSTRAINT unique_daily_member_attendance UNIQUE (gym_id, member_id, attendance_date)
);

-- High-Frequency Lookup Indexes for Attendance
CREATE INDEX IF NOT EXISTS idx_attendance_gym_date ON attendance(gym_id, attendance_date);
CREATE INDEX IF NOT EXISTS idx_attendance_member_date ON attendance(member_id, attendance_date);
CREATE INDEX IF NOT EXISTS idx_attendance_gym_member_date ON attendance(gym_id, member_id, attendance_date);

-- 5. NOTIFICATIONS TABLE
CREATE TABLE IF NOT EXISTS notifications (
    id VARCHAR(64) PRIMARY KEY DEFAULT uuid_generate_v4()::text,
    gym_id VARCHAR(64) NOT NULL REFERENCES gyms(id) ON DELETE CASCADE,
    target_role VARCHAR(32) NOT NULL,
    target_id VARCHAR(64) NOT NULL,
    title VARCHAR(255) NOT NULL,
    body TEXT NOT NULL,
    type VARCHAR(64) NOT NULL,
    is_read BOOLEAN NOT NULL DEFAULT FALSE,
    scheduled_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_notifications_target ON notifications(target_role, target_id, is_read);
CREATE INDEX IF NOT EXISTS idx_notifications_gym_scheduled ON notifications(gym_id, scheduled_at);

-- 6. TASKS TABLE
CREATE TABLE IF NOT EXISTS tasks (
    id VARCHAR(64) PRIMARY KEY DEFAULT uuid_generate_v4()::text,
    gym_id VARCHAR(64) NOT NULL REFERENCES gyms(id) ON DELETE CASCADE,
    task_date DATE NOT NULL DEFAULT CURRENT_DATE,
    title VARCHAR(255) NOT NULL,
    completed BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_tasks_gym_date ON tasks(gym_id, task_date, completed);

-- 7. AUDIT LOGS TABLE
CREATE TABLE IF NOT EXISTS audit_logs (
    id VARCHAR(64) PRIMARY KEY DEFAULT uuid_generate_v4()::text,
    gym_id VARCHAR(64) NOT NULL,
    actor_id VARCHAR(64) NOT NULL,
    action VARCHAR(128) NOT NULL,
    target_id VARCHAR(64),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_audit_logs_gym_date ON audit_logs(gym_id, created_at DESC);
